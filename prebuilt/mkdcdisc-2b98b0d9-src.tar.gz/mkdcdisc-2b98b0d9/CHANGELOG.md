# mkdcdisc Changelog

| Date                   | Author(s)                   | Changes                   |
|:-----------------------|:----------------------------|:--------------------------|
| **2026-08-18** | Mickaël Cardoso | **Feature:** Adds `--duplicates-once` to store byte-identical files only once. |
| **2026-08-17** | Mickaël Cardoso | **Feature:** Adds pre-write boot validation (header, license, boot file, MSINFO). `--disable-bootstrap-checks` downgrades it to warnings.<br>**Fix:** Refuses to overwrite existing files by default (exit code 4). Adds `--allow-overwrite`. Uppercases the `--boot-filename` IP.BIN field to match the ISO9660 tree. |
| **2026-08-16** | Mickaël Cardoso | **Docs:** Clarifies `--help` output, including usage (emulator vs. console) and default values. |
| **2026-08-15** | Mickaël Cardoso | **Feature:** Strictly rejects audio track counts exceeding limits (95 for GDI, 98 for MIL-CD). Warns when a `--gdi-truncate` image may not boot.<br>**Internal:** Stops duplicating the main executable on the disc. |
| **2026-08-14** | Mickaël Cardoso | **CLI:** Renames `-n/--name` to `-n/--title`, and `-b/-B` to `--main-binary-unscrambled/-scrambled`. Old names still accepted.<br>**Breaking:** Replaces `-L/--data-data-layout` and `-K/--merged-data-layout` with `-L/--disc-layout` (`audio-data`, `data-data`, `merged-data`). The old spellings are removed. |
| **2026-08-11** | Mickaël Cardoso | **Fix:** Floors GD-DA data tracks at the Red Book minimum.<br>**Testing:** New end-to-end test pipeline using real Dreamcast executables. |
| **2026-08-10** | Mickaël Cardoso | **Testing:** Pins the table of contents (`disc-manifest.txt`) to prevent regressions.<br>**Build:** Updates `libisofs` (v1.5.8 for MSYS2). |
| **2026-08-09** | Mickaël Cardoso | **Build:** Updates the bundled `libisofs` version (v1.5.9). |
| **2026-08-08** | Mickaël Cardoso | **CLI:** Structures `--help` output into thematic groups.<br>**Feature:** Adds options to disable low-density text files (`COPYRIGH.TXT`, etc.). |
| **2026-08-07** | Mickaël Cardoso | **Feature:** Adds `--gdi-fpu-rounding` (SH-4 rounding) and updates IP.BIN templates.<br>**CLI:** Displays a detailed build plan summary with `-v 3`. |
| **2026-08-04** | Mickaël Cardoso | **CLI:** Redefines verbosity levels (`-v 0` to `3`) and adds ANSI color diagnostics.<br>**Fix:** Reports invalid entries in sort files.<br>**Build:** Fixes `libpng` dependency for MinGW-w64. |
| **2026-08-03** | Mickaël Cardoso | **CLI:** Adds a percentage progress indicator for long steps. |
| **2026-08-02** | Mickaël Cardoso | **Internal:** Splits code into modules. Standardizes options.<br>**Feature:** Supports PNG logos for the license screen and adds IP.BIN options. |
| **2026-07-31** | Mickaël Cardoso | **Feature:** Adds full support for GD-ROM (`.gdi`) output with GD-DA audio tracks. |
| **2026-07-18** | Mickaël Cardoso | **CLI:** Improves help output and adds a startup banner. |
| **2026-07-13** | Mickaël Cardoso | **Fix:** Strengthens temporary directory cleanup and CLI argument validation. Fixes `libisofs` wrongly merging different same-size files on Windows, and `--dump-iso` writing an unusable `.iso` for non-zero MSINFO layouts. |
| **2026-07-12** | Mickaël Cardoso | **Feature:** Adds `.nrg` (Nero) output format and `-V/--volume-label`. Populates the ISO9660 PVD identifiers from IP.BIN.<br>**Fix:** ISO9660/Joliet long names and hardlink detection. |
| **2026-07-10** | Mickaël Cardoso | **Build:** Adds CI pipeline and compilation guide.<br>**Feature:** New `-K/--merged-data-layout` layout. |
| **2026-07-07** | Mickaël Cardoso | **Feature:** MDS/MDF and Data/Data support for external ISO tracks, enforced session limits. |
| **2026-07-06** | Mickaël Cardoso | **Feature:** External ISO track support (`-t/--external-iso-track`) and Data/Data layout (`-L`). |
| **2026-07-05** | Mickaël Cardoso | **Feature:** Adds MDS/MDF (Alcohol 120%) output support. |
| **2025-10-24** | jnmartin84 | **Fix:** Workaround for a crash linked to `.bss` LOAD segments. |
| **2025-10-23** | aleios | **Internal:** Removes the null padding file if estimated at 0. |
| **2025-09-07** | Mickaël Cardoso | **Build:** MinGW-w64 support for Windows, vendoring `libisofs`. |
| **2025-06-18** | T_chan | **Docs:** README updates. |
| **2025-04-11** | Azi Hassan | **Build:** Windows compilation under MSYS and Linux build restoration. |
| **2025-04-06** | T_chan | **Feature:** Support for raw binary executables as input. |
| **2025-02-15** | T_chan | **Feature:** Custom `IP.BIN` selection. |
| **2024-12-31** | Andress Antonio Barajas | **Docs:** README updates for sort files. |
| **2024-11-24** | Andress Antonio Barajas | **Feature:** Sort files support. |
| **2024-11-20** | Andress Antonio Barajas | **Feature:** Adds `-i` flag for a custom MR image. |
| **2024-11-16** | Andress Antonio Barajas | **Fix:** Compilation warnings. |
| **2024-09-29** | Ross Kilgariff | **Feature:** Error if an audio track is under 4 seconds. |
| **2024-09-19** | Ross Kilgariff | **Fix:** Unaligned data chunks in WAV file processing. |
| **2024-03-17** | Quentin Cartier | **Build:** Automatic temporary directory cleanup. |
| **2024-03-17** | Colton Pawielski | **Fix:** ELF parser reorganization and memory fixes. |
| **2024-02-05** | Colton Pawielski | **Feature:** Option to specify a serial number. |
| **2023-07-30** | Luke Benstead | **Fix:** NUL install padding uses spaces. |
| **2023-04-13** | Colton Pawielski | **Fix:** Excludes invalid sections in ELF. |
| **2023-04-09** | Luke Benstead | **Fix:** Potential crash resolution. |
| **2023-04-02** | Colton Pawielski | **Build:** GitLab CI added and README updated. |
| **2023-03-29** | Luke Benstead | **Fix:** Filename issue resolved. |
| **2023-03-11** | Colton Pawielski | **Fix:** Checks `SHF_ALLOC` sections. |
| **2022-12-18** | Colton Pawielski | **Build:** Removes `scramble` and `objcopy` dependencies. |
| **2022-11-27** | Colton Pawielski | **Feature:** Automatic `objcopy` search in KOS. |
| **2022-09-11** | Luke Benstead | **Internal:** Reduced padding size for better booting. |
| **2022-06-04** | Luke Benstead | **Feature:** Basic padding implementation. |
| **2022-06-03** | Luke Benstead | **Feature:** Automatic product number generation (`IND-` prefix). |
| **2022-06-02** | Luke Benstead | **Feature:** Renamed to `mkdcdisc`. CDDA, recursion, and IP.BIN support. |
| **2022-06-01** | Luke Benstead | **Feature:** First working CDI output. |
| **2022-05-24** | Luke Benstead | **Feature:** Uses `libisofs` for data tracks. |
| **2022-05-22** | Luke Benstead | **Feature:** Initial commit (`1ST_READ.BIN` and `IP.BIN`). |
