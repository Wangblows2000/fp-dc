# CD Images (CDI / MDS+MDF / NRG)

Padus DiscJuggler (`.cdi`), Alcohol 120% (`.mds`/`.mdf`), and Nero Burning ROM
(`.nrg`) all share the same logical CD-based structure: a layout
selection (Audio/Data, Data/Data, or Merged Data/Data) built through one of two
operational modes (Standard Mode or External ISO Mode). GD-ROM (`.gdi`) is an
entirely different media format: it always builds its own filesystem with a fixed
physical zone layout, and is covered separately in [docs/topics/gd-image.md](gd-image.md).

```bash
# Padus DiscJuggler (inferred from output extension)
mkdcdisc -e game.elf -o game.cdi

# Padus DiscJuggler (selected explicitly)
mkdcdisc -e game.elf -o game.cdi --format cdi

# Alcohol 120% (inferred from output extension)
mkdcdisc -e game.elf -o game.mds

# Alcohol 120% (selected explicitly)
mkdcdisc -e game.elf -o game.mds --format mds

# Nero Burning ROM (inferred from output extension)
mkdcdisc -e game.elf -o game.nrg

# Nero Burning ROM (selected explicitly)
mkdcdisc -e game.elf -o game.nrg --format nrg
```

See [docs/topics/examples.md](examples.md) for complete recipes organized by build target.

## Disc Layouts

mkdcdisc supports 3 MIL-CD disc layouts, each with distinct compatibility characteristics.
Select between them using `-L/--disc-layout`: `audio-data` (default), `data-data`,
or `merged-data`. This option applies exclusively to MIL-CD targets; `-F gdi` rejects it
because GD-ROM discs have a fixed physical structure.

### Audio/Data Layout (`-L audio-data`, default MIL-CD format)

The classic layout used by official Dreamcast mastering tools, implementing the
[MIL-CD (Music Interactive Live-CD)](https://segaretro.org/Mil-CD) format. MIL-CD is a
digital multi-session format originally created by Sega to combine standard audio tracks
with interactive content. Session 1 contains CDDA audio tracks (from `.wav` or raw audio
files supplied via `-c`, or a 4-second silent placeholder track if none are specified),
and Session 2 contains the data track (ISO9660 filesystem).

This layout offers the broadest feature set (allowing CDDA background music or soundtrack
playback). The vast majority of Dreamcast hardware boots it out of the box, with the exception
of late-production revisions manufactured after Sega disabled MIL-CD support. See
[Which consoles boot MIL-CD](#which-consoles-boot-mil-cd) below for details.

Supply audio tracks with `-c/--cdda-track` (e.g. `-c intro.wav -c music.wav`), up to 98 tracks:
Red Book CD specifications permit a maximum of 99 tracks per disc, and Session 2's data
track consumes one. mkdcdisc enforces this limit and rejects invocations exceeding 98 audio tracks.

### Data/Data Layout (`-L data-data`)

An alternative multi-session layout where both sessions are data tracks. Session 1 holds
the primary ISO filesystem (authored at MSINFO 0), and Session 2 contains a "boot head"
replicating the first 18 sectors of the ISO (the `IP.BIN` system area and ISO9660 volume
descriptors, padded to meet the 300-sector multi-session minimum). This layout does not
support CDDA audio tracks: specifying both `-L data-data` and `-c` results in an error.

This is still recognized by the Dreamcast as a MIL-CD disc, relying on the same BIOS
multi-session boot path with the first audio session replaced by data. This difference is
critical: it boots successfully on certain later console revisions where Audio/Data discs
fail (see [Which consoles boot MIL-CD](#which-consoles-boot-mil-cd)). Sega's late BIOS
tightening specifically restricted the audio session boot check, while leaving the data
session boot path intact.

Use Data/Data layout with `-L data-data`. Compatible with both Standard Mode and External
ISO Mode (`-t`).

### Merged Data/Data Layout (`-L merged-data`)

Another Data/Data variant where the second session contains a genuine, independently authored
ISO rather than a duplicated boot head. It represents a full multi-session merge
(via `mkisofs -M`) of Session 1's directory hierarchy with new or updated files, accompanied
by its own `IP.BIN`. Unlike `data-data`, Session 1 requires no `IP.BIN` because the console
only boots from Session 2.

This layout is available exclusively in External ISO Mode by passing `-t` twice: mkdcdisc
does not generate either filesystem itself, but packages two pre-built ISO images produced
by `mkisofs` into the final disc image. Incompatible with `-c/--cdda-track`.

### Choosing a Layout

If CDDA soundtrack playback is required for your project, choose Audio/Data (the default).
If you need maximum compatibility with late-production consoles or are troubleshooting
read issues on specific hardware, try Data/Data (`-L data-data`) or Merged Data/Data (`-L merged-data`).

Audio/Data remains the recommended default for general distribution: consoles lacking MIL-CD
support were produced only during the final months before hardware discontinuation and are
relatively uncommon. Switch to Data/Data when specifically targeting those consoles or if
users report boot failures.

#### Which Consoles Boot MIL-CD

Sega did not remove MIL-CD support in a single abrupt cutoff, nor does compatibility strictly
align with hardware revisions (such as "VA2") as commonly assumed. Instead, the change
was introduced gradually during the VA2 manufacturing run through a combination of BIOS updates
and minor board revisions. As a result, the revision marking alone is insufficient to determine
compatibility; the date of manufacture (printed on the console's bottom label) provides the
most reliable indicator.

Manufacture dates appear explicitly on NTSC-U console labels. Because PAL and Japanese
labels list region and revision markers without an explicit date, the timeline below is
most firmly established for North American (NTSC-U) consoles:

| Date of Manufacture | MIL-CD Boot Support |
| --- | --- |
| October 2000 and earlier | Supported |
| November 2000 | Transition period (varies by unit) |
| December 2000 and later | Not supported |

These ranges represent consensus findings from hardware preservationists and community testing
rather than official Sega documentation. Units manufactured in November 2000 should be treated
as borderline and verified empirically. This compatibility split is the primary reason why
mkdcdisc provides both Audio/Data and Data/Data layout options.

These dates align with [Zorlon's MIL-CD Compatibility Guide](https://www.epforums.org/showthread.php?54893-Dreamcast-versions-Mil-CD-Selfboot-Compatibility)
(2013), compiled from extensive community console testing across NTSC-U VA2 revisions.

Other references categorize compatibility by board revision rather than calendar date, placing
the cutoff somewhat earlier. For instance, the compatibility table in
[Dreamcast CDI Burner (DCDIB)](https://alex-free.github.io/dcdib/) notes Audio/Data boot failures
on certain late VA1 consoles. While this documentation reflects the prevailing community
consensus, differences across hardware revisions highlight the importance of testing on
physical hardware where possible.

Sources: [Sega Retro: Mil-CD](https://segaretro.org/Mil-CD),
[Reddit Dreamcast Discussion](https://www.reddit.com/r/dreamcast/comments/6zudpb/question_about_boot_discs/),
[Dreamcast CDI Burner (DCDIB)](https://alex-free.github.io/dcdib/), and
[Zorlon's Guide on epforums](https://www.epforums.org/showthread.php?54893-Dreamcast-versions-Mil-CD-Selfboot-Compatibility).

## Operational Modes

mkdcdisc supports two main workflows:

### Standard Mode (Default)

Builds the entire image from source files: provide an executable (ELF or binary) and input directories,
and mkdcdisc generates the ISO9660 filesystem, populates the `IP.BIN` system area, synthesizes
the tracks, and outputs the final container image (CDI, MDS+MDF, NRG, or GDI; see [docs/topics/gd-image.md](gd-image.md)).

```bash
mkdcdisc -e game.elf -d data/ -o game.cdi
```

### External ISO Mode (`-t/--external-data-track`)

Delegates ISO filesystem creation and `IP.BIN` injection to external tools such as `mkisofs`,
then packages the resulting `.iso` image into a CDI, MDS+MDF, or NRG container. The output
format is chosen via `-F/--format` or inferred from the output file extension. (Not available
for GD-ROM targets, which always generate their filesystems internally).

This mode is ideal when you need low-level control over ISO9660 parameters (e.g. Rock Ridge,
Joliet extensions, custom volume descriptors, or specific file sort weights) or when integrating
into existing build toolchains.

The flag `-t/--external-data-track` reflects the role of the input file in the final disc
structure (it forms the session's data track). When `-t` is specified, filesystem generation
options (`-a`, `-b`, `-B`, `-d`, `-D`, `-e`, `-f`, `-i`, `-I`, `-m`, `-n`, `-N`, `-p`, `-r`,
`-s`, `-S`) are disallowed; only audio tracks (`-c`), format selection (`-F`), disc layout (`-L`),
and output path (`-o`) are permitted.

Because mkdcdisc does not generate the ISO in this mode, it performs sanity checks before
packaging: ensuring a valid Dreamcast bootstrap area exists, verifying that the license screen
code is intact, confirming that the specified boot executable resides at the ISO root directory,
and verifying that the ISO was authored for the correct starting LBA sector. If any of the first
three checks fails, mkdcdisc stops with an error to prevent generating an unbootable image
(the fourth check issues a warning). These checks can be bypassed using
`--disable-bootstrap-checks` if necessary. See "Boot prerequisite checks" in
[docs/topics/cli-reference.md](cli-reference.md).

See [docs/topics/examples.md](examples.md) for complete `mkisofs` recipes for MIL-CD, Data/Data,
and Merged Data/Data in External ISO Mode.

## Format Internals

### The CDI Format

DiscJuggler `.cdi` is a single-file disc image container developed by Padus.
Unlike the multi-file MDS+MDF format, a CDI stores all session data and disc metadata
within a single file: raw track sector streams are written sequentially, followed
by a trailer descriptor containing session layout, track modes, and disc parameters.
A 32-bit offset stored in the final 4 bytes points to the start of this trailer,
allowing readers to parse the descriptor from the end of the file.

CDI became the de facto standard format for Dreamcast homebrew because it cleanly
encapsulates multi-session layouts (e.g. Session 1 audio followed by Session 2 bootable
data) in a single portable file recognized directly by optical disc burning utilities
and Dreamcast emulators. mkdcdisc outputs CDI images by default, fulfilling the role
historically served by `cdi4dc`.

### The MDS+MDF Format

Alcohol 120% disc images consist of a dual-file pair sharing a common base name:

- **`.mds`**: The *Media Descriptor*, a structured metadata file describing the
  disc layout: sessions, tracks, recording modes, pregaps, starting LBAs, and track
  offsets into the data stream.
- **`.mdf`**: The *Media Data File*, containing the continuous raw sector payload
  (2352 bytes per sector).

For Dreamcast MIL-CD images, mkdcdisc writes the standard two-session arrangement:
Session 1 holding CDDA audio tracks (or a short silent filler track when no audio
tracks are provided), followed by Session 2 formatted as XA Mode 2 Form 1 data.
Data sectors are fully encoded with sync patterns, headers, subheaders, and EDC/ECC
blocks generated via libedc, matching real physical disc layouts. The resulting images
can be loaded in emulators or burned directly with Alcohol 120%.

Track pregaps are defined within the `.mds` descriptor rather than embedded in the `.mdf`
payload, following Alcohol's Disc-At-Once (DAO) convention where burning software generates
gaps dynamically. The `.mds` descriptor references its paired data file using a `*.mdf`
pattern, allowing both files to be safely renamed together without breaking descriptor links.

This implementation provides a modern, clean-room replacement for the MDS+MDF writer
originally found in `mds4dc`.

### The NRG Format

Nero Burning ROM `.nrg` is a single-file container. Like CDI, raw track data is written
first (including pregaps, which are stored physically in the sector stream), followed
by a trailer of tagged metadata chunks and an end-of-file footer pointing to the
trailer offset.

Nero images support two distinct recording schemes represented by different trailer chunks:
**TAO** (Track-At-Once, using `ETNF`/`ETN2` chunks), which lacks a complete cue sheet and
inserts automatic run-out gaps between tracks; and **DAO** (Disc-At-Once, using `CUEX`,
`DAOX`, and `SINF` chunks), providing full cue sheet definitions and exact sector-level offsets.
mkdcdisc strictly generates **DAO** images: the Dreamcast's multi-session boot process requires
precise MSINFO alignments, an exact -150 pregap on Track 1, and deterministic session
boundaries that TAO mode cannot provide.

For each session, mkdcdisc writes a `CUEX` cue sheet (specifying pregap and track start LBAs,
plus session lead-out), a `DAOX` chunk (providing per-track file offsets, sector sizes, and modes),
and a `SINF` chunk (recording track counts). The sector stream uses identical Audio and
XA Mode 2 Form 1 raw sector encoding (sync, header, subheader, and EDC/ECC via libedc)
as the CDI and MDS+MDF writers.
