# Examples

Practical build recipes organized by project goal rather than theoretical concepts.
For detailed explanations of layouts, media constraints, and modes of operation,
see [docs/topics/cd-images.md](cd-images.md) and [docs/topics/gd-image.md](gd-image.md).

> **Note:** These examples demonstrates `mkdcdisc` options in their long form for
> clarity. Most option used below has a short equivalent too (e.g. `--main-elf`
> is `-e`); see [docs/topics/cli-reference.md](cli-reference.md) for the complete
> short/long mapping.

## MIL-CD (Audio/Data Layout, Default)

### Standard Mode

```bash
mkdcdisc --main-elf game.elf --directory data/ --output game.cdi
```

With CDDA audio tracks:

```bash
mkdcdisc --main-elf game.elf --directory data/ \
  --cdda-track intro.wav --cdda-track music.wav \
  --output game.cdi
```

### External ISO Mode

In this mode, you generate the `IP.BIN` and filesystem contents externally; see
[From a KallistiOS Program to an External ISO](#from-a-kallistios-program-to-an-external-iso)
below for detailed workflow instructions.

```bash
# Step 1: Calculate the starting MSINFO sector offset for your audio tracks
MSINFO=$(mkdcdisc --print-msinfo --cdda-track track01.wav --cdda-track track02.raw)

# Step 2: Build the ISO using that starting LBA offset
# ("cd_root" is the directory containing your game data files)
mkisofs -C 0,$MSINFO -V "GAME_NAME" -G IP.BIN -joliet -rock -l -o data.iso cd_root/

# Step 3: Wrap into a CDI image alongside the audio tracks
mkdcdisc --external-data-track data.iso \
  --cdda-track track01.wav --cdda-track track02.raw \
  --output disc.cdi

# ...or wrap into an Alcohol 120% (MDS+MDF) disc image
mkdcdisc --external-data-track data.iso \
  --cdda-track track01.wav --cdda-track track02.raw \
  --output disc.mds

# ...or wrap into a Nero Burning ROM (NRG) disc image
mkdcdisc --external-data-track data.iso \
  --cdda-track track01.wav --cdda-track track02.raw \
  --output disc.nrg
```

## Data/Data Layout (`--disc-layout data-data`)

### Standard Mode

```bash
mkdcdisc --main-elf game.elf --directory data/ --disc-layout data-data --output game.cdi
```

### External ISO Mode

Because Data/Data contains no initial audio session, generate the ISO starting at MSINFO 0:

```bash
# ("cd_root" is the directory containing your staged game assets)
mkisofs -C 0,0 -V "GAME_NAME" -G IP.BIN -joliet -rock -l -o data.iso cd_root/
mkdcdisc --external-data-track data.iso --disc-layout data-data --output disc.cdi
```

## Merged Data/Data Layout (`--disc-layout merged-data`)

Available exclusively in External ISO Mode (passing `--external-data-track` twice).
Session 1 is generated first without a bootloader (no `mkisofs -G`), followed by
Session 2 created as a multi-session merge (`mkisofs -M`) referencing Session 1,
incorporating new files and the final bootable `IP.BIN`:

```bash
# Step 1: Generate Session 1 ISO (no -G, as it is never booted directly)
# Note: session1_data/ must not exceed 68,808,704 bytes for this example's LBA alignment
mkisofs -V "GAME_NAME" -o session1.iso session1_data/

# Step 2: Calculate Session 2 MSINFO starting offset from Session 1
MSINFO2=$(mkdcdisc --print-msinfo --disc-layout merged-data --external-data-track session1.iso)
# Output: 45000

# Step 3: Generate Session 2, merging Session 1 and embedding the bootable IP.BIN
mkisofs -C 0,$MSINFO2 -V "GAME_NAME" -G IP.BIN -M session1.iso -o session2.iso session2_data/

# Step 4: Package both ISO tracks into the final multi-session image
mkdcdisc --disc-layout merged-data \
  --external-data-track session1.iso --external-data-track session2.iso \
  --output disc.cdi
```

## From a KallistiOS Program to an External ISO

This walkthrough shows that `mkdcdisc` still fits into a workflow built around the native
KallistiOS utilities, rather than requiring Standard Mode's automatic ELF conversion (`--main-elf game.elf`).
KallistiOS provides the required utilities in `$KOS_BASE/utils`:

```bash
# Step 1: Compile the release ELF (strip debug symbols)
make

# Step 2: Convert the ELF to an unscrambled raw binary
$KOS_BASE/utils/elf2bin/elf2bin game.elf game.bin

# Step 3: Scramble the binary into cd_root/ as 1ST_READ.BIN
mkdir -p cd_root
$KOS_BASE/utils/scramble/scramble game.bin cd_root/1ST_READ.BIN

# Step 4: Generate the IP.BIN bootstrap
$KOS_BASE/utils/makeip/makeip -v IP.BIN

# Step 5: Build the ISO, embedding IP.BIN via -G
mkisofs -V "GAME_NAME" -G IP.BIN -joliet -rock -l -o data.iso cd_root/
```

Metadata options (`--title`, `--author`, `--serial`, `--release`, `--product-version`,
`--bootstrap-mr-image`) are handled by `makeip` during Step 4, as those flags are disallowed
in External ISO Mode. Intermediate binary forms are also accepted if already generated:
`--main-binary-unscrambled` takes unscrambled binaries (Step 2), and
`--main-binary-scrambled` accepts pre-scrambled binaries (Step 3).

With `data.iso` in hand, wrap it into the final disc image using External ISO Mode's
`--external-data-track` flag:

```bash
mkdcdisc --external-data-track data.iso --output game.cdi
```

Unless you specifically require custom `mkisofs` switches or manual control over these
intermediates, Steps 2 through 5 can be replaced with a single Standard Mode command, since
`mkdcdisc` already generates the Joliet and Rock Ridge extensions automatically via `libisofs`:

```bash
mkdcdisc --main-elf game.elf --directory-contents data/ --output game.cdi
```

## GD-ROM Images (`.gdi`)

Always uses Standard Mode with fixed physical partitions (see [docs/topics/gd-image.md](gd-image.md)):

```bash
mkdcdisc --main-elf game.elf --directory data/ --output game.gdi
```

With high-density audio tracks (GD-DA, placed between filesystem data tracks):

```bash
mkdcdisc --main-elf game.elf --directory data/ \
  --cdda-track music1.raw --cdda-track music2.raw \
  --output game.gdi
```

Generating a truncated image for compatible Optical Drive Emulators (omitting physical media padding):

```bash
mkdcdisc --main-elf game.elf --directory data/ --gdi-truncate --output game.gdi
```

Use `--gdi-truncate` carefully: truncated images do not conform to the official GD-ROM specification,
and some targets (such as the Demul and nullDC emulators) reject them and fail to boot. See
[docs/topics/gd-image.md](gd-image.md) for full compatibility notes before relying on it.

## Disc Metadata, IP.BIN, and License Logo (Standard Mode)

These options apply to any Standard Mode build (MIL-CD, Data/Data, or GD-ROM) where mkdcdisc
generates the `IP.BIN` system area internally. They are not used in External ISO Mode.

Configuring disc metadata fields (title, author, product serial, release date, version, and ISO volume label):

```bash
mkdcdisc --main-elf game.elf --directory data/ \
  --title "My Game" \
  --author "My Studio" \
  --serial "T-00001" \
  --release 20260101 \
  --product-version V1.000 \
  --volume-label MY_GAME \
  --output game.cdi
```

Embedding a custom license screen MR logo:

```bash
mkdcdisc --main-elf game.elf --directory data/ --bootstrap-mr-image license.mr --output game.cdi
```

Disabling the license screen logo completely:

```bash
mkdcdisc --main-elf game.elf --directory data/ --disable-bootstrap-mr --output game.cdi
```

Providing an existing custom `IP.BIN` template. Metadata options (`--title`, `--author`,
`--serial`, `--release`, `--product-version`, `--bootstrap-mr-image`, `--disable-bootstrap-mr`)
are bypassed in favor of the template's embedded headers:

```bash
mkdcdisc --main-elf game.elf --directory data/ --bootstrap custom_ip.bin --output game.cdi
```
