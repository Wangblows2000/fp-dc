# GD-ROM Images (.gdi)

```bash
# Generate a GD-ROM image (format inferred from .gdi extension)
mkdcdisc -e game.elf -d data/ -o game.gdi
```

Unlike monolithic or dual-file disc image formats (such as CDI, MDS+MDF, or NRG; see [docs/topics/cd-images.md](cd-images.md)),
a GD-ROM image consists of multiple discrete files: a plain-text `.gdi` descriptor file alongside
individual track files stored in the same directory. The `.gdi` descriptor contains one line per track,
recording track number, starting LBA, control flags, sector size, filename, and an offset value (always 0).

GD-ROM images are always authored using internal filesystem and `IP.BIN` generation: there are no
disc layout variations or External ISO modes. Standard Mode is used exclusively, generating the exact
two-zone physical layout specified for Dreamcast GD-ROM optical media.

By default, mkdcdisc outputs the standard 3-track structure found on official Dreamcast GD-ROMs:

1. **Track 1 (Data, Low-Density Area):** Contains a small ISO9660 filesystem and `IP0000.BIN` system area.
2. **Track 2 (Audio, Low-Density Area):** A short CDDA track containing silence (or an audio warning message).
3. **Track 3 (Data, High-Density Area):** The main game ISO9660 filesystem, anchored at physical LBA 45000.

The high-density boot sector embeds the `TOC1` table describing the high-density session, exactly
matching official Sega pressed discs. Additional high-density audio tracks (GD-DA) can be inserted
between filesystem tracks (see below).

`IP0000.BIN` is derived directly from the high-density bootstrap: it replicates the 256-byte header
of the high-density `IP.BIN` across sixteen 2048-byte sectors. All primary bootstrap logic (including
the `TOC1` table, the license screen logo, and executable launch instructions) resides in the high-density
`IP.BIN`. Supplying a custom bootstrap file via `-p/--bootstrap` contributes its header metadata to
the low-density area while applying its complete payload to the high-density track.

The high-density bootstrap is available in two variants, selected via `--gdi-fpu-rounding`:
- `nearest` (default): Rounds floating-point operations to nearest even.
- `zero`: Truncates floating-point values toward zero.
This controls the initial SH-4 `FPSCR` rounding mode set before transferring control to your executable.
Applications developed with KallistiOS configure `FPSCR` explicitly at runtime and are unaffected by
this setting.

The low-density data track contains a standalone ISO9660 filesystem built around `IP0000.BIN`. It
carries the three volume descriptor text files referenced in standard Primary Volume Descriptors (PVD):
`COPYRIGH.TXT`, `ABSTRACT.TXT`, and `BIBLIOGR.TXT`. By default, mkdcdisc auto-generates these from disc
metadata. Use `--copyright`, `--abstract`, and `--biblio` to supply your own custom files. These files
reside exclusively in the low-density partition and are not accessible from the high-density game filesystem.

These three descriptor options are supported across all disc formats. However, outside of `-F gdi`,
these text files are omitted unless explicitly supplied via CLI options.

Conversely, `--gdi-disable-copyright`, `--gdi-disable-abstract`, and `--gdi-disable-biblio` allow omitting
specific text files entirely from the low-density area. Because commercial pressed GD-ROMs invariably
define all three, mkdcdisc includes them by default. If you prefer a minimal low-density area,
these disable flags suppress file generation and clear the corresponding PVD pointer fields. They take
precedence over `--copyright`, `--abstract`, and `--biblio`.

Custom files and directories can also be placed into the low-density area using `--gdi-lda-directory`,
`--gdi-lda-directory-contents`, and `--gdi-lda-file` (mirroring the `-d`, `-D`, and `-f` flags used
for the high-density track). Because the low-density area is accessible when inserted into standard PC
CD-ROM drives, this partition is ideal for user manuals, bonus media, wallpapers, or PC-side extras.

The low-density filesystem can be ordered using its own sort file via `--gdi-lda-sort-file`, operating
identically to `-S/--sort-file` for the high-density partition (see [docs/topics/sort-file.md](sort-file.md)).
Sort paths for each partition are evaluated independently relative to their respective root directories.

Track 2 (the low-density audio track) contains approximately 7 seconds of generated silence by default.
Use `--gdi-lda-cdda-track` to replace this with custom audio (WAV or raw CD-DA PCM, using the same
formats supported by `-c/--cdda-track`):

```bash
mkdcdisc -e game.elf -d data/ --gdi-lda-cdda-track warning.wav -o game.gdi
```

Because Track 2 is accessed when the disc is loaded in a standard audio CD player,
it is traditionally used on official releases to store a warning audio track (e.g. "This
disc is for use only with the Sega Dreamcast"). When a custom track is provided, its duration
overrides the 7-second default. It must be at least 4 seconds long (Red Book minimum) and
short enough that the entire low-density partition finishes prior to LBA 45000 (where the
high-density partition begins). Both constraints are validated before generation starts.

Data tracks default to **raw 2352-byte Mode 1 sectors**: sync patterns, header, user data,
and EDC/ECC blocks generated via libedc, identical to pressed media and standard GD-ROM dumps.
Pass `--gdi-sector-size 2048` to write plain user data without sector headers/ECC framing.
Track file extensions correspond directly to the sector format:

| File | Contents |
| --- | --- |
| `track??.bin` | Raw 2352-byte Mode 1 data sectors |
| `track??.iso` | Plain 2048-byte user data sectors (`--gdi-sector-size 2048`) |
| `track??.raw` | CD-DA audio sectors (2352-byte 16-bit 44.1 kHz stereo PCM) |

Always designate an isolated output directory for each GD-ROM image. Track filenames are fixed
numbered identifiers (`track01.bin`, `track02.raw`, etc.) independent of the `.gdi` filename,
so authoring multiple images in the same folder will overwrite existing tracks. mkdcdisc
checks for conflicting track files prior to writing; use `--allow-overwrite` to permit replacing them.

By default, the high-density partition is padded out to the full physical capacity of a GD-ROM,
placing the boot binary and lead-out exactly where official hardware expects them (~1 GB output).

Using `--gdi-truncate` stops the high-density track immediately after its file contents,
yielding significantly smaller disc images. Note that **truncated images do not conform to official
GD-ROM specifications**: the high-density partition terminates prior to physical LBA 549150.
Compatibility depends entirely on the target loader: while many modern Optical Drive Emulators
(ODEs) accept truncated `.gdi` images, certain emulators (such as Demul and nullDC) reject them
and drop to the BIOS screen. When targeting emulators, full-size padded images are recommended.

When `--gdi-truncate` is enabled, mkdcdisc logs an advisory note indicating the terminal LBA.
The flag also relaxes strict capacity checks: if input files exceed LBA 549150 (exceeding physical
GD-ROM media limits), mkdcdisc emits a warning detailing the sector overflow rather than aborting.

GD-ROM mode internally generates both filesystems and the `IP.BIN` system area, so it cannot be
combined with External ISO Mode (`-t`), MIL-CD disc layouts (`-L`), or ISO dumping (`-I`).
Padding is enabled by default for GD-ROMs; pass `--gdi-truncate` to disable it, meaning
`-N/--disable-data-track-padding` is disallowed. If a pre-scrambled binary is supplied via
`-B/--main-binary-scrambled`, mkdcdisc automatically unscrambles it, as Dreamcast GD-ROM boot
requires an unscrambled `1ST_READ.BIN`.

See [docs/topics/examples.md](examples.md) for complete build recipes.

## High-Density Audio Tracks (GD-DA)

`-c/--cdda-track` is also supported under `-F gdi`, placing audio tracks into the high-density
partition between an initial filesystem header track and a trailing data content track:

```bash
mkdcdisc -e game.elf -d data/ -c music1.raw -c music2.raw -o game.gdi
```

The resulting layout inserts standard 150-sector pregaps on both boundaries of the audio block,
while consecutive audio tracks abut seamlessly without gaps. The embedded `TOC1` table records
accurate track entries and control codes for all high-density tracks, concluding with a data
track as required by commercial Dreamcast titles.

**Track Limit:** Up to 95 GD-DA audio tracks can be added to the high-density partition.
Because high-density tracks occupy track numbers 3 through 99 and the audio block must sit
between two enclosing data tracks, the internal `TOC1` structure accommodates exactly 97
entries. Specifying more than 95 audio tracks causes mkdcdisc to abort with a descriptive error.

All GD-ROM-specific command-line options use the `--gdi-` prefix.
