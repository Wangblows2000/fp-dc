# CLI Reference

The complete option list displayed by `mkdcdisc --help`, detailed operational notes
for each setting, and a compatibility mapping for legacy option names. See the
main [README](../../README.md) for quick-start instructions and general usage overviews.

```
mkdcdisc v0.0.4 - Sega Dreamcast Disc Image Generator
Copyright (C) 2022-2026 Simulant and contributors

A modern command-line interface (CLI) tool for generating disc images for the Sega Dreamcast.

This tool creates a GD-ROM (.gdi) or a self-booting MIL-CD image in Padus DiscJuggler (.cdi),
Alcohol 120% (.mds/.mdf), or Nero Burning ROM (.nrg) format. These images can be used directly on an
emulator or via a virtual drive, or on a physical console via a burned CD-R or an optical drive
emulator (ODE).

Usage: mkdcdisc [OPTION]... [-e ELF | -b|-B BIN | -t ISO] -o OUTPUT

General:
These options decide what the tool prints about its own run, and where it does its work. None of
them affect the generated disc image itself.

  -h, --help                          print this help screen
  -v, --verbosity                     log level: '0' for silent, '1' for one line per build step,
                                      '2' adds each file and track handled, '3' adds the build plan
                                      and the internals; defaults to '1'
  -q, --quiet                         print nothing at all; same as '-v 0'
      --no-banner                     suppress the startup banner
      --color                         colorize the output: 'auto' (only on a terminal), 'always' or
                                      'never'; defaults to 'auto'
      --disable-color                 shorthand for '--color never'
      --temp-dir                      directory to stage the disc contents in; defaults to the
                                      system temporary directory

Output Control:
These options control the output the tool generates. By default, a MIL-CD Audio/Data disc image in
Padus DiscJuggler (CDI) format is produced.

  -o, --output                        output filename (required)
  -F, --format                        output format: 'cdi', 'mds', 'nrg' or 'gdi'; inferred from the
                                      output file extension when omitted; defaults to 'cdi'
      --allow-overwrite               write over the output files when they already exist, instead
                                      of refusing
  -I, --dump-iso                      also write the data track to a separate .iso (not with -F gdi)
      --gdi-truncate                  -F gdi only: don't pad the high-density track to full GD-ROM
                                      size; smaller, but non-standard: only boots from an ODE or
                                      emulator that accepts it
      --gdi-sector-size               -F gdi only: data track sector size, '2352' (track??.bin) or
                                      '2048' (track??.iso); defaults to 2352

Main Executable (1ST_READ.BIN):
The program the console runs at boot, given in exactly one of these 3 forms, or in none of them when
-t/--external-data-track supplies an ISO that already carries it.

  -e, --main-elf                      executable file in ELF format
  -b, --main-binary-unscrambled       executable file in unscrambled binary format
  -B, --main-binary-scrambled         executable file in scrambled binary format
      --boot-filename                 name of the main executable on disc; defaults to
                                      '1ST_READ.BIN'

Disc Metadata Bootstrap (IP.BIN):
The Initial Program (IP) bootstrap every Dreamcast disc needs: the code that loads the executable,
the fields the console reads back, and the customized license screen, if any. This tool carries its
own bootstrap, so these options exist to fill its fields in; each one left out keeps what that
default bootstrap already has. Its license screen reads "... is what official games display, but
this is 100% unofficial and unlicensed."; you may replace that MR image with your own, or leave it
out entirely.

  -p, --bootstrap                     bootstrap file (IP.BIN) to use instead of the built-in one
  -a, --author                        author/company that made the disc/software
  -n, --title                         title of the software
  -s, --serial                        disc serial; defaults to 'IND-' plus a boot binary hash
  -P, --product-version               product version, in Vx.yyy format; defaults to V1.000
  -r, --release                       release date in YYYYMMDD format; defaults to today
  -H, --peripherals                   peripheral support: 5 hex digits plus VGA and Windows CE
                                      flags, e.g. 'E000F10'; defaults to the bootstrap's value
  -i, --bootstrap-mr-image            MR or PNG image for the license screen
  -m, --disable-bootstrap-mr          embed no license screen image at all; takes precedence over -i
      --disable-bootstrap-checks      build even when the disc fails the checks that say it can
                                      boot; the failures are reported as warnings instead
      --gdi-fpu-rounding              -F gdi only: FPU rounding mode the bootstrap leaves set,
                                      'nearest' (the default) or 'zero'

Data Track Contents:
What the ISO9660 filesystem holds besides the main executable, which is added for you. With -F gdi
these fill the high-density area, the low-density one having its own --gdi-lda-* options. They are
all disabled when -t/--external-data-track is used, as that ISO is already built.

  -d, --directory                     add a directory tree, root included; repeat for multiple
  -D, --directory-contents            add a directory tree, root excluded; repeat for multiple
  -f, --file                          add a single file; repeat for multiple files
  -S, --sort-file                     path to sort file
  -N, --disable-data-track-padding    disable data track padding (padding optimizes loading speed)
                                      (not with -F gdi)
      --duplicates-once               write byte-identical files once for optimizing storage
  -V, --volume-label                  ISO9660 volume label; sanitized. Defaults to -n/--title
      --copyright                     file to use as COPYRIGH.TXT; with -F gdi it defaults to a line
                                      built from -n/-a/-r
      --abstract                      likewise for ABSTRACT.TXT
      --biblio                        likewise for BIBLIOGR.TXT
      --gdi-disable-copyright         -F gdi only: leave COPYRIGH.TXT off the disc entirely; takes
                                      precedence over --copyright
      --gdi-disable-abstract          -F gdi only: likewise for ABSTRACT.TXT
      --gdi-disable-biblio            -F gdi only: likewise for BIBLIOGR.TXT
      --gdi-lda-directory             -F gdi only: as -d, but into the low-density area
      --gdi-lda-directory-contents    -F gdi only: as -D, but into the low-density area
      --gdi-lda-file                  -F gdi only: as -f, but into the low-density area
      --gdi-lda-sort-file             -F gdi only: as -S, but for the low-density area

Disc Layout:
In MIL-CD mode, an Audio/Data disc is generated by default, the only layout that supports CD-DA
audio tracks (see -c/--cdda-track). -F gdi has no layout choice: a GD-ROM always has the same
structure.

  -L, --disc-layout                   session arrangement: 'audio-data' (the default), 'data-data',
                                      or 'merged-data', whose second session is a full merged ISO
                                      and which requires two -t ISOs
  -M, --print-msinfo                  print the data-track start LBA to feed mkisofs as -C 0,MSINFO,
                                      then exit

Disc Tracks:
The tracks around the data one: CD-DA audio, either in the MIL-CD audio session or inside a GD-ROM's
high-density zone. -t/--external-data-track is the exception: it replaces the data track itself with
an ISO built elsewhere.

  -c, --cdda-track                    audio track (.wav or raw CD-DA); repeat for multiple tracks
      --gdi-lda-cdda-track            -F gdi only: audio for the low-density CDDA track (track 2);
                                      defaults to silence
  -t, --external-data-track           use a pre-built ISO as the data track; disables the data track
                                      and IP.BIN options. In 'merged-data', give it twice, once per
                                      session (not with -F gdi)

Examples:
  mkdcdisc -e game.elf -o game.cdi
  mkdcdisc -e game.elf -d data/ -n "My Game" -o game.cdi
  mkdcdisc -t data.iso -c track01.wav -o game.mds
  mkdcdisc -e game.elf -d data/ -n "My Game" -o game.gdi

```

## Option Details

While `--help` provides concise summaries, this section details exact behaviors,
edge cases, and interactions. Options not detailed here operate exactly as described
in the help output above.

Disc format compatibility is marked as follows:
- Options starting with `-F gdi only:` or prefixed with `--gdi-` apply strictly to GD-ROM output.
- Options tagged with `(not with -F gdi)` apply to MIL-CD formats and are rejected for GD-ROMs.
- Section-level scopes (such as the "Disc Layout" group) apply strictly as noted.

### General Options

#### `-v/--verbosity`

Configures output logging level (0 to 3); see the verbosity level table below.

#### `-q/--quiet`

Equivalent to `-v 0`. Suppresses all standard log output.

#### `--color`

- `auto` (default): Emits ANSI color escape sequences only when writing directly to an interactive terminal.
  When stdout or stderr is redirected to a file or pipe (such as in continuous integration runners or
  when piped into scripts), styling degrades cleanly to unstyled text.
- `always`: Forces ANSI color escape sequences unconditionally.
- `never`: Disables ANSI color sequences completely.

#### `--disable-color`

Shorthand for `--color never`. If both flags are supplied, `--color` takes precedence.

#### `--temp-dir`

Specifies the directory where disc filesystem contents are staged during image creation.
mkdcdisc populates a uniquely named temporary subdirectory with disc assets and padding sectors
(up to a full 74-minute CD footprint, requiring roughly the size of the final disc image in free space).

Defaults to the system temporary directory (`TMPDIR` on Unix, `%TEMP%` on Windows). Because many
modern Linux distributions mount `/tmp` as a RAM-backed `tmpfs`, large builds can consume significant
system memory. In such cases, point `--temp-dir` to persistent disk storage.

The designated directory must exist beforehand. mkdcdisc creates and removes its own dedicated
staging subdirectory upon completion.

#### Verbosity Levels

`-v/--verbosity` accepts values from 0 to 3 cumulatively:

| Level | Description |
| --- | --- |
| `-v 0` (`-q`) | Completely silent on stdout: suppresses banner, progress steps, and advisory notes. Critical errors are still reported on stderr. Essential machine output (`-M/--print-msinfo`) continues to print. |
| `-v 1` (default) | One progress line per build phase (loading executable, scrambling, staging files, building IP.BIN, padding, generating ISO, writing container). On terminals, long steps update in-place with percentage counters, terminating with `Done.`. |
| `-v 2` | Detailed itemization indented under each phase: every file staged, every audio track added, and applicable layout overrides. |
| `-v 3` | Dumps the complete pre-build plan, followed by internal diagnostics: memory addresses, exact sector sizes, staging directory paths, and before/after sort weights. Recommended when submitting bug reports. |

#### The Build Plan

At `-v 3`, mkdcdisc outputs a comprehensive summary of resolved configuration parameters
before executing any build actions:

```text
Build plan:
Disc type               : MIL-CD
Image format            : Padus DiscJuggler (CDI)
Image layout            : Audio/Data
Output                  : game.cdi
Data track              : built by mkdcdisc from the files below
Volume label            : MY_GAME
Boot filename           : 1ST_READ.BIN
Main executable         : game.elf (ELF)
Executable scrambling   : scrambled for MIL-CD boot
Bootstrap (IP.BIN)      : the built-in template
License screen          : the built-in default MR image
Software title          : My Game
Author                  : Unknown Author
Serial                  : generated from the boot binary
Product version         : V1.000
Release date            : 20260807
Peripherals             : E799F10
Disc contents           : 2 directories, 1 file
Sort file               : none
Volume text files       : none
Audio session           : one blank 4-second track
Data track padding      : enabled, the track is padded out to the full CD size
```

While subsequent log entries track ongoing execution, the build plan provides a single
definitive view of all CLI flags, defaults, and implicit overrides. Values reflect the
actual configuration read by internal builder components.

In GD-ROM mode, the plan includes `FPU rounding` indicating the selected bootstrap mode.
Under `-t/--external-data-track`, internal filesystem and IP.BIN settings are omitted in
favor of the external ISO path.

#### Reproducible Builds: `SOURCE_DATE_EPOCH`

Successive builds over identical source files would normally generate varying image hashes
due to embedded timestamps (ISO9660 volume creation times, per-file directory timestamps,
and the default `IP.BIN` release date).

Setting `SOURCE_DATE_EPOCH` to a Unix timestamp (seconds since epoch) replaces all current
timestamps with the specified fixed point in time, enabling bit-for-bit reproducible output:

```bash
SOURCE_DATE_EPOCH=$(git log -1 --format=%ct) mkdcdisc -e game.elf -o game.cdi
```

If `SOURCE_DATE_EPOCH` is unset, mkdcdisc uses the current system time. If set to an invalid
value, an advisory warning is printed and standard timestamps are used.

Important notes regarding reproducibility:
- **Timezone consistency:** While ISO9660 volume descriptors use GMT, per-file directory
  entries record local time offsets. Set `TZ=UTC` in your environment to ensure identical
  bytes across different host systems.
- **Source file mtimes:** Staging disc contents normalizes source timestamps, decoupling
  reproducibility from host file checkout times.
- **Rock Ridge serial numbers:** An 8-byte inode serial variation exists in Rock Ridge `PX`
  records generated by libisofs, which depend on host filesystem inode allocation order.
  While file contents and directory layouts remain identical, bitwise verification scripts
  should mask `PX` serial numbers before comparing raw images (as demonstrated by
  `iso_read::mask_px_serials()` in mkdcdisc's test suite).

### Output Control

#### `-F/--format`

Supported values: `cdi` (Padus DiscJuggler, default), `mds` (Alcohol 120%, outputs paired `.mds` and `.mdf`),
`nrg` (Nero Burning ROM), and `gdi` (GD-ROM, outputs `.gdi` descriptor alongside raw track files).

When omitted, format is inferred from the output filename extension (`.cdi`, `.mds`, `.nrg`, `.gdi`).
See [docs/topics/cd-images.md](cd-images.md) and [docs/topics/gd-image.md](gd-image.md).

#### `--allow-overwrite`

Permits overwriting existing output files. If any destination file exists and this flag is not provided,
mkdcdisc aborts with exit code 4 prior to performing any writes, naming the conflicting files.

This check protects the complete set of produced artifacts, including `.mdf` pairs, standalone ISO dumps
(`-I/--dump-iso`), and any existing GD-ROM track files in the target directory.

#### `-I/--dump-iso`

In addition to the primary disc image, writes the generated data track as a standalone raw `.iso` file.
Incompatible with `-F gdi`.

#### `--gdi-truncate`

Omits physical media padding on the high-density GD-ROM track. Generates significantly smaller `.gdi`
sets by terminating the high-density data track immediately after file contents instead of extending
to LBA 549150 (~1 GB). Compatible with many ODEs, but rejected by certain emulators (such as Demul
and nullDC). Also relaxes strict capacity limits, warning instead of failing on overflow. See [docs/topics/gd-image.md](gd-image.md).

#### `--gdi-sector-size`

Controls high-density data track framing for GD-ROMs: `2352` (default, writes raw Mode 1 `track??.bin`
sectors with sync and EDC/ECC) or `2048` (writes plain user data `track??.iso`).

### Main Executable (1ST_READ.BIN)

#### `--boot-filename`

Customizes the filename of the primary boot binary (defaults to `1ST_READ.BIN`).
The filename declared in the `IP.BIN` boot header is updated to match.

For ISO9660 compliance, case is handled transparently across readers:
- Uppercased (e.g. `GAME.BIN`) in the ISO9660 Level 1 tree and `IP.BIN` header for console boot compatibility.
- Retained in original case under Joliet and Rock Ridge records for runtime filesystem lookups by KallistiOS.

When a custom template is passed via `-p/--bootstrap`, `--boot-filename` overrides the template's embedded header.

### Disc Metadata and Bootstrap (IP.BIN)

#### `-p/--bootstrap`

Supplies a custom 32 KiB `IP.BIN` bootstrap template, replacing the bundled default.
With `-F gdi`, this template configures both low-density and high-density boot areas.

#### `-s/--serial`

Product serial string. Defaults to `IND-` followed by a deterministic 6-digit hash derived
from the main executable binary.

#### `-H/--peripherals`

Specifies supported peripheral hardware as a bitmask: 5 hex digits followed by binary flags
for VGA support and Windows CE runtime (e.g. `E000F10`). Defaults to the value embedded in the bootstrap template.

#### `-i/--bootstrap-mr-image`

Replaces the default license logo on the boot screen. Accepts native `.mr` images or PNG files
(palettized up to 128 colors) when compiled with PNG support.

#### `-m/--disable-bootstrap-mr`

Omits the licensing screen logo entirely. Takes precedence over `-i/--bootstrap-mr-image`.

#### `--disable-bootstrap-checks`

Converts boot validation errors into warnings, allowing generation to proceed even if the disc
fails structural boot prerequisites.

#### `--gdi-fpu-rounding`

Selects the initial SH-4 `FPSCR` rounding mode set by the GD-ROM bootstrap: `nearest` (default)
or `zero`. (Ignored with a warning if a custom `-p/--bootstrap` template is provided).

#### Boot Prerequisite Checks

Prior to generating disc images, mkdcdisc verifies structural boot requirements. In the log,
this phase appears as `Checking boot prerequisites...`.

These checks primarily protect External ISO Mode (`-t/--external-data-track`), where filesystems
are generated externally. In Standard Mode, these tests always pass under normal operation; if
one fails on an internally built image, it indicates a bug in mkdcdisc and should be reported.

| Validation Check | Severity |
| --- | --- |
| Header presence and required magic strings: Hardware ID `SEGA SEGAKATANA `, Maker ID `SEGA ENTERPRISES`, and valid boot filename. | **Error** |
| SEGA licensing screen bytecode (`IP.BIN` offsets `0x0300`-`0x36FF`) is unmodified (matches what mkdcdisc embeds). | **Error** |
| The file identified in Boot Filename resides at the root of the filesystem. | **Error** (or **Warning** if matching case-insensitively, or when the volume's root directory cannot be read) |
| Starting sector alignment matches the ISO volume descriptor (see [docs/topics/msinfo.md](msinfo.md)). | **Warning** |

Errors abort the build (exit code 5) unless overridden via `--disable-bootstrap-checks`.
Warnings never stop generation.

What separates the two is how strongly the answer is known, not how bad the
consequence would be. The license screen code is an error because it is a
documented hardware fact: the boot ROM holds its own copy of those 13312 bytes
and compares the disc's against it byte for byte, refusing to boot on any
difference at all, so a disc that fails it does not boot on any console. The
MSINFO check is a warning because mkdcdisc's figure is a model of where the
session lands rather than a measurement of it, and a build refused on the
strength of a model is a build refused on an opinion.

Only the volume the console boots is checked. With `-L merged-data` that is
session 2; session 1 is read through session 2's merged view of it and never
booted, so it needs no header of its own, and one it happens to carry is
reported as unused. With `-F gdi` it is the high-density volume: the
low-density one carries a 256-byte copy of the same header by design, naming a
boot file that lives in the high-density area, and no license screen code at
all, because nothing ever boots from it.

### Data Track Contents

#### `-d/--directory`

Includes the directory recursively, the root directory itself included.
Repeat for multiple directories.

#### `-D/--directory-contents`

Includes the directory's contents recursively, excluding the root directory
itself. Repeat for multiple directories.

#### `-f/--file`

Adds a single file to the root of the data track. Repeat for multiple files.

#### `-S/--sort-file`

Controls where files are laid out on the disc; see
[sort-file.md](sort-file.md). With `-F gdi` it orders the high-density
filesystem, the low-density one having its own `--gdi-lda-sort-file`.

#### `-N/--disable-data-track-padding`

Turns off the filler that pads the data track out to a 74-minute CD. The
padding is written first and weighted to the lowest block addresses, which
pushes the real content to the outer edge of the disc where a CD reads
fastest, so switching it off trades load speed for a much smaller image.

It is off for `-F gdi` regardless, which pads its own high-density track
instead; use `--gdi-truncate` there. Disc contents that already reach a
74-minute disc leave nothing to pad with, which is noted at `-v 2` and is not
an error.

#### `--duplicates-once`

Files with identical byte-for-byte content are written only once to the data
track, and each copy points to that single extent. This is what the
`-duplicates-once` option of `mkisofs` does, and like it the test is on
content: files are matched by reading them, never by the device or inode
numbers of the source filesystem. This option is disabled by default, and
its absence does not alter the image in any way.

Candidate files are first grouped by size, so that a directory tree
containing no files of the same length is never read. Files of the same size
are then digested over their first 64 KiB, the same first pass `mkisofs`
makes, so that files which merely happen to share a length are told apart
without being read whole; only those whose prefixes match are digested
entirely. Any pair about to be merged is then compared byte by byte, so that
a digest collision cannot place two different files on the same extent.
`mkisofs` does without that check, trusting its digest outright.

If multiple copies match, the one whose path is sorted first retains the
extent, ensuring reproducibility of the result.

Four files are never shared and retain their own extent, even if their
contents match something else:

- the boot binary, because a GD-ROM places it at the very end of the
  filesystem and a shared extent has only one position;
- the data track filler, the GD-DA spacer and the closing track filler,
  because each exists solely to occupy a range of addresses. Since they are
  written from zeros, any two of the same length are byte-identical, which
  makes such a match a certainty rather than a remote risk.

Files the sort file places are deduplicated like any other: a shared extent
has a single position, so the set takes the highest weight among it, as
`mkisofs` does. A file weighted below that is placed where the heavier copy
asked for, and is named in a warning, the one part `mkisofs` leaves silent.

With `-F gdi`, this applies to the high-density area. The low-density area,
consisting of a few hundred text file sectors, is not modified.

#### `-V/--volume-label`

Used as given when passed, and derived from the IP.BIN title (`-n/--title`)
otherwise. Either way it is sanitized to at most 32 uppercase characters,
with non-alphanumeric ones replaced by `_`.

#### `--copyright`

The file's contents become `COPYRIGH.TXT`, referenced by the ISO9660
volume's Copyright File Identifier. With `-F gdi` it goes in the low-density
area (where pressed discs keep it) and defaults to a line built from
`-n`/`-a`/`-r`; in the other formats it is only added when given.

#### `--abstract`, `--biblio`

The same, for `ABSTRACT.TXT` (Abstract File Identifier) and `BIBLIOGR.TXT`
(Bibliographic File Identifier).

#### `--gdi-disable-copyright`, `--gdi-disable-abstract`, `--gdi-disable-biblio`

Opt out of one of the three: the file is not generated, its Identifier field
in the Primary Volume Descriptor (PVD) is left empty, and a
`--copyright`/`--abstract`/`--biblio` supplying it is ignored, with a
warning.

`-F gdi` only, because it is the only format that writes these files on its
own: a MIL-CD carries just the ones you name, so leaving out the option is
already the way to leave out the file, while a GD-ROM generates all three
whether asked or not.

#### `--gdi-lda-*`

Put content in the GD-ROM low-density area. That area is not reachable from
the high-density filesystem, so this is for content a PC or CD player reads,
not for game data. See [gd-image.md](gd-image.md).

#### `--gdi-lda-sort-file`

Orders the low-density filesystem, exactly as `-S` orders the high-density
one and in the same format. The two areas are separate filesystems whose
paths both start at `/`, so each sort file is resolved against its own tree
only; the three generated text files can be weighted alongside your own
content.

---

If the resulting disc exceeds 360,000 sectors (the nominal capacity of an
80-minute CD-R), mkdcdisc prints a warning showing the disc name and total
sector count before writing the image, and then proceeds anyway. This is
treated as a warning rather than a hard failure because media capacity depends
on the physical blank rather than the disc format: 90- and 99-minute CD-Rs
exist, and minor overburning on standard 80-minute blanks works on many drives.
mkdcdisc cannot determine the exact media being used; it simply flags that the
image has exceeded standard CD-R capacity. `-F gdi` is exempt from this check:
a GD-ROM high-density area has a single fixed size, so `build_gd` rejects an
oversized disc root outright (see [gd-image.md](gd-image.md)). `-q` silences
the warning alongside all other advisory messages.

Two files are never copied into the image by `-d`, `-D`, or `-f`, triggering a
warning if encountered:

- **The file passed to `-e`, `-b`, or `-B`.** The disc already includes this
  binary in converted form as `1ST_READ.BIN`, so duplicating it wastes space
  (for an ELF, often doubling the footprint of the boot executable). This match
  is checked by file identity rather than filename; for example, `-e build/game.elf -D build/`
  is caught just as a directory containing `1ST_READ.BIN` would be. Explicitly
  specifying `-f` behaves identically: naming the file directly does not make a
  duplicate copy useful. If you genuinely need the original file on the disc,
  copy it under a different filename first.
- **Any other file named like the boot executable** (`1ST_READ.BIN`, unless
  overridden by `--boot-filename`). Copying it would overwrite the newly
  generated boot executable with an unbootable file.

The three default metadata files are generated as single CRLF-terminated lines,
matching the format of official Dreamcast reference dumps:

| File | Generated content |
| --- | --- |
| `COPYRIGH.TXT` | `<name> - Copyright (c) <year> <author>. All Rights Reserved` |
| `ABSTRACT.TXT` | `<name>` |
| `BIBLIOGR.TXT` | `<name> - Created with mkdcdisc v<version>` |

`<name>` and `<author>` correspond to the IP.BIN title and company fields
(`-n`/`-a`), and `<year>` is extracted from the first four digits of
`-r/--release`. If a file with the same name already exists in the disc root, it
takes precedence over both the option argument and the generated default,
accompanied by an advisory warning indicating which copy was preserved.

### Disc Layout

#### `-L/--disc-layout`

Selects the session layout: `audio-data`, `data-data`, or `merged-data`. If
omitted, `audio-data` is used by default.

- `data-data`: Produces a Data/Data image, where the boot track resides in the
  second data session.
- `merged-data`: Produces an image whose second data session is a complete ISO
  merging the first session's files with new ones (built externally using
  `mkisofs -M`). Requires exactly two `-t/--external-data-track` ISOs (session
  1 followed by session 2).

Because neither layout includes an audio session, both are incompatible with
`-c/--cdda-track`.

#### `-M/--print-msinfo`

Calculates and prints the MSINFO value (the starting LBA of the data track) for
the specified `-c` audio tracks and exits. Pass this value to mkisofs as
`-C 0,MSINFO` when generating an ISO for use with `-t`.

- With no `-c` tracks specified, prints the default Audio/Data offset.
- With `-L data-data`, always prints `0`.
- With `-L merged-data` and a single `-t` ISO provided, calculates and prints
  the session 2 starting LBA based on the size of that ISO. Pass this to mkisofs
  as `-C 0,MSINFO -M <iso>` when building session 2. See [msinfo.md](msinfo.md).

---

These options apply exclusively to MIL-CD targets. Neither option includes the
`(not with -F gdi)` marker individually because GD-ROMs use a single fixed
disc structure where custom layouts do not apply, and MSINFO calculations are
only needed when building external ISOs with `-t` (which is also not supported
for `-F gdi`).

`-L` requires an argument. It is the only option whose legacy flag spellings were
not retained as aliases: layout options were previously separate boolean flags,
and converting a flag into an option taking an argument would break existing
semantics. Invocations using legacy syntax are rejected outright with an error
pointing to the current usage.

### Disc Tracks

#### `-c/--cdda-track`

Appends a CD-DA audio track from a `.wav` or raw PCM file. See
[msinfo.md](msinfo.md) for supported audio formats. Each track must be at least
4 seconds long (the Red Book standard minimum).

The maximum number of audio tracks depends on the target disc format:
- Up to **98 tracks** for a MIL-CD (the Red Book limit is 99 tracks, and the
  data track occupies one).
- Up to **95 tracks** with `-F gdi` (tracks become GD-DA audio in the
  high-density area spanning tracks 3 to 99, with data tracks at each boundary).
  This also matches the capacity of the TOC in the system area.

Specifying more tracks than allowed triggers an immediate error before any
audio files are read. See [gd-image.md](gd-image.md).

#### `--gdi-lda-cdda-track`

Replaces the ~7 seconds of generated silence in low-density track 2 with an
audio track, accepting the same formats as `-c`. The track length is determined
by the input file; it must run for at least 4 seconds (Red Book minimum) and fit
entirely within the low-density area below LBA 45000 (where the high-density
zone begins). Both conditions are validated before building starts. See
[gd-image.md](gd-image.md).

#### `-t/--external-data-track`

Uses a pre-built ISO filesystem (created externally with `mkisofs`, with IP.BIN
embedded using `-G`) as the data track, bypassing internal ISO and IP.BIN
generation. Compatible with `-L/--disc-layout`; when using `-L merged-data`, pass
`-t` twice (session 1 ISO, then session 2 ISO).

When mastering the external ISO, pass `-C 0,MSINFO` (see `-M`). Using `-t`
disables all other data-track and IP.BIN options. This option is not supported
with `-F gdi`, which always generates its own filesystems and IP.BIN.

Because mkdcdisc does not generate the external ISO itself, it validates the
image against Dreamcast boot requirements before proceeding (see "Boot
prerequisite checks" above).

## Exit codes

When called from scripts or build systems, mkdcdisc reports status using the
following exit codes:

| Code | Meaning |
| --- | --- |
| `0` | Success. The disc image was generated, or the requested information (`-M/--print-msinfo`, `--help`, `--version`) was displayed. |
| `2` | Invalid invocation: unrecognized option, invalid argument, or mutually incompatible options (e.g. `-t` with `-F gdi`, `--cdda-track` with `-L data-data`). No operations were attempted; an error message is displayed along with a suggestion to run `--help`. |
| `4` | I/O error or missing file: a required input file cannot be read (ELF binary, `-t` ISO, `--copyright` text), or the output destination already exists and `--allow-overwrite` was not specified. The command-line options were syntactically valid, but filesystem constraints prevented the build from proceeding. |
| `5` | Build failure: the build process encountered an error during image generation, or was aborted because the disc would not boot (overridable via `--disable-bootstrap-checks`; see "Boot prerequisite checks"). |
| `130` | Process interrupted via SIGINT (Ctrl+C). Standard UNIX signal convention: 128 plus the signal number. |

The distinction between `2` and `4` lies in whether `--help` could resolve the
problem: syntax errors return `2`, whereas missing or unreadable input files
return `4`. All non-zero exit codes output error diagnostics to `stderr`,
ensuring that `-q/--quiet` never conceals a failure.

## Deprecated option names

Several long option names were updated to share common prefixes and group
together logically in `--help` output. Short options remain unchanged, and
legacy long option names are still supported as aliases for backward
compatibility. When a legacy option name is used, mkdcdisc issues a warning on
stderr indicating its replacement. These deprecated aliases are omitted from
`--help` and may be removed in a future release.

Certain options underwent multiple revisions; for example, `-b` and `-B` were
first prefixed with their functional group and later updated to spell out
`binary` instead of `bin`. All historical aliases resolve to the same underlying
option and point to the current preferred spelling.

| Previous name | Current name |
| --- | --- |
| `--elf` | `-e/--main-elf` |
| `--unscrambled-binary` | `-b/--main-binary-unscrambled` |
| `--main-bin-unscrambled` | `-b/--main-binary-unscrambled` |
| `--scrambled-binary` | `-B/--main-binary-scrambled` |
| `--main-bin-scrambled` | `-B/--main-binary-scrambled` |
| `--ipbin` | `-p/--bootstrap` |
| `--name` | `-n/--title` |
| `--image` | `-i/--bootstrap-mr-image` |
| `--no-mr` | `-m/--disable-bootstrap-mr` |
| `--no-padding` | `-N/--disable-data-track-padding` |
| `--cdda` | `-c/--cdda-track` |
| `--external-iso-track` | `-t/--external-data-track` |

Deprecation warnings respect `-v/--verbosity` and are suppressed by `-q/--quiet`.
Like the startup banner, warnings are written to `stderr`, ensuring they do not
interfere with machine-readable `stdout` output (such as `-M/--print-msinfo`).
