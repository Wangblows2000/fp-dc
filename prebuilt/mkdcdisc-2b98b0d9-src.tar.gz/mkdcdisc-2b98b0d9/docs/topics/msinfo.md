# CDDA Audio Tracks and MSINFO (LBA Offsets)

When a disc contains CDDA audio tracks in Session 1, the starting sector of the subsequent
data track varies depending on the cumulative duration of those audio tracks. This starting
Logical Block Address (LBA) is known as the **MSINFO** offset.

Authoring tools like `mkisofs` must know the starting LBA **before** generating the ISO
image (passed via `-C 0,<msinfo>`) so that directory records and path tables contain the
correct absolute sector references. For this reason, External ISO Mode workflows
(see [docs/topics/cd-images.md](cd-images.md)) use `-M/--print-msinfo` to pre-calculate this value;
see [docs/topics/examples.md](examples.md) for complete build scripts.

## Calculating MSINFO (LBA Value)

Use `-M/--print-msinfo` to calculate the data track's starting LBA based on the supplied audio tracks:

```bash
mkdcdisc -M -c track1.wav -c track2.raw
# Output: 12608
```

- When no `-c` tracks are supplied, it prints the default Audio/Data offset (`11702`, corresponding
  to the standard 4-second silent lead-in track).
- With `-L data-data`, it outputs `0`, because the primary ISO resides at the beginning of Session 1.

## Addressing Mismatches

An ISO9660 filesystem embeds absolute sector addresses throughout its volume descriptors
and directory records. Passing an incorrect MSINFO value to `mkisofs` will still produce
a syntactically valid ISO image, but every internal pointer will be offset from its true
physical location on disc. The console appears to mount the disc normally, but reads file
data from the wrong sectors.

To prevent silent boot failures, mkdcdisc inspects external ISOs passed via `-t/--external-data-track`.
It reads the embedded primary volume descriptor to determine the starting sector the ISO was compiled
for, compares it against the planned physical track location, and warns if a discrepancy is detected:

```
Warning: the external ISO was built to start at sector 0, but it will be written
at sector 11702 (-11702). Every address recorded inside it is that far out, so
the console will read each file from the wrong place. Pass mkisofs -C 0,11702;
mkdcdisc -M prints that number for the options this disc is being built with.
```

This diagnostic addresses the most common authoring error: wrapping a plain ISO authored
without the `-C` flag into an Audio/Data layout.

This check emits an advisory warning rather than terminating the build: because inter-session
lead-in and pregap lengths can vary slightly between different optical mastering models,
discrepancies smaller than one standard pregap (150 sectors) are ignored. Session 1 tracks
are held strictly to LBA 0 without tolerance.

See [docs/topics/cli-reference.md](cli-reference.md) for other boot validation checks and the
`--disable-bootstrap-checks` flag.

## Audio Track Formats

`-c/--cdda-track` accepts two audio formats:
1. **WAV**: Standard RIFF waveform audio (uncompressed 44.1 kHz, 16-bit stereo PCM).
2. **Raw CD-DA**: Headerless 44.1 kHz 16-bit stereo little-endian PCM.

Format selection is determined by inspecting the file header: any file starting with the `RIFF`
magic signature is decoded as WAV; all other inputs are processed as raw CD-DA regardless of file
extension (`.wav`, `.raw`, `.pcm`, `.bin`).

Raw audio files must match standard Red Book audio parameters (44.1 kHz, 16-bit stereo, yielding
2352 bytes per sector). If a raw audio file does not terminate on an exact 2352-byte sector
boundary, mkdcdisc automatically pads the final sector with silence and logs an informational note
confirming the padding length. Audio tracks shorter than the 4-second Red Book minimum (300 sectors)
will trigger an advisory note.
