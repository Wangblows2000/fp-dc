# Sort Files

Passing a sort file via `-S/--sort-file` allows you to control the exact physical order
in which files and directories are written into the ISO image. On optical media, data placed
near the outer edge of a track experiences higher linear velocity under constant angular velocity,
yielding faster sequential read throughput and reducing seek latency for critical game assets.

A GD-ROM (`-F gdi`) contains two independent filesystems and therefore supports two distinct
sort files: `-S/--sort-file` orders the primary high-density partition (where the game assets
reside), while `--gdi-lda-sort-file` orders the low-density partition (see [docs/topics/gd-image.md](gd-image.md)).
Both files follow identical syntax, and path references are evaluated strictly relative to
the root of their respective partitions.

## Sort File Format

Each line specifies a target file or directory path followed by a numerical weight:

```
/path/to/file_or_directory weight
```

### Weights

- **Default Weight:** Unlisted files and directories default to a weight of 0.
- **Positive Weights:** Higher values place files closer to the beginning (inner radius) of the data track.
- **Negative Weights:** Lower (more negative) values place files toward the end (outer radius) of the track
  for faster streaming throughput.
- **Directories:** Assigning a weight to a directory applies that weight recursively to all contained files
  and subdirectories.
- **Comments and Whitespace:** Lines starting with `#` and empty lines are ignored.
- **Path Spacing:** Paths cannot contain whitespace. Tokens are separated by whitespace, so an entry like
  `/my file.txt 100` is parsed as path `/my` with invalid weight `file.txt`. Malformed lines are skipped
  with a warning displaying the line number.
- **Filesystem Paths vs Host Paths:** Paths must reflect the directory hierarchy on the **target disc**,
  not the host build environment. For example, staging via `-D data/` places the *contents* of `data/`
  at the disc root, so `data/intro.mp4` becomes `/intro.mp4` on disc. Conversely, staging via `-d data/`
  preserves the parent directory, placing the file at `/data/intro.mp4`. All paths must begin with a leading `/`.
  Entries that do not match any file staged onto the volume trigger warnings about unmatched sort paths.

### Example Sort File

```text
# Place high-bandwidth intro video near the outer track edge for smooth playback
/media/videos/intro.mp4 -1000

# High-resolution textures placed near outer edge for fast streaming
/media/textures/high_res -800

# Frequently accessed core game scripts placed with default weights (0)

# Incidental sound effects and secondary assets placed closer to the center
/media/audio/ambient 200
/media/ui/misc.dat 500
```

## Interaction with `--duplicates-once`

When `--duplicates-once` is enabled, byte-identical files are deduplicated and share a single
extent on disc. Because a single extent cannot occupy multiple physical positions at once,
competing sort weights among identical copies must be resolved into a single placement.

In this scenario, mkdcdisc resolves conflicting sort weights by adopting the **highest weight**
specified among all identical copies (matching `mkisofs` behavior). Files whose explicit weights
are superseded by a higher-weighted sibling trigger an advisory warning:

For example, if `/a.txt`, `/b.txt`, and `/c.txt` share identical content, and the sort file assigns
`/a.txt` a weight of 100 while `/c.txt` is weighted at 9000, all three will share an extent placed
according to weight 9000. mkdcdisc emits a warning noting that `/a.txt` was placed according to the higher
weight of `/c.txt`. Unweighted copies (weight 0) do not trigger warnings.
