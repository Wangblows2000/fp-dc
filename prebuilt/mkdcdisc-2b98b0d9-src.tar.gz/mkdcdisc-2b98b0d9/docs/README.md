# mkdcdisc Documentation

The main [README](../README.md) covers building and running mkdcdisc. This directory
provides detailed reference and conceptual documentation that explains what each option does,
how supported disc formats and layouts differ, and how to combine options to generate
the exact image your project requires.

| Document | Description |
|---|---|
| [CLI Reference](topics/cli-reference.md) | Complete reference for all CLI options and legacy compatibility flags |
| [CD Images](topics/cd-images.md) | CDI, MDS+MDF, NRG formats, disc layouts, and MIL-CD console compatibility |
| [GD-ROM Images](topics/gd-image.md) | `.gdi` output and GD-DA audio tracks |
| [Examples](topics/examples.md) | Step-by-step build recipes organized by project goal |
| [CDDA and MSINFO](topics/msinfo.md) | Working with audio tracks and LBA offsets |
| [Sort Files](topics/sort-file.md) | Optimizing physical file placement on disc |

If you are new to mkdcdisc, start with [Examples](topics/examples.md) for ready-to-use recipes,
then consult the [CLI Reference](topics/cli-reference.md) for full option details.

The [specs/](specs/) directory contains third-party format specifications preserved for
reference, including Henrik Stokseth's Alcohol 120% MDS/MDF documentation used by the `.mds` writer.
