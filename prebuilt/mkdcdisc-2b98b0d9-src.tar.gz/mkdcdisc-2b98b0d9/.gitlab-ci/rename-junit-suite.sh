#!/usr/bin/env bash
# Gives a meson-generated JUnit report a per-job-unique testsuite/classname
# (reads CI_JOB_NAME_SLUG from the environment, set by GitLab CI).
#
# meson's testlog.junit.xml always names the suite/classname after the
# project ("mkdcdisc"), identically on every platform. GitLab's merge
# request test report view aggregates JUnit results across all jobs in a
# pipeline and, per https://docs.gitlab.com/ci/testing/unit_test_reports/,
# drops any test whose name duplicates one already seen. So without this, only
# one of the three platforms' results would actually show up there.
set -eu

file="$1"
sed -i "s/name=\"mkdcdisc\"/name=\"mkdcdisc-${CI_JOB_NAME_SLUG}\"/g" "$file"
