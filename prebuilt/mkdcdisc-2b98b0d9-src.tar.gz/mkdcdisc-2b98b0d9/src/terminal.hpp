/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Terminal management, ANSI color escape sequences, and TTY detection.
 *
 * ANSI escape sequences are only emitted when the target output stream is connected
 * to a compatible interactive terminal. When output is redirected (e.g. `mkdcdisc > build.log`),
 * styling degrades gracefully to plain text. stdout and stderr are evaluated independently.
 *
 * Color override precedence (highest to lowest):
 *   --color always|never        Explicit CLI request; takes immediate precedence.
 *   --disable-color             Equivalent to `--color never`, though an explicit `--color`
 *                               overrides it regardless of argument ordering.
 *   --color auto (default)      Evaluates environment variables in the following order:
 *     NO_COLOR                  If set and non-empty: colors disabled.
 *     CLICOLOR_FORCE            If set to anything other than "0": colors forced.
 *     TERM=dumb                 If set: colors disabled.
 */

#include <iosfwd>
#include <string>
#include <string_view>

namespace term {

/**
 * @brief Fixed column width for wrapping CLI help and diagnostics.
 *
 * Kept constant rather than queried from the terminal so that diagnostics and help
 * output format consistently across different environments and bug reports.
 */
inline constexpr size_t WRAP_WIDTH = 100;

enum class ColorMode {
    Auto,    /* Color enabled only if stream is an ANSI-capable terminal */
    Always,
    Never,
};

/**
 * @brief Semantic roles for text formatting.
 *
 * Uses standard 8-color ANSI sequences so the user's terminal theme controls the
 * final palette, rather than hardcoding 24-bit RGB values.
 */
enum class Style {
    Reset,
    Error,      /* bold red */
    Warning,    /* bold yellow */
    Note,       /* bold cyan */
    Success,    /* bold green */
    Heading,    /* bold */
    Dim,
};

/**
 * @brief Configures terminal streams and enables Windows VT processing if supported.
 *
 * Must be called once from `main()` before printing any output. Performs an early
 * pre-scan of `argv` for `--color` and `-q/--quiet` so early errors honor formatting
 * preferences before full command-line parsing runs.
 */
void configure(int argc, char* argv[]);

/** Re-evaluates terminal formatting using the specified ColorMode. */
void set_color_mode(ColorMode mode);

/**
 * @brief Parses "auto", "always", or "never" into a `ColorMode`.
 *
 * @return false if unrecognized, leaving `mode` unmodified.
 */
bool parse_color_mode(const std::string& when, ColorMode* mode);

/**
 * @brief Checks whether `os` currently supports ANSI escape sequences.
 *
 * Only `std::cout`, `std::cerr`, and `std::clog` can be colored; other streams
 * (such as stringstreams or file streams) evaluate to false.
 */
bool colored(const std::ostream& os);

/**
 * @brief Checks whether `os` is connected to an interactive terminal, regardless of color support.
 *
 * Determines whether dynamic elements like in-place ProgressLines are emitted.
 */
bool is_terminal(const std::ostream& os);

/**
 * @brief Sets the persistent ANSI style on stream `os`.
 *
 * Prefer streaming `term::Text` or `term::styled()`, which automatically reset formatting.
 */
std::ostream& operator<<(std::ostream& os, Style style);

/** A run of text with an associated style that automatically resets after streaming. */
struct Text {
    Style style;
    std::string_view text;
};

std::ostream& operator<<(std::ostream& os, const Text& text);

/** Inline helper for scoped styling: `std::cout << term::styled(Style::Heading, "Usage:")` */
constexpr Text styled(Style style, std::string_view text) {
    return Text{style, text};
}

/**
 * @brief Diagnostic prefix formatting.
 *
 * In quiet mode (`-q`), the program name is prepended and the severity lowercased
 * to ensure diagnostics remain identifiable in unified build logs:
 *
 *   Default: "Error: no output file given."
 *   Quiet:   "mkdcdisc: error: no output file given."
 *
 * This formatting is applied only under `-q` because the startup banner naming the
 * program is suppressed in that mode. The lowercase style also matches conventions
 * used by tools like gcc, ls, and mkisofs.
 */
struct Diagnostic {
    Style style;
    std::string_view label; /* "Error", "Warning", "Note" */
};

std::ostream& operator<<(std::ostream& os, const Diagnostic& diagnostic);

inline constexpr Diagnostic error{Style::Error, "Error"};
inline constexpr Diagnostic warning{Style::Warning, "Warning"};
inline constexpr Diagnostic note{Style::Note, "Note"};

/**
 * @brief Returns "mkdcdisc: " in quiet mode, or an empty string otherwise.
 *
 * Used for top-level messages that lack an explicit Diagnostic severity.
 */
std::string_view program_prefix();

}
