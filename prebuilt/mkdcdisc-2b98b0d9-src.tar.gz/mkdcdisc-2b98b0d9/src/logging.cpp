/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Verbosity levels and the lines that honour them: see logging.hpp. */

#include "logging.hpp"

#include <cctype>
#include <sstream>
#include <streambuf>

#include "cli.hpp"
#include "progress.hpp"
#include "terminal.hpp"

namespace logging {

Level level() {
    int asked = verbosity();

    if(asked <= 0) {
        return Level::Quiet;
    }
    if(asked >= 3) {
        return Level::Debug;
    }

    return asked == 1 ? Level::Normal : Level::Verbose;
}

bool enabled(Level at) {
    return static_cast<int>(level()) >= static_cast<int>(at);
}

Line::Line(bool enabled, std::ostream& out):
    enabled_(enabled),
    out_(out) {
}

Line::~Line() {
    if(!enabled_) {
        return;
    }

    /* Sub-step details indent beneath the active build phase, breaking the
     * partially drawn status line if necessary. */
    const char* indent = "";
    if(ProgressLine* step = active_progress_line()) {
        step->break_line();
        indent = DETAIL_INDENT;
    }

    out_ << indent << buffer_.str() << std::endl;
}

Line verbose() {
    return Line(enabled(Level::Verbose), std::cout);
}

Line debug() {
    return Line(enabled(Level::Debug), std::cout);
}

Line note() {
    return Line(enabled(Level::Normal), std::cout);
}

namespace {

/* Closes the current progress line if one is active. `break_line()` is idempotent,
 * so multi-part diagnostics only break the line once. */
void break_step_line() {
    if(ProgressLine* step = active_progress_line()) {
        step->break_line();
    }
}

/* Calculates visible character width by ignoring ANSI color escape sequences.
 * This prevents styled text from wrapping prematurely compared to unstyled text. */
size_t visible_width(const std::string& text) {
    size_t width = 0;

    for(size_t i = 0; i < text.size(); ++i) {
        if(text[i] != '\033') {
            ++width;
            continue;
        }

        /* Skip until the sequence terminating character. */
        while(i < text.size() && !std::isalpha((unsigned char) text[i])) {
            ++i;
        }
    }

    return width;
}

/* Custom streambuf for `std::cerr` that formats diagnostics automatically:
 *
 * 1. Closes any partially drawn progress line on stdout so that the error message
 *    begins cleanly on a new line. Flushing stdout first ensures proper visual order.
 * 2. Word-wraps text to match the width used by CLI `--help`.
 *
 * Wrapping requires buffering until a newline arrives. `sync()` intentionally does
 * not flush partial lines because `std::cerr` is unbuffered/unit-buffered by default
 * and would otherwise emit unwrapped fragments. */
class DiagnosticBuf: public std::streambuf {
public:
    explicit DiagnosticBuf(std::streambuf* wrapped): wrapped_(wrapped) {}

protected:
    int_type overflow(int_type c) override {
        if(traits_type::eq_int_type(c, traits_type::eof())) {
            return traits_type::not_eof(c);
        }

        put(traits_type::to_char_type(c));
        return c;
    }

    std::streamsize xsputn(const char* s, std::streamsize n) override {
        for(std::streamsize i = 0; i < n; ++i) {
            put(s[i]);
        }

        return n;
    }

    int sync() override {
        return wrapped_->pubsync();
    }

private:
    void put(char c) {
        if(c != '\n') {
            if(pending_.empty()) {
                /* About to emit diagnostic output: break any open progress line on stdout. */
                break_step_line();
            }

            pending_ += c;
            return;
        }

        emit_wrapped();
        wrapped_->sputc('\n');
    }

    /* Greedy line-wrapping: words are appended until the wrap width is reached.
     * Single tokens longer than the wrap limit (e.g. file paths) are not broken. */
    void emit_wrapped() {
        std::istringstream words(pending_);
        std::string word;
        size_t column = 0;

        while(words >> word) {
            size_t width = visible_width(word);

            if(column > 0 && column + 1 + width > term::WRAP_WIDTH) {
                wrapped_->sputc('\n');
                column = 0;
            } else if(column > 0) {
                wrapped_->sputc(' ');
                column += 1;
            }

            wrapped_->sputn(word.data(), (std::streamsize) word.size());
            column += width;
        }

        pending_.clear();
    }

    std::streambuf* wrapped_;
    std::string pending_;
};

DiagnosticBuf* DIAGNOSTIC_BUF = nullptr;

}

void install_diagnostic_guard() {
    if(DIAGNOSTIC_BUF) {
        return;
    }

    /* Intentionally never deleted: `std::cerr` refers to it until process exit,
     * including during `atexit()` cleanup handlers. */
    DIAGNOSTIC_BUF = new DiagnosticBuf(std::cerr.rdbuf());
    std::cerr.rdbuf(DIAGNOSTIC_BUF);
}

}
