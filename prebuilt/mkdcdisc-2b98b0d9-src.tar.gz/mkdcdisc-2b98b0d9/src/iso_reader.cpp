/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* ISO9660 volume reading: see iso_reader.hpp. */

#include <algorithm>
#include <cstring>

#include "iso_reader.hpp"

namespace iso9660 {

/* Locates the root directory extent within an ISO9660 volume buffer.
 *
 * Most ISO9660 authoring tools place volume data in a predictable order:
 * the 16-sector system area, the Volume Descriptor Set (starting with the PVD
 * at sector 16), both path tables, and finally the directory extents (with the
 * root directory appearing first). Consequently, the root directory extent is
 * usually found within the first few sectors; mkdcdisc's own images place it at
 * sector 18.
 *
 * Imposing a scan limit prevents scanning an entire arbitrary file if it is not
 * a valid ISO image. 4096 sectors (8 MiB) is more than generous enough to
 * accommodate path tables for any realistic Dreamcast disc image. */
static const size_t MAX_ROOT_DIRECTORY_SCAN_SECTORS = 4096;

/* Offsets of fields within an ISO9660 / ECMA-119 directory record (section 9.1).
 * Both-endian 16-bit and 32-bit values are read through their little-endian
 * representations, consistent with the rest of this project. */
static const size_t RECORD_EXTENT = 2;
static const size_t RECORD_DATA_LENGTH = 10;
static const size_t RECORD_FILE_FLAGS = 25;
static const size_t RECORD_NAME_LENGTH = 32;
static const size_t RECORD_NAME = 33;

/* Minimum size of a directory record: the 33-byte fixed header plus a 1-byte name. */
static const size_t RECORD_MIN_LENGTH = RECORD_NAME + 1;

static const uint8_t FILE_FLAG_DIRECTORY = 0x02;

static uint32_t le32(const uint8_t* at) {
    return (uint32_t) at[0] | ((uint32_t) at[1] << 8)
        | ((uint32_t) at[2] << 16) | ((uint32_t) at[3] << 24);
}

/* Strips trailing spaces and null terminators from an ECMA-119 fixed-width string. */
static std::string trimmed_field(const uint8_t* at, size_t len) {
    std::string s((const char*) at, len);

    while(!s.empty() && (s.back() == ' ' || s.back() == '\0')) {
        s.pop_back();
    }

    return s;
}

Volume read_volume(const std::vector<uint8_t>& iso) {
    Volume volume;

    if(iso.size() < (SYSTEM_AREA_SECTORS + 1) * SECTOR) {
        return volume;
    }

    const uint8_t* pvd = iso.data() + SYSTEM_AREA_SECTORS * SECTOR;

    /* Verify the descriptor type (1 = Primary Volume Descriptor) and standard
     * identifier ("CD001"). */
    if(pvd[0] != 1 || std::memcmp(pvd + 1, "CD001", 5) != 0) {
        return volume;
    }

    volume.valid = true;
    volume.volume_id = trimmed_field(pvd + 40, 32);
    volume.volume_space = le32(pvd + 80);

    /* The root directory record is embedded directly within the PVD at offset 156. */
    volume.root_lba = le32(pvd + 156 + RECORD_EXTENT);
    volume.root_length = le32(pvd + 156 + RECORD_DATA_LENGTH);

    return volume;
}

/* Checks whether the sector at `at` begins with a valid "." directory record
 * matching the root directory extent described in the PVD.
 *
 * All four conditions must match:
 * 1. Name length of 1 with value 0x00 (ECMA-119 encoding for "." / current directory).
 * 2. Directory flag bit set (ensuring it is not a regular file).
 * 3. Extent LBA matching the PVD's root directory LBA.
 * 4. Data length matching the PVD's root directory size.
 *
 * Meeting all four criteria uniquely identifies this extent as the root directory
 * of this volume. */
static bool is_root_directory_extent(const std::vector<uint8_t>& iso, size_t at,
                                     uint32_t root_lba, uint32_t root_length) {
    if(at + RECORD_MIN_LENGTH > iso.size()) {
        return false;
    }

    uint8_t record_length = iso[at];
    if(record_length < RECORD_MIN_LENGTH || at + record_length > iso.size()) {
        return false;
    }

    if(iso[at + RECORD_NAME_LENGTH] != 1 || iso[at + RECORD_NAME] != 0x00) {
        return false;
    }

    if((iso[at + RECORD_FILE_FLAGS] & FILE_FLAG_DIRECTORY) == 0) {
        return false;
    }

    return le32(iso.data() + at + RECORD_EXTENT) == root_lba
        && le32(iso.data() + at + RECORD_DATA_LENGTH) == root_length;
}

RootDirectory locate_root_directory(const std::vector<uint8_t>& iso) {
    RootDirectory root;

    Volume volume = read_volume(iso);
    if(!volume.valid || volume.root_length == 0) {
        return root;
    }

    /* Start searching immediately after the PVD. The 16-sector system area
     * contains boot header / platform code rather than filesystem descriptors. */
    size_t sectors = iso.size() / SECTOR;
    size_t last = std::min(sectors, SYSTEM_AREA_SECTORS + 1 + MAX_ROOT_DIRECTORY_SCAN_SECTORS);

    for(size_t sector = SYSTEM_AREA_SECTORS + 1; sector < last; ++sector) {
        /* A volume can only be authored for an LBA greater than or equal to its
         * physical sector offset within the track. If the scan sector exceeds
         * the declared root LBA, the resulting MSINFO offset would be negative. */
        if(sector > volume.root_lba) {
            break;
        }

        if(!is_root_directory_extent(iso, sector * SECTOR, volume.root_lba, volume.root_length)) {
            continue;
        }

        root.found = true;
        root.declared_lba = volume.root_lba;
        root.sector = (uint32_t) sector;
        root.length = volume.root_length;

        return root;
    }

    return root;
}

std::optional<uint32_t> detect_msinfo(const std::vector<uint8_t>& iso) {
    RootDirectory root = locate_root_directory(iso);

    if(!root.found) {
        return std::nullopt;
    }

    return root.declared_lba - root.sector;
}

std::vector<Entry> read_root_directory(const std::vector<uint8_t>& iso) {
    std::vector<Entry> entries;

    RootDirectory root = locate_root_directory(iso);
    if(!root.found) {
        return entries;
    }

    size_t extent = (size_t) root.sector * SECTOR;

    for(uint32_t offset = 0; offset < root.length; ) {
        size_t at = extent + offset;

        if(at + RECORD_MIN_LENGTH > iso.size()) {
            return entries;
        }

        uint8_t record_length = iso[at];
        if(record_length == 0) {
            /* Directory records cannot cross 2048-byte sector boundaries;
             * a record length of zero signals zero-padding up to the next sector. */
            offset = ((offset / SECTOR) + 1) * SECTOR;
            continue;
        }

        if(record_length < RECORD_MIN_LENGTH || at + record_length > iso.size()) {
            return entries;
        }

        uint8_t name_length = iso[at + RECORD_NAME_LENGTH];
        if(RECORD_NAME + name_length > record_length) {
            return entries;
        }

        /* Skip "." (0x00) and ".." (0x01) special directory records. */
        bool is_self_or_parent = name_length == 1
            && (iso[at + RECORD_NAME] == 0x00 || iso[at + RECORD_NAME] == 0x01);

        if(!is_self_or_parent) {
            Entry entry;
            entry.lba = le32(iso.data() + at + RECORD_EXTENT);
            entry.size = le32(iso.data() + at + RECORD_DATA_LENGTH);
            entry.is_dir = (iso[at + RECORD_FILE_FLAGS] & FILE_FLAG_DIRECTORY) != 0;

            entry.name.assign((const char*) iso.data() + at + RECORD_NAME, name_length);

            /* Strip the ECMA-119 file version suffix (e.g. ";1"). */
            size_t version = entry.name.find(';');
            if(version != std::string::npos) {
                entry.name = entry.name.substr(0, version);
            }

            entries.push_back(entry);
        }

        offset += record_length;
    }

    return entries;
}

}
