/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Command-line interface definitions: option specifications, argument
 * parser, help/banner rendering, and configuration accessors.
 */

#include <cstdint>
#include <ctime>
#include <map>
#include <optional>
#include <string>
#include <vector>

/**
 * @brief Global command-line options storage.
 *
 * Populated by `parse_options()` in `main()`. Options are keyed by their
 * long flag without leading dashes (e.g., "output", not "--output").
 */
extern std::map<std::string, std::vector<std::string>> OPTS;

/**
 * @brief Disc format compatibility restriction for an option.
 *
 * Defined in the central option table: used both by `--help` to annotate
 * options and by `main()` to enforce format compatibility.
 */
enum class DiscType {
    Any,        /**< Applicable to all formats (-F cdi/mds/nrg/gdi). */
    GdRomOnly,  /**< Applicable only to GD-ROM images (-F gdi). */
    MilCdOnly,  /**< Applicable only to MIL-CD images (-F cdi/mds/nrg). */
};

/**
 * @brief Parses command-line arguments and populates the global options table.
 * @param argc Number of command-line arguments.
 * @param argv Command-line argument vector.
 * @param ok   Output boolean set to true if all options are valid, false otherwise.
 * @return Map of option keys to their parsed string values.
 */
std::map<std::string, std::vector<std::string>> parse_options(int argc, char* argv[], bool* ok);

/**
 * @brief Returns the canonical display name of an option for diagnostics.
 *
 * Ensures consistent option formatting across error messages and warnings.
 * Renaming an option in the option table automatically updates all diagnostics.
 * @param key The OPTS key (long flag without dashes, e.g. "temp-dir").
 * @return Formatted option label (e.g. "-o/--output" or "--temp-dir").
 */
std::string option_label(const std::string& key);

/**
 * @brief Option restriction details used by `main()` for format validation.
 */
struct DiscTypeRestriction {
    std::string key;    /**< OPTS map key (long flag without dashes). */
    std::string label;  /**< Diagnostic label (e.g. "-t/--external-data-track"). */
    std::string hint;   /**< Alternative option suggestion, or empty if none. */
    DiscType disc_type; /**< Disc format restriction. */
};

/**
 * @brief Retrieves all options restricted to specific disc formats.
 * @return Reference to the list of restricted options.
 */
const std::vector<DiscTypeRestriction>& disc_type_restricted_options();

/**
 * @brief Session layout requested via -L/--disc-layout.
 *
 * Applicable only to MIL-CD images; GD-ROM structures are fixed by hardware format.
 */
enum class DiscLayout {
    AudioData,   /**< Standard MIL-CD layout: CD-DA audio session followed by data session. */
    DataData,    /**< Data/Data layout: main ISO followed by a duplicated boot-sector session. */
    MergedData,  /**< Merged Data/Data layout: requires two pre-built ISOs provided via -t. */
};

/* Option accessors, providing defaults when options are omitted.
 *
 * Note: The boot binary name is determined jointly with IP.BIN metadata, so it
 * is handled separately by `boot_filename()` in ip_boot.hpp. */

/** @brief Returns the configured verbosity level (0 to 3, default 1). */
int verbosity();

/** @brief Returns the output image format ("cdi", "mds", "nrg", or "gdi"). */
std::string output_format();

/** @brief Returns the sector size for GDI data tracks (2352 or 2048). */
uint32_t gdi_sector_size();

/** @brief Returns the active MIL-CD disc session layout. */
DiscLayout disc_layout();

/**
 * @brief Returns the CLI argument string corresponding to a DiscLayout (e.g. "data-data").
 * @param layout The DiscLayout enum value.
 * @return The CLI option argument string.
 */
std::string disc_layout_value(DiscLayout layout);

/**
 * @brief Returns the human-readable display name for a DiscLayout (e.g. "Data/Data").
 * @param layout The DiscLayout enum value.
 * @return Display name used in diagnostics.
 */
std::string disc_layout_name(DiscLayout layout);

/**
 * @brief Validates the argument supplied to -L/--disc-layout.
 *
 * Verifies that the supplied layout matches a recognized layout option. Must be
 * called before accessing `disc_layout()`.
 * @return true if valid, false otherwise.
 */
bool validate_disc_layout();

/**
 * @brief Retrieves the reproducible build timestamp from SOURCE_DATE_EPOCH.
 *
 * Represents seconds since the Unix epoch, overriding timestamps embedded in
 * ISO9660 descriptors, directory records, and default IP.BIN metadata.
 *
 * If unset, the current system time is used. If malformed, a warning is printed
 * and current system time is used as fallback.
 * @return Timestamp in seconds since Unix epoch, or std::nullopt if unset/invalid.
 */
std::optional<std::time_t> source_date_epoch();

/**
 * @brief Emits warnings for any deprecated option aliases supplied on the command line.
 *
 * Called after options and verbosity levels are fully parsed.
 */
void warn_about_deprecated_options();

/**
 * @brief Configures terminal color output according to --color and --disable-color options.
 *
 * Overrides the initial terminal detection performed in `term::configure()`.
 * Must be called after options are parsed and before emitting formatted messages.
 * @return true on success, or false if an invalid `--color` argument was given.
 */
bool apply_color_options();

/**
 * @brief Determines whether the startup banner should be displayed.
 *
 * Evaluated directly from raw command-line arguments prior to full option parsing,
 * ensuring that banners are suppressed early when `-q`, `--quiet`, `--no-banner`,
 * `-v 0`, or `-M/--print-msinfo` are passed.
 * @param argc Number of command-line arguments.
 * @param argv Command-line argument vector.
 * @return true if the banner should be printed, false otherwise.
 */
bool banner_wanted(int argc, char* argv[]);

/** @brief Prints the application title, version, and copyright banner to stderr. */
void print_banner();

/**
 * @brief Prints a concise usage hint when mkdcdisc is invoked with no arguments.
 */
void print_usage_hint();

/**
 * @brief Prints a single-line suggestion pointing to `--help` following a syntax error.
 */
void print_help_hint();

/** @brief Prints full usage help, option descriptions, and examples to stdout. */
void print_help();
