/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* libisofs image construction: see iso_builder.hpp. */

#include <algorithm>
#include <cctype>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <tuple>

#include "cli.hpp"
#include "input_files.hpp"
#include "iso_builder.hpp"
#include "logging.hpp"
#include "terminal.hpp"
#include "version.h"

/* Sanitizes an ISO9660 volume identifier: converts to uppercase alphanumeric
 * characters and underscores [A-Z0-9_] and truncates to 32 characters. */
static std::string sanitize_volume_label(std::string s) {
    for(auto& c: s) {
        unsigned char uc = static_cast<unsigned char>(c);
        c = (std::isalnum(uc) || c == '_') ? std::toupper(uc) : '_';
    }

    if(s.size() > 32) {
        if(logging::enabled(logging::Level::Normal)) {
            std::cerr << term::warning << "volume label is " << s.size() << " characters, exceeds the "
                "32-character ISO9660 limit; it will be truncated." << std::endl;
        }
        s.resize(32);
    }

    return s;
}

std::string volume_label() {
    static const std::string resolved = sanitize_volume_label(
        OPTS.count("volume-label") ? OPTS["volume-label"][0] : ipbin_title());

    return resolved;
}

std::string mkdcdisc_preparer_id() {
    return std::string("mkdcdisc v") + MKDCDISC_VERSION;
}

/* Applies `SOURCE_DATE_EPOCH` to ISO image timestamps to support reproducible builds.
 *
 * Volume timestamps are set via `vol_uuid` in UTC format to avoid host timezone bias.
 * Node-level timestamps are assigned using `iso_write_opts_set_replace_timestamps()`. */
static void apply_source_date_epoch(IsoWriteOpts* opts) {
    auto epoch = source_date_epoch();
    if(!epoch) {
        return;
    }

    char uuid[17] = {0};
    std::tm utc{};

#ifdef _WIN32
    gmtime_s(&utc, &*epoch);
#else
    gmtime_r(&*epoch, &utc);
#endif

    std::strftime(uuid, sizeof(uuid), "%Y%m%d%H%M%S", &utc);
    uuid[14] = '0';  /* Centiseconds (omitted from epoch seconds) */
    uuid[15] = '0';

    iso_write_opts_set_pvd_times(opts, 0, 0, 0, 0, uuid);

    /* Mode 2: replace all node mtime values with the specified default timestamp. */
    iso_write_opts_set_replace_timestamps(opts, 2);
    iso_write_opts_set_default_timestamp(opts, *epoch);
}

IsoWriteOpts* create_iso_write_opts(const IPBin& ip_bin, size_t ms_block, bool joliet) {
    IsoWriteOpts* opts = NULL;
    iso_write_opts_new(&opts, 0);
    iso_write_opts_set_joliet(opts, joliet ? 1 : 0);
    iso_write_opts_set_rockridge(opts, 1);
    iso_write_opts_set_system_area(opts, (char*) &ip_bin, 0, 0);
    iso_write_opts_set_ms_block(opts, ms_block);
    /* ISO Level 2: permits filenames up to 31 characters in the primary ISO9660 tree
     * (equivalent to mkisofs `-full-iso9660-filenames`), which is read by Dreamcast BIOS. */
    iso_write_opts_set_iso_level(opts, 2);
    /* Disable automatic trailing period addition on extensionless files (e.g. "README"). */
    iso_write_opts_set_no_force_dots(opts, 1 | 2);

    apply_source_date_epoch(opts);

    return opts;
}

/* Writes zero-filled sectors in 64 KB chunks to avoid buffering large files in RAM. */
void write_zero_file(const std::filesystem::path& path, std::uintmax_t bytes,
                     const progress_t* progress) {
    std::ofstream f(path, std::ios::binary);
    std::vector<char> chunk(64 * 1024, 0);

    for(std::uintmax_t written = 0; written < bytes;) {
        std::uintmax_t n = std::min<std::uintmax_t>(chunk.size(), bytes - written);
        f.write(chunk.data(), (std::streamsize) n);
        written += n;

        if(progress_report(progress, written, bytes)) {
            break;
        }
    }
}

/* Safely releases and tears down a libisofs burn_source instance.
 *
 * Calls `bs_cancel()` to signal and join the background worker thread in libisofs,
 * ensuring all source directory file handles are closed prior to deletion.
 * Then calls `bs_free_data()` to free layout structures. */
static void release_burn_source(struct burn_source* burn_src) {
    if(burn_src->version >= 1 && burn_src->cancel) {
        burn_src->cancel(burn_src);
    }

    if(burn_src->free_data) {
        burn_src->free_data(burn_src);
    }

    free(burn_src);
}

/* Queries the exact final byte size calculated by libisofs for this burn source. */
static uint64_t burn_source_size(struct burn_source* burn_src) {
    return burn_src->get_size ? (uint64_t) burn_src->get_size(burn_src) : 0;
}

uint64_t measure_burn_source(struct burn_source* burn_src) {
    uint64_t total = burn_source_size(burn_src);
    release_burn_source(burn_src);
    return total;
}

std::vector<uint8_t> read_burn_source(struct burn_source* burn_src, const progress_t* progress,
                                      uint64_t reserve_at_least) {
    uint64_t total = burn_source_size(burn_src);

    std::vector<uint8_t> data;
    data.reserve((size_t) std::max(total, reserve_at_least));

    unsigned char buf[2048];
    for(;;) {
        int read = burn_src->read_xt(burn_src, buf, sizeof(buf));

        if(read == 0) { /* EOF: transmission complete */
            break;
        }

        /* A negative return code indicates a read error in the libisofs ring buffer. */
        if(read < 0) {
            release_burn_source(burn_src);
            throw std::runtime_error("libisofs could not read the disc contents through to the "
                                     "end of the image");
        }

        data.insert(data.end(), buf, buf + read);

        if(progress_report(progress, data.size(), total)) {
            break;
        }
    }

    release_burn_source(burn_src);
    return data;
}

const char* const PVD_COPYRIGHT_FILE = "COPYRIGH.TXT";
const char* const PVD_ABSTRACT_FILE = "ABSTRACT.TXT";
const char* const PVD_BIBLIO_FILE = "BIBLIOGR.TXT";

/* Memory buffer stream transfers ownership to the IsoFile and frees buffer on release. */
bool add_iso_file_from_memory(IsoDir* parent, const char* name, const std::string& content) {
    unsigned char* buf = (unsigned char*) malloc(content.size() ? content.size() : 1);
    if(!buf) {
        return false;
    }
    std::memcpy(buf, content.data(), content.size());

    IsoStream* stream = NULL;
    if(iso_memory_stream_new(buf, content.size(), &stream) < 0) {
        free(buf);
        return false;
    }

    IsoFile* file = NULL;
    if(iso_tree_add_new_file(parent, name, stream, &file) < 0) {
        iso_stream_unref(stream);
        return false;
    }

    return true;
}

/* Attaches copyright, abstract, and bibliography text files to the volume.
 *
 * For GD-ROM images, `generate_defaults` is true, ensuring all three files
 * are present in the low-density area matching retail discs. For CD images,
 * files are only added if explicitly requested via CLI options. */
VolumeTextFiles add_volume_text_files(IsoDir* root, const IPBin& ip_bin,
                                             bool generate_defaults) {
    std::string title = trim_ipbin_field(ip_bin.meta.game_name, sizeof(ip_bin.meta.game_name));
    std::string author = trim_ipbin_field(ip_bin.meta.company_name, sizeof(ip_bin.meta.company_name));
    std::string date = trim_ipbin_field(ip_bin.meta.release_date, sizeof(ip_bin.meta.release_date));
    std::string year = date.size() >= 4 ? date.substr(0, 4) : date;

    VolumeTextFiles added;

    /* Generated defaults format: single CRLF-terminated line. */
    const std::tuple<const char*, const char*, const char*, std::string, bool*> wanted[] = {
        {"copyright", "gdi-disable-copyright", PVD_COPYRIGHT_FILE,
            title + " - Copyright (c) " + year + " " + author + ". All Rights Reserved\r\n",
            &added.copyright},
        {"abstract", "gdi-disable-abstract", PVD_ABSTRACT_FILE,
            title + "\r\n",
            &added.abstract},
        {"biblio", "gdi-disable-biblio", PVD_BIBLIO_FILE,
            title + " - Created with " + mkdcdisc_preparer_id() + "\r\n",
            &added.biblio},
    };

    for(const auto& [option, disable_option, filename, generated, flag]: wanted) {
        /* If explicit disable flag is present, omit file and leave PVD field empty. */
        if(OPTS.count(disable_option)) {
            continue;
        }

        std::optional<std::string> content;

        if(OPTS.count(option)) {
            content = read_file_contents(OPTS[option][0]);
        }

        if(!content && generate_defaults) {
            content = generated;
        }

        if(!content) {
            continue;
        }

        if(add_iso_file_from_memory(root, filename, *content)) {
            *flag = true;
            continue;
        }

        /* If file already exists in input directory, keep existing copy and mark present. */
        IsoNode* existing = NULL;
        if(iso_dir_get_node(root, filename, &existing) == 1) {
            *flag = true;
            if(logging::enabled(logging::Level::Normal)) {
                std::cerr << term::warning << "the disc contents already provide " << filename
                          << "; keeping that copy" << (OPTS.count(option) ? " over --" : "")
                          << (OPTS.count(option) ? option : "") << "." << std::endl;
            }
        }
    }

    return added;
}

/* Post-patches PVD file identifiers to bypass libisofs d-character conversion,
 * which replaces '.' with '_' in file identifier fields. ECMA-119 allows SEPARATOR1
 * ('.') here, and retail Dreamcast discs require it. */
void patch_pvd_file_ids(std::vector<uint8_t>& iso, const VolumeTextFiles& present) {
    const size_t PVD = 16 * 2048; /* Preceded by 32 KB system area */
    const size_t FIELD_LEN = 37;

    const std::tuple<size_t, const char*, bool> fields[] = {
        {702, PVD_COPYRIGHT_FILE, present.copyright},
        {739, PVD_ABSTRACT_FILE, present.abstract},
        {776, PVD_BIBLIO_FILE, present.biblio},
    };

    if(iso.size() < PVD + 776 + FIELD_LEN) {
        return;
    }
    if(std::memcmp(&iso[PVD + 1], "CD001", 5) != 0) {
        return;
    }

    for(const auto& [offset, name, enabled]: fields) {
        if(!enabled) {
            continue;
        }

        uint8_t* field = &iso[PVD + offset];
        std::memset(field, ' ', FIELD_LEN);
        std::memcpy(field, name, std::min(std::strlen(name), FIELD_LEN));
    }
}

/* Overwrites the both-endian 32-bit Volume Space Size field in the PVD (offset 80). */
void patch_pvd_volume_space(std::vector<uint8_t>& iso, uint32_t sectors) {
    const size_t PVD = 16 * 2048;

    if(iso.size() < PVD + 88) {
        return;
    }
    if(std::memcmp(&iso[PVD + 1], "CD001", 5) != 0) {
        return;
    }

    uint8_t* field = &iso[PVD + 80];
    for(int i = 0; i < 4; ++i) {
        field[i] = (uint8_t) ((sectors >> (8 * i)) & 0xFF);       /* Little-endian */
        field[7 - i] = (uint8_t) ((sectors >> (8 * i)) & 0xFF);   /* Big-endian */
    }
}

/* Initializes an IsoImage configured with Dreamcast identification strings. */
IsoImageRef new_iso_image(const IPBin& ip_bin, const std::string& volume_label) {
    IsoImage* iso = NULL;
    iso_image_new(volume_label.c_str(), &iso);

    iso_image_set_system_id(iso,
        trim_ipbin_field(ip_bin.meta.hardware_id, sizeof(ip_bin.meta.hardware_id)).c_str());
    iso_image_set_publisher_id(iso,
        trim_ipbin_field(ip_bin.meta.company_name, sizeof(ip_bin.meta.company_name)).c_str());
    iso_image_set_data_preparer_id(iso, mkdcdisc_preparer_id().c_str());
    iso_image_set_application_id(iso,
        trim_ipbin_field(ip_bin.meta.game_name, sizeof(ip_bin.meta.game_name)).c_str());

    iso_tree_set_follow_symlinks(iso, 0);
    iso_tree_set_ignore_hidden(iso, 0);
    iso_tree_set_ignore_special(iso, 0);

    return IsoImageRef(iso);
}
