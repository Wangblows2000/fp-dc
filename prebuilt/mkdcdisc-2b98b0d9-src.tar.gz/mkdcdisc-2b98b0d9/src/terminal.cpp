/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Colored output: see terminal.hpp. */

/* Force POSIX visibility. MSYS2/Cygwin newlib hides POSIX extensions
 * (fileno, isatty) when -std=c++17 implies __STRICT_ANSI__. */
#if defined(__MSYS__) || defined(__CYGWIN__)
#define _DEFAULT_SOURCE 1
#endif

/* Target Vista (0x0600) or higher to expose GetFileInformationByHandleEx()
 * needed for MSYS named pipe detection. */
#ifdef _WIN32
#if !defined(_WIN32_WINNT) || _WIN32_WINNT < 0x0600
#undef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#endif

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>

#include "terminal.hpp"

#ifdef _WIN32
#include <io.h>
#include <windows.h>

/* Fallback for older MinGW-w64 headers missing the Windows 10 ANSI flag. */
#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
#endif
#else
#include <unistd.h>
#endif

namespace {

struct StreamState {
    bool is_terminal = false;
    bool colored = false;
};

/* Track quiet mode early (via pre-scan) to prepend the program name
 * on diagnostics emitted before full CLI parsing completes. */
bool g_name_diagnostics = false;

/* Colors remain disabled by default until `configure()` determines TTY capabilities. */
StreamState g_stdout;
StreamState g_stderr;
term::ColorMode g_mode = term::ColorMode::Auto;

const StreamState* state_for(const std::ostream& os) {
    if(&os == &std::cout) {
        return &g_stdout;
    }
    if(&os == &std::cerr || &os == &std::clog) {
        return &g_stderr;
    }
    return nullptr;
}

const char* escape(term::Style style) {
    switch(style) {
        case term::Style::Reset:   return "\033[0m";
        case term::Style::Error:   return "\033[1;31m";
        case term::Style::Warning: return "\033[1;33m";
        case term::Style::Note:    return "\033[1;36m";
        case term::Style::Success: return "\033[1;32m";
        case term::Style::Heading: return "\033[1m";
        case term::Style::Dim:     return "\033[2m";
    }
    return "";
}

/* Checks if an environment variable is defined and non-empty (e.g. NO_COLOR). */
bool env_is_set(const char* name) {
    const char* value = std::getenv(name);
    return value != nullptr && value[0] != '\0';
}

/* Checks if an environment variable is defined and not equal to "0" (e.g. CLICOLOR_FORCE). */
bool env_is_enabled(const char* name) {
    const char* value = std::getenv(name);
    return value != nullptr && value[0] != '\0' && std::strcmp(value, "0") != 0;
}

#ifdef _WIN32

/* Checks whether the descriptor references an authentic Windows Console.
 * `_isatty()` is insufficient because it returns true for any character device, including NUL. */
bool is_windows_console(int fd) {
    HANDLE handle = (HANDLE) _get_osfhandle(fd);
    if(handle == INVALID_HANDLE_VALUE) {
        return false;
    }

    DWORD mode = 0;
    return GetConsoleMode(handle, &mode) != 0;
}

/* Enables Windows Virtual Terminal processing (Windows 10+).
 * The original console mode is intentionally not restored on exit: abnormal exits
 * or Ctrl+C cannot reliably clean it up, and this flag simply instructs the console
 * to interpret ANSI escapes rather than printing them literally. */
bool enable_virtual_terminal(int fd) {
    HANDLE handle = (HANDLE) _get_osfhandle(fd);
    if(handle == INVALID_HANDLE_VALUE) {
        return false;
    }

    DWORD mode = 0;
    if(!GetConsoleMode(handle, &mode)) {
        return false;
    }

    if(mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING) {
        return true;
    }

    return SetConsoleMode(handle, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING) != 0;
}

/* MSYS2 and Cygwin PTYs (e.g. mintty) communicate via named pipes rather than standard
 * Windows console buffers. `_isatty()` and `GetConsoleMode()` fail on these.
 * We identify them by inspecting the named pipe path pattern (e.g. "\msys-XXXX-pty0-to-master"). */
bool is_msys_terminal(int fd) {
    HANDLE handle = (HANDLE) _get_osfhandle(fd);
    if(handle == INVALID_HANDLE_VALUE || GetFileType(handle) != FILE_TYPE_PIPE) {
        return false;
    }

    /* Allocate extra space for the variable-length FileName in FILE_NAME_INFO. */
    char buffer[sizeof(FILE_NAME_INFO) + MAX_PATH * sizeof(WCHAR)] = {0};
    FILE_NAME_INFO* info = (FILE_NAME_INFO*) buffer;

    if(!GetFileInformationByHandleEx(handle, FileNameInfo, info, sizeof(buffer))) {
        return false;
    }

    std::wstring name(info->FileName, info->FileNameLength / sizeof(WCHAR));

    bool from_cygwin = name.find(L"msys-") != std::wstring::npos ||
                       name.find(L"cygwin-") != std::wstring::npos;
    bool is_pty = name.find(L"-pty") != std::wstring::npos;
    bool is_master_end = name.find(L"-to-master") != std::wstring::npos ||
                         name.find(L"-from-master") != std::wstring::npos;

    return from_cygwin && is_pty && is_master_end;
}

#endif

bool fd_is_terminal(int fd) {
#ifdef _WIN32
    return is_windows_console(fd) || is_msys_terminal(fd);
#else
    return isatty(fd) != 0;
#endif
}

/* Checks whether escape sequences written to `fd` will be interpreted correctly. */
bool fd_takes_ansi(int fd) {
#ifdef _WIN32
    if(is_windows_console(fd)) {
        return enable_virtual_terminal(fd);
    }
    /* MSYS/Cygwin PTYs natively support ANSI escapes without special configuration. */
    return true;
#else
    (void) fd;
    return true;
#endif
}

bool decide(int fd, bool is_terminal) {
    switch(g_mode) {
        case term::ColorMode::Never:
            return false;

        case term::ColorMode::Always:
#ifdef _WIN32
            /* Sequences forced. We still must attempt to enable processing
             * on Windows consoles so they actually parse the sequences. */
            enable_virtual_terminal(fd);
#endif
            return true;

        case term::ColorMode::Auto:
            break;
    }

    if(env_is_set("NO_COLOR")) {
        return false;
    }

    if(env_is_enabled("CLICOLOR_FORCE")) {
#ifdef _WIN32
        enable_virtual_terminal(fd);
#endif
        return true;
    }

    const char* term_name = std::getenv("TERM");
    if(term_name != nullptr && std::strcmp(term_name, "dumb") == 0) {
        return false;
    }

    return is_terminal && fd_takes_ansi(fd);
}

void resolve() {
    int out_fd = fileno(stdout);
    int err_fd = fileno(stderr);

    g_stdout.is_terminal = fd_is_terminal(out_fd);
    g_stderr.is_terminal = fd_is_terminal(err_fd);

    g_stdout.colored = decide(out_fd, g_stdout.is_terminal);
    g_stderr.colored = decide(err_fd, g_stderr.is_terminal);
}

}

namespace term {

bool parse_color_mode(const std::string& when, ColorMode* mode) {
    if(when == "auto") {
        *mode = ColorMode::Auto;
    } else if(when == "always") {
        *mode = ColorMode::Always;
    } else if(when == "never") {
        *mode = ColorMode::Never;
    } else {
        return false;
    }

    return true;
}

void configure(int argc, char* argv[]) {
    /* Fast pre-scan to detect `--color`, `-q/--quiet`, or `-v 0` before full CLI parsing.
     * Unrecognized arguments are ignored here; strict validation is handled later. */
    bool disabled = false;
    bool given = false;
    ColorMode from_option = ColorMode::Auto;

    for(int i = 1; i < argc; ++i) {
        std::string arg = argv[i];

        if(arg == "--disable-color") {
            disabled = true;
        } else if(arg == "--color" && i + 1 < argc && !given) {
            given = parse_color_mode(argv[i + 1], &from_option);
        }

        /* Detect quiet mode early so pre-parse diagnostics format properly. */
        if(arg == "-q" || arg == "--quiet") {
            g_name_diagnostics = true;
        } else if((arg == "-v" || arg == "--verbosity") && i + 1 < argc) {
            try {
                if(std::stoi(argv[i + 1]) <= 0) {
                    g_name_diagnostics = true;
                }
            } catch(...) {
                /* Ignore parsing failures during pre-scan; validated strictly later. */
            }
        }
    }

    if(disabled) {
        g_mode = ColorMode::Never;
    }

    if(given) {
        g_mode = from_option;
    }

    resolve();
}

void set_color_mode(ColorMode mode) {
    g_mode = mode;
    resolve();
}

bool colored(const std::ostream& os) {
    const StreamState* state = state_for(os);
    return state != nullptr && state->colored;
}

bool is_terminal(const std::ostream& os) {
    const StreamState* state = state_for(os);
    return state != nullptr && state->is_terminal;
}

std::ostream& operator<<(std::ostream& os, Style style) {
    if(colored(os)) {
        os << escape(style);
    }
    return os;
}

std::ostream& operator<<(std::ostream& os, const Text& text) {
    if(colored(os)) {
        return os << escape(text.style) << text.text << escape(Style::Reset);
    }
    return os << text.text;
}

std::string_view program_prefix() {
    return g_name_diagnostics ? "mkdcdisc: " : "";
}

std::ostream& operator<<(std::ostream& os, const Diagnostic& diagnostic) {
    std::string opening(diagnostic.label);

    /* Prepends program prefix and lowercases severity in quiet mode. */
    if(g_name_diagnostics) {
        os << program_prefix();
        opening[0] = (char) std::tolower((unsigned char) opening[0]);
    }

    opening += ": ";

    if(colored(os)) {
        return os << escape(diagnostic.style) << opening << escape(Style::Reset);
    }

    return os << opening;
}

}
