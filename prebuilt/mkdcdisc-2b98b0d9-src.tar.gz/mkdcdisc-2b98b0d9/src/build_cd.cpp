/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* CD-shaped disc building: see build_cd.hpp. */

#include <climits>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <set>

#include "boot_checks.hpp"
#include "build_cd.hpp"
#include "cli.hpp"
#include "disc_layout.hpp"
#include "duplicates.hpp"
#include "input_files.hpp"
#include "interrupt.hpp"
#include "ip_boot.hpp"
#include "iso_builder.hpp"
#include "logging.hpp"
#include "paths.hpp"
#include "progress.hpp"
#include "sort_file.hpp"
#include "terminal.hpp"

bool build_cd(const std::filesystem::path& input_dir) {
    std::string output_path = OPTS["output"][0];

    /* Default layout is Audio/Data (audio session followed by data session).
     * Data/Data layout omits the audio session (no CDDA tracks).
     * Merged Data/Data is handled exclusively via build_cd_from_merged_data_isos(). */
    const bool data_data = disc_layout() == DiscLayout::DataData;

    IPBin ip_bin;
    prepare_ip_bin(&ip_bin, input_dir, IP_BIN_MILCD, IP_BIN_MILCD_len);

    /* cd_image_t ownership: allocated here, transferred to and freed by
     * write_disc_image(). Early returns must explicitly call cd_free_image(). */
    cd_image_t* img = cd_new_image();
    cd_image_set_volume_name(img, PATH_TO_CSTR(std::filesystem::path(output_path).filename().stem()));

    /* In Audio/Data layout, session 1 contains CDDA tracks (or a 4-second silence
     * filler track), and session 2 contains the data track placed at the standard
     * post-session offset. The ISO is mastered with `ms_block` set to that offset.
     *
     * In Data/Data layout, there is no audio session; the ISO starts at MSINFO 0,
     * and the boot track is replicated into a second data session. */
    size_t start_lba = 0;

    if(!data_data) {
        cd_session_t* session0 = cd_new_session(img);

        if(!add_audio_session(session0)) {
            cd_free_image(&img);
            return false;
        }

        start_lba = cd_session_length_in_sectors(session0);
    }

    std::size_t padding_file_size = estimate_padding_sectors(img, input_dir) * 2048;

    /* Padding extends the data track so that content is pushed towards the outer
     * rim of a 74-minute CD, where linear read speeds are highest. If the files
     * already fill the disc capacity, no padding file is required. */
    if(!OPTS.count("disable-data-track-padding") && padding_file_size == 0) {
        logging::verbose() << "Data track padding skipped: the disc contents already "
                              "fill a 74-minute CD";
    }

    if(!OPTS.count("disable-data-track-padding") && padding_file_size > 0) {
        ProgressLine padding("Padding data track...");
        write_zero_file(std::filesystem::path(input_dir) / "0.0", padding_file_size,
            padding.progress());

        if(interrupted()) {
            cd_free_image(&img);
            return false;
        }

        padding.finish();
    }

    iso_init();

    IsoWriteOpts *opts = NULL;

    /* Held for the duration of build_cd(): `-I/--dump-iso` reuses this same
     * IsoImage reference to build a standalone ISO at LBA 0 if needed. */
    IsoImageRef image = new_iso_image(ip_bin, volume_label());
    IsoImage* iso = image.get();

    IsoDir* root = iso_image_get_root(iso);

    iso_tree_add_dir_rec(iso, root, PATH_TO_CSTR(input_dir));

    /* Only populate volume text files when explicitly requested via
     * `--copyright`, `--abstract`, or `--biblio`. Unlike GD-ROM low-density areas,
     * MIL-CD images have no requirement or convention to include empty defaults. */
    VolumeTextFiles text_files = add_volume_text_files(root, ip_bin,
        /* generate_defaults */ false);

    if(text_files.copyright) iso_image_set_copyright_file_id(iso, PVD_COPYRIGHT_FILE);
    if(text_files.abstract) iso_image_set_abstract_file_id(iso, PVD_ABSTRACT_FILE);
    if(text_files.biblio) iso_image_set_biblio_file_id(iso, PVD_BIBLIO_FILE);

    /* Track nodes that must be exempt from deduplication via `--duplicates-once`.
     * Uses IsoNode pointers rather than filenames so custom boot binary names are honored. */
    std::set<IsoNode*> undeduplicable;

    /* The padding file ("0.0") is assigned the maximum sort weight and hidden
     * from directory listings (Rock Ridge, Joliet, ECMA-119), equivalent to mkisofs
     * `-hide`/`-hide-joliet`. `LIBISO_HIDE_BUT_WRITE` ensures libisofs writes
     * the physical sectors despite hiding the node.
     *
     * Higher sort weights are placed at lower block addresses by libisofs, so
     * `INT_MAX` forces the padding file to the start of the data track, pushing
     * actual data files to higher sectors on the disc.
     *
     * The boot executable retains sort weight 0 here (unlike GD-ROM images where
     * the boot binary is explicitly pinned to the end of the high-density area). */
    if(!OPTS.count("disable-data-track-padding") && padding_file_size > 0) {
        IsoNode* padding_node = NULL;
        if(iso_dir_get_node(root, "0.0", &padding_node) == 1) {
            iso_node_set_sort_weight(padding_node, INT_MAX);
            iso_node_set_hidden(padding_node,
                LIBISO_HIDE_ON_RR | LIBISO_HIDE_ON_JOLIET | LIBISO_HIDE_BUT_WRITE);

            /* The padding file exists purely to consume sector space; it must
             * never be deduplicated or shared with other files. */
            undeduplicable.insert(padding_node);
        }
    }

    /* Pass weights to `--duplicates-once` to guide extent sharing. When extents
     * are merged, the shared extent inherits the highest sort weight among the duplicates;
     * any file with an overridden lower weight will emit a warning. */
    const std::map<IsoNode*, int> weights = apply_sort_file("sort-file", root);

    /* Protect the boot binary from deduplication across all disc builds. */
    IsoNode* boot_node = NULL;
    const std::string boot_file = boot_filename();
    if(!boot_file.empty() && iso_dir_get_node(root, boot_file.c_str(), &boot_node) == 1) {
        undeduplicable.insert(boot_node);
    }

    apply_duplicates_once("data track", iso, root, undeduplicable, weights);

    opts = create_iso_write_opts(ip_bin, start_lba);

    struct burn_source* burn_src;
    iso_image_create_burn_source(iso, opts, &burn_src);

    ProgressLine generating("Generating data track...");

    std::vector<uint8_t> iso_data = read_burn_source(burn_src, generating.progress());
    iso_write_opts_free(opts);

    if(interrupted()) {
        cd_free_image(&img);
        return false;
    }

    patch_pvd_file_ids(iso_data, text_files);

    generating.finish();

    logging::debug() << "Data track is " << iso_data.size() << " bytes";

    /* Run bootstrap validation over internally generated ISO data.
     * Checks are expected to pass; any failure indicates an internal regression.
     *
     * Exact LBA matching is enforced (`exact = true`) since start_lba was passed
     * directly to libisofs as its starting offset.
     *
     * Validated before `--dump-iso` so failed builds do not leave incomplete dumped ISOs. */
    if(!boot_checks::check_disc({
        {"the data track", boot_checks::Role::Bootable, &iso_data,
         boot_checks::MsinfoExpectation{(uint32_t) start_lba, /* exact */ true}},
    })) {
        cd_free_image(&img);
        return false;
    }

    if(OPTS.count("dump-iso")) {
        std::string iso_path = PATH_TO_CSTR(std::filesystem::path(output_path).replace_extension("iso"));

        logging::note() << "Dumping the data track to " << iso_path;

        if(start_lba == 0) {
            std::ofstream iso_out(iso_path, std::ios::binary);
            iso_out.write((char*) &iso_data[0], iso_data.size());
        } else {
            /* Since `iso_data` has start_lba embedded in all directory record LBAs,
             * it is invalid as a standalone single-session ISO. We re-master it
             * with `ms_block` set to 0. */
            IsoWriteOpts* dump_opts = create_iso_write_opts(ip_bin, 0);

            struct burn_source* dump_burn_src;
            iso_image_create_burn_source(iso, dump_opts, &dump_burn_src);

            ProgressLine dumping("Generating standalone .iso...");
            std::vector<uint8_t> dump_data = read_burn_source(dump_burn_src, dumping.progress());

            if(interrupted()) {
                cd_free_image(&img);
                return false;
            }

            dumping.finish();

            iso_write_opts_free(dump_opts);

            patch_pvd_file_ids(dump_data, text_files);

            std::ofstream iso_out(iso_path, std::ios::binary);
            iso_out.write((char*) &dump_data[0], dump_data.size());
        }
    }

    add_data_track_sessions(img, iso_data, data_data);

    return write_disc_image(img, output_path);
}

bool build_cd_from_external_iso(const std::filesystem::path& iso_path) {
    std::string output_path = OPTS["output"][0];

    const bool data_data = disc_layout() == DiscLayout::DataData;

    std::vector<uint8_t> iso_data;
    if(!read_iso_file(iso_path, iso_data)) {
        return false;
    }

    logging::note() << "Using external ISO as data track: " << iso_path
                    << " (" << iso_data.size() << " bytes)";

    cd_image_t* img = cd_new_image();
    cd_image_set_volume_name(img, PATH_TO_CSTR(std::filesystem::path(output_path).filename().stem()));

    /* For Audio/Data, session 1 holds audio tracks (or silence). The external ISO
     * must have been authored with `mkisofs -C 0,<msinfo>` matching the audio session length.
     * For Data/Data, no audio session exists, so the ISO must have been authored at MSINFO 0. */
    boot_checks::MsinfoExpectation expected_msinfo;

    if(!data_data) {
        cd_session_t* session0 = cd_new_session(img);
        if(!add_audio_session(session0)) {
            cd_free_image(&img);
            return false;
        }

        /* Calculated end of the audio session (pregap + tracks + lead-out).
         * Allow a tolerance window (`exact = false`) for mastering tool discrepancies. */
        expected_msinfo = {(uint32_t) cd_session_length_in_sectors(session0), /* exact */ false};
        logging::note() << "Data track MSINFO: " << expected_msinfo.sectors;
    } else {
        logging::note() << "Data/Data layout: the external ISO must have been built at MSINFO 0.";
    }

    /* Validate external ISO bootstrap and header before writing the disc image. */
    if(!boot_checks::check_disc({
        {"the external ISO", boot_checks::Role::Bootable, &iso_data, expected_msinfo},
    })) {
        cd_free_image(&img);
        return false;
    }

    add_data_track_sessions(img, iso_data, data_data);

    return write_disc_image(img, output_path);
}

bool build_cd_from_merged_data_isos(const std::filesystem::path& iso1_path,
                                      const std::filesystem::path& iso2_path) {
    std::string output_path = OPTS["output"][0];

    std::vector<uint8_t> iso1_data, iso2_data;
    if(!read_iso_file(iso1_path, iso1_data) || !read_iso_file(iso2_path, iso2_data)) {
        return false;
    }

    logging::note() << "Using external ISO as session 1 data track: " << iso1_path
                    << " (" << iso1_data.size() << " bytes)";
    logging::note() << "Using external ISO as session 2 data track: " << iso2_path
                    << " (" << iso2_data.size() << " bytes)";

    /* In a merged-data layout, session 1 contains auxiliary data and is never booted
     * (its IP.BIN is ignored). Session 2 contains the boot executable and IP.BIN.
     *
     * Session 1 starts at LBA 0 (exact). Session 2 begins after session 1 lead-out
     * (calculated by data_session_length_in_sectors, allowing pregap tolerance). */
    boot_checks::MsinfoExpectation session1_msinfo{0, /* exact */ true};
    boot_checks::MsinfoExpectation session2_msinfo{
        (uint32_t) data_session_length_in_sectors(iso1_data.size(), /* is_first_session */ true),
        /* exact */ false,
    };

    if(!boot_checks::check_disc({
        {"the session 1 ISO", boot_checks::Role::NotBooted, &iso1_data, session1_msinfo},
        {"the session 2 ISO", boot_checks::Role::Bootable, &iso2_data, session2_msinfo},
    })) {
        return false;
    }

    cd_image_t* img = cd_new_image();
    cd_image_set_volume_name(img, PATH_TO_CSTR(std::filesystem::path(output_path).filename().stem()));

    add_merged_data_sessions(img, iso1_data, iso2_data);

    return write_disc_image(img, output_path);
}
