/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Disc image building for CD-R / MIL-CD formats.
 *
 * The functions below differ primarily by where the filesystem data originates,
 * rather than the output container format (which is selected via `-F/--format`).
 *
 * MIL-CD images support three track layouts via `-L/--disc-layout`:
 * - Audio/Data: Session 1 contains CDDA audio tracks (or a dummy track), session 2
 *   contains the data track.
 * - Data/Data: Session 1 and session 2 are both data tracks (boot session duplicated).
 * - Merged Data/Data: Two distinct data sessions where session 2 merges files from
 *   session 1 via `mkisofs -M`.
 *
 * See docs/topics/cd-images.md for console compatibility across hardware revisions.
 */

#include <filesystem>

/**
 * @brief Builds a MIL-CD disc image from local directory contents.
 *
 * Standard build mode: mkdcdisc generates both the ISO9660 filesystem
 * and the IP.BIN boot header internally.
 *
 * @param input_dir Root directory containing the files to master onto the disc.
 * @return True if the disc image was successfully created and written; false otherwise.
 */
bool build_cd(const std::filesystem::path& input_dir);

/**
 * @brief Builds a MIL-CD disc image using a pre-built ISO (`-t/--external-data-track`).
 *
 * Designed for workflows where the ISO9660 filesystem is pre-mastered (typically
 * via `mkisofs` with `-G` embedding the IP.BIN). mkdcdisc preserves the filesystem
 * and boot header untouched, constructing the container structure around them.
 *
 * Supports Audio/Data or Data/Data layout (see `-L/--disc-layout`).
 *
 * @param iso_path Path to the pre-mastered ISO image file.
 * @return True if the disc image was successfully generated; false otherwise.
 */
bool build_cd_from_external_iso(const std::filesystem::path& iso_path);

/**
 * @brief Builds a two-session disc image from two ISOs (`-L/--disc-layout merged-data`).
 *
 * Writes two distinct data sessions. Session 2 must be authored to merge session 1's
 * files (`mkisofs -M`) and must include its own IP.BIN boot header.
 *
 * @param iso1_path Path to the session 1 ISO image.
 * @param iso2_path Path to the session 2 ISO image (the bootable volume).
 * @return True if the disc image was successfully generated; false otherwise.
 */
bool build_cd_from_merged_data_isos(const std::filesystem::path& iso1_path,
                                    const std::filesystem::path& iso2_path);
