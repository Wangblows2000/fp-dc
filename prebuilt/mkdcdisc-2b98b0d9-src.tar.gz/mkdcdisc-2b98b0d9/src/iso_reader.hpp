/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Reads an ISO9660 volume directly from raw sector data.
 *
 * Recovers the Primary Volume Descriptor (PVD), the root directory, and the
 * LBA offset (MSINFO) against which addresses were encoded. This is used both
 * to validate mkdcdisc's own generated images and to inspect external data
 * tracks provided by the user (`-t/--external-data-track`).
 *
 * This component is intentionally self-contained: it has no dependencies on
 * configuration options, logging frameworks, or libisofs. It parses raw bytes
 * and extracts factual filesystem layout data. This independence makes it
 * easy to unit-test against hand-crafted volumes and keeps validation logic
 * centralized in boot_checks.cpp.
 *
 * Only the root directory is inspected, never subdirectories. Callers only need
 * to locate the boot binary, which the Dreamcast BIOS exclusively searches for
 * in the root directory. Restricting parsing to the root also avoids the need
 * to translate arbitrary recorded addresses into buffer offsets.
 * See `locate_root_directory()`.
 *
 * Kept separate from tests/common/iso_read.h: test fixtures verify libisofs
 * output independently rather than sharing reader logic with mkdcdisc itself.
 */

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace iso9660 {

constexpr size_t SECTOR = 2048;

/** Sectors 0 to 15, reserved by ECMA-119 / ISO9660. On Dreamcast discs, this
 * area holds the IP.BIN boot header. */
constexpr size_t SYSTEM_AREA_SECTORS = 16;
constexpr size_t SYSTEM_AREA_SIZE = SYSTEM_AREA_SECTORS * SECTOR;

/** Represents the Primary Volume Descriptor (PVD), located at sector 16 of the
 * volume data regardless of the target disc LBA. */
struct Volume {
    bool valid = false;

    std::string volume_id;
    uint32_t volume_space = 0;
    uint32_t root_lba = 0;
    uint32_t root_length = 0;
};

Volume read_volume(const std::vector<uint8_t>& iso);

/**
 * @brief Represents the declared LBA of the root directory versus its actual
 * sector offset within the image buffer.
 *
 * The difference between these two values corresponds exactly to the MSINFO
 * start address the volume was authored for. Tools like `mkisofs -C 0,N` or
 * libisofs (with `ms_block = N`) offset every recorded LBA by N because the
 * track will physically be read starting at sector N on disc, even though the
 * raw image file begins at offset 0. The PVD therefore points to sector N+k,
 * while the root directory extent resides at sector k within the buffer;
 * computing (declared_lba - sector) recovers N.
 *
 * The actual sector offset is located by scanning the buffer rather than
 * guessing, providing built-in verification: the candidate extent must begin
 * with a valid "." directory record matching the LBA and size recorded in the
 * PVD. If no matching extent is found, `found` is set to false.
 */
struct RootDirectory {
    bool found = false;

    uint32_t declared_lba = 0;  /* LBA recorded in the PVD */
    uint32_t sector = 0;        /* Actual sector index within the buffer */
    uint32_t length = 0;
};

RootDirectory locate_root_directory(const std::vector<uint8_t>& iso);

/** Returns the MSINFO offset for which the volume was authored, or std::nullopt
 * if the root directory could not be located. Computes (declared_lba - sector). */
std::optional<uint32_t> detect_msinfo(const std::vector<uint8_t>& iso);

/**
 * @brief An entry within the root directory.
 *
 * The ISO9660 version suffix (e.g. ";1") is stripped from `name`. The remaining
 * characters retain their exact case as recorded in the directory record.
 * Callers comparing names can decide whether to perform case-sensitive or
 * case-insensitive matching (see boot_checks.cpp).
 */
struct Entry {
    std::string name;
    uint32_t lba = 0;
    uint32_t size = 0;
    bool is_dir = false;
};

/** Returns all root directory entries (excluding "." and "..") in the order
 * they appear on disc. Returns an empty vector if the root directory cannot
 * be located or contains no files. */
std::vector<Entry> read_root_directory(const std::vector<uint8_t>& iso);

}
