/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Manages output file naming, target descriptions, and pre-flight
 * overwrite validation.
 *
 * Centralizes output path resolution across supported disc formats:
 * CDI and NRG generate a single output file, MDS/MDF generates a descriptor
 * and data container pair, GDI generates a .gdi descriptor along with multiple
 * raw or cooked track files, and `-I/--dump-iso` generates an additional .iso
 * track dump.
 */

#include <filesystem>
#include <string>

/**
 * @brief Returns a human-readable summary of the files that will be generated.
 *
 * Displays a single file name for CDI/NRG, the `.mds + .mdf` pair for Alcohol 120%,
 * or the `.gdi` descriptor and track folder for GD-ROM images.
 * Used in build plan summaries and completion messages.
 */
std::string output_files_description(const std::string& output_path);

/**
 * @brief Checks whether target output files already exist, preventing accidental data loss.
 *
 * If any target output files exist and `--allow-overwrite` was not specified,
 * this function reports the conflicting files and returns false.
 * If `--allow-overwrite` is enabled, an informational note is logged and execution proceeds.
 *
 * @param output_path Target output path specified by the user.
 * @return true if the build may proceed, false if blocked by existing files.
 */
bool check_output_files(const std::string& output_path);
