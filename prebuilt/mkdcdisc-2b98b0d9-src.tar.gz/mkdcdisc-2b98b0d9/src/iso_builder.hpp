/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief ISO9660 filesystem image construction via libisofs.
 *
 * Handles Primary Volume Descriptor (PVD) configuration, directory tree
 * ingestion, burn source streaming, and post-processing of specialized PVD
 * fields required for Dreamcast optical discs.
 */

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#define LIBISOFS_WITHOUT_LIBBURN yes
#include <libisofs.h>

#include "ip_boot.hpp"
#include "progress.h"

/**
 * @brief Standard 8.3 filenames referenced by ISO9660 Primary Volume Descriptors.
 *
 * Conforms to retail GD-ROM conventions in the low-density area. Note that
 * `COPYRIGH.TXT` is truncated to 8 characters per ISO9660 Level 1 / 8.3 limits.
 *
 * Using fixed target filenames prevents naming drift caused by libisofs
 * transliterating user-provided paths.
 */
extern const char* const PVD_COPYRIGHT_FILE;
extern const char* const PVD_ABSTRACT_FILE;
extern const char* const PVD_BIBLIO_FILE;

/**
 * @brief Tracks presence of PVD-referenced informational text files on the volume.
 *
 * Low-density GD-ROM areas include all three by default; other formats include
 * only files explicitly requested by CLI options.
 */
struct VolumeTextFiles {
    bool copyright = false;
    bool abstract = false;
    bool biblio = false;

    bool any() const { return copyright || abstract || biblio; }
};

/**
 * @brief Resolves the ISO9660 Volume Identifier label.
 *
 * Derived from `-V/--volume-label` or the IP.BIN title. Sanitized to uppercase
 * alphanumeric characters and underscores [A-Z0-9_], truncated to the standard
 * 32-character ISO9660 volume label limit.
 */
std::string volume_label();

/** Returns the ISO9660 Data Preparer Identifier string (identifying mkdcdisc version). */
std::string mkdcdisc_preparer_id();

/**
 * @brief RAII wrapper managing the lifecycle of an IsoImage pointer.
 *
 * Ensures `iso_image_unref()` is invoked upon scope exit, preventing leaks
 * across early returns and error conditions.
 *
 * Note: Once `iso_image_create_burn_source()` is called, the burn source holds
 * an internal reference, keeping the image alive as long as the source exists.
 */
class IsoImageRef {
public:
    explicit IsoImageRef(IsoImage* image): image_(image) {}
    ~IsoImageRef() { if(image_) iso_image_unref(image_); }

    IsoImageRef(const IsoImageRef&) = delete;
    IsoImageRef& operator=(const IsoImageRef&) = delete;

    IsoImage* get() const { return image_; }

private:
    IsoImage* image_;
};

/** Initializes a new IsoImage instance configured with metadata from the IP.BIN. */
IsoImageRef new_iso_image(const IPBin& ip_bin, const std::string& volume_label);

/**
 * @brief Constructs IsoWriteOpts for image serialization.
 *
 * @param ip_bin System area boot header (32 KB).
 * @param ms_block Starting physical LBA of the session (for multisession LBA patching).
 * @param joliet Whether to generate Joliet extension trees (enabled for MIL-CD, disabled for GDI).
 */
IsoWriteOpts* create_iso_write_opts(const IPBin& ip_bin, size_t ms_block, bool joliet = true);

/**
 * @brief Streams and drains a burn_source into an in-memory byte buffer, then frees the source.
 *
 * Throws std::runtime_error if libisofs encounters an unrecoverable read error.
 * Pre-allocates buffer memory to minimize reallocations during large track transfers.
 *
 * @param burn_src The active burn source to stream from.
 * @param progress Optional progress callback receiver.
 * @param reserve_at_least Minimum initial buffer capacity reservation.
 * @return Complete ISO filesystem image bytes.
 */
std::vector<uint8_t> read_burn_source(struct burn_source* burn_src,
                                      const progress_t* progress = nullptr,
                                      uint64_t reserve_at_least = 0);

/**
 * @brief Returns the total byte size of an image to be produced by burn_src, then frees the source.
 *
 * Queries final layout dimensions calculated by libisofs during image setup
 * without reading actual file contents into memory.
 */
uint64_t measure_burn_source(struct burn_source* burn_src);

/**
 * @brief Injects an in-memory buffer as a file into the ISO directory tree.
 *
 * @return True on success; false if the node cannot be added (e.g. name conflict).
 */
bool add_iso_file_from_memory(IsoDir* parent, const char* name, const std::string& content);

/**
 * @brief Generates or attaches volume text files (copyright, abstract, bibliography).
 *
 * @param root Root directory node of the ISO tree.
 * @param ip_bin Boot metadata used for generating default file texts.
 * @param generate_defaults Whether to synthesize missing text files automatically.
 * @return VolumeTextFiles structure indicating which files were successfully attached.
 */
VolumeTextFiles add_volume_text_files(IsoDir* root, const IPBin& ip_bin, bool generate_defaults);

/**
 * @brief Post-patches PVD text file identifiers in the generated ISO image.
 *
 * Directly restores periods in filenames (e.g. `COPYRIGH.TXT`) within PVD fields,
 * bypassing libisofs d-character filtering that replaces periods with underscores.
 */
void patch_pvd_file_ids(std::vector<uint8_t>& iso, const VolumeTextFiles& present);

/**
 * @brief Overrides the Volume Space Size field in the Primary Volume Descriptor (ECMA-119 8.4.8).
 *
 * In low-density GD-ROM areas, updates the PVD sector count to encompass the full
 * low-density area through the end of track 2, matching retail disc layout.
 */
void patch_pvd_volume_space(std::vector<uint8_t>& iso, uint32_t sectors);

/**
 * @brief Generates a zero-filled sparse/filler file of the requested size.
 *
 * Writes data in 64 KB chunks to minimize memory consumption.
 */
void write_zero_file(const std::filesystem::path& path, std::uintmax_t bytes,
                     const progress_t* progress = nullptr);
