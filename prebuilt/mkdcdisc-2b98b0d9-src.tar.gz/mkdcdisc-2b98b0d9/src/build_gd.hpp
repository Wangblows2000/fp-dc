/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Disc image generator for Sega Dreamcast GD-ROM (.gdi) format.
 *
 * Generates a standard GDI descriptor file along with raw track image files,
 * matching original pressed Dreamcast GD-ROM geometry and structure.
 *
 * A physical GD-ROM disc contains two distinct optical zones:
 * - Low-Density Area (LDA): Compatible with standard CD drives. Houses track 1
 *   (ISO9660 filesystem with warning audio/text files) and track 2 (CDDA warning track).
 * - High-Density Area (HDA): Starts at fixed sector LBA 45000. Contains the primary
 *   game filesystem (track 3) and optional GD-DA audio tracks.
 */

#include <filesystem>

/**
 * @brief Builds a GD-ROM (`.gdi`) disc image set from an input directory.
 *
 * Produces the low-density session (data track + audio warning track), followed by
 * the high-density ISO9660 filesystem starting at LBA 45000 (`CD_GD_START_LBA`).
 * Logical filesystem sectors are authored at 2048 bytes; physical output sector sizing
 * (2048 vs 2352 raw) is governed by `--gdi-sector-size`.
 *
 * @param input_dir Directory containing files to author into the high-density area.
 * @return True if the GDI image set was written successfully; false otherwise.
 * @see build_cd() for MIL-CD (CD-R) disc image generation.
 */
bool build_gd(const std::filesystem::path& input_dir);
