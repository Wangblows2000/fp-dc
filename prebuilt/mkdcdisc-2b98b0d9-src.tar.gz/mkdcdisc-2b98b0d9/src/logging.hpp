/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Verbosity levels and structured log stream formatting.
 *
 * `-v/--verbosity` accepts integer levels from 0 to 3 cumulatively:
 *
 *   0  -q/--quiet   Suppresses stdout completely. Only essential output
 *                   (-M/--print-msinfo) and error diagnostics (on stderr) are emitted.
 *   1  (default)    One line per major build phase describing high-level actions.
 *                   Uses interactive ProgressLines (see `progress.hpp`), which render
 *                   as a checklist and update in-place with percentage counters.
 *   2  -v 2         Detailed logging per item within a phase: each file loaded,
 *                   each track added, and applicable option overrides.
 *   3  -v 3         Internal debugging information: sector layouts, memory addresses,
 *                   staging directories, and sort weights. Useful for troubleshooting.
 *
 * Call sites stream directly to loggers rather than manually checking verbosity levels:
 *
 *     logging::verbose() << "Loading " << elf_name;
 *
 * Trailing `std::endl` is unnecessary because `Line` automatically flushes and appends
 * a newline on destruction. When verbosity is below the line's threshold, formatting is
 * bypassed entirely so that disabled debug logs incur zero overhead.
 *
 * Each line writes to its own isolated buffer. This prevents sticky stream manipulators
 * (such as `std::hex` or `std::setw`) on `std::cout` from unintentionally affecting
 * subsequent log output.
 */

#include <iostream>
#include <sstream>

namespace logging {

/**
 * @brief Indentation string for detailed messages within a build phase.
 *
 * Visually associates sub-steps with their parent phase. Also shared with
 * `progress.hpp` to align the "Done." marker when intermediate detail interrupted
 * an in-place progress line.
 */
inline constexpr const char* DETAIL_INDENT = "  ";

enum class Level {
    Quiet   = 0,
    Normal  = 1,
    Verbose = 2,
    Debug   = 3,
};

/** Returns the resolved verbosity level, clamped to the valid range. */
Level level();

/**
 * @brief Checks whether messages at level `at` will be output.
 *
 * Callers typically use the logging helpers directly. This function is intended
 * for skipping expensive non-logging work, such as computing detailed layout dumps.
 */
bool enabled(Level at);

/**
 * @brief Represents a single log line, formatted in full and emitted upon destruction.
 *
 * Instances are created via `verbose()`, `debug()`, or `note()`.
 */
class Line {
public:
    Line(bool enabled, std::ostream& out);
    ~Line();

    Line(const Line&) = delete;
    Line& operator=(const Line&) = delete;

    template<typename T>
    Line& operator<<(const T& value) {
        if(enabled_) {
            buffer_ << value;
        }
        return *this;
    }

    /** Supports standard manipulators (e.g. `std::hex`, `std::setw`), scoped
     * strictly to the current line buffer. */
    Line& operator<<(std::ostream& (*manip)(std::ostream&)) {
        if(enabled_) {
            buffer_ << manip;
        }
        return *this;
    }

    Line& operator<<(std::ios_base& (*manip)(std::ios_base&)) {
        if(enabled_) {
            buffer_ << manip;
        }
        return *this;
    }

private:
    bool enabled_;
    std::ostream& out_;
    std::ostringstream buffer_;
};

/** Level::Verbose: logs an item or operation within the current phase. */
Line verbose();

/** Level::Debug: logs internal debugging details of the phase. */
Line debug();

/**
 * @brief Level::Normal informational note not tied to a progress phase.
 *
 * Emits notes about general build context (such as the target layout of an external ISO).
 * Standard build phases use `ProgressLine` instead.
 */
Line note();

/**
 * @brief Installs a custom buffer on `std::cerr` to prevent diagnostics from clobbering
 *        in-progress terminal status lines.
 *
 * Ensures that any diagnostic emitted during an active build phase completes any
 * open progress line first, printing the diagnostic cleanly on a new line.
 *
 * Call once from `main()` after `term::configure()`. Idempotent.
 */
void install_diagnostic_guard();

}
