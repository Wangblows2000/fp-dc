/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Cross-platform path string conversion helper.
 *
 * On Windows, `std::filesystem::path::c_str()` yields `const wchar_t*`. This macro
 * produces a standard narrow C-string pointer (`const char*`) with a lifetime matching
 * the enclosing expression.
 */
#ifdef _WIN32
#define PATH_TO_CSTR(p) (p).string().c_str()
#else
#define PATH_TO_CSTR(p) (p).c_str()
#endif
