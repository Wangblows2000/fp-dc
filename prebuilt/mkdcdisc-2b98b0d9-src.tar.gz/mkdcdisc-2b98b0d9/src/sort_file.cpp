/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Sort file parsing and application: see sort_file.hpp. */

#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include "cli.hpp"
#include "logging.hpp"
#include "sort_file.hpp"
#include "terminal.hpp"

/* Weights indexed by target absolute disc path, as parsed from a sort file. */
using SortWeights = std::map<std::string, int>;

/* Formats a single node line for tree debug logging. Lines are fully assembled
 * before being sent to the logger so that indentations align correctly with the
 * logger's current prefix formatting. */
static void print_node_info(IsoNode *node, int depth) {
    if(!node) {
        return;
    }

    const char *name = iso_node_get_name(node);
    if(!name)
        return;

    std::ostringstream line;
    line << std::string(depth * 2, ' ') << name;

    if(iso_node_get_type(node) == LIBISO_DIR) {
        line << "/";
    } else if(iso_node_get_type(node) == LIBISO_FILE) {
        IsoFile *file = (IsoFile*)(node);
        if(file) {
            int weight = iso_file_get_sort_weight(file);
            line << " [Weight: " << weight << "]";
        }
    }

    logging::debug() << line.str();
}

static void traverse_directory(IsoDir *dir, int depth) {
    if(!dir) {
        return;
    }

    IsoNode *node;
    IsoDirIter *iter;

    int result = iso_dir_get_children(dir, &iter);
    if(result < 0) {
        return;
    }

    while(iso_dir_iter_next(iter, &node) == 1) {
        if(!node) {
            continue;
        }

        print_node_info(node, depth);

        if(iso_node_get_type(node) == LIBISO_DIR) {
            IsoDir *subdir = (IsoDir*)node;
            traverse_directory(subdir, depth + 1);
        }
    }

    iso_dir_iter_free(iter);
}

static std::string construct_path(const std::vector<std::string> &parents, const std::string &current) {
    std::ostringstream full_path;

    for(const auto &dir : parents) {
        full_path << "/" << dir;
    }

    if(!current.empty()) {
        full_path << "/" << current;
    }

    return full_path.str();
}

/* Recursively traverses the directory tree to apply matching sort weights.
 *
 * `matched` tracks the disc paths that matched an entry in `weights`, allowing
 * `apply_sort_file()` to detect unused or erroneous sort file entries.
 * `weighted` maps visited nodes to their assigned weights. */
static void traverse_and_set_weights(
    IsoDir *dir,
    const SortWeights &weights,
    std::set<std::string> &matched,
    std::map<IsoNode*, int> &weighted,
    std::vector<std::string> parent_dirs = {}
) {
    if(!dir || weights.empty()) {
        return;
    }

    IsoNode *node;
    IsoDirIter *iter;

    int result = iso_dir_get_children(dir, &iter);
    if(result < 0) {
        return;
    }

    while(iso_dir_iter_next(iter, &node) == 1) {
        if(!node) {
            continue;
        }

        const char *name = iso_node_get_name(node);
        if(!name) {
            continue;
        }

        std::string current_name(name);
        std::string child_full_path = construct_path(parent_dirs, current_name);

        auto child_it = weights.find(child_full_path);
        if(child_it != weights.end()) {
            iso_node_set_sort_weight(node, child_it->second);
            matched.insert(child_full_path);
            weighted[node] = child_it->second;
        }

        if(iso_node_get_type(node) == LIBISO_DIR) {
            auto updated_parent_dirs = parent_dirs;
            updated_parent_dirs.push_back(current_name);

            traverse_and_set_weights((IsoDir *)node, weights, matched, weighted,
                                     updated_parent_dirs);
        }
    }

    iso_dir_iter_free(iter);
}

/* Parses a sort file into a map of disc paths to integer weights.
 *
 * Unparseable lines generate warnings rather than terminating the build or
 * failing silently. Silent failures could result in suboptimal file placement
 * and degraded game loading times without the user knowing why.
 *
 * `report` controls diagnostic printing to avoid repeating warnings on
 * multiple passes (see DIAGNOSED_OPTIONS). */
static SortWeights parse_sort_file(const std::string &file_path, bool report) {
    SortWeights weights;
    std::ifstream file(file_path);

    if(!file.is_open()) {
        if(report) {
            std::cerr << term::warning << "could not open the sort file " << file_path
                      << "; the disc contents keep their default order." << std::endl;
        }
        return weights;
    }

    std::string line;
    int line_number = 0;

    while(std::getline(file, line)) {
        ++line_number;

        if(line.empty() || line[0] == '#') {
            continue;
        }

        std::istringstream iss(line);
        std::string path;
        int weight;

        /* Extract path and weight from the line. Notice that whitespace separates
         * tokens, so paths containing spaces will fail to parse here. */
        if(!(iss >> path >> weight)) {
            if(report) {
                std::cerr << term::warning << "ignoring line " << line_number << " of the sort file "
                          << file_path << ", which is not a path followed by a weight (a path "
                             "cannot contain spaces here): " << line << std::endl;
            }
            continue;
        }

        weights[path] = weight;
    }

    file.close();

    return weights;
}

/* Threshold above which unmatched sort file entries are summarized with a count
 * instead of listed individually (unless verbose logging is enabled). */
static const size_t UNMATCHED_LIST_LIMIT = 5;

/* Warns about sort file entries that do not match any path in the filesystem.
 *
 * A common cause is specifying local filesystem paths rather than target disc
 * paths (starting with "/"), or mistaking the directory hierarchy created by
 * `-d` (which preserves the source directory name) versus `-D` (which flattens it). */
static void report_unmatched_entries(const std::string &file_path,
                                     const std::vector<std::string> &unmatched) {
    /* Detailed listing is used when the count is small or when verbose logging is requested. */
    const bool list_them = unmatched.size() <= UNMATCHED_LIST_LIMIT
                        || logging::enabled(logging::Level::Verbose);

    if(list_them) {
        for(const auto &path : unmatched) {
            std::cerr << term::warning << "the sort file " << file_path << " gives a weight to "
                      << path << ", which is not on the disc, so it has no effect." << std::endl;
        }
    } else {
        std::cerr << term::warning << unmatched.size() << " entries of the sort file "
                  << file_path << " name nothing on the disc and have no effect. "
                     "Re-run with -v 2 to list them." << std::endl;
    }

    std::cerr << term::note << "sort file paths are those of the disc being built, and start "
                               "with \"/\": -d keeps the name of the directory it was given, "
                               "-D does not." << std::endl;
}

/* Keeps track of options whose sort files have already produced diagnostics,
 * preventing duplicate warnings during multi-pass builds (such as GD-ROM HDA
 * layout generation in build_gd.cpp). */
static std::set<std::string> DIAGNOSED_OPTIONS;

std::map<IsoNode*, int> apply_sort_file(const char *option, IsoDir *root) {
    /* Collects each node with an applied weight and its final value, so that
     * `--duplicates-once` can propagate the highest weight across shared extents. */
    std::map<IsoNode*, int> weighted;

    if(!root || !OPTS.count(option)) {
        return weighted;
    }

    const bool report = logging::enabled(logging::Level::Normal)
                     && DIAGNOSED_OPTIONS.insert(option).second;

    SortWeights weights = parse_sort_file(OPTS[option][0], report);
    if(weights.empty()) {
        return weighted;
    }

    if(logging::enabled(logging::Level::Debug)) {
        logging::debug() << "--" << option << " weights before:";
        traverse_directory(root, 0);
    }

    /* Set of paths successfully matched on the disc. */
    std::set<std::string> matched;

    /* Handle root directory "/" weight if specified. This is handled directly
     * here because tree traversal visits children rather than the root itself. */
    auto it = weights.find("/");
    if(it != weights.end()) {
        iso_node_set_sort_weight((IsoNode *)root, it->second);
        matched.insert("/");
        weighted[(IsoNode *)root] = it->second;
    }

    traverse_and_set_weights(root, weights, matched, weighted);

    if(report) {
        std::vector<std::string> unmatched;
        for(const auto &entry : weights) {
            if(!matched.count(entry.first)) {
                unmatched.push_back(entry.first);
            }
        }

        if(!unmatched.empty()) {
            report_unmatched_entries(OPTS[option][0], unmatched);
        }
    }

    if(logging::enabled(logging::Level::Debug)) {
        logging::debug() << "--" << option << " weights after:";
        traverse_directory(root, 0);
    }

    return weighted;
}
