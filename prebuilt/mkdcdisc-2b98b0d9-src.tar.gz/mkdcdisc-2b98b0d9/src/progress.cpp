/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Terminal progress lines: see progress.hpp. */

#include <iomanip>
#include <iostream>
#include <sstream>

#include "interrupt.hpp"
#include "logging.hpp"
#include "progress.hpp"
#include "terminal.hpp"

/* Column offset where the status field begins, ensuring percentages and "Done."
 * markers align consistently across all steps regardless of label lengths. */
static const size_t STATUS_COLUMN = 34;

/* The innermost active progress line. See `active_progress_line()`. */
static ProgressLine* ACTIVE_LINE = nullptr;

namespace {

/* Declared extern "C" to provide a C-compatible function pointer for `progress_t`. */
extern "C" int progress_line_trampoline(void* user_data, uint64_t done, uint64_t total) {
    static_cast<ProgressLine*>(user_data)->report(done, total);

    /* Return interruption state regardless of whether progress is rendered on screen.
     * Running in quiet mode (`-q`) suppresses output, but not Ctrl+C cancellation. */
    return interrupted() ? 1 : 0;
}

}

ProgressLine* active_progress_line() {
    return ACTIVE_LINE;
}

ProgressLine::ProgressLine(std::string label):
    progress_{progress_line_trampoline, this},
    label_(std::move(label)),
    enabled_(logging::enabled(logging::Level::Normal)),
    interactive_(term::is_terminal(std::cout)),
    last_percent_(-1),
    finished_(false),
    line_open_(false),
    previous_(ACTIVE_LINE) {

    if(label_.size() < STATUS_COLUMN) {
        label_.resize(STATUS_COLUMN, ' ');
    } else {
        label_ += ' ';
    }

    if(enabled_) {
        std::cout << label_ << std::flush;
        line_open_ = true;
    }

    ACTIVE_LINE = this;
}

ProgressLine::~ProgressLine() {
    /* Only close the line if it was left unterminated without a newline. */
    if(enabled_ && !finished_ && line_open_) {
        std::cout << std::endl;
    }

    ACTIVE_LINE = previous_;
}

void ProgressLine::break_line() {
    if(!enabled_ || !line_open_) {
        return;
    }

    std::cout << std::endl;
    line_open_ = false;

    /* Reset `last_percent_` so that subsequent updates redraw on the new line. */
    last_percent_ = -1;
}

void ProgressLine::draw_status(const std::string& status) {
    /* Re-printing the label along with the status ensures visual correctness even
     * if external output was written in the interim. When starting a fresh line,
     * omit `\r` to avoid overwriting prior log text. */
    if(line_open_) {
        std::cout << '\r';
    }

    std::cout << label_ << status << std::flush;
    line_open_ = true;
}

void ProgressLine::report(uint64_t done, uint64_t total) {
    if(!enabled_ || !interactive_ || finished_ || total == 0) {
        return;
    }

    /* Clamp progress calculation to 100% to guard against any small rounding overflow. */
    int percent = done >= total ? 100 : (int) ((done * 100) / total);

    if(percent == last_percent_) {
        return;
    }
    last_percent_ = percent;

    std::ostringstream status;
    status << std::setw(3) << percent << '%';
    draw_status(status.str());
}

void ProgressLine::finish() {
    if(!enabled_ || finished_) {
        return;
    }
    finished_ = true;

    /* Relinquish ownership of sub-step logging immediately upon completion. */
    ACTIVE_LINE = previous_;

    if(!line_open_) {
        /* When detailed sub-steps were printed below the original label, complete
         * the step by appending an indented "Done." marker. */
        std::cout << logging::DETAIL_INDENT << term::styled(term::Style::Success, "Done.") << std::endl;
        return;
    }

    /* Overwrite the previous percentage counter with "Done." */
    if(interactive_ && last_percent_ >= 0) {
        std::cout << '\r' << label_;
    }

    std::cout << term::styled(term::Style::Success, "Done.") << std::endl;
    line_open_ = false;
}
