/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Disc assembly and output: see disc_layout.hpp. */

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>

#include "audio.hpp"
#include "cli.hpp"
#include "disc_layout.hpp"
#include "logging.hpp"
#include "interrupt.hpp"
#include "output_files.hpp"
#include "paths.hpp"
#include "progress.hpp"
#include "terminal.hpp"

bool add_audio_session(cd_session_t* session0, bool log) {
    if(OPTS.count("cdda-track")) {
        size_t track_idx = 0;
        for(auto& filename: OPTS["cdda-track"]) {
            ++track_idx;
            auto data_maybe = load_audio_track(filename);
            if(!data_maybe) {
                return false;
            }
            auto data = data_maybe.value();

            size_t const audio_sector_size = 2352;
            size_t const audio_bytes_per_second = 176400;
            size_t const minimum_track_sectors = 300;
            size_t const minimum_track_size = minimum_track_sectors * audio_sector_size;
            size_t const minimum_track_duration = minimum_track_size / audio_bytes_per_second;

            if (data.size() < minimum_track_size) {
                std::cerr << term::error << "audio file " << filename << " is too short - it must be at least " << minimum_track_size << " bytes (" << minimum_track_duration << " seconds)" << std::endl;
                return false;
            }

            cd_new_track(session0, TRACK_TYPE_AUDIO, &data[0], data.size());

            if(log) {
                logging::note() << "Added track " << track_idx << " (" << data.size()
                                << " bytes) from " << filename;
            }
        }
    } else {
        cd_new_track_blank(session0, TRACK_TYPE_AUDIO, 2352 * 302); /* 4 seconds of audio */
    }

    return true;
}

size_t estimate_padding_sectors(const cd_image_t* image_so_far, const std::filesystem::path& data_dir) {
    auto dir_size = [](const std::filesystem::path& dir) -> std::size_t {
        std::size_t size{ 0 };
        for(const auto& entry : std::filesystem::recursive_directory_iterator(dir)) {
            if(entry.is_regular_file() && !entry.is_symlink()) {
                size += entry.file_size();
            }
        }
        return size;
    };

    const std::size_t iso_padding = 10 * 1024 * 1024;  /* 10M for ISO structures */
    std::size_t used = cd_image_length_in_sectors(image_so_far);
    used += dir_size(data_dir) / 2048;
    used += iso_padding / 2048;

    return used >= CD_74MIN_SECTORS ? 0 : CD_74MIN_SECTORS - used;
}

/* Warns when the assembled disc image exceeds the nominal capacity of an 80-minute CD-R.
 * Emits a non-fatal warning, as non-standard 90-minute and 99-minute CD-R media exist. */
static void warn_if_over_capacity(const cd_image_t* img) {
    const size_t sectors = cd_image_length_in_sectors(img);

    if(sectors <= CD_80MIN_SECTORS || !logging::enabled(logging::Level::Normal)) {
        return;
    }

    std::cerr << term::warning << "the disc is " << sectors << " sectors, "
              << (sectors - CD_80MIN_SECTORS) << " past the " << CD_80MIN_SECTORS
              << " an 80-minute CD-R holds. It will not burn to standard media."
              << std::endl;
}

/* Configures data tracks and sessions using the authored ISO image.
 * Shared by standard internal builds and external ISO modes. */
void add_data_track_sessions(cd_image_t* img, const std::vector<uint8_t>& iso_data, bool data_data) {
    if(data_data) {
        /* Data/Data layout:
         * - Session 1: Full ISO data track authored at MSINFO 0 (LBA 0).
         * - Session 2: "Boot head" duplicating the first 18 sectors of the ISO
         *   (16 sectors of IP.BIN system area + 2 sectors of volume descriptors),
         *   padded to the 300-sector track minimum.
         *
         * The image writers position session 2 at (session 1 length + 11400 sectors)
         * matching MSINFO_OFFSET_BASE in reference tools. */
        cd_session_t* session1 = cd_new_session(img);
        /* Use borrowed buffer: iso_data is held by the caller until write_disc_image() finishes. */
        cd_track_t* data = cd_new_track_borrowed(session1, TRACK_TYPE_DATA,
            &iso_data[0], iso_data.size());
        cd_track_set_mode(data, TRACK_MODE_XA_MODE2_FORM1);
        cd_track_set_postgap_sectors(data, 2);

        const size_t boot_head_sectors  = 18;   /* IP.BIN + volume descriptors */
        const size_t sector_user_bytes  = 2048; /* Mode2/Form1 user data */
        const size_t min_track_sectors  = 300;  /* Minimum CD track length */

        std::vector<uint8_t> boot_head(min_track_sectors * sector_user_bytes, 0);
        size_t copy_bytes = std::min(boot_head_sectors * sector_user_bytes, iso_data.size());
        std::copy(iso_data.begin(), iso_data.begin() + copy_bytes, boot_head.begin());

        cd_session_t* session2 = cd_new_session(img);
        /* Copied track: boot_head is allocated on the stack and destroyed on function exit. */
        cd_track_t* boot = cd_new_track(session2, TRACK_TYPE_DATA, &boot_head[0], boot_head.size());
        cd_track_set_mode(boot, TRACK_MODE_XA_MODE2_FORM1);
        cd_track_set_postgap_sectors(boot, 2);
    } else {
        /* Audio/Data layout (default): session 1 contains audio tracks;
         * session 2 contains the primary data track starting at the post-session offset. */
        cd_session_t* session1 = cd_new_session(img);
        cd_track_t* data = cd_new_track_borrowed(session1, TRACK_TYPE_DATA,
            &iso_data[0], iso_data.size());
        cd_track_set_mode(data, TRACK_MODE_XA_MODE2_FORM1);
        cd_track_set_postgap_sectors(data, 2);
    }
}

/* Ingests two pre-mastered ISO images for merged-data layout (`-L/--disc-layout merged-data`).
 * Both tracks are added directly to the image descriptor without modification. */
void add_merged_data_sessions(cd_image_t* img,
                                    const std::vector<uint8_t>& iso1_data,
                                    const std::vector<uint8_t>& iso2_data) {
    /* Buffers are borrowed to avoid duplicating full ISO images in memory. */
    cd_session_t* session1 = cd_new_session(img);
    cd_track_t* track1 = cd_new_track_borrowed(session1, TRACK_TYPE_DATA,
        &iso1_data[0], iso1_data.size());
    cd_track_set_mode(track1, TRACK_MODE_XA_MODE2_FORM1);
    cd_track_set_postgap_sectors(track1, 2);

    cd_session_t* session2 = cd_new_session(img);
    cd_track_t* track2 = cd_new_track_borrowed(session2, TRACK_TYPE_DATA,
        &iso2_data[0], iso2_data.size());
    cd_track_set_mode(track2, TRACK_MODE_XA_MODE2_FORM1);
    cd_track_set_postgap_sectors(track2, 2);
}

/* Computes session length in sectors for a single XA Mode 2 Form 1 data track
 * with standard pregap (150) and postgap (2) overhead. */
size_t data_session_length_in_sectors(uintmax_t data_size_bytes, bool is_first_session) {
    const size_t SECTOR_USER_BYTES = 2048;
    const size_t LEAD_IN_SECTORS = 4500;
    const size_t LEAD_OUT_SECTORS = is_first_session ? 6750 : 2250;
    const size_t PREGAP_SECTORS = 150;
    const size_t POSTGAP_SECTORS = 2;

    size_t track_sectors = (size_t) ((data_size_bytes + SECTOR_USER_BYTES - 1) / SECTOR_USER_BYTES);
    return LEAD_IN_SECTORS + LEAD_OUT_SECTORS + PREGAP_SECTORS + track_sectors + POSTGAP_SECTORS;
}

/* Serializes the disc image to the target container format (CDI, MDS, NRG, GDI). */
bool write_disc_image(cd_image_t* img, const std::string& output_path) {
    bool written = false;

    const std::string wrote_what = output_files_description(output_path);

    /* Perform capacity check for CD formats before beginning sector write. */
    if(output_format() != "gdi") {
        warn_if_over_capacity(img);
    }

    ProgressLine writing("Writing disc image...");
    cd_image_set_progress(img, writing.progress());

    if(output_format() == "mds") {
        auto mds_path = std::filesystem::path(output_path).replace_extension("mds");
        auto mdf_path = std::filesystem::path(output_path).replace_extension("mdf");

        FILE* mds = fopen(PATH_TO_CSTR(mds_path), "wb"); // nosemgrep: toctou-race-condition
        FILE* mdf = fopen(PATH_TO_CSTR(mdf_path), "wb"); // nosemgrep: toctou-race-condition

        if(mds && mdf) {
            written = cd_write_to_mds(img, mds, mdf);
        }

        if(mds) fclose(mds);
        if(mdf) fclose(mdf);
    } else if(output_format() == "nrg") {
        const char* path = output_path.c_str();
        FILE* output = fopen(path, "wb"); // nosemgrep: toctou-race-condition

        if(output) {
            written = cd_write_to_nrg(img, output);
            fclose(output);
        }
    } else if(output_format() == "gdi") {
        auto gdi_path = std::filesystem::path(output_path);

        std::error_code ec;
        auto track_dir = gdi_path.parent_path();
        if(!track_dir.empty()) {
            std::filesystem::create_directories(track_dir, ec);
        }

        FILE* gdi_file = fopen(PATH_TO_CSTR(gdi_path), "wb"); // nosemgrep: toctou-race-condition

        if(gdi_file) {
            written = cd_write_to_gdi(img, gdi_file, PATH_TO_CSTR(track_dir), gdi_sector_size());
            fclose(gdi_file);
        }
    } else {
        const char* path = output_path.c_str();
        FILE* output = fopen(path, "wb"); // nosemgrep: toctou-race-condition

        if(output) {
            written = cd_write_to_cdi(img, output, path);
            fclose(output);
        }
    }

    if(written) {
        writing.finish();
        logging::note() << "Wrote " << wrote_what;
    } else if(interrupted()) {
        std::cerr << term::program_prefix() << "Left incomplete: " << wrote_what
                  << std::endl;
    }

    cd_free_image(&img);

    return written;
}

/* See disc_layout.hpp. Warns when the size is not a whole number of 2048-byte
 * sectors. Shared by the External ISO Mode and merged-data paths. */
bool read_iso_file(const std::filesystem::path& path, std::vector<uint8_t>& out_data) {
    std::ifstream in(path, std::ios::binary | std::ios::ate);
    if(!in) {
        std::cerr << term::error << "unable to open ISO file: " << path << std::endl;
        return false;
    }

    std::streamsize size = in.tellg();
    if(size <= 0) {
        std::cerr << term::error << "ISO file is empty: " << path << std::endl;
        return false;
    }

    in.seekg(0, std::ios::beg);
    out_data.resize(size);
    if(!in.read(reinterpret_cast<char*>(&out_data[0]), size)) {
        std::cerr << term::error << "unable to read ISO file: " << path << std::endl;
        return false;
    }

    if(size % 2048 != 0 && logging::enabled(logging::Level::Normal)) {
        std::cerr << term::warning << "ISO size (" << size << " bytes) is not a multiple of "
                                      "2048; the file may not be a raw 2048-byte/sector ISO image." << std::endl;
    }

    return true;
}
