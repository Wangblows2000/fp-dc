/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* User-supplied input files: see input_files.hpp. */

#include <fstream>
#include <iostream>
#include <sstream>

#include "cli.hpp"
#include "input_files.hpp"
#include "interrupt.hpp"
#include "ip_boot.hpp"
#include "logging.hpp"
#include "paths.hpp"
#include "progress.hpp"
#include "terminal.hpp"
#include "third_party/elf_parser/elf_parser.hpp"
#include "third_party/scramble/scramble.h"




bool load_elf_file(const std::filesystem::path& elf_name, std::vector<char>& bin_data) {
    if(!std::filesystem::exists(elf_name)) {
        std::cerr << term::error << "ELF file does not exist: " << elf_name << std::endl;
        return false;
    }

    logging::verbose() << "Loading " << elf_name;

    auto elf_parser_ret = elfparser::Parser::Load(elf_name);
    if (!elf_parser_ret.has_value()) {
        std::cerr << term::error << "failed to load ELF " << elf_name << std::endl;
        return false;
    }
    auto elf_parser = elf_parser_ret.value();

    // Create BIN from  ELF
    if ( !elf_parser->fill_bin(bin_data)) {
        std::cerr << term::error << "failed to create BIN" << std::endl;
        return false;
    }

    return true;
}

bool load_bin_file(const std::filesystem::path& bin_path, std::vector<char>& bin_data) {
    if(!std::filesystem::exists(bin_path)) {
        std::cerr << term::error << "BIN file does not exist: " << bin_path << std::endl;
        return false;
    }

    logging::verbose() << "Loading " << bin_path;

    std::ifstream file;
    std::streamsize file_size = 0;

    file.open(bin_path, std::ios::binary | std::ios::ate);
    if (!file) {
        std::cerr << term::error << "unable to open BIN file: " << bin_path << std::endl;
        return false;
    }

    file_size = file.tellg();
    file.seekg(0, std::ios::beg);
    bin_data.resize(file_size);
    if (!file.read(&bin_data[0], file_size)) {
        std::cerr << term::error << "unable to read BIN file: " << bin_path << std::endl;
        file.close();
        return false;
    }
    file.close();

    return true;
}

/* Strips trailing directory separators from path.
 *
 * Trailing slashes added by shell auto-completion can cause issues:
 * `path.filename()` becomes empty, and certain C runtimes fail `stat()` queries
 * on directories with trailing slashes. */
static std::filesystem::path strip_trailing_separators(std::filesystem::path path) {
    while(path.has_relative_path() && path.filename().empty()) {
        path = path.parent_path();
    }

    return path;
}

/* Returns the path to the main executable source file specified by the user (-e/-b/-B). */
static std::filesystem::path main_executable_source() {
    for(const char* key: {"main-elf", "main-binary-unscrambled", "main-binary-scrambled"}) {
        if(OPTS.count(key)) {
            return OPTS[key][0];
        }
    }

    return {};
}

/* Returns the option key that supplied the main executable (-e/-b/-B). */
static const char* main_executable_option() {
    if(OPTS.count("main-elf")) {
        return "main-elf";
    }
    if(OPTS.count("main-binary-unscrambled")) {
        return "main-binary-unscrambled";
    }

    return "main-binary-scrambled";
}

/* Checks whether two filesystem paths refer to the exact same physical file
 * (e.g. resolving symlinks, relative path components, and Windows case differences). */
static bool is_same_file(const std::filesystem::path& a, const std::filesystem::path& b) {
    if(b.empty()) {
        return false;
    }

    std::error_code ec;
    return std::filesystem::equivalent(a, b, ec) && !ec;
}

/* Warns when a file matching the main executable source is skipped during data
 * track population to avoid storing redundant copies. */
static void warn_executable_not_added(const std::filesystem::path& path, const char* key) {
    if(!logging::enabled(logging::Level::Normal)) {
        return;
    }

    std::error_code ec;
    uintmax_t size = std::filesystem::file_size(path, ec);

    std::cerr << term::warning << "not adding " << path << " from " << option_label(key)
              << ": it is the " << option_label(main_executable_option())
              << " file, already on the disc as " << boot_filename();

    if(!ec) {
        std::cerr << " (saves " << size << " bytes)";
    }

    std::cerr << "." << std::endl;
}

/* Warns when a file in the data tree would conflict with the generated boot binary filename. */
static void warn_boot_filename_not_added(const std::filesystem::path& path, const char* key) {
    if(!logging::enabled(logging::Level::Normal)) {
        return;
    }

    std::cerr << term::warning << "not adding " << path << " from " << option_label(key)
              << ": " << boot_filename() << " is generated from "
              << option_label(main_executable_option())
              << ", and this copy would replace it." << std::endl;
}

/* Searches `dir` recursively for a file identical to `exe`, returning its relative path. */
static std::optional<std::filesystem::path> executable_within(
        const std::filesystem::path& dir, const std::filesystem::path& exe) {
    if(exe.empty()) {
        return std::nullopt;
    }

    std::error_code ec;
    auto walk = std::filesystem::recursive_directory_iterator(dir, ec);
    if(ec) {
        return std::nullopt;
    }

    for(const auto& entry: walk) {
        if(entry.is_directory(ec)) {
            continue;
        }

        if(is_same_file(entry.path(), exe)) {
            return std::filesystem::relative(entry.path(), dir);
        }
    }

    return std::nullopt;
}

/* Recursively copies directory `src` to `dst`, removing any copied file that is
 * identical to the main executable source to avoid duplicating the binary. */
static void copy_tree(const std::filesystem::path& src, const std::filesystem::path& dst,
                      const std::filesystem::path& exe, const char* key) {
    std::filesystem::copy(src, dst, std::filesystem::copy_options::recursive);

    if(auto relative_path = executable_within(src, exe)) {
        std::error_code ec;
        std::filesystem::remove(dst / *relative_path, ec);
        warn_executable_not_added(src / *relative_path, key);
    }
}

static bool copy_disc_contents(const std::filesystem::path& out,
                               const std::filesystem::path& exe);

bool gather_files(const std::filesystem::path& out, bool scramble_output) {
    std::vector<char> bin_data;
    bool source_is_scrambled = false;
    const std::filesystem::path exe = main_executable_source();

    /* Phase 1: Load main executable from ELF or binary. */
    {
        ProgressLine loading("Loading main executable...");

        if(OPTS.count("main-elf")) {
            load_elf_file(exe, bin_data);
        } else {
            load_bin_file(exe, bin_data);
            source_is_scrambled = OPTS.count("main-binary-scrambled") > 0;
        }

        if (!bin_data.size()) {
            std::cerr << term::error << "no bin data available, aborting..." << std::endl;
            return false;
        }

        logging::debug() << "Executable is " << bin_data.size() << " bytes"
                         << (source_is_scrambled ? ", already scrambled" : ", unscrambled");

        loading.finish();
    }

    /* Phase 2: Convert the executable scrambling if required by the target format. */
    {
        const bool converting = source_is_scrambled != scramble_output;
        std::string verb = !converting ? "Writing "
                         : scramble_output ? "Scrambling " : "Unscrambling ";

        ProgressLine converting_line(verb + boot_filename() + "...");

        std::vector<char> output_data;
        if(!converting) {
            output_data = bin_data;
        } else if (scramble_output) {
            output_data = scramble(bin_data);
        } else {
            output_data = unscramble(bin_data);
        }

        std::filesystem::path scrambled_path = out / boot_filename();

        std::ofstream output_stream;
        output_stream.open(scrambled_path, std::ios::binary);
        if (!output_stream.is_open())
        {
            std::cerr << term::error << "failed to open " << scrambled_path << std::endl;
            return false;
        }
        output_stream.write(&output_data[0], output_data.size());
        output_stream.close();

        logging::debug() << "Wrote " << output_data.size() << " bytes to " << scrambled_path;

        converting_line.finish();
    }

    return copy_disc_contents(out, exe);
}

/* Copies user-specified files and directory trees into the staging directory. */
static bool copy_disc_contents(const std::filesystem::path& out,
                               const std::filesystem::path& exe) {
    if(!OPTS.count("directory") && !OPTS.count("directory-contents") && !OPTS.count("file")) {
        logging::verbose() << "No -d/-D/-f contents given; the data track holds only "
                           << boot_filename();
        return true;
    }

    ProgressLine gathering("Gathering input files...");

    if(OPTS.count("directory")) {
        for(const std::filesystem::path given: OPTS["directory"]) {
            if(interrupted()) {
                return false;
            }

            std::filesystem::path dir = strip_trailing_separators(given);

            if(!std::filesystem::is_directory(dir)) {
                std::cerr << term::error << "no such directory: " << given.string() << std::endl;
                return false;
            }

            /* Preserve the root directory name on disc. */
            std::filesystem::path name = dir.filename();
            if(name.empty()) {
                std::cerr << term::error << "cannot work out a directory name from: " << given.string() << std::endl;
                return false;
            }

            logging::verbose() << "Adding directory " << dir << " as " << name;
            copy_tree(dir, out / name, exe, "directory");
        }
    }

    if(OPTS.count("directory-contents")) {
        for(const std::filesystem::path given: OPTS["directory-contents"]) {
            std::filesystem::path dir = strip_trailing_separators(given);

            if(std::filesystem::is_directory(dir)) {
                for (const auto & entry : std::filesystem::directory_iterator(dir)) {
                    if(interrupted()) {
                        return false;
                    }

                    if(is_same_file(entry.path(), exe)) {
                        warn_executable_not_added(entry.path(), "directory-contents");
                        continue;
                    }

                    if(entry.path().filename() == boot_filename()) {
                        warn_boot_filename_not_added(entry.path(), "directory-contents");
                        continue;
                    }

                    logging::verbose() << "Adding " << entry.path().filename();

                    if(entry.is_directory()) {
                        copy_tree(entry.path(), out / entry.path().filename(), exe,
                            "directory-contents");
                    } else {
                        std::filesystem::copy(entry, out / entry.path().filename());
                    }
                }
            } else {
                std::cerr << term::error << "no such directory: " << dir.string() << std::endl;
                return false;
            }
        }
    }

    if(OPTS.count("file")) {
        for(std::filesystem::path file: OPTS["file"]) {
            if(interrupted()) {
                return false;
            }

            if(std::filesystem::exists(file)) {
                /* Left out on the same grounds as a -d/-D entry, rather than
                 * let through for having been named explicitly: the disc
                 * already carries the executable, and a copy at the boot name
                 * would replace it. */
                if(is_same_file(file, exe)) {
                    warn_executable_not_added(file, "file");
                    continue;
                }

                if(file.filename() == boot_filename()) {
                    warn_boot_filename_not_added(file, "file");
                    continue;
                }

                logging::verbose() << "Adding " << file << " -> " << out / file.filename();

                std::filesystem::copy(file, out / file.filename());
            } else {
                std::cerr << term::error << "no such file: " << file.string() << std::endl;
                return false;
            }
        }
    }

    gathering.finish();
    return true;
}

/* Reads a whole file into memory. Returns nullopt if it can't be opened. */
std::optional<std::string> read_file_contents(const std::filesystem::path& path) {
    std::ifstream f(path, std::ios::binary);
    if(!f) {
        return std::nullopt;
    }

    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}
