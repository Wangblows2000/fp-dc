/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Sega Dreamcast boot header (IP.BIN) structures and utilities.
 *
 * The IP.BIN occupies the first 32 KB of the primary data track. It contains
 * system metadata read by the console BIOS, disc security/license data, and
 * the second-stage bootstrap program.
 *
 * A GD-ROM disc uses two distinct boot headers sharing the same 256-byte metadata:
 * - High-density IP.BIN: Contains the Table of Contents (TOC), system logos,
 *   and stage 2 bootstrap. Sits at the start of the high-density area (track 3).
 * - Low-density IP0000.BIN: Contains neither TOC nor logos; consists of a single
 *   2048-byte sector repeated across all 16 sectors (32 KB).
 *
 * For MIL-CD (CD-ROM) discs, only a single IP.BIN is used.
 */

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

struct IPBin {
    struct {
        char hardware_id[16];
        char maker_id[16];
        char device_info[16];
        char area_symbols[8];
        char peripherals[8];
        char product_number[10];
        char product_version[6];
        char release_date[16];
        char boot_filename[16];
        char company_name[16];
        char game_name[128];
    } meta;

    char toc[512] = {0};
    char license_screen[13312];
    char area_protection[256];
    char bootstrap1[10240];
    char bootstrap2[8192];
};

/** Bundled IP.BIN templates defined in ip_boot.cpp (generated via xxd). */
extern unsigned char IP_BIN_MILCD[];        /* MIL-CD template for CDI/MDS/NRG */
extern unsigned int IP_BIN_MILCD_len;
extern unsigned char IP_BIN_GDROM_HDA_NEAREST[];  /* GD-ROM high-density area (round-to-nearest) */
extern unsigned int IP_BIN_GDROM_HDA_NEAREST_len;
extern unsigned char IP_BIN_GDROM_HDA_ZERO[];     /* GD-ROM high-density area (round-to-zero) */
extern unsigned int IP_BIN_GDROM_HDA_ZERO_len;

/**
 * @brief Selects the high-density GD-ROM template matching `--gdi-fpu-rounding`.
 *
 * Defaults to "nearest" (round-to-nearest). When requested, selects "zero"
 * (round-to-zero). The two templates differ only in their second-stage
 * bootstrap code, which configures the SH-4 FPSCR rounding mode before jumping
 * to the main binary.
 *
 * Applications linked against KallistiOS set their own rounding mode and are
 * unaffected. This option is primarily intended for binaries that rely on the
 * bootstrap's initial FPU state (traditionally round-to-nearest on official discs).
 */
const unsigned char* gd_hda_template();
size_t gd_hda_template_len();

/** Returns the active FPU rounding mode string ("nearest" or "zero") for plan diagnostics. */
std::string gd_fpu_rounding();

/** Extracts a fixed-width, space- or null-padded metadata string into a trimmed std::string. */
std::string trim_ipbin_field(const char* data, size_t max_len);

/**
 * @brief Mandatory Dreamcast identification strings.
 *
 * Every bootable Dreamcast disc must include these exact strings in its header.
 * Neither is null-terminated on disc; comparisons must match the exact field length.
 */
extern const char* const IPBIN_HARDWARE_ID;  /* "SEGA SEGAKATANA " */
extern const char* const IPBIN_MAKER_ID;     /* "SEGA ENTERPRISES" */

/**
 * @brief Validates that a string is a valid Dreamcast boot filename.
 *
 * Must be a non-empty, simple filename without directory separators or path components.
 * Applied both to user-supplied bootstrap files (`-p/--bootstrap`) and external ISO headers.
 */
bool is_usable_boot_filename(const std::string& name);

/**
 * @brief SEGA license screen code block (IP.BIN offsets 0x0300 - 0x36FF).
 *
 * Code that displays the "PRODUCED BY OR UNDER LICENSE FROM SEGA ENTERPRISES,
 * LTD." screen prior to executing bootstrap code.
 *
 * This region is strictly verified by the Dreamcast boot ROM via a direct byte-by-byte
 * comparison against its internal ROM copy. Any alteration causes the console BIOS
 * to reject the disc.
 *
 * Identical across all bundled templates, allowing universal validation without
 * needing to know which template was originally used.
 */
extern const size_t IPBIN_LICENSE_CODE_OFFSET;
extern const size_t IPBIN_LICENSE_CODE_LENGTH;

const unsigned char* ipbin_license_code();

/**
 * @brief Planned IP.BIN metadata values computed prior to disc image generation.
 *
 * Reflects fields from a custom `-p/--bootstrap` file if provided, or CLI metadata
 * overrides applied on top of the default template.
 *
 * If `-s/--serial` is omitted, `serial` remains empty here, as its default hash
 * is generated from the boot binary during image creation.
 *
 * Evaluated up-front so that verbose build reports (`-v 3`) display the exact values
 * that will be written into the disc header.
 */
struct IPBinMetadata {
    std::string title;
    std::string author;
    std::string serial;
    std::string product_version;
    std::string release_date;
    std::string peripherals;
    std::string boot_filename;

    /** Indicates whether metadata was loaded verbatim from a custom `-p/--bootstrap`
     * file (in which case CLI metadata overrides are ignored). */
    bool from_custom_bootstrap = false;
};

IPBinMetadata planned_ip_bin_metadata(const unsigned char* template_data, size_t template_len);

/**
 * @brief Resolves the game/disc title to be written into the header.
 *
 * Prioritizes the `-p/--bootstrap` header, followed by `-n/--title`, falling
 * back to the default project title. Extracted separately because the ISO9660
 * volume descriptor label also defaults to this value (`volume_label()` in iso_builder.hpp).
 */
std::string ipbin_title();

/**
 * @brief Resolves the target filename of the main executable.
 *
 * Must match between the filesystem and the Boot Filename field of the IP.BIN;
 * a mismatch prevents the Dreamcast BIOS from loading the executable.
 *
 * If a custom `-p/--bootstrap` is supplied, its internal filename is used.
 * Otherwise uses `--boot-filename`, defaulting to `1ST_READ.BIN`.
 *
 * This function returns the staged filename (e.g. `game.bin`) used in Rock Ridge
 * and Joliet extensions, which KallistiOS resolves at runtime. In the ISO9660
 * primary descriptor and IP.BIN, filenames are uppercase (`GAME.BIN`).
 */
std::string boot_filename();

bool load_ip_bin(const std::filesystem::path& ipbin_path, IPBin* out);

/** Populates `out` from `template_data` and CLI metadata, and embeds the MR logo. */
bool generate_ip_bin(const std::filesystem::path& output_dir,
                     const std::filesystem::path& bin_path, IPBin* out,
                     const unsigned char* template_data, size_t template_len);

/**
 * @brief Prepares the IP.BIN, loading a custom bootstrap or generating one from template.
 *
 * @return True if a custom bootstrap file was used, allowing callers to apply
 *         format-specific post-processing if necessary.
 */
bool prepare_ip_bin(IPBin* out, const std::filesystem::path& input_dir,
                    const unsigned char* template_data, size_t template_len);

/**
 * @brief Replicates the 256-byte header across all 16 sectors of a low-density GD-ROM IP0000.BIN.
 *
 * Ensures all sectors in the 32 KB area contain consistent header metadata,
 * conforming to original pressed GD-ROM structure.
 */
void replicate_lda_header(IPBin* ip_bin);
