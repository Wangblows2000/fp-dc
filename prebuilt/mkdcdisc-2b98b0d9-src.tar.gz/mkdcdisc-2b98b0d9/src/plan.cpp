/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* The `-v 3` build plan: see plan.hpp. */

#include <iomanip>
#include <string>
#include <vector>

#include "cli.hpp"
#include "ip_boot.hpp"
#include "iso_builder.hpp"
#include "logging.hpp"
#include "output_files.hpp"
#include "plan.hpp"

#include "disc_image/disc_image.h"

namespace {

/* Fixed column width to align values, chosen to fit the longest label.
 * Kept constant rather than computed dynamically: labels vary by disc mode,
 * and a consistent layout makes it easier to compare logs across bug reports. */
constexpr int LABEL_WIDTH = 24;

void field(const char* label, const std::string& value) {
    logging::debug() << std::left << std::setw(LABEL_WIDTH) << label << ": " << value;
}

/* Number of times an option was specified. For repeatable options, this represents
 * how many files or directories were supplied. */
size_t times_given(const char* option) {
    return OPTS.count(option) ? OPTS[option].size() : 0;
}

std::string first_value(const char* option) {
    return OPTS[option][0];
}

/* Formats a count with appropriate singular or plural noun (e.g. "1 file", "3 files"). */
std::string counted(size_t count, const char* singular, const char* plural) {
    return std::to_string(count) + " " + (count == 1 ? singular : plural);
}

std::string join(const std::vector<std::string>& parts, const char* separator) {
    std::string joined;

    for(const auto& part: parts) {
        if(!joined.empty()) {
            joined += separator;
        }
        joined += part;
    }

    return joined;
}

/* Summarizes volume inputs from -d/-D/-f options as counts rather than full lists.
 * Individual files are logged at -v 2 as they are staged into the image.
 *
 * `-d` and `-D` are counted together: they differ in whether the directory container
 * itself appears on the volume, which affects filesystem layout rather than how many
 * inputs were supplied on the command line. */
std::string contents_summary(const char* directory, const char* directory_contents, const char* file) {
    std::vector<std::string> parts;

    size_t directories = times_given(directory) + times_given(directory_contents);
    if(directories) {
        parts.push_back(counted(directories, "directory", "directories"));
    }

    if(times_given(file)) {
        parts.push_back(counted(times_given(file), "file", "files"));
    }

    return parts.empty() ? "nothing" : join(parts, ", ");
}

std::string image_format_name() {
    const std::string format = output_format();

    if(format == "mds") {
        return "Alcohol 120% (MDS+MDF)";
    }
    if(format == "nrg") {
        return "Nero Burning ROM (NRG)";
    }
    if(format == "gdi") {
        return "GD-ROM disc image (GDI)";
    }

    return "Padus DiscJuggler (CDI)";
}

std::string image_layout_name() {
    if(output_format() == "gdi") {
        /* Not a MIL-CD layout: a GD-ROM's low-density and high-density zones
         * are inherent to the physical media format. */
        return "Low-density/high-density (GD-ROM)";
    }
    return disc_layout_name(disc_layout());
}

/* Identifies which option (-e, -b, or -B) provided the main executable and how
 * mkdcdisc will process it. */
std::string main_executable() {
    if(OPTS.count("main-elf")) {
        return first_value("main-elf") + " (ELF)";
    }
    if(OPTS.count("main-binary-unscrambled")) {
        return first_value("main-binary-unscrambled") + " (unscrambled binary)";
    }

    return first_value("main-binary-scrambled") + " (already scrambled binary)";
}

std::string executable_scrambling() {
    /* Determined strictly by output format regardless of whether -e, -b, or -B
     * was passed: MIL-CD boot requires a scrambled binary, whereas GD-ROM boot
     * requires it unscrambled. An already-scrambled binary (-B) is therefore
     * unscrambled when targeting GD-ROM. */
    if(output_format() == "gdi") {
        return OPTS.count("main-binary-scrambled")
            ? "unscrambled again for GD-ROM boot"
            : "none, GD-ROM boot wants it unscrambled";
    }

    return OPTS.count("main-binary-scrambled")
        ? "already scrambled, used as given"
        : "scrambled for MIL-CD boot";
}

std::string bootstrap_source(const IPBinMetadata& meta) {
    if(!OPTS.count("bootstrap")) {
        return "the built-in template";
    }

    if(!meta.from_custom_bootstrap) {
        return first_value("bootstrap") + " (unreadable; falling back to the built-in template)";
    }

    return first_value("bootstrap") + " (used as given; the other IP.BIN options are ignored)";
}

/* `-F gdi` only: identifies which of the two high-density templates is active.
 *
 * A custom `-p/--bootstrap` file is used verbatim (including its bootstrap code),
 * so it supplies its own rounding mode and this option has no effect. This is why
 * main.cpp emits a warning if both are specified. */
std::string fpu_rounding(const IPBinMetadata& meta) {
    if(meta.from_custom_bootstrap) {
        return "whatever the " + option_label("bootstrap") + " file's bootstrap sets";
    }

    return gd_fpu_rounding() == "zero" ? "round to zero" : "round to nearest (the default)";
}

std::string license_screen(const IPBinMetadata& meta) {
    if(meta.from_custom_bootstrap) {
        return "whatever the " + option_label("bootstrap") + " file carries";
    }
    if(OPTS.count("disable-bootstrap-mr")) {
        return "none";
    }
    if(OPTS.count("bootstrap-mr-image")) {
        return first_value("bootstrap-mr-image");
    }

    return "the built-in default MR image";
}

/* Identifies the three text files referenced in the Primary Volume Descriptor (PVD).
 * GD-ROM images generate any of the three not explicitly supplied, as pressed discs
 * normally include all three unless disabled via `--gdi-disable-*`. Other formats
 * include only what was explicitly requested. */
std::string volume_text_files() {
    const std::tuple<const char*, const char*, const char*> files[] = {
        {"copyright", "gdi-disable-copyright", PVD_COPYRIGHT_FILE},
        {"abstract",  "gdi-disable-abstract",  PVD_ABSTRACT_FILE},
        {"biblio",    "gdi-disable-biblio",    PVD_BIBLIO_FILE},
    };

    /* For non-GDI formats, nothing is auto-generated and `--gdi-disable-*` flags
     * are rejected, so the volume contains only explicitly named files. */
    if(output_format() != "gdi") {
        std::vector<std::string> present;
        for(const auto& [option, disable_option, filename]: files) {
            (void) disable_option;
            if(OPTS.count(option)) {
                present.push_back(filename);
            }
        }

        return present.empty() ? "none" : join(present, ", ");
    }

    /* For GDI, report the provenance of each file: since there are multiple
     * ways a file can be populated or omitted, listing each status explicitly
     * is clearest. */
    std::vector<std::string> described;
    for(const auto& [option, disable_option, filename]: files) {
        std::string state = "generated";
        if(OPTS.count(disable_option)) {
            state = "disabled";
        } else if(OPTS.count(option)) {
            state = "from " + first_value(option);
        }

        described.push_back(std::string(filename) + " " + state);
    }

    return join(described, ", ");
}

/* First session of a MIL-CD disc, which contains audio tracks unless configured
 * with a layout that has no audio session. */
std::string audio_session() {
    if(disc_layout() != DiscLayout::AudioData) {
        return "none, this layout has no audio session";
    }
    if(!OPTS.count("cdda-track")) {
        return "one blank 4-second track";
    }

    return counted(times_given("cdda-track"), "CDDA track", "CDDA tracks")
        + " (" + join(OPTS["cdda-track"], ", ") + ")";
}

std::string data_track_padding() {
    return OPTS.count("disable-data-track-padding")
        ? "disabled, the track stops after its contents"
        : "enabled, the track is padded out to the full CD size";
}

std::string high_density_track() {
    return OPTS.count("gdi-truncate")
        ? "truncated to its contents (non-standard: needs an ODE or emulator that accepts it)"
        : "padded out to the full GD-ROM size";
}

std::string data_track_sector_size() {
    return gdi_sector_size() == CD_GDI_SECTOR_SIZE_COOKED
        ? "2048 bytes, plain user data (track??.iso)"
        : "2352 bytes, raw Mode 1 (track??.bin)";
}

/* Metadata block and filesystem contents: everything that exists only when
 * mkdcdisc generates the ISO filesystem and IP.BIN itself. An external data track
 * (`-t/--external-data-track`) run skips this because mkisofs already built the
 * filesystem, and options configured here are rejected in that mode. */
void print_standard_mode_plan() {
    const bool gdrom = output_format() == "gdi";

    IPBinMetadata meta = planned_ip_bin_metadata(
        gdrom ? gd_hda_template() : IP_BIN_MILCD,
        gdrom ? gd_hda_template_len() : IP_BIN_MILCD_len);

    field("Volume label", volume_label());
    field("Boot filename", meta.boot_filename);
    field("Main executable", main_executable());
    field("Executable scrambling", executable_scrambling());
    field("Bootstrap (IP.BIN)", bootstrap_source(meta));
    if(gdrom) {
        field("FPU rounding", fpu_rounding(meta));
    }
    field("License screen", license_screen(meta));

    field("Software title", meta.title);
    field("Author", meta.author);
    field("Serial", meta.serial.empty() ? "generated from the boot binary" : meta.serial);
    field("Product version", meta.product_version);
    field("Release date", meta.release_date);
    field("Peripherals", meta.peripherals);

    field("Disc contents", contents_summary("directory", "directory-contents", "file"));
    field("Sort file", OPTS.count("sort-file") ? first_value("sort-file") : "none");
    field("Volume text files", volume_text_files());

    if(gdrom) {
        field("Low-density contents",
            contents_summary("gdi-lda-directory", "gdi-lda-directory-contents", "gdi-lda-file"));
        field("Low-density sort file",
            OPTS.count("gdi-lda-sort-file") ? first_value("gdi-lda-sort-file") : "none");
        field("Low-density audio",
            OPTS.count("gdi-lda-cdda-track") ? first_value("gdi-lda-cdda-track") : "silence");
        field("GD-DA tracks", OPTS.count("cdda-track")
            ? counted(times_given("cdda-track"), "track", "tracks")
                + " (" + join(OPTS["cdda-track"], ", ") + ")"
            : "none");
        field("High-density track", high_density_track());
    } else {
        field("Audio session", audio_session());
        field("Data track padding", data_track_padding());
    }
}

void print_build_plan() {
    logging::debug() << "Build plan:";

    field("Disc type", output_format() == "gdi" ? "GD-ROM" : "MIL-CD");
    field("Image format", image_format_name());
    field("Image layout", image_layout_name());
    field("Output", output_files_description(first_value("output")));

    if(OPTS.count("dump-iso")) {
        field("Extra output", "the data track, also written as a standalone .iso");
    }

    if(output_format() == "gdi") {
        field("Data track sectors", data_track_sector_size());
    }

    if(OPTS.count("external-data-track")) {
        /* Merged-data layouts require two ISOs; all others require one.
         * File existence has already been validated prior to this step. */
        const auto& isos = OPTS["external-data-track"];

        if(isos.size() == 2) {
            field("Session 1 data track", isos[0] + " (pre-built ISO)");
            field("Session 2 data track", isos[1] + " (pre-built ISO)");
        } else {
            field("Data track", isos[0] + " (pre-built ISO, with its own IP.BIN)");
        }

        field("Audio session", audio_session());
    } else {
        field("Data track", "built by mkdcdisc from the files below");
        print_standard_mode_plan();
    }

    /* Print a blank line separator so the plan stands out as a distinct block. */
    logging::debug() << "";
}

}

void announce_build_plan() {
    /* Building the plan reads the bootstrap file and validates the boot filename,
     * which can emit warnings. Only execute this when debug logging is active. */
    if(logging::enabled(logging::Level::Debug)) {
        print_build_plan();
    }

    logging::verbose() << "Pre-run checks finished, beginning generation";
}
