/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Handles user-supplied input files: loading the main executable,
 * converting ELF files to flat binaries, and staging data track contents.
 */

#include <filesystem>
#include <optional>
#include <string>
#include <vector>

/**
 * @brief Extracts loadable segments from an ELF executable into a flat binary.
 *
 * Emulates the behavior of `objcopy -O binary`: extracts PT_LOAD segments residing
 * in valid console RAM addresses, discarding debug symbols and non-loadable headers.
 * Segments are positioned in the output buffer at their respective virtual load addresses.
 *
 * @param elf_name Path to the input ELF file.
 * @param bin_data Output buffer populated with the flattened binary.
 * @return true if the ELF was successfully parsed and extracted, false otherwise.
 */
bool load_elf_file(const std::filesystem::path& elf_name, std::vector<char>& bin_data);

/**
 * @brief Reads a raw binary executable into memory.
 *
 * @param bin_path Path to the binary file.
 * @param bin_data Output buffer populated with file contents.
 * @return true if successfully read, false otherwise.
 */
bool load_bin_file(const std::filesystem::path& bin_path, std::vector<char>& bin_data);

/**
 * @brief Stages the boot executable and filesystem contents into a temporary directory.
 *
 * Writes the main executable under its target boot filename (e.g. `1ST_READ.BIN`),
 * applying scrambling or unscrambling as required by the target disc format.
 * Then copies all user files and directories specified via `-d`, `-D`, and `-f`.
 *
 * @param out Staging directory path where files are assembled.
 * @param scramble_output true to produce a scrambled binary (required for MIL-CD),
 *                       false to produce an unscrambled binary (required for GD-ROM).
 * @return true if all files were staged successfully, false on error or abort.
 */
bool gather_files(const std::filesystem::path& out, bool scramble_output = true);

/**
 * @brief Reads an entire file into a string buffer.
 *
 * @param path Path to the file to read.
 * @return String containing file data, or std::nullopt if the file cannot be opened.
 */
std::optional<std::string> read_file_contents(const std::filesystem::path& path);
