/* IP creator (makeip)
 *
 * Copyright (C) 2000, 2001, 2002, 2019, 2020 The KOS Team and contributors.
 * All rights reserved.
 *
 * This code was contributed to KallistiOS (KOS) by Andress Antonio Barajas
 * (BBHoodsta). It was originally made by Marcus Comstedt (zeldin). Some
 * portions of code were made by Andrew Kieschnick (ADK/Napalm). Heavily
 * updated by SiZiOUS. Bootstrap replacement (IP.TMPL) was made by Jacob
 * Alberty (LiENUS).
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

/**
 * @file
 * @brief PNG-to-MR conversion routines adapted from KallistiOS makeip (mr.c).
 *
 * MR is Sega's palettized, run-length-compressed image format displayed by the
 * Dreamcast boot license screen.
 *
 * This module is compiled only when PNG support is enabled (MKDCDISC_WITH_PNG).
 * Higher-level conversions and error diagnostics are handled in src/mr_image.cpp.
 */

#include <cstdint>
#include <string>
#include <vector>

#ifdef MKDCDISC_WITH_PNG

namespace makeip {

/** @brief Maximum number of palette entries the MR format supports. */
constexpr int MR_MAX_PALETTE_COLORS = 128;

/**
 * @brief Result of a PNG-to-MR conversion.
 */
enum class MrStatus {
    Ok,            /**< Conversion succeeded. */
    ReadFailed,    /**< The input file could not be opened or parsed by libpng. */
    TooManyColors, /**< The image contains more than 128 unique RGB colors. */
};

/**
 * @brief Converts a PNG image into MR format.
 *
 * Appends the compressed MR payload to `out` on success (MrStatus::Ok); leaves
 * `out` unmodified on error.
 *
 * @param path Path to the source PNG file.
 * @param out Destination buffer that receives the MR payload on success.
 * @return Conversion result.
 */
MrStatus png_to_mr(const std::string& path, std::vector<uint8_t>& out);

} // namespace makeip

#endif /* MKDCDISC_WITH_PNG */
