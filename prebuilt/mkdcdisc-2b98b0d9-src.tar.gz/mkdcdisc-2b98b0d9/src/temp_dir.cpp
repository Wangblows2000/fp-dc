/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Temporary directory lifecycle: see temp_dir.hpp. */

#include <csignal>
#include <cstdlib>
#include <iostream>
#include <random>
#include <sstream>

#include "cli.hpp"
#include "logging.hpp"
#include "temp_dir.hpp"
#include "terminal.hpp"

/* Uses a single `atexit()` handler to ensure consistent cleanup across all exit
 * paths, including calls to `exit()`. Note that `atexit()` handlers do not run on
 * `abort()`, unhandled exceptions, or process termination via signals. */
static std::optional<std::filesystem::path> g_temp_dir_to_cleanup;

/* Defaults to the system temporary directory unless overridden by `--temp-dir`.
 * Many Linux distributions mount `/tmp` as a RAM-backed tmpfs, where large builds
 * could exhaust available memory. This helper is evaluated on every call so that
 * `temp_dir_destroy()` remains functional even during static deinitialization. */
static std::filesystem::path temp_dir_get_staging_root(std::error_code& ec) {
    if(OPTS.count("temp-dir")) {
        ec.clear();
        return std::filesystem::path(OPTS["temp-dir"][0]);
    }
    return std::filesystem::temp_directory_path(ec);
}

std::optional<std::filesystem::path> temp_dir_generate_path() {
    std::error_code ec;
    auto temp_dir = temp_dir_get_staging_root(ec);

    if(ec) {
        std::cerr << term::error << "temporary directory is unusable: " << ec.message()
                  << std::endl;
        return std::optional<std::filesystem::path>();
    }

    /* Validate that the staging root is a directory to produce a clear error message.
     * Otherwise, failures would manifest as opaque errors during `create_directory()`.
     * Validating the default root also catches misconfigured `TMPDIR` environments. */
    if(!std::filesystem::is_directory(temp_dir, ec)) {
        if(OPTS.count("temp-dir")) {
            std::cerr << term::error << option_label("temp-dir")
                      << " does not name a directory: " << temp_dir.string()
                      << std::endl;
        } else {
            std::cerr << term::error << "system temporary directory is unusable: "
                      << temp_dir.string() << " is not a directory. You may use "
                      << option_label("temp-dir") << " to stage the build somewhere else."
                      << std::endl;
        }
        return std::optional<std::filesystem::path>();
    }

    std::random_device dev;
    std::mt19937 prng(dev());
    std::uniform_int_distribution<uint64_t> rand(0);
    std::filesystem::path path;

    std::stringstream ss;
    ss << std::hex << rand(prng);
    path = temp_dir / ss.str();
    if(std::filesystem::create_directory(path)) {
        logging::debug() << "Staging directory: " << path;
        return path;
    } else {
        std::cerr << term::error << "could not create a staging directory in "
                  << temp_dir.string() << ". Check that it is writable, or pass "
                  << option_label("temp-dir") << " to stage the build somewhere else."
                  << std::endl;
        return std::optional<std::filesystem::path>();
    }
}

void temp_dir_destroy(const std::filesystem::path& path) {
    /* Use error codes rather than exceptions: throwing from inside an `atexit()`
     * handler terminates the process abruptly, bypassing any remaining cleanup. */
    std::error_code ec;

    /* Canonicalize paths to resolve symlinks and normalize representations.
     * Check `ec` after each call to catch errors early. */
    auto temp_root = temp_dir_get_staging_root(ec);
    auto temp_dir_path = ec ? std::filesystem::path()
                            : std::filesystem::canonical(temp_root, ec);
    auto provided_path_parent = ec ? std::filesystem::path()
                                   : std::filesystem::canonical(path.parent_path(), ec);

    logging::debug() << "Staging directory is under " << provided_path_parent
                     << ", staging root is " << temp_dir_path;

    /* Safety check: ensure the target directory is a direct child of the configured
     * staging root before deleting anything. */
    if(ec || provided_path_parent != temp_dir_path) {
        if(logging::enabled(logging::Level::Normal)) {
            std::cerr << term::warning << "not removing " << path.string() << ": cannot "
                         "confirm it is the staging directory this build created. You may "
                         "delete it by hand." << std::endl;
        }
        return;
    }

    logging::debug() << "Removing staging directory " << path;

    std::filesystem::remove_all(path, ec);

    /* If deletion fails (e.g. open file locks on Windows if interrupted mid-copy),
     * warn the user and display the path so it can be removed manually. */
    if(ec && logging::enabled(logging::Level::Normal)) {
        std::cerr << term::warning << "could not fully remove the temporary directory "
                  << path.string() << " (" << ec.message() << "). You may delete it "
                     "by hand." << std::endl;
    }
}

static void temp_dir_cleanup_on_exit() {
    if(g_temp_dir_to_cleanup) {
        temp_dir_destroy(*g_temp_dir_to_cleanup);
        g_temp_dir_to_cleanup.reset();
    }
}

void temp_dir_install_cleanup(const std::filesystem::path& path) {
    g_temp_dir_to_cleanup = path;
    std::atexit(temp_dir_cleanup_on_exit);
}
