/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Signal handling for Ctrl+C and SIGTERM via cooperative polling.
 *
 * The signal handler sets a flag rather than executing complex cleanup directly.
 * Long-running tasks periodically poll this flag, terminate cleanly, and unwind
 * their stacks so that all open files and resources are closed before exit handlers run.
 *
 * Calling `exit()` directly from a signal handler is problematic: on Windows,
 * the C runtime invokes signal handlers on a dedicated thread, meaning the main
 * thread continues running concurrently with exit handlers (e.g. libisofs still
 * reading or `std::filesystem::copy` still active). In addition, directories
 * cannot be removed while their files remain open. Calling `exit()` from a signal
 * handler is also non-portable in POSIX.
 *
 * Polling is performed during operations that hold open files or take noticeable
 * time: staging disc contents, writing filler blocks, reading from libisofs, and
 * streaming disc images via the progress callback (see `progress.h`). Signals
 * occurring during short steps are detected once that step finishes.
 *
 * A second signal forcefully kills the process immediately, ensuring the application
 * can always be terminated.
 */

/**
 * @brief Installs the SIGINT and SIGTERM handlers.
 *
 * Must be called once before executing any long-running operations.
 */
void install_interrupt_handler();

/**
 * @brief Checks whether a SIGINT, SIGTERM, or SIGBREAK signal has been received.
 *
 * Long-running tasks poll this function to stop early. Callers also inspect it
 * to distinguish normal failures from user cancellations.
 */
bool interrupted();

/**
 * @brief Returns 128 plus the caught signal number (standard shell exit convention).
 *
 * Only meaningful when `interrupted()` returns true.
 */
int interrupted_exit_code();
