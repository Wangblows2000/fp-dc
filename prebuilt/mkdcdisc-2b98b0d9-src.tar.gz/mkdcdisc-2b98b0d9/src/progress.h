/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Progress reporting interface across the C/C++ boundary.
 *
 * Defined in C99 to decouple high-level C++ application logic (such as ISO generation)
 * from the low-level C disc image backends. Neither layer needs to know whether the
 * caller is an interactive terminal, a GUI, or a non-interactive pipe; `progress.hpp`
 * provides the terminal implementation used by mkdcdisc.
 *
 * `done` and `total` use caller-defined units (e.g. bytes or sectors). Only their
 * ratio is evaluated by the receiver, so units must remain consistent across calls.
 * `total == 0` denotes an indeterminate size.
 */

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Progress callback function pointer.
 *
 * Returns 0 to continue execution, or non-zero to request cancellation.
 *
 * Allows long-running C backend routines to be interrupted cleanly (e.g. via Ctrl+C)
 * without exposing application globals or signal handlers directly to the library.
 * An interrupted operation must report an error rather than partial success.
 */
typedef int (*progress_fn)(void* user_data, uint64_t done, uint64_t total);

typedef struct {
    progress_fn report;
    void* user_data;
} progress_t;

/**
 * @brief Safely invokes a progress callback if configured.
 *
 * A NULL `progress` pointer or a struct with no callback returns 0 (continue),
 * allowing callers to report progress unconditionally without manual null-checks.
 */
static inline int progress_report(const progress_t* progress,
                                  uint64_t done, uint64_t total) {
    if(progress && progress->report) {
        return progress->report(progress->user_data, done, total);
    }

    return 0;
}

#ifdef __cplusplus
}
#endif
