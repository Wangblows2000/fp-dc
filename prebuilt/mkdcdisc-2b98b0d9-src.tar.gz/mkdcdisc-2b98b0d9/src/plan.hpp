/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Displays the final build configuration at verbosity level 3 (`-v 3`)
 *        before image generation starts.
 *
 * Details the disc type, format, layout, inputs, and metadata. Standard logs
 * track the progress of a run, rather than the initial requested parameters.
 * Since settings are distributed across dozens of CLI options, defaults, and
 * situational overrides, the plan dumps the resolved state.
 *
 * Invariant: nothing here makes policy decisions. Every value is read through
 * the same accessors used by the builder, ensuring the displayed plan never
 * drifts from actual build behavior.
 */

/**
 * @brief Prints the build plan (`-v 3`) and the completion marker for pre-run
 *        checks (`-v 2`) right before generation starts.
 *
 * Called from `main()` once all options have been validated.
 */
void announce_build_plan();
