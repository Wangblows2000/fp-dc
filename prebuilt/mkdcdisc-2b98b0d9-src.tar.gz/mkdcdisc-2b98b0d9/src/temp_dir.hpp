/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Creates and manages the temporary directory used for staging disc contents.
 */

#include <filesystem>
#include <optional>

/**
 * @brief Creates a unique temporary directory to stage disc contents.
 * @return The path to the created directory, or std::nullopt on failure.
 */
std::optional<std::filesystem::path> temp_dir_generate_path();

/**
 * @brief Recursively removes `path` and all of its contents.
 * @param path The temporary directory to remove.
 */
void temp_dir_destroy(const std::filesystem::path& path);

/**
 * @brief Registers `path` to be removed on program termination (normal or via `exit()`).
 *
 * Must be called immediately after directory creation. Signal interruptions are
 * handled separately via stack unwinding (see `interrupt.hpp`).
 * @param path The temporary directory to remove on exit.
 */
void temp_dir_install_cleanup(const std::filesystem::path& path);
