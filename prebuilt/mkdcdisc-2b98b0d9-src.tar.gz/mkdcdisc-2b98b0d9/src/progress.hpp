/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Terminal-based progress reporting and in-place status line updates.
 */

#include <cstdint>
#include <string>

#include "progress.h"

/**
 * @brief Manages terminal output for a single build phase from start to completion.
 *
 *   Generating data track...         42%     (during execution)
 *   Generating data track...        Done.    (upon completion)
 *
 * Each major phase instantiates a `ProgressLine`. Default verbosity (`-v 1`) consists
 * of these lines. Phases with indeterminate progress display their label and completion
 * marker without an intermediate percentage counter.
 *
 * On interactive terminals, percentage updates rewrite the current line using carriage
 * return (`\r`). When output is redirected to a file or pipe, percentages are omitted,
 * emitting a single clean log line per step.
 *
 * At `-v 2` and above, intermediate sub-step details print below the current phase.
 * Calling `break_line()` ensures detail appears on a separate line without overwriting
 * the progress label; the phase then concludes with an indented "Done." marker:
 *
 *   Gathering input files...
 *     Loading "game.elf"
 *     Done.
 *
 * In quiet mode (`-q`), all output and percentage updates are suppressed.
 */
class ProgressLine {
public:
    /** Prints the step label immediately upon instantiation. */
    explicit ProgressLine(std::string label);

    /** Closes the terminal line if `finish()` was not explicitly called, ensuring
     * subsequent error messages begin on a clean line. */
    ~ProgressLine();

    ProgressLine(const ProgressLine&) = delete;
    ProgressLine& operator=(const ProgressLine&) = delete;

    /**
     * @brief Returns a C-compatible `progress_t*` handle for passing to backend APIs
     *        (e.g. `cd_image_set_progress()` or `read_burn_source()`).
     *
     * Remains valid for the lifetime of this `ProgressLine` object.
     *
     * Also conveys interruption signals: the callback returns non-zero when a cancellation
     * signal has been received (see `interrupt.hpp`), independent of output verbosity.
     */
    const progress_t* progress() const { return &progress_; }

    /**
     * @brief Updates the progress percentage.
     *
     * A `total` of 0 indicates an indeterminate duration and performs no rendering.
     * Efficient to call frequently: terminal updates only occur when the integer
     * percentage changes.
     */
    void report(uint64_t done, uint64_t total);

    /**
     * @brief Marks the phase as complete, prints "Done.", and ends the line. Idempotent.
     */
    void finish();

    /**
     * @brief Ends the active line so that subsequent log output prints cleanly underneath.
     *
     * Invoked automatically by the logging system prior to writing detailed sub-step messages.
     * Idempotent.
     */
    void break_line();

private:
    void draw_status(const std::string& status);

    progress_t progress_;
    std::string label_;
    bool enabled_;      /* Output enabled (false under -q / -v 0) */
    bool interactive_;  /* True if stdout is an interactive terminal supporting `\r` */
    int last_percent_;  /* Previous integer percentage, initialized to -1 */
    bool finished_;
    bool line_open_;    /* True while a line is open on the terminal without a trailing newline */

    /**
     * Tracks nested progress lines.
     *
     * Sub-steps can nest by lexical scope (for instance, ISO dumping within `build_cd()`).
     * The active line is maintained as a stack to preserve hierarchy.
     */
    ProgressLine* previous_;
};

/**
 * @brief Returns the active innermost `ProgressLine`, or `nullptr` if none is open.
 *
 * Used by the logging subsystem to route indented messages under the appropriate phase.
 */
ProgressLine* active_progress_line();
