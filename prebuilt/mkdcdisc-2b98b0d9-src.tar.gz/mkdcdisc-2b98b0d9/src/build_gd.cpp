/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* GD-ROM building: see build_gd.hpp. */

#include <climits>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <set>

#include "audio.hpp"
#include "boot_checks.hpp"
#include "build_gd.hpp"
#include "cli.hpp"
#include "disc_layout.hpp"
#include "duplicates.hpp"
#include "gd_track_plan.hpp"
#include "input_files.hpp"
#include "interrupt.hpp"
#include "ip_boot.hpp"
#include "iso_builder.hpp"
#include "logging.hpp"
#include "paths.hpp"
#include "progress.hpp"
#include "sort_file.hpp"
#include "terminal.hpp"

/* Synthetic files used temporarily to shape the high-density ISO layout:
 * - "0.0": Pre-padding file to push actual contents toward the outer disc edge.
 * - "0.1": Spacer file reserving sector ranges occupied by GD-DA audio tracks.
 * - "0.2": Back-padding file ensuring the closing data track satisfies minimum length. */
static const char* const GDI_PADDING_FILE = "0.0";
static const char* const GDI_SPACER_FILE = "0.1";
static const char* const GDI_BACK_PADDING_FILE = "0.2";

/* Locates the lowest starting LBA among recorded directory files in a high-density ISO.
 * Directory record extents are absolute disc LBAs (the image itself starts at `CD_GD_START_LBA`).
 * Returns 0 if traversal fails.
 *
 * Used to determine the end of the GD-DA spacer file: because temporary filler files
 * are hidden from all directory trees, they lack directory records. Consequently,
 * the first file with a visible directory entry begins immediately following the spacer. */
static uint32_t find_first_hda_file_lba(const std::vector<uint8_t>& iso) {
    auto sector = [&](uint32_t lba) -> const uint8_t* {
        if(lba < CD_GD_START_LBA) {
            return nullptr;
        }
        size_t offset = (size_t) (lba - CD_GD_START_LBA) * 2048;
        return offset + 2048 <= iso.size() ? &iso[offset] : nullptr;
    };
    auto le32 = [](const uint8_t* p) -> uint32_t {
        return (uint32_t) p[0] | ((uint32_t) p[1] << 8) | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
    };

    const uint8_t* pvd = sector(CD_GD_START_LBA + 16);
    if(!pvd || std::memcmp(pvd + 1, "CD001", 5) != 0) {
        return 0;
    }

    std::vector<std::pair<uint32_t, uint32_t>> pending;  /* extent, length */
    std::set<uint32_t> seen;
    pending.push_back({le32(pvd + 156 + 2), le32(pvd + 156 + 10)});

    uint32_t first = 0;

    while(!pending.empty()) {
        auto [dir_lba, dir_len] = pending.back();
        pending.pop_back();

        if(dir_len == 0 || !seen.insert(dir_lba).second) {
            continue;
        }

        for(uint32_t s = 0; (size_t) s * 2048 < dir_len; ++s) {
            const uint8_t* dir = sector(dir_lba + s);
            if(!dir) {
                break;
            }

            for(size_t off = 0; off + 33 < 2048;) {
                unsigned rec_len = dir[off];
                if(rec_len == 0) {
                    break;
                }

                unsigned name_len = dir[off + 32];
                if(off + 33 + name_len > 2048) {
                    break;
                }

                uint32_t extent = le32(dir + off + 2);
                uint32_t length = le32(dir + off + 10);
                bool is_dir = (dir[off + 25] & 2) != 0;
                bool is_dot = (name_len == 1 && (dir[off + 33] == 0 || dir[off + 33] == 1));

                if(!is_dot && name_len > 0) {
                    if(is_dir) {
                        pending.push_back({extent, length});
                    } else if(length > 0 && (first == 0 || extent < first)) {
                        first = extent;
                    }
                }

                off += rec_len;
            }
        }
    }

    return first;
}

/* Constructs an ISO9660 filesystem tree for the high-density area and returns
 * the burn source. Called in two passes:
 * 1. Pass 1: Prior to writing filler files, to measure unpadded content size.
 * 2. Pass 2: After filler files are staged and TOC is finalized, to generate image data.
 *
 * Enforces hardware placement constraints: the primary boot binary (default `1ST_READ.BIN`,
 * or as resolved by `boot_filename()`) is pinned to the end of the filesystem, positioned
 * before the 150-sector run-out. */
static struct burn_source* create_hda_burn_source(const std::filesystem::path& input_dir,
                                                  const IPBin& ip_bin) {
    IsoImageRef image = new_iso_image(ip_bin, volume_label());
    IsoImage* iso = image.get();

    IsoDir* root = iso_image_get_root(iso);
    iso_tree_add_dir_rec(iso, root, PATH_TO_CSTR(input_dir));

    /* Note on sort weights in libisofs: sort comparison subtracts weights
     * (`cmp = g->sort_weight - f->sort_weight`). Using INT_MAX and INT_MIN directly
     * triggers signed integer overflow, inverting the intended sort order.
     * Fixed offset powers of 2 are used to safely bound the difference. */
    const int SORT_WEIGHT_FIRST = 1 << 24;
    const int SORT_WEIGHT_SPACER = 1 << 23;
    const int SORT_WEIGHT_BACK_PADDING = 1 << 22;
    const int SORT_WEIGHT_LAST = -(1 << 24);

    /* Hide the front-padding file from directory listings while preserving
     * sector allocation. Higher sort weights are placed at lower block addresses,
     * positioning padding at the start of track 3 and pushing data outward. */
    IsoNode* padding_node = NULL;
    if(iso_dir_get_node(root, GDI_PADDING_FILE, &padding_node) == 1) {
        iso_node_set_sort_weight(padding_node, SORT_WEIGHT_FIRST);
        iso_node_set_hidden(padding_node, LIBISO_HIDE_ON_RR | LIBISO_HIDE_BUT_WRITE);
    }

    /* Reserve sector ranges for GD-DA audio tracks via spacer node.
     * Since libisofs allocates extents contiguously, a synthetic hidden file
     * bridges the gap occupied by intermediate audio tracks. */
    IsoNode* spacer_node = NULL;
    if(iso_dir_get_node(root, GDI_SPACER_FILE, &spacer_node) == 1) {
        iso_node_set_sort_weight(spacer_node, SORT_WEIGHT_SPACER);
        iso_node_set_hidden(spacer_node, LIBISO_HIDE_ON_RR | LIBISO_HIDE_BUT_WRITE);
    }

    /* Back-padding node positioned immediately after the audio spacer to ensure
     * the closing data track satisfies minimum track length requirements. */
    IsoNode* back_padding_node = NULL;
    if(iso_dir_get_node(root, GDI_BACK_PADDING_FILE, &back_padding_node) == 1) {
        iso_node_set_sort_weight(back_padding_node, SORT_WEIGHT_BACK_PADDING);
        iso_node_set_hidden(back_padding_node, LIBISO_HIDE_ON_RR | LIBISO_HIDE_BUT_WRITE);
    }

    /* Pass sort weights to `--duplicates-once` to maintain extent placement rules. */
    const std::map<IsoNode*, int> weights = apply_sort_file("sort-file", root);

    /* Pin the boot binary to the end of the high-density data area, matching
     * official Dreamcast GD-ROM mastering structure (typically terminating near LBA 549000).
     * In libisofs, higher weights correspond to lower LBAs; assigning the lowest
     * weight (SORT_WEIGHT_LAST) positions the node at the highest LBA.
     *
     * Filename is resolved dynamically via `boot_filename()` to support custom
     * boot binaries configured via `-p/--bootstrap` or `--boot-filename`. */
    const std::string boot_file = boot_filename();

    IsoNode* boot_node = NULL;
    if(!boot_file.empty()
        && iso_dir_get_node(root, boot_file.c_str(), &boot_node) == 1) {
        iso_node_set_sort_weight(boot_node, SORT_WEIGHT_LAST);
    } else if(logging::enabled(logging::Level::Normal)) {
        std::cerr << term::warning << "the IP.BIN boot file \"" << boot_file
                  << "\" is not present in the data track, so it cannot be placed at the end "
                     "of the high-density area where GD-ROM hardware expects it. The disc is "
                     "unlikely to boot." << std::endl;
    }

    /* Exempt synthetic fillers and the boot binary from deduplication:
     * - Filler files consist of all-zero bytes; deduplicating them would merge
     *   distinct address reservations.
     * - The boot binary requires an explicit fixed placement at the end of the track. */
    std::set<IsoNode*> undeduplicable;
    for(IsoNode* node: {padding_node, spacer_node, back_padding_node, boot_node}) {
        if(node) {
            undeduplicable.insert(node);
        }
    }

    apply_duplicates_once("high-density area", iso, root, undeduplicable, weights);

    IsoWriteOpts* opts = create_iso_write_opts(ip_bin, CD_GD_START_LBA, /* joliet */ false);

    struct burn_source* burn_src;
    iso_image_create_burn_source(iso, opts, &burn_src);

    /* Free write options; cloned internally by libisofs into the image layout. */
    iso_write_opts_free(opts);

    return burn_src;
}

/* Generates the high-density ISO image data, pre-allocating buffer capacity to `track_bytes`
 * to avoid expensive reallocations when padding out the run-out margin. */
static std::vector<uint8_t> build_hda_iso(const std::filesystem::path& input_dir,
                                           const IPBin& ip_bin,
                                           const progress_t* progress,
                                           uint64_t track_bytes) {
    return read_burn_source(create_hda_burn_source(input_dir, ip_bin), progress, track_bytes);
}

/* Ingests files and directories specified via `--gdi-lda-directory`,
 * `--gdi-lda-directory-contents`, or `--gdi-lda-file` directly into the
 * low-density area root directory.
 *
 * Files are added directly to the ISO image tree rather than copied to a temporary
 * staging directory, avoiding naming conflicts with high-density contents.
 *
 * Directory paths are converted to generic POSIX formatting (`/`) so that libisofs
 * parses directory hierarchy correctly regardless of host platform. */
static void add_lda_contents(IsoImage* iso, IsoDir* root) {
    if(OPTS.count("gdi-lda-directory")) {
        for(const std::filesystem::path given: OPTS["gdi-lda-directory"]) {
            std::filesystem::path dir = std::filesystem::absolute(given);
            std::string dir_path = dir.generic_string();
            std::string name = dir.filename().string();
            if(name.empty()) {
                /* Trailing separator: "foo/bar/" leaves `filename()` empty. */
                name = dir.parent_path().filename().string();
            }

            IsoDir* node = NULL;
            if(iso_tree_add_new_dir(root, name.c_str(), &node) < 0) {
                if(logging::enabled(logging::Level::Normal)) {
                    std::cerr << term::warning << "could not add directory " << name
                              << " to the low-density area." << std::endl;
                }
                continue;
            }

            iso_tree_add_dir_rec(iso, node, dir_path.c_str());
        }
    }

    if(OPTS.count("gdi-lda-directory-contents")) {
        for(const std::filesystem::path given: OPTS["gdi-lda-directory-contents"]) {
            std::string dir_path = std::filesystem::absolute(given).generic_string();
            iso_tree_add_dir_rec(iso, root, dir_path.c_str());
        }
    }

    if(OPTS.count("gdi-lda-file")) {
        for(const std::filesystem::path given: OPTS["gdi-lda-file"]) {
            std::string file_path = std::filesystem::absolute(given).generic_string();
            if(iso_tree_add_node(iso, root, file_path.c_str(), NULL) < 0) {
                if(logging::enabled(logging::Level::Normal)) {
                    std::cerr << term::warning << "could not add file " << file_path
                              << " to the low-density area." << std::endl;
                }
            }
        }
    }
}

/* Builds the low-density area's ISO9660 filesystem: the low-density boot
 * image as its 32K system area, followed by the three PVD-referenced text
 * files. Built at `ms_block` 0, since the LDA starts at LBA 0.
 *
 * Real discs put these three files here and nowhere else (the high-density
 * PVD leaves the same fields empty) which is why this is separate from
 * `build_hda_iso()` rather than a flag on it. There is no boot binary to pin
 * and no padding file to weight, so the two share only the identifier setup
 * in `new_iso_image()`. */
static std::vector<uint8_t> build_lda_iso(const IPBin& lda_ip_bin, const progress_t* progress) {
    IsoImageRef image = new_iso_image(lda_ip_bin, volume_label());
    IsoImage* iso = image.get();

    /* User content first, so that a `COPYRIGH.TXT` of their own is detected as
     * already present and wins over the generated one. */
    IsoDir* root = iso_image_get_root(iso);
    add_lda_contents(iso, root);

    VolumeTextFiles text_files = add_volume_text_files(root, lda_ip_bin, /* generate_defaults */ true);

    /* All three, unless a `--gdi-disable-`* flag kept one off the volume: an
     * identifier naming a file that isn't there would be a dangling reference,
     * and `patch_pvd_file_ids()` only rewrites the fields set here. */
    if(text_files.copyright) iso_image_set_copyright_file_id(iso, PVD_COPYRIGHT_FILE);
    if(text_files.abstract) iso_image_set_abstract_file_id(iso, PVD_ABSTRACT_FILE);
    if(text_files.biblio) iso_image_set_biblio_file_id(iso, PVD_BIBLIO_FILE);

    /* Applied last, so it can weight the three generated text files too. The
     * low-density area has its own sort file: it is a separate filesystem
     * whose paths have nothing to do with the high-density one's, so sharing
     * `-S/--sort-file` between them would mean one list of paths addressing two
     * unrelated trees. */
    apply_sort_file("gdi-lda-sort-file", root);

    IsoWriteOpts* opts = create_iso_write_opts(lda_ip_bin, 0, /* joliet */ false);

    struct burn_source* burn_src;
    iso_image_create_burn_source(iso, opts, &burn_src);
    std::vector<uint8_t> data = read_burn_source(burn_src, progress);
    iso_write_opts_free(opts);

    patch_pvd_file_ids(data, text_files);

    return data;
}

/* Writes the Table of Contents (TOC) for the high-density session into IPBin::toc,
 * matching official Sega GD-ROM IP.BIN layout specifications:
 *
 *   0x100: "TOC1"            - 4-byte ASCII magic identifier (checked by GD-ROM Explorer)
 *   0x104: uint32 entry[97]  - Array of 97 track descriptors for high-density tracks (3..99).
 *                               Tracks 1 and 2 (low-density) are not recorded here.
 *                               Unused track entries are filled with 0xFFFFFFFF.
 *   0x288: uint32 first      - Packed descriptor: (CTRL << 28) | (ADR << 24) | (first_track << 16)
 *   0x28C: uint32 last       - Packed descriptor for last high-density track
 *   0x290: uint32 leadout    - Packed descriptor: (CTRL << 28) | (ADR << 24) | leadout_FAD
 *
 * Each track descriptor packs FAD (Frame Address Code = LBA + 150) in bits 0-23,
 * ADR in bits 24-27, and CTRL in bits 28-31 (0 = audio, 4 = Mode 1 data), stored
 * in little-endian byte order. */
struct GdiTocTrack {
    uint32_t lba;
    bool is_data;
};

static void write_gdi_hda_toc(IPBin* ip_bin, uint32_t first_hda_track,
                             const std::vector<GdiTocTrack>& hda_tracks,
                             uint32_t leadout_lba) {
    const uint32_t ADR = 1;
    const uint32_t CTRL_DATA = 4;
    const uint32_t CTRL_AUDIO = 0;
    const size_t TOC_ENTRIES = 97;

    auto make_entry = [&](uint32_t ctrl, uint32_t lba) -> uint32_t {
        return (ctrl << 28) | (ADR << 24) | ((lba + 150) & 0x00FFFFFFu);
    };
    auto make_point = [&](uint32_t ctrl, uint32_t track) -> uint32_t {
        return (ctrl << 28) | (ADR << 24) | ((track & 0xFFu) << 16);
    };

    uint32_t entry[TOC_ENTRIES];
    for(auto& e: entry) {
        e = 0xFFFFFFFF;
    }

    for(size_t i = 0; i < hda_tracks.size() && i < TOC_ENTRIES; ++i) {
        entry[i] = make_entry(hda_tracks[i].is_data ? CTRL_DATA : CTRL_AUDIO, hda_tracks[i].lba);
    }

    /* Track 3 is always a Mode 1 data track; on discs with GD-DA audio,
     * the session terminates with a closing data track as well. */
    uint32_t last_hda_track = first_hda_track + (uint32_t) hda_tracks.size() - 1;
    uint32_t first = make_point(CTRL_DATA, first_hda_track);
    uint32_t last = make_point(CTRL_DATA, last_hda_track);
    uint32_t leadout = make_entry(CTRL_DATA, leadout_lba);

    /* IPBin::toc begins at offset 0x100 (metadata header is 256 bytes). */
    uint8_t* toc = (uint8_t*) ip_bin->toc;
    std::memcpy(toc, "TOC1", 4);
    std::memcpy(toc + 4, entry, sizeof(entry));
    std::memcpy(toc + 4 + sizeof(entry), &first, sizeof(first));
    std::memcpy(toc + 4 + sizeof(entry) + 4, &last, sizeof(last));
    std::memcpy(toc + 4 + sizeof(entry) + 8, &leadout, sizeof(leadout));
}

bool build_gd(const std::filesystem::path& input_dir) {
    std::string output_path = OPTS["output"][0];

    using gd_track::TRACK_END_RESERVED_SECTORS;

    /* Prepare high-density IP.BIN using the GD-ROM HDA template or custom bootstrap. */
    IPBin ip_bin;
    prepare_ip_bin(&ip_bin, input_dir, gd_hda_template(), gd_hda_template_len());

    /* Construct low-density IP0000.BIN header by replicating the 256-byte metadata
     * across all 16 sectors of the 32 KB system area.
     *
     * The low-density area intentionally omits the TOC, license graphic, and
     * SEGA trademark screens present in high-density IP.BIN, matching original
     * GD-ROM pressing structure. */
    IPBin lda_ip_bin{};
    std::memcpy(&lda_ip_bin.meta, &ip_bin.meta, sizeof(lda_ip_bin.meta));
    replicate_lda_header(&lda_ip_bin);

    const size_t MIN_AUDIO_SECTORS = 300; /* Red Book minimum: 4 seconds */

    /* GD-DA audio tracks: loaded early to determine high-density track layout sizing. */
    std::vector<std::vector<uint8_t>> gdda_tracks;
    size_t gdda_sectors = 0;

    if(OPTS.count("cdda-track")) {
        for(const auto& filename: OPTS["cdda-track"]) {
            auto data_maybe = load_audio_track(filename);
            if(!data_maybe) {
                return false;
            }

            size_t sectors = (data_maybe->size() + 2351) / 2352;
            if(sectors < MIN_AUDIO_SECTORS) {
                std::cerr << term::error << "audio file " << filename << " is too short - it must be at least "
                          << (MIN_AUDIO_SECTORS * 2352) << " bytes (4 seconds)" << std::endl;
                return false;
            }

            gdda_sectors += sectors;
            gdda_tracks.push_back(std::move(*data_maybe));

            logging::note() << "Added GD-DA track " << gdda_tracks.size()
                            << " (" << sectors << " sectors) from " << filename;
        }
    }

    /* Track 2 (audio warning track in low-density area). Loaded up front to fail early
     * if the file is invalid. */
    std::vector<uint8_t> lda_cdda;
    if(OPTS.count("gdi-lda-cdda-track")) {
        const std::string& filename = OPTS["gdi-lda-cdda-track"][0];
        auto data_maybe = load_audio_track(filename);
        if(!data_maybe) {
            return false;
        }

        if((data_maybe->size() + 2351) / 2352 < MIN_AUDIO_SECTORS) {
            std::cerr << term::error << "audio file " << filename << " is too short - it must be at least "
                      << (MIN_AUDIO_SECTORS * 2352) << " bytes (4 seconds)" << std::endl;
            return false;
        }

        lda_cdda = std::move(*data_maybe);
    }

    /* Sectors allocated for the GD-DA audio range (including 150-sector run-out and pregaps).
     * The spacer file reserves this range in the ISO filesystem image. */
    const size_t gdda_spacer_sectors = gdda_tracks.empty()
        ? 0
        : TRACK_END_RESERVED_SECTORS + 150 + gdda_sectors + 150;

    iso_init();

    /* Pass 1: Measure unpadded filesystem size using burn source metadata without
     * reading file bodies into memory. */
    ProgressLine measuring("Measuring high-density area...");
    uint64_t content_bytes = measure_burn_source(create_hda_burn_source(input_dir, ip_bin));

    if(interrupted()) {
        return false;
    }

    measuring.finish();

    size_t content_sectors = (size_t) ((content_bytes + 2047) / 2048);

    const bool truncate = OPTS.count("gdi-truncate");
    gd_track::Plan plan = gd_track::plan_track(content_sectors, gdda_spacer_sectors, truncate);

    if(!plan.fits) {
        std::cerr << term::error << "data track (" << content_sectors << " sectors"
                  << (gdda_spacer_sectors ? " plus " + std::to_string(gdda_spacer_sectors)
                                            + " reserved for the GD-DA tracks" : "")
                  << ") doesn't fit in the GD-ROM high-density zone ("
                  << gd_track::MAX_CONTENT_SECTORS << " usable sectors, the last "
                  << TRACK_END_RESERVED_SECTORS << " being reserved). "
                     "Reduce the disc contents, or pass " << option_label("gdi-truncate")
                  << " to build a smaller, "
                     "non-standard image." << std::endl;
        return false;
    }

    /* Warn if a truncated build exceeds standard physical GD-ROM capacity. */
    if(truncate && plan.track_sectors > gd_track::FULL_TRACK_SECTORS
        && logging::enabled(logging::Level::Normal)) {
        std::cerr << term::warning << "high-density track ends "
                  << (plan.track_sectors - gd_track::FULL_TRACK_SECTORS)
                  << " sectors past LBA " << gd_track::GD_END_LBA
                  << ", where a GD-ROM ends." << std::endl;
    }

    const size_t hda_track_sectors = plan.track_sectors;
    const size_t content_target_sectors = plan.content_target_sectors;

    /* Minimum reservation per side in split layouts to ensure both data tracks
     * satisfy Red Book minimum length requirements. */
    const size_t split_side_sectors =
        gdda_spacer_sectors > 0 ? gd_track::MIN_SPLIT_SIDE_SECTORS : 0;

    const size_t occupied_sectors =
        content_sectors + gdda_spacer_sectors + 2 * split_side_sectors;

    auto write_filler = [&](const char* name, size_t sectors, const char* label) {
        ProgressLine filling(label);
        write_zero_file(std::filesystem::path(input_dir) / name,
            (std::uintmax_t) sectors * 2048, filling.progress());

        if(interrupted()) {
            return false;
        }

        filling.finish();
        return true;
    };

    /* Write padding file ("0.0") to fill out to content_target_sectors. */
    size_t pad_sectors = content_target_sectors - occupied_sectors + split_side_sectors;
    if(pad_sectors > 0
        && !write_filler(GDI_PADDING_FILE, pad_sectors, "Padding high-density area...")) {
        return false;
    }

    /* Write spacer file ("0.1") to reserve GD-DA audio track space. */
    if(gdda_spacer_sectors > 0
        && !write_filler(GDI_SPACER_FILE, gdda_spacer_sectors, "Reserving GD-DA area...")) {
        return false;
    }

    /* Write back-padding file ("0.2") to ensure closing data track meets minimum length. */
    if(split_side_sectors > 0
        && !write_filler(GDI_BACK_PADDING_FILE, split_side_sectors,
                         "Reserving the closing track...")) {
        return false;
    }

    /* Generate low-density area filesystem (track 1) with IP0000.BIN boot header. */
    ProgressLine building_lda("Generating low-density area...");
    std::vector<uint8_t> lda_iso = build_lda_iso(lda_ip_bin, building_lda.progress());

    if(interrupted()) {
        return false;
    }

    building_lda.finish();

    size_t lda_content_sectors = (lda_iso.size() + 2047) / 2048;

    /* Sizing for track 1: content length + 150-sector run-out, floored at 450 sectors
     * matching common retail GD-ROM mastering conventions. */
    const size_t LDA_MIN_SECTORS = 450;
    const uint32_t track1_sectors = (uint32_t) std::max(LDA_MIN_SECTORS,
        lda_content_sectors + TRACK_END_RESERVED_SECTORS);

    /* Track 2 length: 526 sectors of silence (~7s) by default, or supplied audio file. */
    const uint32_t LDA_CDDA_SILENCE_SECTORS = 526;
    const uint32_t track2_sectors = lda_cdda.empty()
        ? LDA_CDDA_SILENCE_SECTORS
        : (uint32_t) ((lda_cdda.size() + 2351) / 2352);
    const uint32_t track3_lba = CD_GD_START_LBA;

    /* Low-density area and pregap must terminate prior to LBA 45000. */
    if(track1_sectors + 150 + track2_sectors > track3_lba) {
        std::cerr << term::error << "the low-density area does not fit below LBA " << track3_lba
                  << ": track 1 is " << track1_sectors << " sectors and track 2 is "
                  << track2_sectors << ". Use a shorter " << option_label("gdi-lda-cdda-track")
                  << " file (at most "
                  << ((track3_lba - track1_sectors - 150) * 2352) << " bytes here)." << std::endl;
        return false;
    }

    if(!lda_cdda.empty()) {
        logging::note() << "Added low-density CDDA track (" << track2_sectors << " sectors) from "
                        << OPTS["gdi-lda-cdda-track"][0];
    }

    /* Record total volume space in the low-density PVD spanning through track 2. */
    patch_pvd_volume_space(lda_iso, track1_sectors + 150 + track2_sectors);

    /* Pass 2: Rebuild the high-density ISO with filler files present. */
    ProgressLine generating("Generating high-density area...");
    std::vector<uint8_t> iso_data = build_hda_iso(input_dir, ip_bin, generating.progress(),
        (uint64_t) hda_track_sectors * 2048);

    if(interrupted()) {
        return false;
    }

    generating.finish();

    logging::debug() << "Data track is " << iso_data.size() << " bytes";

    size_t final_content_sectors = (iso_data.size() + 2047) / 2048;
    if(!truncate && final_content_sectors != content_target_sectors
        && logging::enabled(logging::Level::Normal)) {
        std::cerr << term::warning << "high-density filesystem ended up " << final_content_sectors
                  << " sectors instead of the targeted " << content_target_sectors
                  << " (libisofs structural overhead shifted by "
                  << ((int64_t) final_content_sectors - (int64_t) content_target_sectors)
                  << " sector(s)); 1ST_READ.BIN may not end exactly "
                  << TRACK_END_RESERVED_SECTORS << " sectors before the end of the track."
                  << std::endl;
    }

    /* Compute track boundaries across the high-density area:
     * - Track 3 (first data track): LBA 45000 up to spacer + 150 run-out.
     * - GD-DA tracks: follow track 3 pregap, written flush.
     * - Closing data track: begins after audio spacer and extends to zone end. */
    const uint32_t hda_end_lba = track3_lba + (uint32_t) hda_track_sectors;
    uint32_t track3_sectors = (uint32_t) hda_track_sectors;
    uint32_t gdda_start_lba = 0;
    uint32_t last_track_lba = 0;

    if(gdda_spacer_sectors > 0) {
        /* Locate spacer by finding the first recorded directory record and subtracting
         * hidden reservation sizes. */
        uint32_t first_file_lba = find_first_hda_file_lba(iso_data);
        uint32_t hidden_before_first_file =
            (uint32_t) (gdda_spacer_sectors + split_side_sectors);

        uint32_t spacer_lba = first_file_lba > hidden_before_first_file
            ? first_file_lba - hidden_before_first_file
            : 0;

        first_file_lba = spacer_lba + (uint32_t) gdda_spacer_sectors;

        if(spacer_lba <= track3_lba || first_file_lba >= hda_end_lba) {
            std::cerr << term::error << "could not place the GD-DA tracks in the high-density zone."
                      << std::endl;
            return false;
        }

        track3_sectors = spacer_lba + TRACK_END_RESERVED_SECTORS - track3_lba;
        gdda_start_lba = spacer_lba + TRACK_END_RESERVED_SECTORS + 150;
        last_track_lba = first_file_lba;
    }

    /* Build and inject final Table of Contents into high-density IP.BIN. */
    std::vector<GdiTocTrack> hda_tracks;
    hda_tracks.push_back({track3_lba, /* is_data */ true});

    for(size_t i = 0, lba = gdda_start_lba; i < gdda_tracks.size(); ++i) {
        hda_tracks.push_back({(uint32_t) lba, /* is_data */ false});
        lba += (gdda_tracks[i].size() + 2351) / 2352;
    }

    if(last_track_lba) {
        hda_tracks.push_back({last_track_lba, /* is_data */ true});
    }

    write_gdi_hda_toc(&ip_bin, /* first_hda_track */ 3, hda_tracks, hda_end_lba);
    std::memcpy(&iso_data[0], &ip_bin, sizeof(IPBin));

    /* Run bootstrap checks against the high-density data track.
     * Low-density area is exempt: by design it does not boot and contains no license code. */
    if(!boot_checks::check_disc({
        {"the high-density data track", boot_checks::Role::Bootable, &iso_data,
         boot_checks::MsinfoExpectation{CD_GD_START_LBA, /* exact */ true}},
    })) {
        return false;
    }

    cd_image_t* img = cd_new_image();
    cd_image_set_volume_name(img, PATH_TO_CSTR(std::filesystem::path(output_path).filename().stem()));

    cd_session_t* session1 = cd_new_session(img);

    /* Low-density area: Track 1 (Mode 1 data) and Track 2 (Audio). */
    std::vector<uint8_t> track1_data = std::move(lda_iso);
    track1_data.resize(track1_sectors * (size_t) 2048, 0);
    cd_track_t* track1 = cd_new_track(session1, TRACK_TYPE_DATA, &track1_data[0], track1_data.size());
    cd_track_set_mode(track1, TRACK_MODE_MODE1);

    if(lda_cdda.empty()) {
        cd_new_track_blank(session1, TRACK_TYPE_AUDIO, track2_sectors * 2352);
    } else {
        lda_cdda.resize((size_t) track2_sectors * 2352, 0);
        cd_new_track(session1, TRACK_TYPE_AUDIO, &lda_cdda[0], (uint32_t) lda_cdda.size());
    }

    /* Pad high-density data buffer to full track length. */
    if(iso_data.size() < hda_track_sectors * 2048) {
        iso_data.resize(hda_track_sectors * 2048, 0);
    }

    cd_session_t* session2 = cd_new_session(img);

    /* Slice high-density tracks using borrowed pointers to avoid duplicating gigabyte buffers. */
    auto add_hda_data_track = [&](uint32_t lba, const uint8_t* data, size_t bytes) {
        cd_track_t* track = cd_new_track_borrowed(session2, TRACK_TYPE_DATA, data, (uint32_t) bytes);
        cd_track_set_mode(track, TRACK_MODE_MODE1);
        cd_track_set_placement_lba(track, lba);
    };

    add_hda_data_track(track3_lba, &iso_data[0], track3_sectors * (size_t) 2048);

    /* GD-DA audio tracks (flush placement without intermediate pregaps). */
    uint32_t lba = gdda_start_lba;
    for(auto& audio: gdda_tracks) {
        cd_track_t* track = cd_new_track(session2, TRACK_TYPE_AUDIO, &audio[0], (uint32_t) audio.size());
        cd_track_set_placement_lba(track, lba);
        lba += (uint32_t) ((audio.size() + 2351) / 2352);
    }

    /* Closing Mode 1 data track following GD-DA audio tracks. */
    if(last_track_lba) {
        size_t offset = (size_t) (last_track_lba - track3_lba) * 2048;
        add_hda_data_track(last_track_lba, &iso_data[offset], iso_data.size() - offset);
    }

    if(!write_disc_image(img, output_path)) {
        return false;
    }

    if(truncate && plan.track_sectors < gd_track::FULL_TRACK_SECTORS
        && logging::enabled(logging::Level::Normal)) {
        std::cerr << term::warning << option_label("gdi-truncate")
                  << " ended the high-density area at LBA "
                  << (CD_GD_START_LBA + plan.track_sectors) << ", where a GD-ROM ends at "
                  << gd_track::GD_END_LBA << ". This is not a standard image and may not boot."
                  << std::endl;
    }

    return true;
}
