/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Entry point: parses command-line options, validates option combinations
 * for the requested target format and session layout, and dispatches to the
 * appropriate disc image builder.
 *
 * Exit codes and contract guarantees are defined in exit_codes.hpp. */

#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

#include "audio.hpp"
#include "build_cd.hpp"
#include "build_gd.hpp"
#include "cli.hpp"
#include "disc_layout.hpp"
#include "exit_codes.hpp"
#include "gd_track_plan.hpp"
#include "input_files.hpp"
#include "interrupt.hpp"
#include "logging.hpp"
#include "output_files.hpp"
#include "plan.hpp"
#include "temp_dir.hpp"
#include "terminal.hpp"

#include "disc_image/disc_image.h"

#include "temp_dir.hpp"

/* Prints a help hint to stderr and returns the exit_code::USAGE status code.
 * Used for command-line syntax and option validation failures. */
static int usage_error() {
    print_help_hint();
    return exit_code::USAGE;
}

int main(int argc, char* argv[]) {
    /* Configure ANSI color support prior to printing any output. */
    term::configure(argc, argv);

    /* Ensure that diagnostics logged during long-running tasks appear on a fresh line. */
    logging::install_diagnostic_guard();

    /* Print startup banner unless early suppression flags are present. */
    if(banner_wanted(argc, argv)) {
        print_banner();
    }

    bool args_ok = false;
    OPTS = parse_options(argc, argv, &args_ok);

    if(!apply_color_options()) {
        return usage_error();
    }

    warn_about_deprecated_options();

    if(argc == 1) {
        print_usage_hint();
        return exit_code::USAGE;
    }

    if(OPTS.count("help")) {
        print_help();
        return exit_code::SUCCESS;
    }

    /* Option parser has already printed specific syntax errors; show hint and exit. */
    if(!args_ok) {
        return usage_error();
    }

    /* Validate disc layout argument early since `-M/--print-msinfo` inspects it. */
    if(!validate_disc_layout()) {
        return usage_error();
    }

    const DiscLayout layout = disc_layout();

    /* Reject CD-DA audio tracks when paired with Data/Data layouts, which do not
     * have an audio session. (GD-ROM images are validated separately). */
    if(output_format() != "gdi" && layout != DiscLayout::AudioData && OPTS.count("cdda-track")) {
        std::cerr << term::error << option_label("cdda-track") << " cannot be combined with "
                  << option_label("disc-layout") << " " << disc_layout_value(layout)
                  << ". A " << disc_layout_name(layout)
                  << " image has no audio session for CDDA tracks." << std::endl;
        return usage_error();
    }

    /* Validate audio track counts against format constraints:
     * - GD-ROM: at most gd_track::MAX_GDDA_TRACKS in the high-density area.
     * - MIL-CD: capped by CD_MAX_TRACKS (reserving 1 track for data). */
    if(OPTS.count("cdda-track") && (output_format() == "gdi" || layout == DiscLayout::AudioData)) {
        const bool gd_rom = output_format() == "gdi";
        const size_t limit = gd_rom ? gd_track::MAX_GDDA_TRACKS : CD_MAX_TRACKS - 1;
        const size_t given = OPTS["cdda-track"].size();

        if(given > limit) {
            std::cerr << term::error << given << (gd_rom ? " GD-DA" : " CDDA")
                      << " tracks given, but at most " << limit << " fit: "
                      << (gd_rom
                            ? "a GD-ROM's high-density area spans tracks 3 to 99, and the audio "
                              "sits between an opening data track and the closing one"
                            : "a disc holds " + std::to_string(CD_MAX_TRACKS)
                              + " tracks and the data track takes one of them")
                      << "." << std::endl;
            return usage_error();
        }
    }

    /* MSINFO mode: outputs the second-session starting LBA required by `mkisofs -C 0,LBA`.
     * Exits immediately upon outputting the value. */
    if(OPTS.count("print-msinfo")) {
        /* Reject MSINFO for GD-ROM images; MSINFO is strictly for multi-session MIL-CDs. */
        if(output_format() == "gdi") {
            std::cerr << term::error << "option " << option_label("print-msinfo")
                      << " cannot be used with " << option_label("format") << " gdi. "
                         "MSINFO belongs to the multi-session MIL-CD layouts." << std::endl;
            return usage_error();
        }

        if(layout == DiscLayout::MergedData) {
            if(!OPTS.count("external-data-track") || OPTS["external-data-track"].size() != 1) {
                std::cerr << term::error << option_label("print-msinfo") << " with "
                          << option_label("disc-layout") << " merged-data requires exactly one "
                          << option_label("external-data-track")
                          << " (the already-built session 1 ISO)." << std::endl;
                return usage_error();
            }

            std::error_code ec;
            auto iso1_size = std::filesystem::file_size(OPTS["external-data-track"][0], ec);
            if(ec) {
                std::cerr << term::error << "unable to determine size of ISO file: "
                          << OPTS["external-data-track"][0] << std::endl;
                return exit_code::FILE_ERROR;
            }

            std::cout << std::dec << data_session_length_in_sectors(iso1_size, /* is_first_session */ true)
                      << std::endl;
            return exit_code::SUCCESS;
        }

        if(layout == DiscLayout::DataData) {
            std::cout << 0 << std::endl;
            return exit_code::SUCCESS;
        }

        cd_image_t* img = cd_new_image();
        cd_session_t* session0 = cd_new_session(img);
        if(!add_audio_session(session0, /* log */ false)) {
            cd_free_image(&img);
            return exit_code::FILE_ERROR;
        }
        std::cout << std::dec << cd_session_length_in_sectors(session0) << std::endl;
        cd_free_image(&img);
        return exit_code::SUCCESS;
    }

    if(!OPTS.count("output")) {
        std::cerr << term::error << "no output file given. Use " << option_label("output")
                  << "." << std::endl;
        return usage_error();
    }

    if(output_format() != "cdi" && output_format() != "mds" && output_format() != "nrg" && output_format() != "gdi") {
        std::cerr << term::error << "unknown output format: " << output_format() << " (expected 'cdi', 'mds', 'nrg', or 'gdi')" << std::endl;
        return usage_error();
    }

    /* In External ISO mode (-t), reject filesystem creation and metadata options
     * since the ISO and its IP.BIN have already been authored externally. */
    if(OPTS.count("external-data-track")) {
        static const std::vector<std::string> disabled_in_external_mode = {
            "author",
            "main-binary-unscrambled",
            "main-binary-scrambled",
            "directory",
            "directory-contents",
            "main-elf",
            "file",
            "peripherals",
            "bootstrap-mr-image",
            "disable-bootstrap-mr",
            "dump-iso",
            "title",
            "disable-data-track-padding",
            "bootstrap",
            "product-version",
            "release",
            "serial",
            "sort-file",
            "volume-label",
            "abstract",
            "biblio",
            "boot-filename",
            "copyright",
            "duplicates-once",
        };

        bool has_conflict = false;
        for(const auto& key: disabled_in_external_mode) {
            if(OPTS.count(key)) {
                std::cerr << term::error << "option " << option_label(key)
                          << " cannot be used with " << option_label("external-data-track")
                          << " (the ISO and its IP.BIN are built externally by mkisofs)." << std::endl;
                has_conflict = true;
            }
        }
        if(has_conflict) {
            return usage_error();
        }

    }

    /* Verify file accessibility early to avoid failing halfway through disc creation. */
    for(const char* option: {"copyright", "abstract", "biblio"}) {
        if(OPTS.count(option) && !read_file_contents(OPTS[option][0])) {
            std::cerr << term::error << "cannot read --" << option << " file: "
                      << OPTS[option][0] << std::endl;
            return exit_code::FILE_ERROR;
        }
    }

    for(const char* option: {"gdi-lda-directory", "gdi-lda-directory-contents", "gdi-lda-file",
                              "gdi-lda-cdda-track", "gdi-lda-sort-file"}) {
        if(!OPTS.count(option)) {
            continue;
        }

        for(const auto& path: OPTS[option]) {
            if(!std::filesystem::exists(path)) {
                std::cerr << term::error << "no such path for --" << option << ": " << path << std::endl;
                return exit_code::FILE_ERROR;
            }
        }
    }

    /* Format-specific option validation. */
    if(output_format() == "gdi") {
        /* Disallow MIL-CD options when targeting GD-ROM. */
        bool has_conflict = false;
        for(const auto& opt: disc_type_restricted_options()) {
            if(opt.disc_type == DiscType::MilCdOnly && OPTS.count(opt.key)) {
                std::cerr << term::error << "option " << opt.label << " cannot be used with "
                          << option_label("format") << " gdi." << opt.hint << std::endl;
                has_conflict = true;
            }
        }
        if(has_conflict) {
            return usage_error();
        }

        if(OPTS.count("gdi-sector-size")) {
            const std::string& size = OPTS["gdi-sector-size"][0];
            if(size != "2048" && size != "2352") {
                std::cerr << term::error << "invalid " << option_label("gdi-sector-size")
                          << " value: " << size
                          << " (expected '2352' for raw Mode 1 sectors or '2048' for plain user data)"
                          << std::endl;
                return usage_error();
            }
        }

        if(OPTS.count("gdi-fpu-rounding")) {
            const std::string& mode = OPTS["gdi-fpu-rounding"][0];
            if(mode != "nearest" && mode != "zero") {
                std::cerr << term::error << "invalid " << option_label("gdi-fpu-rounding")
                          << " value: " << mode
                          << " (expected 'nearest' or 'zero')" << std::endl;
                return usage_error();
            }

            /* A custom bootstrap IP.BIN already sets its own FPU rounding flags. */
            if(OPTS.count("bootstrap") && logging::enabled(logging::Level::Normal)) {
                std::cerr << term::warning << option_label("gdi-fpu-rounding")
                          << " is ignored because " << option_label("bootstrap")
                          << " supplies its own bootstrap." << std::endl;
            }
        }

        static const std::vector<std::pair<std::string, std::string>> text_file_options = {
            {"copyright", "gdi-disable-copyright"},
            {"abstract",  "gdi-disable-abstract"},
            {"biblio",    "gdi-disable-biblio"},
        };

        for(const auto& [supply, disable]: text_file_options) {
            if(OPTS.count(supply) && OPTS.count(disable) && logging::enabled(logging::Level::Normal)) {
                std::cerr << term::warning << "--" << supply << " is ignored because --" << disable
                          << " was given." << std::endl;
            }
        }
    } else {
        /* Disallow GD-ROM options when building MIL-CD images. */
        for(const auto& opt: disc_type_restricted_options()) {
            if(opt.disc_type == DiscType::GdRomOnly && OPTS.count(opt.key)) {
                std::cerr << term::error << opt.label << " only applies to "
                          << option_label("format") << " gdi." << std::endl;
                return usage_error();
            }
        }
    }

    /* Merged Data/Data layout requires two pre-built ISOs provided via `-t`. */
    if(layout == DiscLayout::MergedData && !OPTS.count("external-data-track")) {
        std::cerr << term::error << option_label("disc-layout") << " merged-data requires "
                  << option_label("external-data-track") << ", given twice (session 1 ISO, then "
                     "session 2 ISO). Standard Mode does not support this layout." << std::endl;
        return usage_error();
    }

    /* Check for existing output files to prevent accidental overwrite. */
    if(!check_output_files(OPTS["output"][0])) {
        return exit_code::FILE_ERROR;
    }

    /* External ISO Mode: wrap user-provided pre-built ISO(s) into CDI/MDS/NRG images. */
    if(OPTS.count("external-data-track")) {
        if(layout == DiscLayout::MergedData) {
            if(OPTS["external-data-track"].size() != 2) {
                std::cerr << term::error << option_label("disc-layout")
                          << " merged-data requires exactly two "
                          << option_label("external-data-track")
                          << " ISOs (session 1, then session 2)." << std::endl;
                return usage_error();
            }

            std::filesystem::path iso1_path = OPTS["external-data-track"][0];
            std::filesystem::path iso2_path = OPTS["external-data-track"][1];

            if(!std::filesystem::exists(iso1_path)) {
                std::cerr << term::error << "ISO file does not exist: " << iso1_path << std::endl;
                return exit_code::FILE_ERROR;
            }
            if(!std::filesystem::exists(iso2_path)) {
                std::cerr << term::error << "ISO file does not exist: " << iso2_path << std::endl;
                return exit_code::FILE_ERROR;
            }

            announce_build_plan();

            if(!build_cd_from_merged_data_isos(iso1_path, iso2_path)) {
                std::cerr << term::error << "unable to build the disc image." << std::endl;
                return exit_code::BUILD_FAILED;
            }

            return exit_code::SUCCESS;
        }

        if(OPTS["external-data-track"].size() != 1) {
            std::cerr << term::error << option_label("external-data-track")
                      << " may only be given once (use " << option_label("disc-layout")
                      << " merged-data to wrap two ISOs)." << std::endl;
            return usage_error();
        }

        std::filesystem::path iso_path = OPTS["external-data-track"][0];
        if(!std::filesystem::exists(iso_path)) {
            std::cerr << term::error << "ISO file does not exist: " << iso_path << std::endl;
            return exit_code::FILE_ERROR;
        }

        announce_build_plan();

        if(!build_cd_from_external_iso(iso_path)) {
            std::cerr << term::error << "unable to build the disc image." << std::endl;
            return exit_code::BUILD_FAILED;
        }

        return exit_code::SUCCESS;
    }

    /* Standard Mode: require exactly one source for the main executable. */
    if(!OPTS.count("main-elf") && !OPTS.count("main-binary-unscrambled") && !OPTS.count("main-binary-scrambled")) {
        std::cerr << term::error << "no main executable given. Use " << option_label("main-elf")
                  << ", " << option_label("main-binary-unscrambled") << " or "
                  << option_label("main-binary-scrambled") << ". To wrap a pre-built ISO instead, use "
                  << option_label("external-data-track") << "." << std::endl;
        return usage_error();
    }

    if(OPTS.count("main-elf") + OPTS.count("main-binary-unscrambled") + OPTS.count("main-binary-scrambled") > 1) {
        std::cerr << term::error << option_label("main-elf") << ", "
                  << option_label("main-binary-unscrambled") << ", and "
                  << option_label("main-binary-scrambled")
                  << " are mutually exclusive; specify only one 1ST_READ.BIN source." << std::endl;
        return usage_error();
    }

    announce_build_plan();

    auto temp_dir_maybe = temp_dir_generate_path();
    if(!temp_dir_maybe) {
        return exit_code::FILE_ERROR;
    }

    auto temp_dir = temp_dir_maybe.value();
    temp_dir_install_cleanup(temp_dir);

    /* Install signal handler for graceful shutdown and temporary directory cleanup on SIGINT/SIGTERM. */
    install_interrupt_handler();

    /* Wrap image generation in exception handler to ensure proper cleanup and error exit code. */
    try {
        bool is_gdi = output_format() == "gdi";

        /* GD-ROM boot requires unscrambled 1ST_READ.BIN; MIL-CD boot requires scrambled. */
        if(!gather_files(temp_dir, /* scramble_output */ !is_gdi)) {
            return interrupted() ? interrupted_exit_code() : 4;
        }

        if(!(is_gdi ? build_gd(temp_dir) : build_cd(temp_dir))) {
            if(interrupted()) {
                std::cerr << term::program_prefix() << "Interrupted." << std::endl;
                return interrupted_exit_code();
            }

            std::cerr << term::error << "unable to build the disc image." << std::endl;
            return exit_code::BUILD_FAILED;
        }
    } catch(const std::exception& e) {
        std::cerr << term::error << e.what() << std::endl;
        return exit_code::BUILD_FAILED;
    } catch(...) {
        std::cerr << term::error << "unknown exception" << std::endl;
        return exit_code::BUILD_FAILED;
    }

    return exit_code::SUCCESS;
}
