/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Boot checks for validating the bootstrap process: see boot_checks.hpp. */

#include <algorithm>
#include <cctype>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <sstream>

#include "boot_checks.hpp"
#include "cli.hpp"
#include "ip_boot.hpp"
#include "iso_reader.hpp"
#include "logging.hpp"
#include "progress.hpp"
#include "terminal.hpp"

namespace boot_checks {

namespace {

/* Collects diagnostics and handles the `--disable-bootstrap-checks` override.
 *
 * The override is handled exclusively here. Checks report their findings along
 * with the confidence level, without reading configuration options directly.
 *
 * Severity also dictates `-q` (quiet mode) suppression behavior: errors are
 * always displayed because an aborted build must explain the cause. Non-fatal
 * diagnostics can be silenced, including failures downgraded to warnings by
 * the override flag. */
class Report {
public:
    void fail(const std::string& message) {
        if(OPTS.count("disable-bootstrap-checks")) {
            if(logging::enabled(logging::Level::Normal)) {
                std::cerr << term::warning << message << std::endl;
            }
            overridden_ += 1;
            return;
        }

        std::cerr << term::error << message << std::endl;
        failed_ += 1;
    }

    void warn(const std::string& message) {
        if(logging::enabled(logging::Level::Normal)) {
            std::cerr << term::warning << message << std::endl;
        }
    }

    void note(const std::string& message) {
        logging::note() << message;
    }

    bool ok() const { return failed_ == 0; }
    size_t overridden() const { return overridden_; }

private:
    size_t failed_ = 0;
    size_t overridden_ = 0;
};

/* Returns a pointer to the boot header (IPBin), or nullptr if the volume is too
 * small to contain one.
 *
 * The header occupies the first 32 KB (the system area reserved by ECMA-119).
 * Since IPBin maps these bytes directly and consists solely of char arrays,
 * this cast has no memory alignment constraints. */
const IPBin* boot_header(const std::vector<uint8_t>& iso) {
    if(iso.size() < sizeof(IPBin)) {
        return nullptr;
    }
    return reinterpret_cast<const IPBin*>(iso.data());
}

/* Validates the presence of the mandatory Dreamcast hardware ID. */
bool has_hardware_id(const IPBin* header) {
    return std::memcmp(header->meta.hardware_id, IPBIN_HARDWARE_ID,
        sizeof(header->meta.hardware_id)) == 0;
}

std::string as_ipbin_offset(size_t offset) {
    std::ostringstream out;
    out << std::uppercase << std::hex << std::setfill('0') << std::setw(4) << offset;
    return out.str();
}

/* Check 1: Verify header presence and fixed identification fields.
 *
 * Only mandatory, non-configurable fields are verified here. Product numbers,
 * regional symbols, release dates, and peripheral bitmasks are application-
 * specific. The device information checksum is omitted because setting it to
 * 0000 is documented and supported behavior.
 *
 * Returns true if a valid header was identified, allowing subsequent checks to
 * proceed without generating redundant missing-header errors. */
bool check_boot_header(Report& report, const Volume& volume, const IPBin* header) {
    const std::vector<uint8_t>& iso = *volume.data;
    const bool present = header != nullptr && has_hardware_id(header);

    /* Session 1 of merged-data is never booted. A header present here is not an
     * error, but we log an informational note so the user understands that
     * editing it has no effect on bootstrap. */
    if(volume.role == Role::NotBooted) {
        if(present) {
            report.note("The boot header in " + volume.name + " is unused: the console boots "
                "from session 2. Editing this header changes nothing.");
        }
        return present;
    }

    if(header == nullptr) {
        report.fail(volume.name + " is " + std::to_string(iso.size()) + " bytes, too short to "
            "hold the 32768-byte boot header.");
        return false;
    }

    if(!present) {
        report.fail(volume.name + " carries no boot header (missing Hardware ID). "
            "Build the ISO with mkisofs' -G switch, pointing it at an IP.BIN.");
        return false;
    }

    if(std::memcmp(header->meta.maker_id, IPBIN_MAKER_ID, sizeof(header->meta.maker_id)) != 0) {
        report.fail(volume.name + " declares the Maker ID \""
            + trim_ipbin_field(header->meta.maker_id, sizeof(header->meta.maker_id))
            + "\" instead of \"" + std::string(IPBIN_MAKER_ID) + "\". The disc will not boot.");
    }

    std::string declared = trim_ipbin_field(header->meta.boot_filename,
        sizeof(header->meta.boot_filename));

    if(!is_usable_boot_filename(declared)) {
        report.fail(volume.name + " declares "
            + (declared.empty() ? std::string("no boot file name")
                                : "the invalid boot file name \"" + declared + "\"")
            + " at IP.BIN offset " + as_ipbin_offset(0x060) + ". The console looks that name up "
            "at the root of the filesystem, so it has to be a plain file name.");
    }

    return true;
}

/* Case-insensitive ASCII comparison.
 *
 * Implemented directly because standard C++ lacks a built-in case-insensitive
 * string comparison. `strcasecmp()` is POSIX rather than standard C++, MSVC
 * uses `_stricmp()`, and both can be locale-dependent.
 *
 * ISO9660 primary volume descriptors strictly use ASCII. While `std::toupper`
 * is technically locale-dependent, it is safe here because `setlocale()` is
 * not called. Characters are cast to unsigned char to avoid undefined behavior
 * with negative values. */
bool same_name_ignoring_case(const std::string& a, const std::string& b) {
    return std::equal(a.begin(), a.end(), b.begin(), b.end(),
        [](unsigned char x, unsigned char y) { return std::toupper(x) == std::toupper(y); });
}

std::string root_contents_summary(const std::vector<iso9660::Entry>& entries) {
    const size_t MAX_NAMED = 8;
    if(entries.empty()) {
        return "nothing at all";
    }

    std::string listed;
    for(size_t i = 0; i < entries.size() && i < MAX_NAMED; ++i) {
        if(i > 0) {
            listed += ", ";
        }
        listed += entries[i].name + (entries[i].is_dir ? "/" : "");
    }

    if(entries.size() > MAX_NAMED) {
        listed += ", and " + std::to_string(entries.size() - MAX_NAMED) + " more";
    }
    return listed;
}

/* Check 2: Verify that the executable named in IP.BIN exists in the root directory.
 *
 * The expected filename is read directly from the header rather than assuming
 * `1ST_READ.BIN`, since `--boot-filename` or a custom `-p/--bootstrap` header
 * may define a different binary name. The file must reside at the filesystem root;
 * binaries placed in subdirectories cannot be booted directly by the console. */
void check_boot_file(Report& report, const Volume& volume, const IPBin* header) {
    const std::vector<uint8_t>& iso = *volume.data;

    std::string declared = trim_ipbin_field(header->meta.boot_filename,
        sizeof(header->meta.boot_filename));

    if(!is_usable_boot_filename(declared)) {
        return;
    }

    /* Treat an unreadable directory as undetermined rather than a confirmed failure.
     * The internal parser is a strict, minimalist ECMA-119 reader; inability to parse
     * the directory does not necessarily mean the disc image is corrupt. */
    if(!iso9660::locate_root_directory(iso).found) {
        report.warn(volume.name + " has an unreadable ISO9660 root directory. "
            "Boot file presence was not checked.");
        return;
    }

    std::vector<iso9660::Entry> entries = iso9660::read_root_directory(iso);

    for(const auto& entry: entries) {
        if(entry.name != declared) {
            continue;
        }

        if(entry.is_dir) {
            report.fail(volume.name + " has a directory called \"" + declared + "\" at its root. "
                "The console cannot start a directory.");
        }
        return;
    }

    /* Check if the file exists under a case-insensitive match. ISO9660 primary
     * trees mandate uppercase identifiers (d-characters). If the header specifies
     * a mixed-case or lowercase filename, it will not match the primary tree.
     *
     * This is reported as a warning rather than a fatal error, as console BIOS
     * path resolution case-sensitivity is not conclusively documented.
     * Internally generated images via mkdcdisc's `--boot-filename` will not trigger
     * this because `set_ipbin_boot_filename()` forces uppercase; custom headers
     * from `-p/--bootstrap` or external ISOs may contain mixed-case names. */
    for(const auto& entry: entries) {
        if(entry.is_dir || !same_name_ignoring_case(entry.name, declared)) {
            continue;
        }

        report.warn(volume.name + " declares the boot file as \"" + declared
            + "\", but its filesystem calls it \"" + entry.name
            + "\". ISO9660 uses upper-case names. If the disc doesn't boot, change this first.");
        return;
    }

    report.fail(volume.name + " does not carry \"" + declared + "\" at its root. "
        "Its root holds: " + root_contents_summary(entries) + ".");
}

/* 150 sectors correspond to standard CD pregap duration (2 seconds).
 * Disc mastering utilities frequently differ on whether the 150-sector pregap
 * between sessions belongs to the preceding lead-out or following lead-in,
 * so a drift within this threshold reflects mastering tool discrepancy.
 *
 * This tolerance only applies when an offset exists; an expected offset of 0
 * requires an exact match since sector 0 has no preceding pregap. */
const long long MSINFO_TOLERANCE_SECTORS = 150;

/* Check 3: Verify that the ISO was authored for its target physical start sector.
 *
 * ISO9660 structures contain absolute sector addresses; tools such as
 * `mkisofs -C 0,N` require the starting LBA of the session beforehand.
 * This value is manually specified, and mismatched offsets cause file read failures.
 *
 * This check emits a warning rather than an error: the expected LBA is derived
 * from mkdcdisc's track layout model rather than an absolute hardware measurement,
 * and rejecting images solely on model differences could block valid discs. */
void check_msinfo(Report& report, const Volume& volume) {
    if(!volume.msinfo) {
        return;
    }

    const uint32_t expected = volume.msinfo->sectors;
    auto detected = iso9660::detect_msinfo(*volume.data);

    if(!detected) {
        report.warn(volume.name + " has an unreadable root directory. "
            "Expected start sector " + std::to_string(expected) + " was not checked.");
        return;
    }

    if(*detected == expected) {
        return;
    }

    const long long drift = (long long) *detected - (long long) expected;
    const long long distance = drift < 0 ? -drift : drift;

    if(!volume.msinfo->exact && distance <= MSINFO_TOLERANCE_SECTORS) {
        logging::debug() << volume.name << " was built for sector " << *detected
            << " against expected " << expected << " (within 150-sector pregap tolerance).";
        return;
    }

    std::string said = volume.name + " was built to start at sector " + std::to_string(*detected)
        + ", but will be written at sector " + std::to_string(expected) + " ("
        + (drift > 0 ? "+" : "") + std::to_string(drift) + "). Every address recorded inside it "
        "is that far out, so the console will read files from the wrong place.";

    if(expected == 0) {
        said += " Build the ISO with mkisofs -C 0,0, or without -C.";
    } else {
        said += " Pass mkisofs -C 0," + std::to_string(expected)
            + " (run mkdcdisc -M to get this exact number).";
    }

    report.warn(said);
}

/* Check 4: Validate that the SEGA license screen code is unmodified.
 *
 * This is a strict hardware-enforced constraint. The Dreamcast boot ROM contains
 * a copy of this code block and performs an exact byte-by-byte comparison before
 * executing the bootstrap. Any mismatch causes the console to reject the disc.
 *
 * Adjacent header regions are deliberately excluded from this check: the TOC area
 * below is dynamic, and the bootstrap regions above are customizable by design
 * (mkdcdisc modifies them when embedding the MR logo and configuring the SH-4
 * FPU rounding mode). Expanding this verification range would incorrectly flag
 * valid mkdcdisc images. */
void check_license_code(Report& report, const Volume& volume) {
    const std::vector<uint8_t>& iso = *volume.data;
    const uint8_t* found = iso.data() + IPBIN_LICENSE_CODE_OFFSET;
    const unsigned char* expected = ipbin_license_code();

    if(std::memcmp(found, expected, IPBIN_LICENSE_CODE_LENGTH) == 0) {
        return;
    }

    size_t at = 0;
    while(at < IPBIN_LICENSE_CODE_LENGTH && found[at] == expected[at]) {
        at += 1;
    }

    size_t differing = 0;
    for(size_t i = 0; i < IPBIN_LICENSE_CODE_LENGTH; ++i) {
        if(found[i] != expected[i]) {
            differing += 1;
        }
    }

    report.fail(volume.name + " carries a modified SEGA licence screen code: "
        + std::to_string(differing) + " of the "
        + std::to_string(IPBIN_LICENSE_CODE_LENGTH) + " bytes differ, the first at offset "
        + as_ipbin_offset(IPBIN_LICENSE_CODE_OFFSET + at) + ". "
        "The boot ROM byte-compares this zone and refuses any mismatch. "
        "This is a hardware requirement, not a customizable zone.");
}

}

bool check_disc(const std::vector<Volume>& volumes) {
    ProgressLine checking("Checking boot prerequisites...");
    Report report;

    for(const auto& volume: volumes) {
        if(volume.data == nullptr) {
            continue;
        }

        const IPBin* header = boot_header(*volume.data);
        bool has_header = check_boot_header(report, volume, header);

        /* Checked on every volume, including non-booted sessions. The target LBA
         * is a property of the filesystem rather than the boot header; files in
         * session 1 are still read even if session 1 does not boot directly. */
        check_msinfo(report, volume);

        if(!has_header || volume.role != Role::Bootable) {
            continue;
        }

        check_boot_file(report, volume, header);
        check_license_code(report, volume);
    }

    if(report.overridden() > 0) {
        report.note(std::to_string(report.overridden()) + " boot check(s) failed. Building anyway "
            "due to " + option_label("disable-bootstrap-checks")
            + "; the disc is unlikely to boot.");
    }

    if(!report.ok()) {
        /* Print as a note rather than another error line, as the underlying error
         * has already been reported and the caller will report the build failure.
         *
         * Always emitted regardless of verbosity level so that quiet mode (`-q`)
         * users are informed of the available override flag. */
        std::cerr << term::note
                  << "pass " << option_label("disable-bootstrap-checks")
                  << " to build this disc anyway." << std::endl;
        return false;
    }

    checking.finish();
    return true;
}

}
