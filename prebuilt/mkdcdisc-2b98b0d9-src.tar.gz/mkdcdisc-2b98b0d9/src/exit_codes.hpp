/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Standard process exit codes returned by mkdcdisc.
 *
 * Defines a stable interface for scripts and automation tools to identify failure
 * causes programmatically. These values are documented in `docs/topics/cli-reference.md`
 * and must remain consistent across releases.
 *
 * Note: USAGE errors correspond to invalid command-line flags or syntax issues,
 * whereas FILE_ERROR corresponds to missing or unreadable files on disk.
 *
 * SUCCESS is defined here rather than using EXIT_SUCCESS to prevent identifier
 * conflicts with `<cstdlib>`.
 */

namespace exit_code {

/** Success: The requested operation or output completed normally. */
inline constexpr int SUCCESS = 0;

/** Usage error: Invalid options, bad values, or malformed arguments. */
inline constexpr int USAGE = 2;

/** File error: Missing/unreadable input files, or refusal to overwrite existing outputs. */
inline constexpr int FILE_ERROR = 4;

/** Build failed: The build process started but encountered an error. */
inline constexpr int BUILD_FAILED = 5;

/** Interrupted runs exit with 128 plus the signal number (e.g. 130 on SIGINT / Ctrl+C).
 * Calculated dynamically; see `interrupted_exit_code()` in `interrupt.hpp`. */

}
