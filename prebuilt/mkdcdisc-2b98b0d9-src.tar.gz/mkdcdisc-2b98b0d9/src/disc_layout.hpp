/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Disc layout composition, session assembly, and image output writers.
 *
 * Handles track/session organization for various disc topologies (Audio/Data,
 * Data/Data, and Merged Data/Data), sector padding estimation, and low-level
 * image serialization (CDI, MDS, NRG, GDI).
 */

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#include "disc_image/disc_image.h"

/* Nominal Red Book CD-R capacities (75 sectors per second).
 * Note: Non-standard 90- and 99-minute media also exist, so exceeding 80 minutes
 * generates a diagnostic warning rather than a fatal error. */

/** Nominal capacity of a 74-minute CD-R (target for automatic track padding). */
static const size_t CD_74MIN_SECTORS = 333000;

/** Nominal maximum capacity of a standard 80-minute CD-R. */
static const size_t CD_80MIN_SECTORS = 360000;

/**
 * @brief Constructs the initial audio session (session 1) for Audio/Data layouts.
 *
 * Populates session 1 with audio tracks specified via `-c/--cdda-track`, or inserts
 * a 4-second silence track if no audio files were provided.
 *
 * @param session0 Target session descriptor to populate.
 * @param log When false, suppresses informational logging (used during MSINFO calculation).
 * @return True if the audio session was successfully configured; false on error.
 */
bool add_audio_session(cd_session_t* session0, bool log = true);

/**
 * @brief Adds data sessions containing the primary ISO filesystem image.
 *
 * For Audio/Data layout, adds a single data session (session 2).
 * For Data/Data layout (`data_data = true`), adds session 1 (full ISO at LBA 0)
 * and session 2 (duplicated 18-sector boot head padded to 300 sectors).
 *
 * @param img Target disc image descriptor.
 * @param iso_data Raw ISO9660 filesystem image data.
 * @param data_data True to generate Data/Data session pairs; false for Audio/Data.
 */
void add_data_track_sessions(cd_image_t* img, const std::vector<uint8_t>& iso_data, bool data_data);

/**
 * @brief Constructs the two distinct data sessions required for merged-data layouts.
 *
 * @param img Target disc image descriptor.
 * @param iso1_data Raw ISO image for session 1.
 * @param iso2_data Raw ISO image for session 2 (containing merged directory tree).
 */
void add_merged_data_sessions(cd_image_t* img,
                            const std::vector<uint8_t>& iso1_data,
                            const std::vector<uint8_t>& iso2_data);

/**
 * @brief Computes the total physical sector length of a single-track data session.
 *
 * Calculates session length (lead-in + pregap + user data + postgap + lead-out)
 * without allocating track buffer memory, enabling `-M/--print-msinfo` to compute
 * session 2 starting offsets directly from session 1 file sizes.
 *
 * @param data_size_bytes Byte size of the raw data track.
 * @param is_first_session True if this is session 1 of the disc (affects lead-out length).
 * @return Total session length in sectors.
 */
size_t data_session_length_in_sectors(uintmax_t data_size_bytes, bool is_first_session);

/**
 * @brief Calculates required padding sectors to push data to the outer rim of a 74-minute CD.
 *
 * @param image_so_far Disc image structure constructed up to this point.
 * @param data_dir Source directory containing disc contents.
 * @return Number of padding sectors needed (0 if contents already exceed 74 minutes).
 */
size_t estimate_padding_sectors(const cd_image_t* image_so_far,
                                const std::filesystem::path& data_dir);

/**
 * @brief Serializes the completed disc image to disk and frees image resources.
 *
 * Writes image files according to the format selected by `-F/--format` or file extension.
 * Takes ownership of `img` and frees it prior to returning in all code paths.
 *
 * @param img Disc image descriptor (freed internally before function returns).
 * @param output_path Destination file path.
 * @return True if image files were written successfully; false otherwise.
 */
bool write_disc_image(cd_image_t* img, const std::string& output_path);

/**
 * @brief Loads a pre-authored ISO filesystem image into memory.
 *
 * @param path Path to the ISO image file.
 * @param out_data Output vector populated with file data.
 * @return True if read successfully; false on I/O error or empty file.
 */
bool read_iso_file(const std::filesystem::path& path, std::vector<uint8_t>& out_data);
