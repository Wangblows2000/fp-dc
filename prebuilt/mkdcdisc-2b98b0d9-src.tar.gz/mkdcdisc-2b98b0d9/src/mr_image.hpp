/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Format detection and PNG-to-MR conversion for the `IP.BIN` boot logo image.
 *
 * Low-level MR format compression and encoding is handled by `makeip`
 * (`src/third_party/makeip/mr.cpp`). This module provides mkdcdisc-specific
 * integration, error translation, and reporting.
 *
 * PNG support depends on `libpng` and is enabled when `MKDCDISC_WITH_PNG` is defined
 * (detected automatically in `meson.build`). Pre-converted `.mr` files are always
 * supported, even when PNG support is omitted.
 */

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

/**
 * @brief Image file signature detected by `detect_image_format()`.
 */
enum class ImageFormat {
    Unknown, /**< Unrecognized header, unsupported format, or unreadable file. */
    Mr,      /**< Starts with "MR" magic; valid ready-to-embed MR image. */
    Png,     /**< PNG signature; requires conversion via convert_png_to_mr(). */
};

/**
 * @brief Identifies an image file format by inspecting its header magic.
 *
 * Evaluates the leading bytes of the file without decoding the full stream.
 *
 * @param path Path to the image file.
 * @return Detected format, or `ImageFormat::Unknown`.
 */
ImageFormat detect_image_format(const std::string& path);

#ifdef MKDCDISC_WITH_PNG

/**
 * @brief Converts a PNG image into the palettized, RLE-compressed MR format.
 *
 * Accepts any color type and bit depth supported by `libpng`.
 *
 * @param path Path to the source PNG file.
 * @return Raw MR bytes, or `std::nullopt` on I/O failure, decode error, or if
 *         the image contains more unique colors than the MR palette limit
 *         (`makeip::MR_MAX_PALETTE_COLORS`). Errors are logged to stderr.
 */
std::optional<std::vector<uint8_t>> convert_png_to_mr(const std::string& path);

#endif
