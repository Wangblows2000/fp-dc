/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* Raw 2352-byte Yellow Book sector encoding (Mode 1 and XA Mode 2 Form 1): header
 * formatting, payload alignment, and EDC/ECC generation.
 *
 * Encapsulates calls to libedc so that image writers can produce properly framed
 * disc sectors without directly referencing internal EDC/ECC primitives. */

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Yellow Book CD-ROM raw sector size in bytes (including sync and error correction). */
#define RAW_SECTOR_SIZE 2352

/* Yellow Book user payload size per data sector in bytes (Mode 1 and XA Mode 2 Form 1). */
#define RAW_SECTOR_USER_DATA_SIZE 2048

/* Payload start offsets per sector mode:
 * - Mode 1: 12-byte sync + 4-byte header = offset 16.
 * - XA Mode 2 Form 1: 12-byte sync + 4-byte header + 8-byte subheader = offset 24. */
#define RAW_SECTOR_MODE1_DATA_OFFSET 16
#define RAW_SECTOR_FORM1_SUBHEADER_OFFSET 16
#define RAW_SECTOR_FORM1_DATA_OFFSET 24

/* Stored sector size for CDI data tracks (2336 bytes, omitting the 16-byte sync/header). */
#define RAW_SECTOR_FORM1_STORED_SIZE (RAW_SECTOR_SIZE - RAW_SECTOR_FORM1_SUBHEADER_OFFSET)

/**
 * Encodes a complete 2352-byte XA Mode 2 Form 1 sector:
 * Generates sync pattern, 4-byte header, 8-byte duplicate subheader, places
 * `len` bytes of data (zero-padded up to 2048 bytes), and computes EDC and P/Q parity.
 *
 * @param sector Output buffer (must be at least RAW_SECTOR_SIZE bytes).
 * @param data   Input user data buffer.
 * @param len    Length of input data in bytes (clamped to 2048).
 * @param address Target sector LBA used in header encoding.
 */
void raw_sector_encode_form1(uint8_t* sector, const void* data, size_t len,
                             uint32_t address);

/**
 * Encodes a complete 2352-byte Mode 1 sector:
 * Generates sync pattern, 4-byte header, places `len` bytes of data at offset 16
 * (zero-padded up to 2048 bytes), zeroes 8 intermediate bytes, and computes EDC/ECC.
 *
 * @param sector Output buffer (must be at least RAW_SECTOR_SIZE bytes).
 * @param data   Input user data buffer.
 * @param len    Length of input data in bytes (clamped to 2048).
 * @param address Target sector LBA used in header encoding.
 */
void raw_sector_encode_mode1(uint8_t* sector, const void* data, size_t len,
                             uint32_t address);

#ifdef __cplusplus
}
#endif
