/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/*
 * GD-ROM (.gdi) disc image writer.
 *
 * Unlike single-container disc formats (CDI, MDS/MDF, NRG), a GDI image set
 * consists of a plain-text track descriptor file (the .gdi itself) accompanied
 * by separate raw track files.
 *
 * Data tracks are stored either as raw 2352-byte Mode 1 sectors (sync + header +
 * user data + EDC/ECC) or as cooked 2048-byte user data. Raw format is the default,
 * matching authentic GD-ROM dumps. Audio tracks are stored as raw 2352-byte PCM.
 * File extensions correspond to the stored sector format:
 *
 *   track??.bin  Raw 2352-byte Mode 1 data
 *   track??.iso  Cooked 2048-byte user data
 *   track??.raw  Raw 2352-byte CD-DA audio
 *
 * Each line in the .gdi file contains:
 *   <track_number> <starting_lba> <ctrl_flags> <sector_size> <filename> <offset>
 * where offset is always 0. Lines are terminated with CRLF.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "disc_image/disc_image.h"
#include "disc_image/private.h"
#include "disc_image/raw_sector.h"

#define GDI_CTRL_AUDIO 0
#define GDI_CTRL_DATA  4

#define AUDIO_SECTOR_SIZE RAW_SECTOR_SIZE

/* Mode 1 raw sector layout: 12-byte sync + 4-byte header + 2048-byte data +
 * 4-byte EDC + 8-byte reserved + 276-byte P/Q parity. See raw_sector.h. */

/* Frame Address (FAD) offset: Sector headers encode their physical address as MSF,
 * which counts from the start of the lead-in rather than LBA 0 (FAD = LBA + 150). */
#define CD_FAD_OFFSET 150

static bool join_track_path(const char* track_dir, const char* filename, char* out, size_t out_size) {
    int n;

    if(track_dir && track_dir[0] != '\0' && strcmp(track_dir, ".") != 0) {
        n = snprintf(out, out_size, "%s/%s", track_dir, filename);
    } else {
        n = snprintf(out, out_size, "%s", filename);
    }

    return n > 0 && (size_t) n < out_size;
}

/* Writes data verbatim, zero-padding the final sector when the payload is not
 * an exact multiple of the sector size. Used for cooked 2048-byte data and
 * raw CD-DA audio, neither of which includes sector framing. */
static bool write_plain(FILE* f, const uint8_t* data, size_t data_len, size_t sector_size,
                        cd_write_progress_t* progress) {
    /* Chunked rather than written in a single call, so a multi-hundred-
     * megabyte track is reported on more than once. The bytes that reach the
     * file are the same either way. */
    const size_t chunk_bytes = 512 * sector_size;
    size_t written = 0;

    while(written < data_len) {
        size_t n = data_len - written;
        if(n > chunk_bytes) {
            n = chunk_bytes;
        }

        fwrite(data + written, 1, n, f);
        written += n;

        /* A short final chunk leaves a partial sector uncounted here; the
         * padding below completes it. */
        if(cd_write_progress_add(progress, n / sector_size)) {
            return false;
        }
    }

    if(data_len % sector_size) {
        cd_write_sector_tail_padding(f, data_len, sector_size);
        if(cd_write_progress_add(progress, 1)) {
            return false;
        }
    }

    return !ferror(f);
}

/* Writes a data track as raw 2352-byte Mode 1 sectors. track_lba is the
 * track's own start LBA, needed because each sector's header encodes its
 * absolute address on the disc. */
static bool write_raw_mode1(FILE* f, const uint8_t* data, size_t data_len,
                            size_t sector_count, uint32_t track_lba,
                            cd_write_progress_t* progress) {
    for(size_t s = 0; s < sector_count; ++s) {
        uint8_t sector[CD_GDI_SECTOR_SIZE_RAW];

        /* Anything past the payload is zeroed: a short final sector is padded
         * inside the user-data area, before framing, so the EDC and ECC still
         * cover a full, valid sector. Sectors past the payload entirely, a track
         * being able to run longer than its data, come out empty but valid. */
        size_t offset = s * CD_GDI_SECTOR_SIZE_COOKED;
        const uint8_t* chunk = offset < data_len ? data + offset : NULL;
        size_t chunk_len = chunk ? data_len - offset : 0;

        raw_sector_encode_mode1(sector, chunk, chunk_len,
            track_lba + (uint32_t) s + CD_FAD_OFFSET);

        fwrite(sector, 1, sizeof(sector), f);
        if(cd_write_progress_add(progress, 1)) {
            return false;
        }
    }

    return !ferror(f);
}

static bool write_track_file(const cd_track_t* track, const char* path, bool is_data,
                             uint32_t data_sector_size, uint32_t track_lba,
                             cd_write_progress_t* progress) {
    /* nosemgrep: toctou-race-condition - a track file beside the .gdi the
     * caller named, on the same footing as the writers in disc_layout.cpp: no
     * privilege boundary, so no race worth closing. See the note there. */
    FILE* f = fopen(path, "wb");
    if(!f) {
        return false;
    }

    const uint8_t* data = cd_track_data(track);
    size_t data_len = cd_track_data_size_in_bytes(track);
    bool ok;

    if(is_data && data_sector_size == CD_GDI_SECTOR_SIZE_RAW) {
        ok = write_raw_mode1(f, data, data_len, cd_track_data_size_in_sectors(track), track_lba,
                             progress);
    } else {
        ok = write_plain(f, data, data_len, is_data ? CD_GDI_SECTOR_SIZE_COOKED : AUDIO_SECTOR_SIZE,
                         progress);
    }

    fclose(f);
    return ok;
}

bool cd_write_to_gdi(const cd_image_t* image, FILE* gdi_file, const char* track_dir,
                     uint32_t data_sector_size) {
    size_t total_tracks = cd_image_track_count(image);
    if(!gdi_file || total_tracks == 0 || total_tracks > CD_MAX_TRACKS) {
        return false;
    }

    if(data_sector_size != CD_GDI_SECTOR_SIZE_RAW && data_sector_size != CD_GDI_SECTOR_SIZE_COOKED) {
        return false;
    }

    fprintf(gdi_file, "%u\r\n", (unsigned) total_tracks);

    /* A .gdi's track files hold no gap sectors at all, the gaps being implied
     * by the LBAs the descriptor gives, so only the tracks' own sectors are
     * ever written. */
    uint64_t total_sectors = 0;
    for(size_t s = 0; s < cd_image_session_count(image); ++s) {
        cd_session_t* session = cd_image_get_session(image, s);
        for(size_t t = 0; t < cd_session_track_count(session); ++t) {
            total_sectors += cd_track_data_size_in_sectors(cd_session_get_track(session, t));
        }
    }

    cd_write_progress_t progress;
    cd_write_progress_init(&progress, image, total_sectors);

    uint32_t lba = 0;
    unsigned track_number = 0;
    bool ok = true;

    for(size_t s = 0; ok && s < cd_image_session_count(image); ++s) {
        cd_session_t* session = cd_image_get_session(image, s);
        size_t n_tracks = cd_session_track_count(session);

        for(size_t t = 0; ok && t < n_tracks; ++t) {
            cd_track_t* track = cd_session_get_track(session, t);
            ++track_number;

            uint32_t placed_lba = cd_track_placement_lba(track);

            if(placed_lba != 0) {
                /* The caller positioned this track itself. Required once GD-DA
                 * is in play: consecutive audio tracks sit flush against one
                 * another with no pregap at all, while data-to-audio boundaries
                 * keep their 150 sectors. The running walk below applies one
                 * pregap rule per track and cannot express that. */
                lba = placed_lba;
            } else if(track_number == 1) {
                lba = 0;
            } else if(t == 0) {
                /* First track of a later session: the fixed high-density
                 * zone start. There is no Red Book-style lead-in or lead-out
                 * gap on a GD-ROM between the low- and high-density zones. The
                 * gap is a fixed physical constant, not something computed from
                 * the previous session's length. */
                lba = CD_GD_START_LBA;
            } else {
                lba += (uint32_t) cd_track_pregap_sectors(track);
            }

            bool is_data = cd_track_type(track) == TRACK_TYPE_DATA;
            uint32_t sector_size = is_data ? data_sector_size : AUDIO_SECTOR_SIZE;
            uint32_t ctrl = is_data ? GDI_CTRL_DATA : GDI_CTRL_AUDIO;

            const char* ext = !is_data ? "raw"
                : (data_sector_size == CD_GDI_SECTOR_SIZE_RAW ? "bin" : "iso");

            char filename[32];
            snprintf(filename, sizeof(filename), "track%02u.%s", track_number, ext);

            char path[1024];
            if(!join_track_path(track_dir, filename, path, sizeof(path))) {
                ok = false;
                break;
            }

            ok = write_track_file(track, path, is_data, data_sector_size, lba, &progress);
            if(!ok) {
                break;
            }

            fprintf(gdi_file, "%u %u %u %u %s 0\r\n", track_number, lba, ctrl, sector_size, filename);

            lba += (uint32_t) cd_track_data_size_in_sectors(track);
        }
    }

    return ok && !ferror(gdi_file);
}

cd_image_t* cd_load_from_gdi(FILE* input) {
    (void) input;
    return NULL;
}
