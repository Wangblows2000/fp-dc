/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

#include "disc_image.h"

struct _cd_track_t {
    cd_session_t* session;

    track_type_t type;
    track_mode_t mode;

    uint8_t* data;
    size_t data_len;

    /* false when data is borrowed from caller (cd_new_track_borrowed);
     * true when allocated and owned by this track object. */
    bool owns_data;

    size_t pregap_sectors;
    size_t postgap_sectors;

    /* Explicit starting LBA (e.g. for GD-ROM track spacing), or 0 to derive
     * position automatically from session layout. */
    uint32_t placement_lba;

    cd_track_t* next_track;
};

struct _cd_session_t {
    cd_image_t* image;
    cd_track_t* first_track;
    cd_session_t* next_session;
};

struct _cd_image_t {
    char volume_name[255];
    cd_session_t* first_session;

    /* Borrowed progress callback reference (or NULL). */
    const progress_t* progress;
};

/* Tracks writing progress across multiple disc image formats.
 * Because each format writes a distinct set of sectors (e.g. including or omitting
 * pregaps), progress is tracked in terms of actual sectors written out. */
typedef struct {
    const progress_t* progress;
    uint64_t written;
    uint64_t total;
} cd_write_progress_t;

static inline void cd_write_progress_init(cd_write_progress_t* p,
                                          const cd_image_t* image,
                                          uint64_t total_sectors) {
    p->progress = cd_image_progress(image);
    p->written = 0;
    p->total = total_sectors;
}

/* Updates sector write progress. Returns non-zero if writing was cancelled/interrupted. */
static inline int cd_write_progress_add(cd_write_progress_t* p, uint64_t sectors) {
    p->written += sectors;
    return progress_report(p->progress, p->written, p->total);
}

/* Fills trailing bytes of an incomplete sector with zeros up to `sector_size`. */
void cd_write_sector_tail_padding(FILE* f, size_t data_len, size_t sector_size);

/* Writes `count` sectors of digital silence (zero-filled 2352-byte sectors). */
void cd_write_silent_sectors(FILE* f, size_t count);
