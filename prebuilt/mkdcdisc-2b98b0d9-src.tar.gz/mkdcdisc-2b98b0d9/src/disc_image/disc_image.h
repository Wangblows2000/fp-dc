/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>

#include "progress.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Example Usage:
 *
 * cd_image_t* image = cd_new_image();
 * cd_session_t* session = cd_new_session(image);
 * cd_track_t* track = cd_new_track(session, TRACK_TYPE_AUDIO, audio_data, audio_len);
 *
 * FILE* f = fopen("myimage.cdi", "wb");
 * cd_write_to_cdi(image, f, "myimage.cdi");
 * fclose(f);
 * cd_free_image(&image);
 */

typedef enum {
    TRACK_TYPE_AUDIO,
    TRACK_TYPE_DATA
} track_type_t;

typedef enum {
    TRACK_MODE_CDDA,
    TRACK_MODE_MODE1,
    TRACK_MODE_MODE2,
    TRACK_MODE_XA_MODE2_FORM1,
    TRACK_MODE_XA_MODE2_FORM2,
} track_mode_t;

/* Starting LBA of the GD-ROM high-density area (LBA 45000 on pressed media).
 * Used both by libisofs (as `ms_block`) and by the GDI image writer. */
#define CD_GD_START_LBA 45000

/* Red Book maximum track limit per disc (tracks 1 to 99).
 * GD-ROM images allocate tracks 1 and 2 to the low-density area and
 * tracks 3 through 99 to the high-density area. */
#define CD_MAX_TRACKS 99

struct _cd_session_t;
struct _cd_track_t;
struct _cd_image_t;

typedef struct _cd_session_t cd_session_t;
typedef struct _cd_track_t cd_track_t;
typedef struct _cd_image_t cd_image_t;

cd_image_t* cd_new_image();
void cd_free_image(cd_image_t** img);

size_t cd_image_session_count(const cd_image_t* img);
size_t cd_image_track_count(const cd_image_t* img);
size_t cd_image_length_in_sectors(const cd_image_t* img);

cd_session_t* cd_image_get_session(const cd_image_t* img, size_t idx);

void cd_image_set_volume_name(cd_image_t* img, const char* name);
const char* cd_image_volume_name(const cd_image_t* img);

/* Attaches a progress callback invoked during image output writing.
 * The progress pointer is borrowed and must remain valid for the duration
 * of any write operations. Pass NULL to disable progress reporting. */
void cd_image_set_progress(cd_image_t* img, const progress_t* progress);
const progress_t* cd_image_progress(const cd_image_t* img);

cd_session_t* cd_new_session(cd_image_t* img);
size_t cd_session_track_count(const cd_session_t* session);
cd_track_t* cd_session_get_track(const cd_session_t* session, size_t idx);

size_t cd_track_pregap_sectors(const cd_track_t* track);
bool cd_track_set_pregap_sectors(cd_track_t* track, size_t pregap);
size_t cd_track_postgap_sectors(const cd_track_t* track);
bool cd_track_set_postgap_sectors(cd_track_t* track, size_t pregap);

/* Total session length including lead-in and lead-out areas. */
size_t cd_session_length_in_sectors(const cd_session_t* session);

/* Total user data sectors within the session, including pregap sectors. */
size_t cd_session_data_length_in_sectors(const cd_session_t* session);

/* Creates a track by copying `data_len` bytes from `data`.
 * Pass NULL to initialize a zero-filled track buffer (equivalent to cd_new_track_blank()). */
cd_track_t* cd_new_track(
    cd_session_t* session,
    track_type_t type,
    const uint8_t* data,
    const uint32_t data_len
);

/* Creates a track that borrows the caller's data buffer without copying.
 *
 * Used primarily for GD-ROM high-density data tracks (~1 GB) to avoid redundant
 * memory allocations during disc image generation.
 *
 * Caller requirement: `data` must remain allocated, valid, and unmodified until
 * the containing cd_image_t is freed via cd_free_image(). */
cd_track_t* cd_new_track_borrowed(
    cd_session_t* session,
    track_type_t type,
    const uint8_t* data,
    const uint32_t data_len
);

cd_track_t* cd_new_track_blank(
    cd_session_t* session,
    track_type_t type,
    const uint32_t data_len
);

track_type_t cd_track_type(const cd_track_t* track);
uint8_t* cd_track_data(const cd_track_t* track);

size_t cd_track_data_size_in_bytes(const cd_track_t* track);
size_t cd_track_data_size_in_sectors(const cd_track_t* track);

size_t cd_track_total_size_in_sectors(const cd_track_t* track);

track_mode_t cd_track_mode(const cd_track_t* track);
void cd_track_set_mode(cd_track_t* track, track_mode_t mode);

/* Computes the track's starting LBA based on disc session layout, preceding track
 * lengths, pregaps, and postgaps. Used by CDI and NRG writers. */
uint32_t cd_track_start_lba(const cd_track_t* track);

/* Overrides standard layout-derived LBA with an explicit placement LBA (0 = no override).
 *
 * Honored exclusively by the GDI writer to accommodate GD-ROM track spacing:
 * contiguous GD-DA audio tracks have no pregap, while transition boundaries
 * retain the standard 150-sector pregap. */
void cd_track_set_placement_lba(cd_track_t* track, uint32_t lba);
uint32_t cd_track_placement_lba(const cd_track_t* track);

bool cd_write_to_cdi(const cd_image_t* image, FILE* output, const char* filename);
bool cd_write_to_mds(const cd_image_t* image, FILE* mds, FILE* mdf);
bool cd_write_to_nrg(const cd_image_t* image, FILE* output);

/* Sector sizes for GD-ROM data tracks in cd_write_to_gdi(). */
#define CD_GDI_SECTOR_SIZE_RAW    2352 /* Mode 1: sync + header + user data + EDC/ECC */
#define CD_GDI_SECTOR_SIZE_COOKED 2048 /* User data only (no sector framing) */

/* Writes a GD-ROM image: the .gdi text descriptor to gdi_file, and individual
 * track files into track_dir (e.g. "." or "output_dir").
 * `data_sector_size` must be CD_GDI_SECTOR_SIZE_RAW (track??.bin) or
 * CD_GDI_SECTOR_SIZE_COOKED (track??.iso). Audio tracks are written as track??.raw. */
bool cd_write_to_gdi(const cd_image_t* image, FILE* gdi_file, const char* track_dir,
                     uint32_t data_sector_size);

cd_image_t* cd_load_from_cdi(FILE* input);
cd_image_t* cd_load_from_mds(FILE* input);
cd_image_t* cd_load_from_nrg(FILE* input);
cd_image_t* cd_load_from_gdi(FILE* input);

#ifdef __cplusplus
}
#endif
