/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Content-based file deduplication (`--duplicates-once`).
 *
 * Writes byte-identical files into the data track once, mirroring the behavior
 * of mkisofs' `--duplicates-once` option.
 *
 * Duplicate detection is based strictly on file contents rather than filesystem
 * metadata (such as inode numbers).
 *
 * libisofs shares an on-disc extent between two IsoFile nodes whenever both
 * nodes reference the exact same `IsoStream*` pointer. Extent sharing is therefore
 * achieved by supplying identical streams rather than relying on OS-level inode
 * queries. This ensures consistent cross-platform behavior: `iso_stream_cmp_ino()`
 * checks pointer equality before evaluating (fs_id, dev_id, ino_id) triples,
 * avoiding reliance on `st_ino`, which is not supported by the Windows CRT.
 *
 * Equality is verified through a progressive multi-stage check:
 * 1. File size matching.
 * 2. MD5 digest of the first 64 KiB chunk.
 * 3. Full-file MD5 digest.
 * 4. Byte-by-byte content comparison (eliminating hash collision risks).
 */

#include <cstddef>
#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

#define LIBISOFS_WITHOUT_LIBBURN yes
#include <libisofs.h>

struct DuplicateStats {
    /** Number of unique groups containing identical files. */
    size_t groups = 0;

    /** Total number of redundant files merged into shared extents. */
    size_t aliases = 0;

    /** Total bytes saved across all deduplicated files (unpadded). */
    uint64_t bytes_saved = 0;

    /** Diagnostic messages for files whose sort weight was adjusted to match
     * a higher-weighted duplicate. */
    std::vector<std::string> weight_conflicts;
};

/**
 * @brief Collapses byte-identical regular files onto a single shared disc extent.
 *
 * Order of execution is critical: this must run after the directory tree
 * is populated and sort weights have been applied (`-S/--sort-file`), but before
 * `iso_image_create_burn_source()`, so that extent layout is determined using
 * the updated stream relationships.
 *
 * @param image The ISO image being constructed.
 * @param root  Root directory to inspect recursively.
 * @param excluded Set of nodes excluded from deduplication (e.g. boot binaries).
 * @param weights Applied sort weights per node. Following mkisofs conventions,
 *                a shared extent adopts the highest sort weight among all
 *                files referencing it. Subordinated weights are recorded in
 *                `weight_conflicts`.
 * @return Summary of merged duplicates and any sort weight adjustments.
 */
DuplicateStats collapse_duplicate_files(IsoImage* image, IsoDir* root,
                                        const std::set<IsoNode*>& excluded,
                                        const std::map<IsoNode*, int>& weights);

/**
 * @brief Applies deduplication if `--duplicates-once` is enabled and logs the results.
 *
 * @param area Name of the disc area being processed (e.g. "high-density area").
 *             Used in diagnostic messages and to prevent duplicate logging
 *             during multi-pass builds.
 * @param image The ISO image being constructed.
 * @param root  Root directory to inspect recursively.
 * @param excluded Set of nodes excluded from deduplication.
 * @param weights Applied sort weights per node.
 */
void apply_duplicates_once(const char* area, IsoImage* image, IsoDir* root,
                           const std::set<IsoNode*>& excluded,
                           const std::map<IsoNode*, int>& weights);
