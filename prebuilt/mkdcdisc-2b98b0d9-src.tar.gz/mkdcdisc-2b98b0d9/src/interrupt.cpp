/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Interruption handling: see interrupt.hpp. */

#include <csignal>

#include "interrupt.hpp"

/* `volatile sig_atomic_t` is the only object type standard C signal handlers
 * can safely access and mutate without risking undefined behavior. */
static volatile std::sig_atomic_t g_interrupting_signal = 0;

namespace {

extern "C" void record_interrupt(int sig) {
    g_interrupting_signal = sig;

    /* Reset to default signal disposition so a second signal terminates the process
     * immediately if the active operation hangs. The Windows C runtime resets
     * the disposition automatically before calling the handler, whereas POSIX does
     * not; restoring SIG_DFL explicitly guarantees consistent behavior across both. */
    std::signal(sig, SIG_DFL);
}

}

void install_interrupt_handler() {
    std::signal(SIGINT, record_interrupt);
    std::signal(SIGTERM, record_interrupt);

#ifdef SIGBREAK
    /* Windows Ctrl+Break event. Delivered to console applications via a process
     * group control event rather than a console interrupt, but represents the
     * same user intent to cancel. */
    std::signal(SIGBREAK, record_interrupt);
#endif
}

bool interrupted() {
    return g_interrupting_signal != 0;
}

int interrupted_exit_code() {
    return 128 + (int) g_interrupting_signal;
}
