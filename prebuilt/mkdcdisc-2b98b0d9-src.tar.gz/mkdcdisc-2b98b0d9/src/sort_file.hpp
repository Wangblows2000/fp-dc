/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Parses and applies mkisofs-compatible sort weight files.
 *
 * Sort files define disc paths and corresponding integer weights to control the
 * physical placement of files on the disc, optimizing seek times and loading
 * performance.
 *
 * libisofs assigns higher weights to lower block addresses ("the greater
 * this value is, the closer from the beginning of image the file will be
 * written"). Consequently, higher weights position files closer to the inner
 * edge of the disc track.
 */

#include <map>

#define LIBISOFS_WITHOUT_LIBBURN yes
#include <libisofs.h>

/**
 * Reads the sort file specified by command-line `option` (taking no action if
 * the option was omitted) and applies the weights to `root` and all child nodes.
 * Paths are matched against target disc paths; an entry for "/" weights `root`.
 *
 * Sort weights are parsed fresh on every call and are not cached, ensuring that
 * options for different disc sessions (e.g. low-density vs high-density) remain
 * isolated and preventing order-dependent side effects across multiple build
 * passes.
 *
 * Returns a mapping from each visited IsoNode to its assigned weight. This is
 * required for `--duplicates-once` deduplication: shared extents occupy a
 * single physical location and, following mkisofs semantics, take the highest
 * weight among all referencing files.
 */
std::map<IsoNode*, int> apply_sort_file(const char* option, IsoDir* root);
