/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Track geometry and layout planning calculations for GD-ROM high-density tracks.
 *
 * Provides physical disc constants and layout sizing calculations for the GD-ROM
 * high-density area.
 *
 * Implemented without external dependencies (no CLI option parsing or libisofs types)
 * to facilitate direct unit testing of boundary edge cases.
 */

#include <cstddef>

#include "disc_image/disc_image.h"

namespace gd_track {

/** Fixed physical boundary of the GD-ROM high-density area: begins at
 * CD_GD_START_LBA (45000) and terminates at sector 549150. */
inline constexpr size_t GD_END_LBA = 549150;

/**
 * @brief Reserved run-out sectors at the end of a GD-ROM data track (150 sectors).
 *
 * Pressed GD-ROM data tracks reserve a 150-sector run-out margin at the end of the track.
 * GDIbuilder follows the same convention, terminating the last file at GD_END_LBA - 150.
 *
 * These sectors serve as an optical run-out buffer on physical media. Placing critical
 * files (such as `1ST_READ.BIN`) in this zone risks read errors on real hardware,
 * even though software emulators generally read beyond the run-out margin without error.
 */
inline constexpr size_t TRACK_END_RESERVED_SECTORS = 150;

/** Minimum track length specified by Red Book standards (300 sectors = 150 pregap + 150 content).
 * Enforced even with `--gdi-truncate`, as disc inspection tools (such as GD-ROM Explorer)
 * reject high-density tracks shorter than 300 sectors. */
inline constexpr size_t MIN_HD_SECTORS = 300;

/**
 * @brief Minimum content length required for individual tracks in a split high-density layout.
 *
 * When GD-DA audio is present, the high-density area is split into three parts:
 * an initial data track, intermediate audio tracks, and a closing data track.
 * Each data track must independently satisfy MIN_HD_SECTORS.
 *
 * Accounting for the 150-sector run-out on each data track, each side requires
 * at least MIN_SPLIT_SIDE_SECTORS of filesystem space. `build_gd()` inserts filler
 * buffers to ensure compliance.
 */
inline constexpr size_t MIN_SPLIT_SIDE_SECTORS = MIN_HD_SECTORS - TRACK_END_RESERVED_SECTORS;

/** Calculates the total sector reservation required for split tracks when GD-DA tracks are present. */
inline constexpr size_t split_reserve(size_t spacer_sectors) {
    return spacer_sectors > 0 ? 2 * MIN_SPLIT_SIDE_SECTORS : 0;
}

/**
 * @brief Maximum supported GD-DA audio tracks in the high-density area (95 tracks).
 *
 * The high-density area spans tracks 3 through 99 (97 tracks total).
 * Reserving track 3 for the initial data track and track 99 for the closing data
 * track leaves a maximum of 95 audio tracks.
 *
 * The IP.BIN Table of Contents (TOC) structure also reserves exactly 97 entries
 * for high-density tracks (see `write_gdi_hda_toc()`).
 */
inline constexpr size_t MAX_GDDA_TRACKS = 95;

/** Total physical sectors in a standard high-density area and usable content capacity. */
inline constexpr size_t FULL_TRACK_SECTORS = GD_END_LBA - CD_GD_START_LBA;
inline constexpr size_t MAX_CONTENT_SECTORS = FULL_TRACK_SECTORS - TRACK_END_RESERVED_SECTORS;

/**
 * @brief Result of track layout planning via plan_track().
 *
 * If `fits` is false, the requested content exceeds the maximum track capacity.
 */
struct Plan {
    bool fits;
    size_t track_sectors;          /* Physical track length in sectors */
    size_t content_target_sectors; /* Sectors allocated for filesystem data */
};

/**
 * @brief Computes track geometry and layout dimensions for high-density GD-ROM tracks.
 *
 * For standard (padded) builds, the track is padded to the full physical GD-ROM
 * capacity (FULL_TRACK_SECTORS), ending at GD_END_LBA.
 *
 * For truncated builds (`--gdi-truncate`), the track size is truncated to fit the
 * content plus run-out (floored at MIN_HD_SECTORS).
 *
 * Note on `--gdi-truncate` compatibility: Truncated GDI images are non-standard.
 * While optical drive emulators (ODEs) using GDI metadata can boot truncated tracks,
 * some emulators (such as nullDC and Demul) expect the high-density area to extend
 * to the physical end LBA (549150) and return to the BIOS menu if truncated.
 *
 * @param content_sectors Total filesystem sectors required by the contents.
 * @param spacer_sectors  Sectors reserved for GD-DA audio tracks (0 if no audio).
 * @param truncate        Whether `--gdi-truncate` is enabled.
 */
inline Plan plan_track(size_t content_sectors, size_t spacer_sectors, bool truncate) {
    /* Account for content, GD-DA tracks, and minimum split-track safety margins. */
    const size_t occupied_sectors =
        content_sectors + spacer_sectors + split_reserve(spacer_sectors);

    if(!truncate) {
        if(occupied_sectors > MAX_CONTENT_SECTORS) {
            return {false, 0, 0};
        }

        return {true, FULL_TRACK_SECTORS, MAX_CONTENT_SECTORS};
    }

    /* Size track to content plus run-out, respecting Red Book minimum length. */
    const size_t wanted = occupied_sectors + TRACK_END_RESERVED_SECTORS;
    const size_t track_sectors = wanted > MIN_HD_SECTORS ? wanted : MIN_HD_SECTORS;

    return {true, track_sectors, track_sectors - TRACK_END_RESERVED_SECTORS};
}

}  /* namespace gd_track */
