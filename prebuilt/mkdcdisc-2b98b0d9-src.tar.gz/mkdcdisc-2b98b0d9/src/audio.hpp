/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/**
 * @file
 * @brief Decodes audio files into raw CD-DA sectors for disc tracks.
 *
 * Session assembly and track arrangement are handled separately by `disc_layout`.
 */

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

#include "disc_image/raw_sector.h"

/**
 * @brief Represents one CD-DA sector: 588 stereo 16-bit frames (1/75 s).
 *
 * Alias for `RAW_SECTOR_SIZE` (`disc_image/raw_sector.h`), named for readability
 * in this audio-specific context.
 */
inline constexpr size_t CDDA_SECTOR_SIZE = RAW_SECTOR_SIZE;

/**
 * @brief Extracts the CD-DA payload from a WAV file.
 *
 * Returns raw audio PCM data ready to be split into `CDDA_SECTOR_SIZE` sectors.
 * This function validates the format and performs no audio conversion: any WAV
 * whose format chunk is not exactly 44.1 kHz, 16-bit stereo PCM is rejected.
 *
 * @param filename Path to the WAV file.
 * @return Raw PCM bytes, or `std::nullopt` if the format is unsupported or the
 *         file cannot be read (errors are reported on stderr).
 */
std::optional<std::vector<uint8_t>> wav_to_cdda(const std::string& filename);

/**
 * @brief Reads a headerless raw audio file into a CD-DA payload.
 *
 * Reads the bytes as-is, assuming the input is already formatted as 44.1 kHz,
 * 16-bit stereo PCM. If the file does not end on a sector boundary, it is still
 * accepted with a diagnostic note on stderr; disc image writers pad the final
 * sector with silence.
 *
 * @param filename Path to the raw audio file.
 * @return Raw PCM bytes, or `std::nullopt` if the file cannot be read (errors
 *         are reported on stderr).
 */
std::optional<std::vector<uint8_t>> raw_to_cdda(const std::string& filename);

/**
 * @brief Loads an audio track by auto-detecting its format.
 *
 * Inspects the file contents for a RIFF header to determine whether to call
 * `wav_to_cdda()` or `raw_to_cdda()`. The file extension is ignored; only the
 * header signature is evaluated. This is the preferred entry point for loading
 * audio tracks.
 *
 * @param filename Path to the audio file.
 * @return Raw PCM bytes, or `std::nullopt` on failure.
 */
std::optional<std::vector<uint8_t>> load_audio_track(const std::string& filename);
