# Test payloads

The end-to-end tests need real Dreamcast executables to build discs from, so
this folder provides two: one built with KallistiOS and one built with the
Katana SDK. Both are prebuilt and committed, along with their source, and
neither needs to be rebuilt unless you want to change one. No proprietary
code is included in this repository.

Despite coming from different SDKs, the two samples behave identically: each
plays two CD-DA audio tracks and draws one PVR background image (`bkgnd.pvr`)
read from the disc.

`tests/e2e/test_bootable_disc.cpp` uses these files to build its discs. There
is one folder per environment, plus a `common/` folder shared by both:

```
common/                 the CD-DA tracks (.da), and the background artwork
kos/
  kos.elf               the executable, as an ELF          -> mkdcdisc -e
  cd_root/bkgnd.pvr     what goes in the MIL-CD filesystem -> mkdcdisc -D
  src/                  source and makefile
katana/
  katana.bin            the executable, unscrambled        -> mkdcdisc -b
  gd_root/bkgnd.pvr     what goes in the GD-ROM filesystem -> mkdcdisc -D
  src/                  source and makefile
```

The executable lives beside the disc root, not inside it. mkdcdisc writes it
into the filesystem itself when given `-e`/`-b`, so putting a copy in the `-D`
tree too would duplicate the same file.

The executables keep their own names instead of being renamed to
`1ST_READ.BIN`. That name is what mkdcdisc puts on the disc, driven by the
IP.BIN header; `--boot-filename` changes both the header and the filesystem
entry together. Since this folder does not decide that name, its files
shouldn't pretend to.

## Why one is an ELF and the other a binary

Each toolchain hands over whatever it produces. KallistiOS produces an ELF,
and mkdcdisc converts it itself via the `-e` route. The Katana toolchain
converts its own ELF with `elf2bin`, producing a binary already loadable at
`0x8C010000`; mkdcdisc has no equivalent conversion for that format, so this
one is stored pre-converted and used via `-b`. Together the two payloads
exercise both routes naturally. The test also exercises the third route,
`-B`, by scrambling the Katana binary itself, so no fourth file is needed.

## Why the binaries are committed

No CI runner has an SH-4 toolchain, and the Katana toolchain cannot even be
installed on one. So these files follow the same arrangement already used for
the bundled MR logo: the maintainer builds them locally and commits the
result, and CI just consumes it. Until `kos/kos.elf` exists, `meson setup`
reports that and skips registering the `bootable_disc` test.

## Which disc each payload is built for

Each environment ships the disc root that matches its payload's target:
KallistiOS targets the MIL-CD, Katana targets the GD-ROM.

That pairing is required, not arbitrary. The two CD-DA tracks sit at
different track numbers on each disc: 1 and 2 on a MIL-CD, where the audio
session comes first, versus 4 and 5 on a GD-DA disc, after the low-density
pair and the high-density data track. A payload has to be built knowing
which disc it targets.

To add a missing combination (for example a `kos/gd_root`), add that root to
the environment and extend the corpus table in the test.

## The background image

Every disc root includes a `bkgnd.pvr`. Both payloads read it from the disc
at boot and draw it across the whole screen; that's the only reason these
roots contain anything. `-D` is what writes these files into the filesystem,
and having a payload actually open one is what confirms that what mkdcdisc
writes is readable on a real console, not just readable back out of the
image file.

Both payloads read the image before starting audio playback. The drive
cannot serve the data track and the audio session at once, so a read
triggered after music has started would interrupt it to seek.

The file is `bkgnd.pvr` on disc but both payloads open it as `BKGND.PVR`,
matching Sega's own GDFS sample (`gd_root/abc.dat`, opened as `"ABC.DAT"`).
ISO9660 uppercases names and appends a version, and on a GD-ROM that
uppercase tree is all the Katana payload's filesystem has to search. The
KallistiOS payload instead reads the Joliet tree, which keeps the original
case, but its lookup is case-insensitive, so the same uppercase string works
for both.

Neither payload requires this image. A disc root with no `bkgnd.pvr` still
boots and plays; the screen just stays blank behind the text. Before this
file was added, every image built by the e2e test looked like that, which is
why each payload checks for the image instead of assuming it's there.

### Requirements for the image

* **Square, a power of two per side, 512x512 at most.** Power-of-two because
  that's what PVR supports; 512 because that's the largest texture the
  Katana payload's work buffer is sized for. Smaller images are still fine:
  both payloads map the whole texture across the whole screen using
  fractions, not pixel counts, so any size covers the screen, just with less
  detail.
* **ARGB1555, RGB565 or ARGB4444**, twiddled or VQ-compressed.
* **No mipmaps and no palette.** A mipmapped file stores its smallest level
  first, and the KallistiOS loader rejects such a file rather than upload
  the mipmap pyramid as if it were the actual image.

The committed image uses VQ compression: 66 KB versus 512 KB uncompressed.
It's committed twice, once per disc root. VQ is lossy and can hurt fine
detail, so this choice is specific to this image rather than a general rule.
The logo is mostly flat color, and after decoding the compressed result no
pixel differed from the source by more than 32 levels out of 255; the mean
error was 1.2 levels per channel and the worst case was 25. Artwork with
gradients or fine texture may be worth the extra 512 KB uncompressed instead.

Those numbers describe this specific image. Re-measure them if the artwork
changes rather than assuming they still hold: a VQ codebook tuned for flat
color says nothing about one that has to cover a gradient.

### Making one

The source file is `common/bkgnd.png`, exported from `common/bkgnd.psd`.

`pvrtex` is KallistiOS's converter, located at `utils/pvrtex` and available
on the DreamSDK path. It reads PNG directly, and mipmaps are off by default:

```sh
pvrtex -i bkgnd.png -o bkgnd.pvr -f RGB565 -c
```

`-f RGB565` sets the pixel format, and `-c` enables VQ with a full codebook.
Copy the result into both `kos/cd_root/` and `katana/gd_root/`. Adding
`-p preview.png` writes out what the compression did, worth checking before
committing a new image.

**The output has no `GBIX` chunk, and neither payload needs one.** `GBIX` is
optional in the PVR container; only `PVRT` is required. The Katana payload
supplies its own global index from C via `NJD_TEXATTR_GLOBALINDEX` in its
`NJS_TEXNAME`, with the index in the next field. The Ninja documentation
describes this as the way to load a file that carries no index of its own,
and it takes precedence over the chunk when both exist. The KallistiOS
payload's parser also just skips a `GBIX` chunk if present and only requires
`PVRT`. So the tool's warning that official loaders may reject files without
`GBIX` does not apply here.

The Katana SDK also ships its own converter, `pvrconv`, at
`Utl\Gfx\Conv\PVRConv`. It doesn't read PNG, only `.bmp`, `.tga`, `.pic` and
`.pix`, so the image needs to be exported to a 24-bit `.bmp` first. Its
default output is a mipmapped square, so the flags disabling mipmaps are
required, not optional:

```
pvrconv -v4 -5 -nm -nvm -gi 0 -out bkgnd.pvr bkgnd.bmp
```

`-v4` selects VQ, `-5` selects RGB565, `-nm`/`-nvm` disable mipmaps, and
`-gi 0` writes a global index chunk of 0. On this image `pvrconv` produces a
measurably worse codebook than `pvrtex`: a worst-case error of 42 levels
versus 25, and 21 pixels past the 32-level mark where `pvrtex` has none.
That's why `pvrconv` wasn't used to generate the committed file.

Both `pvrtex` and `pvrconv` rely on machine-specific SDK paths, so the same
arrangement applies here as elsewhere: the maintainer converts the image
locally and commits the result, and CI just consumes it.

Swapping the image does not require regenerating
`tests/fixtures/bootable-disc-manifest.txt`. That file pins the boot binary
and the IP.BIN header; it says nothing about how the filesystem is sized or
laid out. What the disc root carries is validated by being read on a real
console, which is the whole point of having the payloads draw it.

## Building them

Both makefiles place their output where the test expects it, at the root of
their environment's folder, so building is all that's needed; nothing else
has to be copied afterward.

**KallistiOS.** From any shell where KallistiOS is set up (DreamSDK is one,
but nothing here depends on it specifically):

```sh
cd kos/src && make
```

**Katana.** Run the SDK's `SetPaths.bat` first, which puts `gmake`, `shc` and
`elf2bin` on the path, then:

```
cd katana\src
gmake
```

The Hitachi SHC compiler builds this source, not GCC, so `__GNUC__` is never
defined there.

There is deliberately no `regen-payloads` meson target. Both SDKs live at
machine-specific paths, so a target that only works on one workstation and
fails everywhere else would add little value.

After rebuilding either payload, run this to update the manifest:

    meson compile -C builddir regen-bootable-disc-manifest

Review the diff before committing it. A rebuilt binary should only change
its size and digests; anything else that changed is worth investigating.

## What they do

Both payloads are meant to be run, not just built. `meson compile -C builddir
demo-discs` builds the disc images for exactly that purpose. Each payload
draws the disc's background image, reports which CD-DA tracks it requested
and whether the drive is still playing them, and lets the controller do
whatever that SDK supports: start/stop on the Katana side, volume/pan on the
KallistiOS side (the only one of the two with a mixer it can reach). This
makes a disc verifiable by ear as well as by eye, exercising all three things
mkdcdisc writes to it: the boot binary, the CD-DA tracks, and the disc root
files.

The two SDKs are not interchangeable here. A KallistiOS program sets the
SH-4 `FPSCR` rounding mode itself, while Katana code inherits whatever the
bootstrap left it, which is exactly the distinction `--gdi-fpu-rounding`
exists to control. Having one payload of each SDK is what makes that
difference observable on real hardware.

## What is not in here

No Katana SDK source. Sega's samples all include a copy of `sbinit.c` for
system bring-up, and the GD-DA sample loads `MANATEE.DRV` for CD-DA
volume/pan control. Neither can go in a public MIT repository, so
`katana/src/init.c` is written from scratch against the documented API, and
this payload does without volume control. Playback itself only needs
`gdFsDaPlay()`, a GD filesystem call that requires no sound driver.

No SDK artwork either. The Katana samples ship plenty of `.pvr` files, and
all of them belong to Sega, so the background image had to come from
elsewhere this repository is free to carry. `pvrconv` is a converter, not a
source of images.
