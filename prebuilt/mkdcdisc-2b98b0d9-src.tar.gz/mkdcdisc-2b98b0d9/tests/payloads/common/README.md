# Shared payload assets

What belongs to neither payload in particular: the CD-DA tracks both play, and
the artwork both draw. Shared here rather than under `kos/` or `katana/` because
the same material goes on the MIL-CD and on the GD-DA disc.

## CD-DA tracks

The two audio tracks `tests/e2e/test_bootable_disc.cpp` writes to every disc in
the corpus that carries CD-DA, and that both payloads play. The same two tracks
go on both discs, only at different track numbers.

| File | Sectors | Length | Source |
|:-----|--------:|-------:|:-------|
| `wien-bleibt-wien.da` | 2709 | 0:36 | [Wien_bleibt_Wien](https://freesound.org/people/thulitt/sounds/150025/) by **thulitt** |
| `stargazer.da` | 2448 | 0:32 | [Stargazer (125 BPM)](https://freesound.org/people/Alien_I_Trust/sounds/785736/) by **Alien_I_Trust** |

Both are **CC0 1.0** — public domain, usable for any purpose, commercial
included, with no attribution required. That matters here beyond good manners:
this repository is MIT, and the CI publishes disc images carrying these tracks
for download. Anything under a NonCommercial clause would contradict the licence
the repository itself grants, so a replacement track has to be CC0 too. The
credits above are courtesy, not obligation.

### The format

Red Book CD-DA, which is what `-c/--cdda-track` expects: headerless PCM, 16-bit
little-endian, stereo, 44.1 kHz. A sector holds 2352 bytes, which is 588 frames.

The `.da` extension is the Katana SDK's name for exactly this, and is used here
rather than `.raw`, which says only that something has no header.

Both sources are 32-bit WAV, so converting is not just a matter of dropping the
header:

```sh
ffmpeg -i <source>.wav -f s16le -ar 44100 -ac 2 -y <track>.da
```

Then pad to a whole number of sectors, which ffmpeg will not do. `stargazer`
happened to land exactly on 2448 sectors; `wien-bleibt-wien` came out 2288 bytes
short of 2709 and was filled out with silence:

```sh
head -c $((2352 - $(stat -c%s track.da) % 2352)) /dev/zero >> track.da
```

Different lengths on purpose. A swapped or repeated track then moves an LBA
further down the disc, which the disc manifest notices, and is audible to
whoever is holding the controller.

## The background image

`bkgnd.png` is the Simulant logo at 512x512, and it is what the `bkgnd.pvr` in
each disc root is converted from; `bkgnd.psd` is the layered original it was
exported from. Neither of them reaches a disc — a Dreamcast reads neither format
— so only the converted texture is copied into `kos/cd_root/` and
`katana/gd_root/`.

The conversion, and what the payloads require of the result, is in
[../README.md](../README.md).
