/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/*

Based on the basic_cdda example in the KOS source tree, which is a simple test
of the CD-DA playback code. (c) 2002 Megan Potter.

The KallistiOS half of the bootable-disc payloads, from the KOS example
basic_cdda: it plays the disc's two CD-DA tracks in a loop and then lets you
control them until you hit START.

Adapted in which tracks it plays (see below) and given something to look at.
The stock example displays nothing at all, which on a disc whose whole purpose
is to be tried on a console leaves you guessing whether it booted. It now draws
a background image read off the disc, with the same status lines the Katana
payload next door prints, so the two discs can be told apart at a glance.

The background is what makes the disc root worth shipping. mkdcdisc's -D writes
those files into the filesystem, and until a payload opened one of them nothing
here had ever shown that what it writes is readable on hardware -- only that the
bytes come back out of the image file.

Paired with that Katana payload, which covers the GD-ROM. Between the two,
mkdcdisc's -e and -b routes are both exercised on a disc that really boots.

Use the DPAD to control the left channel and A/B/X/Y to control the right
channel. You can use any attached controller.

*/

#include <errno.h>
#include <kos.h>

/* The two CD-DA tracks tests/e2e/test_bootable_disc.cpp puts on a MIL-CD.
   They are tracks 1 and 2 here because the audio session comes first and
   the data track follows them; on a GD-DA disc the same two tracks are 4
   and 5, which is why that disc gets the Katana payload instead and this
   one is not built for it.

   The stock example plays 1 to 3, which on this disc would mean asking the
   drive to play the data track. */
#define CDDA_FIRST_TRACK 1
#define CDDA_LAST_TRACK  2
#define CDDA_REPEATS     15

/* The background image, in the disc root tests/payloads/kos/cd_root/ ships as
   bkgnd.pvr and mkdcdisc writes into the filesystem with -D.

   Asked for in uppercase although the file is lowercase, which is the same way
   round as Sega's own GDFS sample: ISO9660 uppercases whatever it is handed and
   appends a version, so that is the only name the Katana payload next door can
   use -- its GD filesystem has nothing but the ISO9660 tree to look in. KOS
   reads the Joliet tree here, where the name kept its case, but it compares
   case-insensitively, so the two payloads can ask for one identical string.
   See tests/payloads/README.md. */
#define BACKGROUND_PATH "/cd/BKGND.PVR"

/* What the .pvr is expected to be, and what the sprite below maps across the
   screen. Anything else would still load, but would be drawn stretched from the
   wrong corner of itself. */
#define BACKGROUND_SIZE 512

/* The status text is rasterised into a texture of its own and drawn over the
   background. 1024 wide because the PVR only samples power-of-two textures and
   640 is not one; only the leftmost 640 columns are ever shown, which is what
   keeps the glyphs at their own size rather than stretched across the screen.

   Five 24-pixel lines and a small margin fit in 128 rows exactly. */
#define TEXT_WIDTH    1024
#define TEXT_HEIGHT   128
#define TEXT_LEFT     16
#define TEXT_TOP      4

/* bfont writes these straight through as pixels, so they are ARGB4444 literals:
   opaque white on a half-transparent black plate. The plate is the point -- the
   background image is whatever the disc happens to carry, and text laid
   directly on it would be legible or not by luck. */
#define TEXT_FOREGROUND 0xffff
#define TEXT_BACKGROUND 0x8000

/* The stock example sleeps 100 ms between controller samples, which is what
   makes holding a direction ramp the volume instead of slamming it. This loop
   runs once a frame instead, so the same feel comes from acting on the sticks
   every sixth one. START is read every frame; nothing is gained by making the
   disc feel unresponsive. */
#define FRAMES_PER_SAMPLE 6

typedef struct {
    pvr_ptr_t data;  /* In video RAM, or NULL when there was nothing to load */
    uint32_t  fmt;   /* The PVR_TXRFMT_* bits pvr_poly_cxt_txr() wants */
    int       w, h;
} texture_t;

static texture_t background;
static texture_t status;

/* The status texture's pixels, kept in main RAM: bfont draws into them and the
   result is uploaded whole, and only when the text has actually changed. */
static uint16_t *status_pixels;

static uint32_t read_u32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint32_t read_u16(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8);
}

/* The two format bytes of a PVR file, as the flags pvr_poly_cxt_txr() takes.

   Deliberately not exhaustive. A mipmapped file puts its small levels first, so
   a loader that took the data format on trust would upload the pyramid as if it
   were the image and draw something that looks like a broken disc; refusing it
   here means the payload says "no background" instead, which is a far easier
   thing to diagnose. Palettised files need a palette uploaded alongside, which
   nothing here does. tests/payloads/README.md gives the pvrconv options that
   produce what this accepts. */
static bool texture_format(uint8_t pixel, uint8_t data, uint32_t *fmt) {
    switch(pixel) {
        case 0: *fmt = PVR_TXRFMT_ARGB1555; break;
        case 1: *fmt = PVR_TXRFMT_RGB565;   break;
        case 2: *fmt = PVR_TXRFMT_ARGB4444; break;
        default: return false;  /* YUV422, bump maps, palettes */
    }

    switch(data) {
        case 1: *fmt |= PVR_TXRFMT_TWIDDLED; break;
        case 3: *fmt |= PVR_TXRFMT_TWIDDLED | PVR_TXRFMT_VQ_ENABLE; break;
        case 9: *fmt |= PVR_TXRFMT_NONTWIDDLED; break;
        default: return false;  /* mipmapped, palettised, strided */
    }

    return true;
}

/* A .pvr off the disc, into video RAM.

   The file is a 16-byte 'PVRT' chunk -- its length, one byte of pixel format,
   one of data format, then the dimensions -- followed by the texture data in
   the exact arrangement the hardware samples from, optionally behind a 'GBIX'
   chunk carrying the converter's global index, which nothing here needs. So
   there is no decoding to do at all: the twiddling and the VQ compression are
   the converter's work, which is the whole reason a payload ships a .pvr rather
   than a .png. What the chunk claims to be long is not taken at face value;
   see below.

   Returns false and leaves the texture empty for anything it does not
   understand, including the file simply not being on the disc. */
static bool load_pvr(const char *path, texture_t *out) {
    uint8_t header[16];
    uint8_t *staging = NULL;
    uint32_t bytes;
    long at, end;
    FILE *fp;
    bool ok = false;

    if(!(fp = fopen(path, "rb"))) {
        dbglog(DBG_WARNING, "%s: %s\n", path, strerror(errno));
        return false;
    }

    if(fread(header, 1, sizeof(header), fp) != sizeof(header))
        goto done;

    /* The global index chunk, skipped whole: identifier, length, payload. */
    if(!memcmp(header, "GBIX", 4)) {
        if(fseek(fp, 8 + (long)read_u32(header + 4), SEEK_SET) ||
           fread(header, 1, sizeof(header), fp) != sizeof(header))
            goto done;
    }

    if(memcmp(header, "PVRT", 4)) {
        dbglog(DBG_WARNING, "%s: not a PVR file\n", path);
        goto done;
    }

    /* The chunk length is documented as the byte count that follows it: the
       eight bytes of format and dimensions, then the texture data. What is
       left of the file overrides it, because converters disagree about it.

       The Katana SDK's pvrconv writes what the specification says. KallistiOS's
       own pvrtex writes the whole chunk instead, tag and length field included,
       which is eight bytes too many -- and a payload that believed it asked for
       eight bytes past the end, got a short read, and gave up. That failure is
       silent by design here (a disc need not carry an image at all), so it
       showed up as a background that never appeared, on a file the Katana
       payload beside it was drawing perfectly: Ninja sizes the data from the
       dimensions and the format, and never reads this field. */
    bytes = read_u32(header + 4) - 8;
    out->w = (int)read_u16(header + 12);
    out->h = (int)read_u16(header + 14);

    if((at = ftell(fp)) < 0 || fseek(fp, 0, SEEK_END) || (end = ftell(fp)) < 0 ||
       fseek(fp, at, SEEK_SET))
        goto done;

    if(bytes > (uint32_t)(end - at))
        bytes = (uint32_t)(end - at);

    if(!texture_format(header[8], header[9], &out->fmt)) {
        dbglog(DBG_WARNING, "%s: unsupported texture format %d/%d\n",
               path, header[8], header[9]);
        goto done;
    }

    /* Staged through main RAM rather than read straight into video RAM: the
       upload has its own path onto the bus, and this way a short read is caught
       before anything has been written to the hardware. */
    if(!(staging = memalign(32, bytes)))
        goto done;

    if(fread(staging, 1, bytes, fp) != bytes)
        goto done;

    if(!(out->data = pvr_mem_malloc(bytes)))
        goto done;

    pvr_txr_load(staging, out->data, bytes);
    ok = true;

done:
    free(staging);
    fclose(fp);
    return ok;
}

/* One textured quad, as a triangle strip: bottom left, top left, bottom right,
   top right. The u and v given are where the right and bottom edges land in the
   texture, which is how the status texture shows only the part of itself that
   fits the screen.

   Every quad here sits at the same depth. The two are kept apart by the list
   they go in -- opaque first, then translucent -- and not by z. */
static void draw_quad(const texture_t *t, pvr_list_t list, int filter,
                      float x1, float y1, float x2, float y2,
                      float u, float v) {
    pvr_poly_cxt_t cxt;
    pvr_poly_hdr_t hdr;
    pvr_vertex_t vert;

    pvr_poly_cxt_txr(&cxt, list, t->fmt, t->w, t->h, t->data, filter);
    pvr_poly_compile(&hdr, &cxt);
    pvr_prim(&hdr, sizeof(hdr));

    vert.argb = 0xffffffff;
    vert.oargb = 0;
    vert.flags = PVR_CMD_VERTEX;
    vert.z = 1.0f;

    vert.x = x1; vert.y = y2; vert.u = 0.0f; vert.v = v;
    pvr_prim(&vert, sizeof(vert));

    vert.x = x1; vert.y = y1; vert.u = 0.0f; vert.v = 0.0f;
    pvr_prim(&vert, sizeof(vert));

    vert.x = x2; vert.y = y2; vert.u = u; vert.v = v;
    pvr_prim(&vert, sizeof(vert));

    vert.flags = PVR_CMD_VERTEX_EOL;
    vert.x = x2; vert.y = y1; vert.u = u; vert.v = 0.0f;
    pvr_prim(&vert, sizeof(vert));
}

/* Rasterises the status lines and hands them to the hardware. bfont takes the
   whole block at once, newlines and all, one 24-pixel row per line. */
static void load_status_text(const char *text) {
    memset(status_pixels, 0, TEXT_WIDTH * TEXT_HEIGHT * 2);
    bfont_draw_str_ex(status_pixels + TEXT_TOP * TEXT_WIDTH + TEXT_LEFT,
                      TEXT_WIDTH, TEXT_FOREGROUND, TEXT_BACKGROUND, 16, true,
                      text);
    pvr_txr_load(status_pixels, status.data, TEXT_WIDTH * TEXT_HEIGHT * 2);
}

int main(int argc, char **argv) {
    maple_device_t  *addr;
    cont_state_t    *st;
    int     i;
    int     done;
    int     lvol, rvol, lpan, rpan;
    int     frames = 0;
    int     playing = 0;
    char    text[256], shown[256];

    pvr_init_defaults();

    /* Read before a note is played, not after. The drive cannot serve the data
       track and the audio session at the same time: starting playback first
       would mean seeking away from the music to load this, and the music would
       stop. Everything the payload needs off the disc is fetched here. */
    load_pvr(BACKGROUND_PATH, &background);

    status.data = pvr_mem_malloc(TEXT_WIDTH * TEXT_HEIGHT * 2);
    status.fmt = PVR_TXRFMT_ARGB4444 | PVR_TXRFMT_NONTWIDDLED;
    status.w = TEXT_WIDTH;
    status.h = TEXT_HEIGHT;
    status_pixels = memalign(32, TEXT_WIDTH * TEXT_HEIGHT * 2);

    if(!status.data || !status_pixels)
        return -1;

    shown[0] = '\0';

    cdrom_cdda_play(CDDA_FIRST_TRACK, CDDA_LAST_TRACK, CDDA_REPEATS,
                    CDDA_TRACKS);

    /* Wait for a controller button */
    done = 0;
    lvol = rvol = 15;
    lpan = 0;
    rpan = 31;

    while(!done) {
        int sample = (++frames % FRAMES_PER_SAMPLE) == 0;
        int state, type;

        i = 0;

        while((addr = maple_enum_type(i++, MAPLE_FUNC_CONTROLLER))) {
            /* Check for input */
            st = (cont_state_t *)maple_dev_status(addr);

            /* Exit */
            if(st->buttons & CONT_START) {
                done = 1;
                break;
            }

            if(!sample)
                continue;

            /* Left channel */
            if(st->buttons & CONT_DPAD_UP)
                lvol++;

            if(st->buttons & CONT_DPAD_DOWN)
                lvol--;

            if(st->buttons & CONT_DPAD_LEFT)
                lpan--;

            if(st->buttons & CONT_DPAD_RIGHT)
                lpan++;

            /* Right channel */
            if(st->buttons & CONT_B)
                rvol++;

            if(st->buttons & CONT_A)
                rvol--;

            if(st->buttons & CONT_X)
                rpan--;

            if(st->buttons & CONT_Y)
                rpan++;

            /* Normalize */
            if(lvol < 0) lvol = 0;

            if(lvol > 15) lvol = 15;

            if(lpan < -16) lpan = -16;

            if(lpan > 31) lpan = 31;

            if(rvol < 0) rvol = 0;

            if(rvol > 15) rvol = 15;

            if(rpan < -16) rpan = -16;

            if(rpan > 31) rpan = 31;

            /* Set pan/vol */
            spu_cdda_volume(lvol, rvol);
            spu_cdda_pan(lpan, rpan);
        }

        /* Whether the drive is still on the audio: the tracks run about nine
           seconds each and the repeat count is finite, so a disc left alone
           eventually goes quiet, and the screen should say so rather than leave
           you wondering which end the silence came from. */
        if(cdrom_get_status(&state, &type) == ERR_OK)
            playing = (state == CD_STATUS_PLAYING);

        snprintf(text, sizeof(text),
                "mkdcdisc bootable-disc payload (KallistiOS)\n"
                "CD-DA tracks %d-%d: %s\n"
                "volume L%2d R%2d   pan L%3d R%3d\n"
                "DPAD: left channel   A/B/X/Y: right channel\n"
                "START: exit",
                CDDA_FIRST_TRACK, CDDA_LAST_TRACK,
                playing ? "playing" : "stopped", lvol, rvol, lpan, rpan);

        if(strcmp(text, shown)) {
            load_status_text(text);
            strcpy(shown, text);
        }

        pvr_wait_ready();
        pvr_scene_begin();

        /* Empty when the disc carries no background, which is a scene with
           nothing in its opaque list and not an error. */
        pvr_list_begin(PVR_LIST_OP_POLY);

        if(background.data)
            draw_quad(&background, PVR_LIST_OP_POLY, PVR_FILTER_BILINEAR,
                      0.0f, 0.0f, (float)vid_mode->width,
                      (float)vid_mode->height, 1.0f, 1.0f);

        pvr_list_finish();

        pvr_list_begin(PVR_LIST_TR_POLY);
        draw_quad(&status, PVR_LIST_TR_POLY, PVR_FILTER_NONE,
                  0.0f, 0.0f, (float)vid_mode->width, (float)TEXT_HEIGHT,
                  (float)vid_mode->width / TEXT_WIDTH, 1.0f);
        pvr_list_finish();

        pvr_scene_finish();
    }

    /* Stop the CDDA */
    cdrom_cdda_pause();

    /* Spin down the CD */
    cdrom_spin_down();

    return 0;
}
