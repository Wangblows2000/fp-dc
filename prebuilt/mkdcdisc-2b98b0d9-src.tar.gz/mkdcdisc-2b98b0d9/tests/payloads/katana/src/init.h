/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Bringing the machine up far enough to play a CD-DA track and print a line.
 *
 * The Katana samples all carry a copy of Sega's sbinit.c for this. That file is
 * SDK source and does not belong in a public repository, so this is our own,
 * written against the documented API and cut down to what this payload uses:
 * no Kamui, no sound driver, no C++ support, one graphics library. */

#ifndef PAYLOAD_INIT_H
#define PAYLOAD_INIT_H

#include <shinobi.h>

/* mode/frame are the NJD_RESOLUTION_* and NJD_FRAMEBUFFER_MODE_* pair for the
 * cable that is plugged in; pick them with video_mode() below. Leaves the
 * heap, the controllers, the timer and the GD filesystem ready to use, and
 * never returns if the GD drive cannot be brought up -- there is nothing this
 * payload can do without it. */
void payload_init(Int mode, Int frame, Int vsync_count);

/* Undoes payload_init(), in reverse. Call it before syBtExit(). */
void payload_exit(void);

/* The resolution the attached cable calls for. Writes the framebuffer mode to
 * *frame and the screen height in pixels to *height, and returns the
 * resolution; returns -1 for a cable the payload does not know, which is a
 * reason to hand the machine back to the BootROM.
 *
 * The height is out here rather than worked out again by the caller because it
 * is the one thing that differs between the modes -- every one of them is 640
 * wide, and only PAL is 544 tall -- and anything drawn across the whole screen
 * needs to know which. */
Int video_mode(Int* frame, Int* height);

#endif /* PAYLOAD_INIT_H */
