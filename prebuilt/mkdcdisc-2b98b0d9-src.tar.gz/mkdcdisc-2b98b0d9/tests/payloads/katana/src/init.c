/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* See init.h for why this is ours rather than the SDK's sbinit.c. */

#include <shinobi.h>
#include <sg_syhw.h>
#include <ninja.h>

#include "init.h"

/* Placed by the linker at the end of the last data section: everything above
 * it is free, and the heap starts there. */
extern Uint8* _BSG_END;

/* Cached, translated to P1 (uncached), and capped at the 16 MB of work RAM the
 * console has. */
#define P1AREA    0x80000000u
#define WORK_END  (((Uint32) _BSG_END & 0xe0000000u) | 0x0d000000u)

/* Every work area handed to a Katana library has to start on a 32-byte
 * boundary, so each buffer below is over-allocated by 32 and the pointer moved
 * up to the next boundary. */
#define ALIGN32(p) ((void*) ((((Uint32) (p)) & 0xffffffe0u) + 0x20u))

#define HEAP_BASE ALIGN32((Uint32) _BSG_END | P1AREA)
#define HEAP_SIZE (WORK_END - (Uint32) HEAP_BASE)

/* This payload opens one file at a time at most, and reads no directory but
 * the root. Sega's boilerplate reserves 8 and 1024; both are per-entry
 * allocations out of the work RAM, and there is no reason to pay for them. */
#define MAX_OPEN_FILES 2
#define DIR_ENTRIES    64

/* How many times to ask the drive before giving up. A disc that has just been
 * inserted answers "unit attention" for a while, which is not a failure. */
#define GD_INIT_TRIES 8

static Uint8 maple_recv[1024 * 24 * 2 + 32];
static Uint8 maple_send[1024 * 24 * 2 + 32];
static Uint8 gdfs_work[GDFS_WORK_SIZE(MAX_OPEN_FILES) + 32];
static Uint8 gdfs_dir[GDFS_DIRREC_SIZE(DIR_ENTRIES) + 32];

Int video_mode(Int* frame, Int* height) {
    *frame = NJD_FRAMEBUFFER_MODE_RGB565;
    *height = 480;

    switch(syCblCheck()) {
        case SYE_CBL_NTSC: /* North American NTSC and Brazilian PAL-M, both 60 Hz */
            return NJD_RESOLUTION_640x480_NTSCNI;
        case SYE_CBL_PAL:  /* European PAL and Argentine PAL-N, both 50 Hz */
            *height = 544;
            return NJD_RESOLUTION_640x544_PALNI;
        case SYE_CBL_VGA:
            return NJD_RESOLUTION_VGA;
        default:
            return -1;
    }
}

/* The GD filesystem, which everything this payload does runs on: gdFsDaPlay()
 * is a GDFS call, so an unreadable drive means there is nothing to do. Returns
 * false when the drive never came up, and when the tray is open -- which is
 * not something to retry, since nobody is going to close it mid-boot. */
static Bool gd_filesystem_init(void) {
    Uint8* work = (Uint8*) ALIGN32(gdfs_work);
    Uint8* dir = (Uint8*) ALIGN32(gdfs_dir);
    Sint32 tries;

    for(tries = 0; tries < GD_INIT_TRIES; tries++) {
        Sint32 err = gdFsInit(MAX_OPEN_FILES, work, DIR_ENTRIES, dir);

        if(err == GDD_ERR_OK) {
            return TRUE;
        }

        if(err == GDD_ERR_TRAYOPEND || err == GDD_ERR_UNITATTENT) {
            return FALSE;
        }
    }

    return FALSE;
}

void payload_init(Int mode, Int frame, Int vsync_count) {
    /* Nothing below wants to be interrupted half-built. */
    set_imask(15);

    syHwInit();
    syMallocInit(HEAP_BASE, HEAP_SIZE);

    njInitSystem(mode, frame, vsync_count);

    /* The second half of the hardware bring-up, which the SDK documents as
     * belonging after the graphics library rather than beside syHwInit(). */
    syHwInit2();

    pdInitPeripheral(PDD_PLOGIC_ACTIVE, maple_recv, maple_send);
    syRtcInit();

    set_imask(0);

    if(!gd_filesystem_init()) {
        payload_exit();
        syBtExit();
    }
}

void payload_exit(void) {
    gdFsFinish();
    syRtcFinish();
    pdExitPeripheral();
    njExitSystem();
    syMallocFinish();
    syHwFinish();

    set_imask(15);
}
