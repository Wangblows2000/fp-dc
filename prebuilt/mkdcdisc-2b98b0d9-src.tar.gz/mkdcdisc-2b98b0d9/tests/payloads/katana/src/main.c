/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* The Katana half of the bootable-disc payloads: plays the two GD-DA tracks
 * tests/e2e/test_bootable_disc.cpp writes, draws the background image the disc
 * carries, and says on screen what it is doing.
 *
 * Between them the two payloads prove a disc boots and reads. This one is here
 * because it is not built the way the KallistiOS one is: it comes out of the
 * Katana toolchain as a raw binary rather than an ELF, so mkdcdisc receives it
 * through -b instead of -e, and it inherits whatever FPU rounding mode the
 * bootstrap left rather than setting its own -- which is the distinction
 * --gdi-fpu-rounding exists for.
 *
 * Deliberately without the sound driver. Sega's own GD-DA sample loads
 * MANATEE.DRV, but only for sdGddaSetVol()/sdGddaSetPan(): playback itself is
 * gdFsDaPlay(), which belongs to the GD filesystem library. Dropping the volume
 * and pan controls drops the driver with them, and with it a binary that would
 * have had to be committed to this repository.
 *
 * What the driver would have brought up is done directly instead, through the
 * G2 library and the AICA's own registers -- see sound_init(). Leaving the
 * sound chip to whatever the BootROM had left is what made this payload play
 * in silence on both reference emulators.
 *
 * Run the SDK's SetPaths.bat, then `gmake` in src/. The makefile leaves the
 * binary at ../katana.bin -- beside gd_root rather than inside it, since
 * mkdcdisc writes the boot binary into the filesystem itself, under the name
 * its IP.BIN declares, and would otherwise be handed the same file twice. */

#include <shinobi.h>
#include <ninja.h>
#include <sg_syg2.h>

#include "init.h"

/* Which tracks to play. The corpus writes the two GD-DA tracks from
 * tests/payloads/common/, but they do not land at the same numbers on the two
 * kinds of disc: they are tracks 1 and 2 on a MIL-CD, where the audio session
 * comes first, and tracks 4 and 5 on a GD-DA disc, behind the low-density pair
 * and the high-density data track.
 *
 * So this is a build-time choice, and this payload is the GD-DA one; the
 * KallistiOS payload covers the MIL-CD.
 *
 * One binary could do both by reading the table of contents: gdFsGetToc() ends
 * up at the drive's own GETTOC2 command, so its buffer is the hardware TOC --
 * 99 track entries of (ctrl << 28) | (adr << 24) | FAD, then first, last and
 * lead-out -- and finding the audio tracks is a scan for ctrl 0. It is left
 * undone because it would be code that has never run: the request is
 * asynchronous like gdFsReqDrvStat(), and none of this payload has been on a
 * console yet. Worth revisiting once it has.
 *
 * The default is the GD-DA disc. A MIL-CD build, should one ever be wanted, is
 * `gmake EXTRA_DEFS=AUDIO_MILCD`. A bare flag rather than a numeric macro on
 * purpose: dc.inc walks the define list with cmd's `for`, which treats `=` as a
 * separator, so a valued -D never survives the trip. */
#ifdef AUDIO_MILCD
#define AUDIO_FIRST_TRACK 1
#else
#define AUDIO_FIRST_TRACK 4
#endif

#define AUDIO_LAST_TRACK (AUDIO_FIRST_TRACK + 1)

/* The background image, from the disc root tests/payloads/katana/gd_root/ ships
 * as bkgnd.pvr and mkdcdisc writes into the filesystem with -D.
 *
 * Asked for in uppercase although the file is lowercase, exactly as Sega's own
 * GDFS sample does it -- gd_root/abc.dat on the disc, opened as "ABC.DAT". On a
 * GD-ROM that is the only name there is: mkdcdisc gives one an ISO9660 tree and
 * a Rock Ridge one and no Joliet, ISO9660 uppercases whatever it is handed and
 * appends a version, and the GD filesystem reads that tree and nothing else.
 * The KallistiOS payload reads Joliet, where the name kept its case, but
 * compares case-insensitively, so it asks for this same string. See
 * tests/payloads/README.md.
 *
 * Drawing it is the point of shipping a disc root at all. Until a payload
 * opened one of these files, nothing here had shown that what -D writes is
 * readable on a console -- only that the bytes come back out of the image. */
#define BACKGROUND_FILE "BKGND.PVR"

/* The largest image the payload will take, in pixels along a side. It sizes the
 * work buffer below and nothing else: the sprite maps the texture by fractions
 * rather than by pixels, so a smaller file still covers the whole screen. */
#define BACKGROUND_SIZE 512

/* The far corner of the texture, in the units njDrawSprite2D() reads texture
 * coordinates in. They are not pixels: 0 to 255 spans the whole image whatever
 * its real size is, which is why the SDK's 2D samples write 255 for a full
 * sprite at 400x300, at 256x256 and at 128x128 alike, and why Sample/Periph/
 * lcd1 asks for three quarters of one with 191.
 *
 * A pixel coordinate here is read as a fraction larger than one and the image
 * repeats: 511 drew this background four times, twice across and twice down. */
#define BACKGROUND_UV_MAX 255

/* Every video mode this payload accepts is 640 across; only the height moves,
 * which is why video_mode() hands that one back. */
#define SCREEN_WIDTH 640

/* Where the sprite sits in the draw order. Ninja's 2D calls take a depth whose
 * larger values are the nearer ones -- the SDK's own 2D samples layer sprites
 * at -2 behind -1 -- so this is comfortably behind everything else the payload
 * draws, njPrint's text included. */
#define BACKGROUND_DEPTH (-1000.0f)

/* What Ninja reads the file into on its way to video RAM, so it has to hold the
 * largest .pvr the payload can be handed: 512x512 at 16 bits per pixel,
 * uncompressed, plus the 0x800 the loader wants on top of the image itself --
 * the size rule the SDK's F40 sample spells out. A VQ-compressed image needs an
 * eighth of that, but sizing for the uncompressed case means every file the
 * README allows will load.
 *
 * Off the heap rather than in BSS: half a megabyte of zeroes is not something
 * to grow the payload, or the startup clear that precedes main(), by. */
#define TEXTURE_BUFFER_SIZE (BACKGROUND_SIZE * BACKGROUND_SIZE * 2 + 0x800)

static NJS_TEXNAME background_texname[] = {
    { BACKGROUND_FILE, NJD_TEXATTR_GLOBALINDEX, 0 },
};

static NJS_TEXLIST background_texlist = { background_texname, 1 };
static NJS_TEXMEMLIST background_texmem[1];

/* All of the texture, across all of the screen. The destination size is the one
 * thing filled in at startup, from the video mode, so that a PAL console gets
 * no band along the bottom. */
static NJS_TEXANIM background_anim = {
    0, 0,                                         /* size, set at startup */
    0, 0,                                         /* origin: its top left */
    0, 0, BACKGROUND_UV_MAX, BACKGROUND_UV_MAX,   /* the whole image */
    0, 0,                                         /* texture 0, no flags */
};

static NJS_SPRITE background = {
    { 0.0f, 0.0f, 0.0f },  /* the top left corner of the screen */
    1.0f, 1.0f, 0,         /* unscaled, unrotated */
    &background_texlist,
    &background_anim,
};

static Bool background_loaded = FALSE;

/* Passed to gdFsDaPlay() as its repeat count, the way Sega's GD-DA sample
 * calls it. The two tracks together run about a minute and ten seconds, so a
 * disc left running goes quiet; press A to start it again. */
#define REPEAT_COUNT 0

/* Bringing the AICA up far enough to hear a GD-DA track, which is more than
 * opening a mixer.
 *
 * Sega's GD-DA sample gets all of this from MANATEE.DRV, and calls the driver
 * only for sdGddaSetVol()/sdGddaSetPan() afterwards. That reads as though the
 * driver were there for the volume control, which is what the first version of
 * this payload assumed: it set the two mixer registers and nothing else, and
 * played in silence on both reference emulators. The sound chip has to be
 * running before a mixer setting means anything.
 *
 * None of it needs the driver, or any Sega binary in this repository. What it
 * needs is the G2 library, which syHwInit2() has already started by the time
 * payload_init() returns, and four registers.
 *
 * The addresses are in no SDK header. They are the ones KallistiOS writes in
 * spu_init(), spu_cdda_volume() and spu_cdda_pan(), and the payload next door
 * is the evidence: same emulator, same disc layout, audible. */
#define AICA_SOUND_RAM  ((Void*) 0xa0800000) /* what the sound CPU executes */
#define AICA_MASTER     ((Void*) 0xa0702800) /* RAM mode, stereo, master volume */
#define AICA_ARM_RESET  ((Void*) 0xa0702c00) /* bit 0 holds the sound CPU */
#define AICA_CDDA_LEFT  ((Void*) 0xa0702040) /* per-channel volume and pan */
#define AICA_CDDA_RIGHT ((Void*) 0xa0702044)

/* Retail 2 MB sound RAM, stereo, master volume at its maximum in bits 0-3.
 * Zero here silences the chip whatever the GD-DA mixer says, and zero is what
 * spu_init() writes before raising it. */
#define AICA_MASTER_SETTING 0x0000000fU

/* One ARM instruction, branching to itself, and the reason it is here is worth
 * stating plainly: the GD-DA path produces nothing at all while the sound CPU
 * is held in reset, so it is given a program that does nothing, forever.
 * KallistiOS writes this same word for this same reason -- see the comment on
 * spu_init(), "so that CD audio works".
 *
 * Sound RAM is left as found rather than cleared. Nothing will ever read it:
 * the one instruction at its start is all the CPU ever executes. */
#define ARM_SPIN 0xeafffff8U

/* Full volume, each channel panned hard to its own side: bit 4 picks the side
 * and bits 0-3 the amount, so 0x0f is fully left and 0x1f fully right. The
 * pair KallistiOS starts from, and the pair the payload next door shows on
 * screen as "volume L15 R15  pan L 0 R 31". */
#define CDDA_VOLUME    15
#define CDDA_PAN_LEFT  0x0f
#define CDDA_PAN_RIGHT 0x1f

static Uint32 g2_read(Void* reg) {
    Uint32 value;

    syG2Read(reg, &value, SYE_G2_DATA_WIDTH_32BIT, 1,
             SYE_G2_ADR_MODE_FIX, SYE_G2_ADR_MODE_FIX);

    return value;
}

static void g2_write(Void* reg, Uint32 value) {
    syG2Write(&value, reg, SYE_G2_DATA_WIDTH_32BIT, 1,
              SYE_G2_ADR_MODE_FIX, SYE_G2_ADR_MODE_FIX);
}

/* Read-modify-write, so the rest of the register is left alone: what else
 * lives in it is not documented anywhere this payload can see, and guessing
 * would be a poor trade for two bytes. */
static void set_cdda_mixer(Void* reg, Uint32 pan) {
    g2_write(reg, (g2_read(reg) & ~0xffffU) | (CDDA_VOLUME << 8) | pan);
}

/* Done before playback starts, and in this order: the chip, then its CPU, then
 * the mixer. gdFsDaPlay() succeeds and the drive reports GDD_DRVSTAT_PLAY
 * whatever state any of it is in, so a payload that skips this sits there
 * saying "playing" in complete silence -- which it did. */
static void sound_init(void) {
    Int i;

    g2_write(AICA_MASTER, AICA_MASTER_SETTING);

    /* Held, given its instruction, released. */
    g2_write(AICA_ARM_RESET, g2_read(AICA_ARM_RESET) | 1U);
    g2_write(AICA_SOUND_RAM, ARM_SPIN);
    g2_write(AICA_ARM_RESET, g2_read(AICA_ARM_RESET) & ~1U);

    /* KallistiOS waits ten milliseconds here for the CPU to get going. This
     * payload has no scheduler to sleep on, and it is called with the display
     * already up, so it waits on the vertical blank instead -- four frames
     * being comfortably more than ten milliseconds in every video mode. */
    for(i = 0; i < 4; ++i) {
        njWaitVSync();
    }

    set_cdda_mixer(AICA_CDDA_LEFT, CDDA_PAN_LEFT);
    set_cdda_mixer(AICA_CDDA_RIGHT, CDDA_PAN_RIGHT);
}

static void start_playback(void) {
    gdFsDaPlay(AUDIO_FIRST_TRACK, AUDIO_LAST_TRACK, REPEAT_COUNT);
}

/* Brings the background into video RAM, if the disc carries one at all.
 *
 * Ninja does the file access itself, through the GD filesystem payload_init()
 * has already brought up; what this adds is the check for the file not being
 * there. A disc built without one is a perfectly good disc -- every image the
 * e2e test builds was, until this file existed -- and the payload should boot
 * and play on it rather than sit on a blank screen wondering. gdFsOpen()
 * answers that question through the contract Sega's own GDFS sample relies on;
 * njLoadTexture()'s return value is not documented anywhere this can.
 *
 * Called before playback starts, and that order matters: the drive cannot serve
 * the data track and the audio session at the same time, so a read issued after
 * gdFsDaPlay() would stop the music to go and seek for it. */
static Bool load_background(Int height) {
    Sint8* buffer;
    GDFS file;

    /* Asked before anything is set up for it: half a megabyte of work buffer
     * handed to njInitTextureBuffer() is half a megabyte Ninja then owns, and a
     * disc with no background image should not be paying for it. */
    file = gdFsOpen(BACKGROUND_FILE, NULL);
    if(file == NULL) {
        return FALSE;
    }

    gdFsClose(file);

    buffer = (Sint8*) syMalloc(TEXTURE_BUFFER_SIZE);
    if(buffer == NULL) {
        return FALSE;
    }

    njInitTextureBuffer(buffer, TEXTURE_BUFFER_SIZE);
    njInitTexture(background_texmem, 1);

    /* The disc root, which is where the GD filesystem already is. Said out
     * loud rather than left to whatever the library starts with. */
    njSetTexturePath("");

    background_anim.sx = (Sint16) SCREEN_WIDTH;
    background_anim.sy = (Sint16) height;

    njLoadTexture(&background_texlist);
    njSetTexture(&background_texlist);

    return TRUE;
}

void main(void) {
    GDFS sys;
    Int mode, frame, height;
    Uint32 frames = 0;

#ifdef __GNUC__
    shinobi_workaround();
#endif

    mode = video_mode(&frame, &height);
    if(mode < 0) {
        /* A cable the payload cannot drive: hand the machine back rather than
         * display nothing at all on it. */
        syBtExit();
    }

    payload_init(mode, frame, 1);

    njSetBorderColor(0x00000000);
    njInitVertexBuffer(20000, 0, 20000, 0, 0);
    njInitPrint(NULL, 0, NJD_TEXFMT_ARGB_1555);
    njPrintSize(14);
    njSetBackColor(0x00000000, 0x00000000, 0x000000ff);

    sys = gdFsGetSysHn();

    background_loaded = load_background(height);

    sound_init();
    start_playback();
    gdFsReqDrvStat();

    while(1) {
        PDS_PERIPHERAL* pad = pdGetPeripheral(PDD_PORT_A0);
        Bool playing;

        /* The drive answers asynchronously: the request was posted at the end
         * of the previous pass, and this waits for that answer before reading
         * it.
         *
         * GDD_STAT_ERR ends the wait too, and that is not a formality. The
         * corpus builds Katana GD-ROMs with no audio at all -- see the "gdrom"
         * entries in tests/e2e/test_bootable_disc.cpp -- and on one of those the
         * gdFsDaPlay() above asks for tracks the disc does not have. The drive
         * answers the next status request with an error and keeps answering it,
         * so a wait that only accepts GDD_STAT_COMPLETE never returns: the
         * payload spins here on its first pass and never draws a frame, which
         * on a console looks exactly like a disc that did not boot. Taking the
         * error instead leaves `playing` false, and the disc comes up and says
         * "stopped". */
        while(1) {
            Sint32 stat = gdFsGetStat(sys);
            if(stat == GDD_STAT_COMPLETE || stat == GDD_STAT_ERR) break;
        }
        playing = (gdFsGetDrvStat() == GDD_DRVSTAT_PLAY);

        if(background_loaded) {
            njDrawSprite2D(&background, 0, BACKGROUND_DEPTH, 0);
        }

        njPrintC(NJM_LOCATION(4, 3), "mkdcdisc bootable-disc payload (Katana)");
        njPrint(NJM_LOCATION(4, 5), "GD-DA tracks %d-%d",
                AUDIO_FIRST_TRACK, AUDIO_LAST_TRACK);
        njPrintC(NJM_LOCATION(4, 6), playing ? "playing" : "stopped");
        njPrint(NJM_LOCATION(4, 8), "frames %d", frames++);
        njPrintC(NJM_LOCATION(4, 10), "A: play   B: stop   START: reboot");

        if(pad != NULL) {
            if(pad->press & PDD_DGT_TA) {
                start_playback();
            }

            if(pad->press & PDD_DGT_TB) {
                gdFsDaStop();
            }

            if(pad->press & PDD_DGT_ST) {
                break;
            }
        }

        /* GDFS has no thread of its own; without this its requests never
         * progress. Sega's sample gets away with omitting it because the sound
         * driver's server pumps it, and this payload has no sound driver. */
        gdFsExecServer();

        gdFsReqDrvStat();
        njWaitVSync();
    }

    gdFsDaStop();
    payload_exit();
    syBtExit();
}
