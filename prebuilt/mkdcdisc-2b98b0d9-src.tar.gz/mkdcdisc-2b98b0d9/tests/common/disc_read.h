/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* Reading the table of contents back out of a finished image, in all four
 * formats mkdcdisc writes: which sessions exist, which tracks they hold, and
 * where on the disc each track says it begins.
 *
 * This is a *descriptive structure* reader and nothing more. It parses the CDI
 * trailer, the MDS descriptor, the NRG chunk chain and the GDI text file -- the
 * parts of each format that describe the disc -- and it can hand back a track's
 * user data so an ISO9660 volume can be lifted out of it with iso_read.h. It
 * never validates sector framing, never checks EDC/ECC, and knows nothing about
 * what belongs on a Dreamcast disc.
 *
 * The one rule this file exists to obey: **it shares no layout arithmetic with
 * the writers.** Every number it reports is read out of the image, or derived
 * from a documented property of the container format itself. Nothing here calls
 * into libdiscimage, and nothing here recomputes what the writer computed -- a
 * reader that recomputes only ever confirms the writer, mistakes included, and
 * a golden built on it would be worthless. Where a value cannot be read and has
 * to be derived (the CDI track-data walk below is the only case), the rule used
 * is a property of the format, spelled out at the point of use.
 *
 * Separate from gdi_verify.h, which answers GD-ROM correctness questions about
 * a .gdi and its tracks; this one only says what a container declares. It is
 * used by e2e/test_disc_manifest.cpp to write tests/fixtures/disc-manifest.txt.
 */

#include <cctype>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <vector>

namespace disc_read {

/* Control field as it appears in a TOC: audio tracks carry 0, data tracks 4. */
constexpr unsigned CTRL_AUDIO = 0;
constexpr unsigned CTRL_DATA = 4;

/* The fixed physical LBA a GD-ROM's high-density area starts at. A .gdi does
 * not say where its sessions begin -- it is a flat list of tracks -- so the
 * split has to come from this constant, which is exactly what makes a
 * regression in it show up as a session boundary that moved. */
constexpr uint32_t GD_START_LBA = 45000;

/* How much of a track this reader will ever pull into memory, in sectors.
 * Everything it is pointed at is a deliberately small image; a padded release
 * build is hundreds of megabytes and has nothing extra to say. */
constexpr uint64_t MAX_TRACK_SECTORS = 8192;

struct Track {
    unsigned number = 0;   /* Disc-wide, 1-based, in the order the TOC lists */
    unsigned session = 0;  /* 1-based */

    unsigned ctrl = 0;     /* CTRL_AUDIO / CTRL_DATA, as declared */

    /* The container's own mode value, and a name for it. Both are reported:
     * the formats disagree on how finely they describe a mode (a CDI says
     * "Mode 2", an MDS distinguishes Form 1), and a change in the raw value is
     * worth seeing even when the name it maps to does not move. */
    uint32_t mode_value = 0;
    std::string mode_name;

    unsigned sector_size = 0;  /* Bytes per stored sector, as declared */

    /* LBA of the track's first *data* sector -- the pregap, where there is one,
     * occupies the LBAs immediately before it. Signed because a session's start
     * can be negative and the formats store it as a two's-complement u32. */
    int64_t start_lba = 0;

    /* Declared pregap length. Empty for GDI, which declares none: its gaps are
     * implied by the LBAs it gives. */
    std::optional<uint32_t> pregap_sectors;

    /* Declared track length in sectors, pregap excluded. Partly libisofs's
     * business on a data track -- it is the volume's size plus whatever
     * mkdcdisc adds -- so callers comparing across platforms should relate it
     * to the volume rather than pin it. */
    uint64_t sectors = 0;

    /* Where this track's first data sector physically lives, for
     * track_user_data() below. */
    std::filesystem::path file;
    uint64_t file_offset = 0;
    unsigned user_data_offset = 0; /* Into a stored sector */

    bool is_data() const { return ctrl == CTRL_DATA; }
};

struct Session {
    unsigned index = 0; /* 1-based */

    /* Only the formats that declare a program area report these: MDS in its
     * session block, NRG in the CUEX header/trailer entries. */
    std::optional<int64_t> start_lba;
    std::optional<int64_t> end_lba;

    std::vector<size_t> tracks; /* Indices into Disc::tracks */
};

struct Disc {
    bool valid = false;
    std::string format; /* "cdi", "mds", "nrg", "gdi" */

    std::vector<Session> sessions;
    std::vector<Track> tracks;

    /* CDI's closing disc-info block is the only place any of the four records
     * a disc-wide sector total. */
    std::optional<uint64_t> total_sectors;

    std::vector<std::string> errors;

    void fail(const std::string& message) { errors.push_back(message); }
};

/* ------------------------------------------------------------------ */
/* Byte access                                                         */
/* ------------------------------------------------------------------ */

inline uint16_t le16(const uint8_t* p) {
    return (uint16_t) ((uint16_t) p[0] | ((uint16_t) p[1] << 8));
}

inline uint32_t le32(const uint8_t* p) {
    return (uint32_t) p[0] | ((uint32_t) p[1] << 8)
        | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
}

inline uint64_t le64(const uint8_t* p) {
    return (uint64_t) le32(p) | ((uint64_t) le32(p + 4) << 32);
}

inline uint16_t be16(const uint8_t* p) {
    return (uint16_t) (((uint16_t) p[0] << 8) | (uint16_t) p[1]);
}

inline uint32_t be32(const uint8_t* p) {
    return ((uint32_t) p[0] << 24) | ((uint32_t) p[1] << 16)
        | ((uint32_t) p[2] << 8) | (uint32_t) p[3];
}

inline uint64_t be64(const uint8_t* p) {
    return ((uint64_t) be32(p) << 32) | (uint64_t) be32(p + 4);
}

/* A u32 holding a signed LBA, which is how all four formats store the negative
 * addresses a first-track pregap sits at. */
inline int64_t as_signed_lba(uint32_t raw) {
    return (int64_t) (int32_t) raw;
}

inline uint64_t file_size_of(const std::filesystem::path& path) {
    std::error_code ec;
    auto size = std::filesystem::file_size(path, ec);
    return ec ? 0 : (uint64_t) size;
}

/* Reads `len` bytes at `offset`, or returns false without touching `out` on
 * any short read -- a truncated image must not come back as a plausible one. */
inline bool read_at(std::ifstream& f, uint64_t offset, void* out, size_t len) {
    f.clear();
    f.seekg((std::streamoff) offset, std::ios::beg);
    if(!f) return false;
    f.read((char*) out, (std::streamsize) len);
    return (size_t) f.gcount() == len;
}

inline bool read_region(const std::filesystem::path& path, uint64_t offset, size_t len,
                        std::vector<uint8_t>& out) {
    std::ifstream f(path, std::ios::binary);
    if(!f) return false;
    out.assign(len, 0);
    return read_at(f, offset, out.data(), len);
}

/* ------------------------------------------------------------------ */
/* Track contents                                                      */
/* ------------------------------------------------------------------ */

/* The 2048 bytes of user data from each of the track's first `sectors` sectors,
 * concatenated -- which for a data track is the ISO9660 volume it carries, ready
 * for iso_read.h. The LBAs recorded inside that volume are absolute, so the base
 * to resolve them against is the track's own start_lba.
 *
 * Reads whatever is there and stops: a track shorter than asked for comes back
 * short rather than empty, since a truncated volume still describes itself. */
inline std::vector<uint8_t> track_user_data(const Track& track, uint64_t sectors) {
    std::vector<uint8_t> out;

    if(track.sector_size == 0 || track.user_data_offset + 2048 > track.sector_size) {
        return out;
    }

    if(sectors > track.sectors) sectors = track.sectors;
    if(sectors > MAX_TRACK_SECTORS) sectors = MAX_TRACK_SECTORS;

    std::ifstream f(track.file, std::ios::binary);
    if(!f) return out;

    std::vector<uint8_t> sector(track.sector_size);
    out.reserve((size_t) sectors * 2048);

    for(uint64_t i = 0; i < sectors; ++i) {
        uint64_t at = track.file_offset + i * track.sector_size;
        if(!read_at(f, at, sector.data(), sector.size())) break;
        out.insert(out.end(), sector.begin() + track.user_data_offset,
                   sector.begin() + track.user_data_offset + 2048);
    }

    return out;
}

/* The whole of a data track's user area, capped at MAX_TRACK_SECTORS. */
inline std::vector<uint8_t> track_user_data(const Track& track) {
    return track_user_data(track, track.sectors);
}

/* ------------------------------------------------------------------ */
/* CDI                                                                 */
/* ------------------------------------------------------------------ */

/* Sizes fixed by the format; see the layout diagram at the top of
 * src/disc_image/formats/cdi.c. */
constexpr size_t CDI_SESSION_HEADER_SIZE = 7;
constexpr size_t CDI_TRACK_HEADER_SIZE = 88;
constexpr size_t CDI_TRACK_DESC_SHORT = 180;
constexpr size_t CDI_TRACK_DESC_LONG = 188; /* Last track of a session */
constexpr size_t CDI_DISC_INFO_SIZE = 79;

/* A CD-DA track is stored padded up to this many sectors, data and postgap
 * together, however short the declared length is. Needed to walk the track data
 * area, which a CDI -- unlike MDS and NRG -- gives no byte offsets into. */
constexpr uint64_t CDI_CDDA_MIN_STORED_SECTORS = 302;

inline std::string cdi_mode_name(uint32_t track_mode) {
    switch(track_mode) {
    case 0: return "audio";
    case 1: return "mode1";
    case 2: return "mode2";
    default: return "unknown";
    }
}

/* read_mode is a sector-size selector, not a mode: 0 = 2048, 1 = 2336, 2 = 2352. */
inline unsigned cdi_sector_size(uint32_t read_mode) {
    switch(read_mode) {
    case 0: return 2048;
    case 1: return 2336;
    case 2: return 2352;
    default: return 0;
    }
}

inline Disc read_cdi(const std::filesystem::path& path) {
    Disc disc;
    disc.format = "cdi";

    uint64_t size = file_size_of(path);
    if(size < 5) {
        disc.fail("file is too small to be a CDI");
        return disc;
    }

    std::ifstream f(path, std::ios::binary);
    if(!f) {
        disc.fail("cannot open " + path.string());
        return disc;
    }

    /* A CDI is read back to front: the last four bytes give the distance from
     * the descriptor's first byte to EOF. */
    uint8_t footer[4];
    if(!read_at(f, size - 4, footer, sizeof(footer))) {
        disc.fail("cannot read the trailing descriptor size");
        return disc;
    }

    uint64_t descriptor_size = le32(footer);
    if(descriptor_size < 5 || descriptor_size > size) {
        disc.fail("trailing descriptor size " + std::to_string(descriptor_size)
                  + " does not point inside a " + std::to_string(size) + "-byte file");
        return disc;
    }

    uint64_t descriptor_start = size - descriptor_size;

    std::vector<uint8_t> desc((size_t) descriptor_size);
    if(!read_at(f, descriptor_start, desc.data(), desc.size())) {
        disc.fail("cannot read the descriptor");
        return disc;
    }

    size_t at = 0;
    unsigned session_count = desc[at++];
    if(session_count == 0) {
        disc.fail("descriptor declares no sessions");
        return disc;
    }

    /* The track data area runs from byte 0 and is walked in step with the
     * descriptor, since nothing in a CDI records where a track starts in the
     * file. What each track costs is a property of the format: its pregap is
     * physically stored, and so is its data and postgap. */
    uint64_t track_data_offset = 0;
    unsigned track_number = 0;

    for(unsigned s = 0; s < session_count; ++s) {
        if(at + CDI_SESSION_HEADER_SIZE > desc.size()) {
            disc.fail("descriptor ends inside session " + std::to_string(s + 1));
            return disc;
        }

        unsigned track_count = le16(desc.data() + at + 1);
        at += CDI_SESSION_HEADER_SIZE;

        Session session;
        session.index = s + 1;

        for(unsigned t = 0; t < track_count; ++t) {
            /* The 88-byte track header repeats before every descriptor and
             * opens with two identical 10-byte markers, which is what a reader
             * keys on to find track entries. */
            static const uint8_t MARKER[10] = {0x00, 0x00, 0x01, 0x00, 0x00,
                                               0x00, 0xFF, 0xFF, 0xFF, 0xFF};

            /* Only the last track of a session carries the trailing 8 bytes. */
            bool last_in_session = (t + 1 == track_count);
            size_t desc_size = last_in_session ? CDI_TRACK_DESC_LONG : CDI_TRACK_DESC_SHORT;

            if(at + CDI_TRACK_HEADER_SIZE + desc_size > desc.size()) {
                disc.fail("descriptor ends inside track " + std::to_string(track_number + 1));
                return disc;
            }

            if(std::memcmp(desc.data() + at, MARKER, sizeof(MARKER)) != 0 ||
               std::memcmp(desc.data() + at + 10, MARKER, sizeof(MARKER)) != 0) {
                disc.fail("track " + std::to_string(track_number + 1)
                          + " is not preceded by the two track-header markers");
                return disc;
            }

            at += CDI_TRACK_HEADER_SIZE;
            const uint8_t* d = desc.data() + at;

            Track track;
            track.number = ++track_number;
            track.session = s + 1;
            track.pregap_sectors = le32(d + 2);
            track.sectors = le32(d + 6);
            track.mode_value = le32(d + 16);
            track.mode_name = cdi_mode_name(track.mode_value);
            track.start_lba = as_signed_lba(le32(d + 32));
            track.sector_size = cdi_sector_size(le32(d + 56));
            track.ctrl = (unsigned) le32(d + 60);

            /* Everything from the XA subheader on is stored; the 12-byte sync
             * and the 4-byte header are not. So a 2336-byte stored sector opens
             * with 8 bytes of subheader, and 2048 of user data follow. */
            track.user_data_offset = (track.sector_size == 2336) ? 8 : 0;

            uint64_t pregap = *track.pregap_sectors;
            uint64_t stored = track.sectors;
            if(track.ctrl == CTRL_AUDIO && stored < CDI_CDDA_MIN_STORED_SECTORS) {
                stored = CDI_CDDA_MIN_STORED_SECTORS;
            }

            track.file = path;
            track.file_offset = track_data_offset + pregap * track.sector_size;
            track_data_offset += (pregap + stored) * track.sector_size;

            if(last_in_session && desc[at + 182] != 0) {
                disc.fail("track " + std::to_string(track.number)
                          + " closes its session but flags a next track");
            }

            at += desc_size;

            session.tracks.push_back(disc.tracks.size());
            disc.tracks.push_back(track);
        }

        disc.sessions.push_back(session);
    }

    /* Terminator: a session header declaring no tracks, one more track header,
     * then the disc info block. */
    at += CDI_SESSION_HEADER_SIZE + CDI_TRACK_HEADER_SIZE;
    if(at + CDI_DISC_INFO_SIZE > desc.size()) {
        disc.fail("descriptor ends before the disc info block");
        return disc;
    }

    disc.total_sectors = le32(desc.data() + at);

    if(track_data_offset != descriptor_start) {
        disc.fail("the tracks account for " + std::to_string(track_data_offset)
                  + " bytes but the descriptor starts at " + std::to_string(descriptor_start));
    }

    disc.valid = disc.errors.empty();
    return disc;
}

/* ------------------------------------------------------------------ */
/* MDS                                                                 */
/* ------------------------------------------------------------------ */

constexpr size_t MDS_HEADER_SIZE = 88;
constexpr size_t MDS_SESSION_BLOCK_SIZE = 24;
constexpr size_t MDS_BLOCK_SIZE = 80;
constexpr size_t MDS_EXTRA_BLOCK_SIZE = 8;

inline std::string mds_mode_name(uint8_t mode) {
    switch(mode) {
    case 0x00: return "none";
    case 0xA9: return "audio";
    case 0xAA: return "mode1";
    case 0xAB: return "mode2";
    case 0xEC: return "mode2_form1";
    case 0xAD: return "mode2_form2";
    default: return "unknown";
    }
}

inline Disc read_mds(const std::filesystem::path& path) {
    Disc disc;
    disc.format = "mds";

    /* The MDS footer names its data file with a wildcard ("*.mdf"), meaning an
     * MDF sharing the descriptor's base name. */
    std::filesystem::path mdf = std::filesystem::path(path).replace_extension("mdf");

    std::vector<uint8_t> mds;
    {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if(!f) {
            disc.fail("cannot open " + path.string());
            return disc;
        }
        std::streamoff size = f.tellg();
        if(size < (std::streamoff) MDS_HEADER_SIZE) {
            disc.fail("file is too small to be an MDS");
            return disc;
        }
        mds.assign((size_t) size, 0);
        f.seekg(0, std::ios::beg);
        f.read((char*) mds.data(), size);
    }

    if(std::memcmp(mds.data(), "MEDIA DESCRIPTOR", 16) != 0) {
        disc.fail("missing the MEDIA DESCRIPTOR signature");
        return disc;
    }

    unsigned session_count = le16(mds.data() + 0x14);
    uint32_t session_blocks_at = le32(mds.data() + 0x50);

    if(!std::filesystem::exists(mdf)) {
        disc.fail("the descriptor's MDF (" + mdf.filename().string() + ") is missing");
    }

    unsigned track_number = 0;

    for(unsigned s = 0; s < session_count; ++s) {
        size_t sb = session_blocks_at + (size_t) s * MDS_SESSION_BLOCK_SIZE;
        if(sb + MDS_SESSION_BLOCK_SIZE > mds.size()) {
            disc.fail("session block " + std::to_string(s + 1) + " is past the end of the file");
            return disc;
        }

        Session session;
        session.index = le16(mds.data() + sb + 0x08);
        session.start_lba = as_signed_lba(le32(mds.data() + sb + 0x00));
        session.end_lba = as_signed_lba(le32(mds.data() + sb + 0x04));

        unsigned block_count = mds[sb + 0x0A];
        uint32_t blocks_at = le32(mds.data() + sb + 0x14);

        for(unsigned b = 0; b < block_count; ++b) {
            size_t tb = blocks_at + (size_t) b * MDS_BLOCK_SIZE;
            if(tb + MDS_BLOCK_SIZE > mds.size()) {
                disc.fail("track block " + std::to_string(b) + " of session "
                          + std::to_string(s + 1) + " is past the end of the file");
                return disc;
            }

            /* Points 0xA0/0xA1/0xA2 and 0xB0/0xC0/0xC1 are lead-in entries
             * describing the session rather than tracks of it; a real track's
             * point is its own number, 1 to 99. */
            uint8_t point = mds[tb + 0x04];
            if(point == 0 || point > 99) continue;

            Track track;
            track.number = ++track_number;
            track.session = session.index;
            track.mode_value = mds[tb + 0x00];
            track.mode_name = mds_mode_name((uint8_t) track.mode_value);

            /* ADR in the high nibble, CTL in the low one: 0x14 is data, 0x10
             * audio. */
            track.ctrl = mds[tb + 0x02] & 0x0F;

            track.sector_size = le16(mds.data() + tb + 0x10);
            track.start_lba = le32(mds.data() + tb + 0x24);

            uint64_t start_offset = le64(mds.data() + tb + 0x28);
            uint32_t extra_at = le32(mds.data() + tb + 0x0C);

            if(extra_at + MDS_EXTRA_BLOCK_SIZE > mds.size()) {
                disc.fail("the extra block of track " + std::to_string(track.number)
                          + " is past the end of the file");
                return disc;
            }

            track.pregap_sectors = le32(mds.data() + extra_at + 0x00);
            track.sectors = le32(mds.data() + extra_at + 0x04);

            /* Raw 2352-byte sectors, with the pregap declared here but never
             * stored -- so start_offset already points at the first data
             * sector. Mode 1 puts its user data after the 16-byte sync and
             * header, Mode 2 Form 1 after a further 8-byte subheader. */
            track.user_data_offset = (track.mode_value == 0xEC) ? 24 : 16;
            track.file = mdf;
            track.file_offset = start_offset;

            session.tracks.push_back(disc.tracks.size());
            disc.tracks.push_back(track);
        }

        disc.sessions.push_back(session);
    }

    disc.valid = disc.errors.empty();
    return disc;
}

/* ------------------------------------------------------------------ */
/* NRG                                                                 */
/* ------------------------------------------------------------------ */

constexpr size_t NRG_FOOTER_SIZE = 12;
constexpr size_t NRG_CUEX_ENTRY_SIZE = 8;
constexpr size_t NRG_DAOX_COMMON_SIZE = 22;
constexpr size_t NRG_DAOX_TRACK_SIZE = 42;

inline std::string nrg_mode_name(uint32_t mode) {
    /* Only the high byte is interpreted, and it is its own value space -- not
     * the CUEX mode byte and not the TAO codes. */
    switch(mode >> 24) {
    case 0x06: return "mode2_form1";
    case 0x07: return "audio";
    default: return "unknown";
    }
}

inline Disc read_nrg(const std::filesystem::path& path) {
    Disc disc;
    disc.format = "nrg";

    uint64_t size = file_size_of(path);
    if(size < NRG_FOOTER_SIZE) {
        disc.fail("file is too small to be an NRG");
        return disc;
    }

    std::ifstream f(path, std::ios::binary);
    if(!f) {
        disc.fail("cannot open " + path.string());
        return disc;
    }

    uint8_t footer[NRG_FOOTER_SIZE];
    if(!read_at(f, size - NRG_FOOTER_SIZE, footer, sizeof(footer))) {
        disc.fail("cannot read the footer");
        return disc;
    }

    if(std::memcmp(footer, "NER5", 4) != 0) {
        disc.fail("missing the NER5 footer signature");
        return disc;
    }

    uint64_t chunk_at = be64(footer + 4);
    if(chunk_at >= size) {
        disc.fail("the footer points outside the file");
        return disc;
    }

    /* The trailer is a chain of {4-byte id, 4-byte big-endian length, payload}
     * chunks ending at END!, in the order CUEX,DAOX,...,SINF,...,MTYP,END!.
     * A session's CUEX gives its LBAs and its DAOX the byte offsets of the
     * tracks, so the two are collected and paired up per session below. */
    struct Chunk {
        std::string id;
        std::vector<uint8_t> payload;
    };

    std::vector<Chunk> chunks;
    while(chunk_at + 8 <= size) {
        uint8_t header[8];
        if(!read_at(f, chunk_at, header, sizeof(header))) {
            disc.fail("cannot read a chunk header");
            return disc;
        }

        Chunk chunk;
        chunk.id.assign((const char*) header, 4);
        uint32_t payload_size = be32(header + 4);

        if(chunk_at + 8 + payload_size > size) {
            disc.fail("chunk " + chunk.id + " runs past the end of the file");
            return disc;
        }

        chunk.payload.assign(payload_size, 0);
        if(payload_size && !read_at(f, chunk_at + 8, chunk.payload.data(), payload_size)) {
            disc.fail("cannot read the payload of chunk " + chunk.id);
            return disc;
        }

        chunk_at += 8 + payload_size;
        bool end = chunk.id == "END!";
        chunks.push_back(std::move(chunk));
        if(end) break;
    }

    if(chunks.empty() || chunks.back().id != "END!") {
        disc.fail("the chunk chain does not end at END!");
        return disc;
    }

    std::vector<const Chunk*> cuex, daox;
    for(const auto& chunk: chunks) {
        if(chunk.id == "CUEX") cuex.push_back(&chunk);
        else if(chunk.id == "DAOX") daox.push_back(&chunk);
    }

    if(cuex.size() != daox.size()) {
        disc.fail("there are " + std::to_string(cuex.size()) + " CUEX chunks but "
                  + std::to_string(daox.size()) + " DAOX chunks");
        return disc;
    }

    unsigned track_number = 0;

    for(size_t s = 0; s < cuex.size(); ++s) {
        const std::vector<uint8_t>& cue = cuex[s]->payload;
        const std::vector<uint8_t>& dao = daox[s]->payload;

        if(cue.size() % NRG_CUEX_ENTRY_SIZE != 0 || cue.size() < 2 * NRG_CUEX_ENTRY_SIZE) {
            disc.fail("session " + std::to_string(s + 1) + " has a malformed CUEX chunk");
            return disc;
        }

        if(dao.size() < NRG_DAOX_COMMON_SIZE ||
           (dao.size() - NRG_DAOX_COMMON_SIZE) % NRG_DAOX_TRACK_SIZE != 0) {
            disc.fail("session " + std::to_string(s + 1) + " has a malformed DAOX chunk");
            return disc;
        }

        size_t n_tracks = (dao.size() - NRG_DAOX_COMMON_SIZE) / NRG_DAOX_TRACK_SIZE;

        Session session;
        session.index = (unsigned) s + 1;

        /* The leading entry carries the session's own start, the trailing one
         * (marked 0xAA) its lead-out. */
        session.start_lba = as_signed_lba(be32(cue.data() + 4));
        session.end_lba = as_signed_lba(be32(cue.data() + cue.size() - 4));

        for(size_t t = 0; t < n_tracks; ++t) {
            const uint8_t* rec = dao.data() + NRG_DAOX_COMMON_SIZE + t * NRG_DAOX_TRACK_SIZE;

            Track track;
            track.number = ++track_number;
            track.session = session.index;
            track.sector_size = be32(rec + 10);
            track.mode_value = be32(rec + 14);
            track.mode_name = nrg_mode_name(track.mode_value);
            track.ctrl = (track.mode_name == "audio") ? CTRL_AUDIO : CTRL_DATA;

            uint64_t index0 = be64(rec + 18);
            uint64_t index1 = be64(rec + 26);
            uint64_t end = be64(rec + 34);

            if(track.sector_size == 0 || index1 < index0 || end < index1) {
                disc.fail("track " + std::to_string(track.number)
                          + " has offsets that do not run forwards");
                return disc;
            }

            track.pregap_sectors = (uint32_t) ((index1 - index0) / track.sector_size);
            track.sectors = (end - index1) / track.sector_size;

            /* Whatever the mode, mkdcdisc's NRG tracks are full raw sectors.
             * The user data of a Mode 2 Form 1 sector begins after the 16-byte
             * sync and header plus an 8-byte subheader. */
            track.user_data_offset = (track.mode_name == "audio") ? 0 : 24;
            track.file = path;
            track.file_offset = index1;

            /* The cue sheet holds a session header entry, then an index0/index1
             * pair per track, then the trailer: index 1 of track t is entry
             * 1 + 2t + 1. */
            size_t index1_entry = 1 + 2 * t + 1;
            if((index1_entry + 1) * NRG_CUEX_ENTRY_SIZE > cue.size()) {
                disc.fail("the CUEX chunk of session " + std::to_string(s + 1)
                          + " has no index 1 entry for track " + std::to_string(track.number));
                return disc;
            }

            const uint8_t* entry = cue.data() + index1_entry * NRG_CUEX_ENTRY_SIZE;
            if(entry[2] != 1) {
                disc.fail("CUEX entry " + std::to_string(index1_entry) + " of session "
                          + std::to_string(s + 1) + " is not an index 1");
                return disc;
            }

            track.start_lba = as_signed_lba(be32(entry + 4));

            session.tracks.push_back(disc.tracks.size());
            disc.tracks.push_back(track);
        }

        disc.sessions.push_back(session);
    }

    disc.valid = disc.errors.empty();
    return disc;
}

/* ------------------------------------------------------------------ */
/* GDI                                                                 */
/* ------------------------------------------------------------------ */

/* A .gdi is a track count on the first line, then one line per track:
 * number, LBA, CTRL, sector size, filename, and a trailing offset always 0.
 * There is no session structure in the file at all, and no pregaps: the gaps
 * are implied by the LBAs. */
inline Disc read_gdi(const std::filesystem::path& path) {
    Disc disc;
    disc.format = "gdi";

    std::ifstream f(path);
    if(!f) {
        disc.fail("cannot open " + path.string());
        return disc;
    }

    long declared = -1;
    if(!(f >> declared) || declared < 0) {
        disc.fail("the first line is not a track count");
        return disc;
    }

    std::filesystem::path dir = path.parent_path();

    unsigned expected_number = 0;
    unsigned session = 1;

    for(;;) {
        unsigned number = 0;
        long lba = 0;
        unsigned ctrl = 0, sector_size = 0;
        std::string filename;
        long trailing = -1;

        if(!(f >> number >> lba >> ctrl >> sector_size >> filename >> trailing)) break;

        Track track;
        track.number = number;
        track.ctrl = ctrl;
        track.sector_size = sector_size;
        track.start_lba = lba;
        track.sectors = 0;

        if(++expected_number != number) {
            disc.fail("track " + std::to_string(number) + " is listed in position "
                      + std::to_string(expected_number));
        }

        if(trailing != 0) {
            disc.fail("track " + std::to_string(number) + " has a non-zero trailing offset");
        }

        /* The high-density area begins at a fixed physical LBA; the first track
         * that reaches it opens the second session. */
        if(lba >= (long) GD_START_LBA && session == 1) {
            session = 2;
        }
        track.session = session;

        if(ctrl == CTRL_DATA) {
            /* 2352 means raw Mode 1 -- 12 sync, 4 header, then user data. 2048
             * is user data alone. */
            track.mode_name = (sector_size == 2352) ? "mode1" : "mode1_cooked";
            track.mode_value = 1;
            track.user_data_offset = (sector_size == 2352) ? 16 : 0;
        } else {
            track.mode_name = "audio";
            track.mode_value = 0;
            track.user_data_offset = 0;
        }

        track.file = dir.empty() ? std::filesystem::path(filename) : dir / filename;

        uint64_t bytes = file_size_of(track.file);
        if(bytes == 0) {
            disc.fail("track file " + filename + " is missing or empty");
        } else if(sector_size == 0 || bytes % sector_size != 0) {
            disc.fail("track file " + filename + " is not a whole number of "
                      + std::to_string(sector_size) + "-byte sectors");
        } else {
            track.sectors = bytes / sector_size;
        }

        while(disc.sessions.size() < session) {
            Session s;
            s.index = (unsigned) disc.sessions.size() + 1;
            disc.sessions.push_back(s);
        }

        disc.sessions[session - 1].tracks.push_back(disc.tracks.size());
        disc.tracks.push_back(track);
    }

    if((long) disc.tracks.size() != declared) {
        disc.fail("the header declares " + std::to_string(declared) + " tracks but "
                  + std::to_string(disc.tracks.size()) + " are listed");
    }

    disc.valid = disc.errors.empty();
    return disc;
}

/* ------------------------------------------------------------------ */

/* Dispatches on the extension, which is how the format is named everywhere
 * else in this project. */
inline Disc read(const std::filesystem::path& path) {
    std::string ext = path.extension().string();
    for(char& c: ext) c = (char) std::tolower((unsigned char) c);

    if(ext == ".cdi") return read_cdi(path);
    if(ext == ".mds") return read_mds(path);
    if(ext == ".nrg") return read_nrg(path);
    if(ext == ".gdi") return read_gdi(path);

    Disc disc;
    disc.fail("unknown image extension '" + ext + "'");
    return disc;
}

} /* namespace disc_read */
