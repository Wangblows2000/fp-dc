/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* The short digest the committed manifests carry, so that a block of bytes too
 * large to print can still be pinned.
 *
 * FNV-1a, 64-bit. Not a cryptographic hash and does not need to be: it says
 * "these bytes are not those bytes", and every manifest using it carries a
 * decoded summary alongside so a difference can be read rather than merely
 * detected. Shared so that the manifests agree on what a digest means -- two
 * tests hashing the same bytes must print the same line. */

#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace digest {

inline uint64_t fnv1a(const uint8_t* data, size_t len) {
    uint64_t h = 1469598103934665603ull;
    for(size_t i = 0; i < len; ++i) {
        h ^= data[i];
        h *= 1099511628211ull;
    }
    return h;
}

inline uint64_t fnv1a(const std::vector<uint8_t>& data) {
    return fnv1a(data.data(), data.size());
}

inline std::string hex(uint64_t value, int width) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%0*llx", width, (unsigned long long) value);
    return buf;
}

/* The form every manifest prints a whole-buffer digest in. */
inline std::string of(const std::vector<uint8_t>& data) {
    return hex(fnv1a(data), 16);
}

} // namespace digest
