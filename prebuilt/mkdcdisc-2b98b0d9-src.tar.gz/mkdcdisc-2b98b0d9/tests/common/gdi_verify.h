/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* Checks a produced .gdi against the structural rules every commercial GD-ROM
 * follows, measured across 18 reference dumps from three different mastering
 * tools. Reports what is wrong rather than asserting, so a caller can print
 * every problem at once.
 *
 * The point of doing this here rather than with per-file helpers is the track
 * map: once GD-DA is involved the high-density filesystem spans two data
 * tracks with the audio between them, so answering "where does the boot binary
 * end" means resolving an absolute LBA through every track in turn. No check
 * that opens a single track file can do that.
 */

#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace gdi_verify {

/* The high-density area starts at a fixed physical offset, and every data
 * track ends with this many sectors carrying no file content. */
static const uint32_t GD_START_LBA = 45000;
static const uint32_t TRACK_RUN_OUT = 150;

struct Track {
    unsigned number = 0;
    uint32_t lba = 0;
    unsigned ctrl = 0; /* 4 = data, 0 = audio */
    unsigned sector_size = 0;
    uint64_t sectors = 0;
    std::filesystem::path path;

    bool is_data() const { return ctrl == 4; }
    uint32_t end_lba() const { return lba + (uint32_t) sectors; }
};

struct File {
    std::string name;
    uint32_t lba = 0;
    uint32_t end_lba = 0;
};

class Image {
public:
    std::vector<Track> tracks;

    bool load(const std::filesystem::path& gdi, std::vector<std::string>& errors) {
        std::ifstream f(gdi);
        if(!f) {
            errors.push_back("cannot open " + gdi.string());
            return false;
        }

        auto dir = gdi.parent_path();
        std::string line;
        std::getline(f, line); /* track count */

        while(std::getline(f, line)) {
            std::istringstream ls(line);
            Track t;
            std::string name;

            if(!(ls >> t.number >> t.lba >> t.ctrl >> t.sector_size >> name)) {
                continue;
            }
            if(t.sector_size != 2048 && t.sector_size != 2352) {
                errors.push_back("track " + std::to_string(t.number)
                    + ": unexpected sector size " + std::to_string(t.sector_size));
                return false;
            }

            t.path = dir / name;
            if(!std::filesystem::exists(t.path)) {
                errors.push_back("track " + std::to_string(t.number) + ": missing " + name);
                return false;
            }

            auto bytes = std::filesystem::file_size(t.path);
            if(bytes % t.sector_size != 0) {
                errors.push_back("track " + std::to_string(t.number)
                    + ": size is not a whole number of sectors");
                return false;
            }

            t.sectors = bytes / t.sector_size;
            tracks.push_back(t);
        }

        return !tracks.empty();
    }

    /* User data of one absolute LBA, resolved through whichever data track
     * holds it. False when no track covers it -- which is the normal answer
     * for the range the GD-DA tracks occupy. */
    bool read_sector(uint32_t lba, uint8_t out[2048]) const {
        for(const auto& t: tracks) {
            if(!t.is_data() || lba < t.lba || lba >= t.end_lba()) {
                continue;
            }

            std::ifstream f(t.path, std::ios::binary);
            if(!f) return false;

            std::streamoff header = (t.sector_size == 2352) ? 16 : 0;
            f.seekg((std::streamoff) (lba - t.lba) * t.sector_size + header);
            f.read((char*) out, 2048);
            return (bool) f;
        }

        return false;
    }
};

static uint32_t le32(const uint8_t* p) {
    return (uint32_t) p[0] | ((uint32_t) p[1] << 8) | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
}

/* Every file of the ISO9660 volume that starts at `volume_lba`, walked
 * recursively through the track map. */
static bool list_files(const Image& img, uint32_t volume_lba, std::vector<File>& out) {
    uint8_t pvd[2048];
    if(!img.read_sector(volume_lba + 16, pvd) || std::memcmp(pvd + 1, "CD001", 5) != 0) {
        return false;
    }

    std::vector<std::pair<uint32_t, uint32_t>> pending;
    std::set<uint32_t> seen;
    pending.push_back({le32(pvd + 156 + 2), le32(pvd + 156 + 10)});

    while(!pending.empty()) {
        auto [dir_lba, dir_len] = pending.back();
        pending.pop_back();

        if(dir_len == 0 || !seen.insert(dir_lba).second) {
            continue;
        }

        for(uint32_t s = 0; (uint64_t) s * 2048 < dir_len; ++s) {
            uint8_t dir[2048];
            if(!img.read_sector(dir_lba + s, dir)) break;

            for(size_t off = 0; off + 33 < sizeof(dir);) {
                unsigned rec_len = dir[off];
                if(rec_len == 0) break;

                unsigned name_len = dir[off + 32];
                if(off + 33 + name_len > sizeof(dir)) break;

                uint32_t extent = le32(dir + off + 2);
                uint32_t length = le32(dir + off + 10);
                bool is_dir = (dir[off + 25] & 2) != 0;
                bool is_dot = (name_len == 1 && (dir[off + 33] == 0 || dir[off + 33] == 1));

                if(!is_dot && name_len > 0) {
                    if(is_dir) {
                        pending.push_back({extent, length});
                    } else if(length > 0) {
                        std::string name((const char*) dir + off + 33, name_len);
                        auto semi = name.find(';');
                        if(semi != std::string::npos) name.resize(semi);

                        out.push_back({name, extent, extent + (length + 2047) / 2048});
                    }
                }

                off += rec_len;
            }
        }
    }

    return true;
}

/* Track layout: where the high-density area starts, how tracks are spaced,
 * and what kind of track closes the disc. */
static void check_layout(const Image& img, std::vector<std::string>& errors) {
    bool saw_hd = false;

    for(size_t i = 0; i < img.tracks.size(); ++i) {
        const Track& t = img.tracks[i];

        if(t.lba >= GD_START_LBA && !saw_hd) {
            saw_hd = true;
            if(t.lba != GD_START_LBA) {
                errors.push_back("the high-density area starts at LBA " + std::to_string(t.lba)
                    + ", not " + std::to_string(GD_START_LBA));
            }
            if(!t.is_data()) {
                errors.push_back("the high-density area opens on an audio track");
            }
        }

        if(i + 1 >= img.tracks.size()) {
            continue;
        }

        const Track& next = img.tracks[i + 1];

        /* The step up to the high-density area is a fixed physical offset,
         * not a gap between tracks. */
        if(next.lba == GD_START_LBA) {
            continue;
        }

        long gap = (long) next.lba - (long) t.end_lba();
        long expected = (!t.is_data() && !next.is_data()) ? 0 : (long) TRACK_RUN_OUT;

        if(gap != expected) {
            errors.push_back("gap between tracks " + std::to_string(t.number) + " and "
                + std::to_string(next.number) + " is " + std::to_string(gap)
                + ", expected " + std::to_string(expected));
        }
    }

    if(!img.tracks.empty() && !img.tracks.back().is_data()) {
        errors.push_back("the disc does not close on a data track");
    }
}

/* The boot file the IP.BIN declares, read from the first sector of the
 * high-density area (offset 96, 16 bytes). Not every disc calls it
 * 1ST_READ.BIN: the Windows CE titles boot 0WINCEOS.BIN, and Segagaga
 * 1_SGGG.BIN. */
static std::string boot_filename(const Image& img) {
    uint8_t ip[2048];
    if(!img.read_sector(GD_START_LBA, ip)) {
        return "";
    }

    std::string name((const char*) ip + 96, 16);
    while(!name.empty() && (name.back() == ' ' || name.back() == '\0')) {
        name.pop_back();
    }
    return name;
}

/* Content placement inside the high-density filesystem: every data track's
 * content stops short of its run-out, and the boot binary is the last file. */
static void check_content(const Image& img, std::vector<std::string>& errors) {
    std::vector<File> files;
    if(!list_files(img, GD_START_LBA, files)) {
        errors.push_back("no readable ISO9660 volume in the high-density area");
        return;
    }

    std::string boot = boot_filename(img);
    if(boot.empty()) {
        errors.push_back("the IP.BIN declares no boot file");
        return;
    }

    uint32_t last_end = 0;
    const File* last = nullptr;

    for(const auto& file: files) {
        const Track* holder = nullptr;
        for(const auto& t: img.tracks) {
            if(file.lba >= t.lba && file.lba < t.end_lba()) {
                holder = &t;
                break;
            }
        }

        if(!holder) {
            errors.push_back(file.name + " starts at LBA " + std::to_string(file.lba)
                + ", which no track covers");
            continue;
        }

        /* A file may deliberately point at an audio track, so the game can
         * reach its own GD-DA through the filesystem -- South Park Rally
         * exposes all eight of its tracks that way. Only data tracks carry
         * real file content, so only they get the run-out check. */
        if(!holder->is_data()) {
            continue;
        }

        if(file.end_lba > holder->end_lba()) {
            errors.push_back(file.name + " runs past the end of track "
                + std::to_string(holder->number));
        } else if(file.end_lba > holder->end_lba() - TRACK_RUN_OUT) {
            errors.push_back(file.name + " ends at LBA " + std::to_string(file.end_lba)
                + ", inside the run-out of track " + std::to_string(holder->number)
                + " (which ends at " + std::to_string(holder->end_lba()) + ")");
        }

        if(file.end_lba > last_end) {
            last_end = file.end_lba;
            last = &file;
        }
    }

    if(last && last->name != boot) {
        errors.push_back("the last file is " + last->name + ", not the declared boot binary "
            + boot + "; GD-ROM hardware expects the binary at the end of the area");
    }
}

/* Runs every check. */
static std::vector<std::string> verify(const std::filesystem::path& gdi) {
    std::vector<std::string> errors;

    Image img;
    if(!img.load(gdi, errors)) {
        if(errors.empty()) errors.push_back("no tracks in " + gdi.string());
        return errors;
    }

    check_layout(img, errors);
    check_content(img, errors);
    return errors;
}

} /* namespace gdi_verify */
