/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* Which ISO9660 volume each data track of a finished image belongs to, and how
 * to reach the volume's bytes when it does not fit inside one track.
 *
 * A volume does not always stop at the end of the track carrying its PVD. Once
 * there is audio inside a session -- the low-density pair of a GD-ROM, or a
 * GD-DA disc -- mkdcdisc reserves the audio's address range with a hidden
 * spacer file, so the filesystem spans the audio tracks and resumes in a
 * closing data track that has no descriptors of its own. Volumes are therefore
 * anchored at the tracks that do have a PVD, and each one runs until the next
 * anchor.
 *
 * Two things are offered on top of that. find() says where each volume begins
 * and ends, which is all a table-of-contents description needs. window()
 * assembles the volume's whole address range into one buffer, which is what
 * reading a file out of it needs: on a GD-DA disc the boot binary sorts last
 * and therefore lives in the closing track, several tracks past its own PVD.
 *
 * Built on disc_read.h and iso_read.h and sharing no arithmetic with the
 * writers, for the reason given at the top of disc_read.h. Used by
 * e2e/test_disc_manifest.cpp and e2e/test_bootable_disc.cpp. */

#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>

#include "disc_read.h"
#include "iso_read.h"

namespace volume_span {

/* The ISO9660 volume a data track carries, as its sector count and its root
 * directory. Read out of the track itself rather than out of anything mkdcdisc
 * dumped alongside: -I/--dump-iso rebuilds the volume at ms_block 0, which is a
 * different filesystem of a different size, and the point here is what the
 * track actually holds. */
struct Volume {
    bool valid = false;
    uint32_t sectors = 0;
    std::string volume_id;
    std::string system_id;

    /* In the order the directory records come in, which is libisofs's choice.
     * Left that way on purpose: a caller wanting a stable listing sorts, and a
     * caller asking which file sits last needs the order untouched. */
    std::vector<iso_read::Entry> entries;

    /* Descriptors without a directory tree behind them: the "boot head" track a
     * Data/Data image closes with, which duplicates the first 18 sectors of the
     * real volume -- IP.BIN and the descriptors -- into a track padded to the
     * Red Book minimum. Its PVD therefore describes session 1's filesystem
     * while the track holds none of it, so nothing about that filesystem may be
     * measured against this track. */
    bool has_tree() const { return !entries.empty(); }
};

/* Where a volume's descriptors were found, and how far its filesystem reaches.
 * Both members index into Disc::tracks. */
struct Span {
    size_t anchor = 0;  /* The track holding the descriptors */
    size_t last = 0;    /* The last track the volume reaches into */
    Volume volume;
};

inline Volume read_volume(const disc_read::Track& track) {
    Volume volume;

    std::vector<uint8_t> user_data = disc_read::track_user_data(track);
    iso_read::Pvd pvd = iso_read::read_pvd(user_data);
    if(!pvd.valid) return volume;

    volume.valid = true;
    volume.sectors = pvd.volume_space;
    volume.volume_id = pvd.volume_id;
    volume.system_id = pvd.system_id;

    /* Addresses inside the volume count from the start of the disc, so the base
     * to resolve them against is the track's own start. */
    uint32_t base = (uint32_t) (track.start_lba < 0 ? 0 : track.start_lba);
    iso_read::read_directory(user_data, pvd.root_lba, pvd.root_len, "", volume.entries, base);

    return volume;
}

/* Which volume each data track belongs to. Fails only when a data track appears
 * before any of them, which would mean content that no filesystem accounts
 * for. */
inline bool find(const disc_read::Disc& disc, std::vector<Span>& spans, std::string& error) {
    for(size_t i = 0; i < disc.tracks.size(); ++i) {
        if(!disc.tracks[i].is_data()) continue;

        Volume volume = read_volume(disc.tracks[i]);
        if(volume.valid) {
            Span span;
            span.anchor = i;
            span.last = i;
            span.volume = std::move(volume);
            spans.push_back(std::move(span));
            continue;
        }

        if(spans.empty()) {
            error = "track " + std::to_string(disc.tracks[i].number)
                  + " is a data track, but no volume has begun that could account for it";
            return false;
        }
    }

    if(spans.empty()) {
        error = "the disc carries no readable ISO9660 volume at all";
        return false;
    }

    /* Each volume reaches to just before the next one begins, and the last to
     * the end of the disc. */
    for(size_t v = 0; v + 1 < spans.size(); ++v) {
        spans[v].last = spans[v + 1].anchor - 1;
    }
    spans.back().last = disc.tracks.size() - 1;

    return true;
}

/* The LBA every address inside the volume is relative to: where its anchor
 * track begins, which is also where window() below starts. */
inline uint32_t base_lba(const disc_read::Disc& disc, const Span& span) {
    int64_t lba = disc.tracks[span.anchor].start_lba;
    return lba < 0 ? 0 : (uint32_t) lba;
}

/* The volume's whole address range as one buffer of 2048-byte sectors, ready
 * for iso_read.h with base_lba() above as its base.
 *
 * Data tracks contribute their user data at their own offset. Audio tracks
 * contribute nothing and are left as zeroes: their address range belongs to the
 * volume -- that is what the hidden spacer file reserves it for -- but no part
 * of the filesystem is stored there, and a console following a directory record
 * into that range would be reading a file mkdcdisc never wrote.
 *
 * Capped at disc_read::MAX_TRACK_SECTORS, like every other read in these tests:
 * everything they are pointed at is a deliberately small image. */
inline std::vector<uint8_t> window(const disc_read::Disc& disc, const Span& span) {
    if(span.anchor >= disc.tracks.size() || span.last >= disc.tracks.size()) return {};

    int64_t begin = disc.tracks[span.anchor].start_lba;
    const disc_read::Track& last = disc.tracks[span.last];

    int64_t end = last.start_lba + (int64_t) last.sectors;
    if(end <= begin) return {};

    uint64_t sectors = (uint64_t) (end - begin);
    if(sectors > disc_read::MAX_TRACK_SECTORS) sectors = disc_read::MAX_TRACK_SECTORS;

    std::vector<uint8_t> out((size_t) sectors * iso_read::SECTOR, 0);

    for(size_t i = span.anchor; i <= span.last; ++i) {
        const disc_read::Track& track = disc.tracks[i];
        if(!track.is_data() || track.start_lba < begin) continue;

        uint64_t at = (uint64_t) (track.start_lba - begin) * iso_read::SECTOR;
        if(at >= out.size()) continue;

        std::vector<uint8_t> data = disc_read::track_user_data(track);
        size_t room = out.size() - (size_t) at;
        if(data.size() > room) data.resize(room);

        std::copy(data.begin(), data.end(), out.begin() + (std::ptrdiff_t) at);
    }

    return out;
}

} // namespace volume_span
