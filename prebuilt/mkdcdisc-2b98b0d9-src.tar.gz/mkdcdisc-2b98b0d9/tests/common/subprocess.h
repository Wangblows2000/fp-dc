/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* Running the built mkdcdisc binary and capturing what it said. Shared by the
 * e2e tests, which all need it and none of which should have to rediscover the
 * cmd.exe quoting rule below. */

/* The POSIX half below needs popen()/pclose()/setenv() to be visible. Only
 * MSYS2's non-MinGW gcc hides them, and what unlocks them there is the
 * -D_POSIX_C_SOURCE that tests/meson.build puts on the command line -- not
 * anything this header could do, since a feature-test macro is read when the
 * first system header is processed and this one is included last. See the
 * comment on e2e_cpp_args there for the whole story. */

#include <cstdio>
#include <cstdlib>
#include <string>

#ifdef _WIN32
#include <process.h>
#define POPEN _popen
#define PCLOSE _pclose
#define GETPID() _getpid()
#else
#include <sys/wait.h>
#include <unistd.h>
#define POPEN popen
#define PCLOSE pclose
#define GETPID() getpid()
#endif

struct RunResult {
    int exit_code = -1;
    std::string output;
};

inline RunResult run(const std::string& cmd) {
    RunResult result;

    std::string full_cmd = cmd + " 2>&1";
#ifdef _WIN32
    /* _popen() runs the command through cmd.exe /c, which only preserves
     * quotes exactly as written when the command line contains exactly two
     * of them. Any of our commands quoting both the executable path and an
     * argument has four, so cmd.exe falls back to blindly stripping just
     * the first and last characters if they happen to be quotes -- which
     * corrupts the line instead of un-wrapping it. Wrapping the whole
     * command in one more pair of quotes makes that fallback strip only
     * the wrapper, leaving the real command untouched. */
    full_cmd = "\"" + full_cmd + "\"";
#endif

    FILE* pipe = POPEN(full_cmd.c_str(), "r");
    if(!pipe) {
        return result;
    }

    char buf[4096];
    size_t n;
    while((n = fread(buf, 1, sizeof(buf), pipe)) > 0) {
        result.output.append(buf, n);
    }

    int status = PCLOSE(pipe);
#ifdef _WIN32
    result.exit_code = status;
#else
    result.exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
#endif

    return result;
}

inline std::string quote(const std::string& s) {
    return "\"" + s + "\"";
}

/* Set in this process, so that every command run() starts inherits it. There
 * is no portable way to hand one variable to one child: prefixing the command
 * line would have to survive the cmd.exe quoting above, which is not a fight
 * worth having for something the environment does properly. */
inline void set_env(const char* name, const char* value) {
#ifdef _WIN32
    _putenv_s(name, value);
#else
    setenv(name, value, 1);
#endif
}

inline void unset_env(const char* name) {
#ifdef _WIN32
    _putenv_s(name, "");
#else
    unsetenv(name);
#endif
}
