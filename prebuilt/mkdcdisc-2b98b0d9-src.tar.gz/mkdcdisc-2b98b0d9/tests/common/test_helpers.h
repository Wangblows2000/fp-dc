/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#ifdef _WIN32
#include <process.h>
#define TEST_GETPID() _getpid()
#else
#include <unistd.h>
#define TEST_GETPID() getpid()
#endif

#include "disc_image/disc_image.h"

static int g_test_failures = 0;

#define CHECK(cond) do { \
    if(!(cond)) { \
        fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        g_test_failures++; \
    } \
} while(0)

/* A named temp file rather than tmpfile(): tmpfile() has a long history of
 * trying (and failing) to create files at the root of C:\ on some Windows
 * CRTs. This just uses TMPDIR/TEMP/TMP like everything else does. */
typedef struct {
    FILE* file;
    char path[1024];
} temp_file_t;

static inline temp_file_t open_temp_file(void) {
    static int counter = 0;
    temp_file_t tf;

    const char* dir = getenv("TMPDIR");
    if(!dir) dir = getenv("TEMP");
    if(!dir) dir = getenv("TMP");
    if(!dir) dir = ".";

    snprintf(tf.path, sizeof(tf.path), "%s/mkdcdisc-test-%d-%d.tmp",
        dir, (int) TEST_GETPID(), counter++);

    tf.file = fopen(tf.path, "wb+");
    return tf;
}

static inline void close_temp_file(temp_file_t* tf) {
    if(tf->file) {
        fclose(tf->file);
        tf->file = NULL;
    }
    remove(tf->path);
}

/* Builds a deterministic 2-session image: session 0 holds the default
 * blank 4-second audio track (as used when no -c/--cdda-track is given), session
 * 1 holds a single XA Mode 2 Form 1 data track of `data_len` bytes filled
 * with a repeating byte pattern. Mirrors the shape build_cdi() in main.cpp
 * produces for the default Audio/Data layout. */
static inline cd_image_t* build_test_image(size_t data_len) {
    cd_image_t* img = cd_new_image();
    cd_image_set_volume_name(img, "TESTVOL");

    cd_session_t* session0 = cd_new_session(img);
    cd_new_track_blank(session0, TRACK_TYPE_AUDIO, 2352 * 302);

    cd_session_t* session1 = cd_new_session(img);
    uint8_t* data = (uint8_t*) malloc(data_len);
    for(size_t i = 0; i < data_len; ++i) {
        data[i] = (uint8_t) (i & 0xFF);
    }

    cd_track_t* track = cd_new_track(session1, TRACK_TYPE_DATA, data, (uint32_t) data_len);
    cd_track_set_mode(track, TRACK_MODE_XA_MODE2_FORM1);
    cd_track_set_postgap_sectors(track, 2);

    free(data);
    return img;
}

/* Builds a deterministic 3-track GD-ROM-shaped image for the writer tests:
 * session 0 holds a 300-sector Mode 1 placeholder data track (track 1, LBA 0)
 * and a 302-sector blank CDDA track (track 2, LBA 450 -- 300 + the default
 * 150-sector pregap); session 1 holds a single Mode 1 data track (track 3,
 * fixed at CD_GD_START_LBA) of `hd_data_len` bytes filled with a repeating
 * byte pattern.
 *
 * The track lengths are the fixture's own, deliberately not the ones
 * build_gd() picks: what is under test here is cd_write_to_gdi()'s LBA and
 * pregap arithmetic, which must not depend on any particular track size. */
static inline cd_image_t* build_test_gdi_image(size_t hd_data_len) {
    cd_image_t* img = cd_new_image();
    cd_image_set_volume_name(img, "TESTVOL");

    cd_session_t* session0 = cd_new_session(img);

    size_t track1_len = 300 * 2048;
    uint8_t* track1_data = (uint8_t*) calloc(1, track1_len);
    cd_track_t* track1 = cd_new_track(session0, TRACK_TYPE_DATA, track1_data, (uint32_t) track1_len);
    cd_track_set_mode(track1, TRACK_MODE_MODE1);
    free(track1_data);

    cd_new_track_blank(session0, TRACK_TYPE_AUDIO, 2352 * 302);

    cd_session_t* session1 = cd_new_session(img);
    uint8_t* hd_data = (uint8_t*) malloc(hd_data_len);
    for(size_t i = 0; i < hd_data_len; ++i) {
        hd_data[i] = (uint8_t) (i & 0xFF);
    }

    cd_track_t* track3 = cd_new_track(session1, TRACK_TYPE_DATA, hd_data, (uint32_t) hd_data_len);
    cd_track_set_mode(track3, TRACK_MODE_MODE1);

    free(hd_data);
    return img;
}
