/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

#pragma once

/* Reading an ISO9660 volume out of a flat byte buffer -- the .iso that
 * -I/--dump-iso writes, or a 2048-byte-sector GD-ROM track, both of which are
 * a volume's own bytes with nothing wrapped around them.
 *
 * Deliberately a plain ECMA-119 reader: it walks the Primary Volume Descriptor
 * and the directory records, and knows nothing of Joliet or Rock Ridge beyond
 * being able to say a supplementary descriptor is there. What it reports is
 * therefore what any ISO9660 reader would see, which is the point -- these
 * checks exist to describe libisofs's output, not to agree with it.
 *
 * Separate from gdi_verify.h, which reads a volume through a .gdi track map
 * and answers GD-ROM questions. */

#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <vector>

namespace iso_read {

constexpr size_t SECTOR = 2048;

/* Sectors 0-15, which ECMA-119 reserves and says nothing about. It is where
 * the Dreamcast bootstrap lives. */
constexpr size_t SYSTEM_AREA_SIZE = 16 * SECTOR;

inline uint32_t le32(const uint8_t* p) {
    return (uint32_t) p[0] | ((uint32_t) p[1] << 8)
        | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
}

/* The LBA a GD-ROM's high-density volume starts at. Every address recorded
 * inside that volume counts from the start of the disc, not from the start of
 * the track file it is read out of, so following one means subtracting this.
 * A standalone .iso needs no such adjustment and uses 0. */
constexpr uint32_t GD_HIGH_DENSITY_LBA = 45000;

/* Where an LBA recorded inside the volume lands in the buffer holding it, or
 * SIZE_MAX when it points outside -- which is what happens if the wrong base
 * is used, and is worth failing on rather than reading rubbish. */
inline size_t offset_of(uint32_t lba, uint32_t base_lba) {
    if(lba < base_lba) return (size_t) -1;
    return (size_t) (lba - base_lba) * SECTOR;
}

inline std::vector<uint8_t> read_whole_file(const std::filesystem::path& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if(!f) return {};

    std::streamoff size = f.tellg();
    if(size <= 0) return {};

    std::vector<uint8_t> data((size_t) size);
    f.seekg(0, std::ios::beg);
    f.read((char*) data.data(), size);
    if(!f) return {};

    return data;
}

/* One entry of the volume descriptor set, which starts at sector 16 and runs
 * until the terminator (type 255). Type 1 is the Primary Volume Descriptor,
 * type 2 a Supplementary one -- which is what Joliet is carried in. */
struct VolumeDescriptor {
    uint8_t type = 0;
    std::string escape_sequences; /* Supplementary only: offset 88, 32 bytes */
};

inline std::vector<VolumeDescriptor> volume_descriptors(const std::vector<uint8_t>& iso) {
    std::vector<VolumeDescriptor> found;

    for(size_t lba = 16; (lba + 1) * SECTOR <= iso.size(); ++lba) {
        const uint8_t* sector = iso.data() + lba * SECTOR;
        if(std::memcmp(sector + 1, "CD001", 5) != 0) {
            break;
        }

        VolumeDescriptor descriptor;
        descriptor.type = sector[0];

        if(descriptor.type == 2) {
            std::string escapes((const char*) sector + 88, 32);
            while(!escapes.empty() && (escapes.back() == ' ' || escapes.back() == '\0')) {
                escapes.pop_back();
            }
            descriptor.escape_sequences = escapes;
        }

        found.push_back(descriptor);
        if(descriptor.type == 255) {
            break;
        }
    }

    return found;
}

/* True when the volume carries a supplementary descriptor, which for a
 * mkdcdisc image means Joliet: on for MIL-CD, off for GD-ROM. */
inline bool has_supplementary_descriptor(const std::vector<uint8_t>& iso) {
    for(const auto& descriptor: volume_descriptors(iso)) {
        if(descriptor.type == 2) return true;
    }
    return false;
}

/* The identifier fields mkdcdisc sets, and the geometry the rest of this
 * reader needs. Strings come back with ECMA-119's space padding stripped. */
struct Pvd {
    bool valid = false;

    std::string system_id;
    std::string volume_id;
    std::string publisher_id;
    std::string preparer_id;
    std::string application_id;
    std::string copyright_file;
    std::string abstract_file;
    std::string biblio_file;

    uint32_t volume_space = 0;
    uint32_t root_lba = 0;
    uint32_t root_len = 0;
};

inline std::string trimmed_field(const uint8_t* at, size_t len) {
    std::string s((const char*) at, len);
    while(!s.empty() && (s.back() == ' ' || s.back() == '\0')) {
        s.pop_back();
    }
    return s;
}

inline Pvd read_pvd(const std::vector<uint8_t>& iso) {
    Pvd pvd;
    if(iso.size() < 17 * SECTOR) return pvd;

    const uint8_t* at = iso.data() + 16 * SECTOR;
    if(at[0] != 1 || std::memcmp(at + 1, "CD001", 5) != 0) return pvd;

    pvd.valid = true;
    pvd.system_id = trimmed_field(at + 8, 32);
    pvd.volume_id = trimmed_field(at + 40, 32);
    pvd.volume_space = le32(at + 80);
    pvd.publisher_id = trimmed_field(at + 318, 128);
    pvd.preparer_id = trimmed_field(at + 446, 128);
    pvd.application_id = trimmed_field(at + 574, 128);
    pvd.copyright_file = trimmed_field(at + 702, 37);
    pvd.abstract_file = trimmed_field(at + 739, 37);
    pvd.biblio_file = trimmed_field(at + 776, 37);

    /* The root directory record lives inside the PVD at offset 156; its extent
     * and data length are the little-endian halves of both-endian pairs. */
    pvd.root_lba = le32(at + 156 + 2);
    pvd.root_len = le32(at + 156 + 10);

    return pvd;
}

struct Entry {
    std::string path;  /* "/SUB/C.TXT", always with a leading slash */
    uint32_t lba = 0;
    uint32_t size = 0;
    bool is_dir = false;
};

/* Every directory record of one directory extent, "." and ".." excluded. */
inline void read_directory(const std::vector<uint8_t>& iso, uint32_t lba, uint32_t len,
                           const std::string& prefix, std::vector<Entry>& out,
                           uint32_t base_lba = 0) {
    size_t extent = offset_of(lba, base_lba);
    if(extent == (size_t) -1) return;

    for(uint32_t offset = 0; offset < len; ) {
        size_t at = extent + offset;
        if(at + 33 > iso.size()) return;

        uint8_t record_len = iso[at];
        if(record_len == 0) {
            /* A directory record never straddles a sector boundary, so a zero
             * length means "skip to the next sector". */
            offset = ((offset / SECTOR) + 1) * SECTOR;
            continue;
        }

        uint8_t name_len = iso[at + 32];
        if(at + 33 + name_len > iso.size()) return;

        /* "." and ".." are one byte, 0x00 and 0x01 -- not printable names. */
        bool is_self_or_parent = (name_len == 1 && (iso[at + 33] == 0 || iso[at + 33] == 1));

        if(!is_self_or_parent) {
            Entry entry;
            entry.lba = le32(iso.data() + at + 2);
            entry.size = le32(iso.data() + at + 10);
            entry.is_dir = (iso[at + 25] & 0x02) != 0;

            std::string name((const char*) iso.data() + at + 33, name_len);
            size_t version = name.find(';');
            if(version != std::string::npos) {
                name = name.substr(0, version);
            }

            entry.path = prefix + "/" + name;
            out.push_back(entry);

            if(entry.is_dir) {
                read_directory(iso, entry.lba, entry.size, entry.path, out, base_lba);
            }
        }

        offset += record_len;
    }
}

/* A half-open byte range of the image. */
struct Range {
    size_t begin = 0;
    size_t end = 0;
};

/* Scans the System Use area of one directory record for SUSP entries,
 * recording the Rock Ridge PX file serial number wherever it appears, and
 * following CE entries into their continuation areas.
 *
 * A SUSP entry is a 2-byte signature, a length, a version, then payload. The
 * PX entry (RRIP 4.1.1) holds mode, nlink, uid and gid as both-endian pairs,
 * and -- only when it is 44 bytes rather than 36 -- a file serial number at
 * offset 36. That last field is the one worth locating: libisofs fills it
 * from a counter of its own whose order is not stable between runs, so it is
 * the one part of an image that does not reproduce. Nothing reads it on a
 * Dreamcast; see the SOURCE_DATE_EPOCH section of docs/topics/cli-reference.md. */
inline void scan_system_use(const std::vector<uint8_t>& iso, size_t begin, size_t end,
                            std::vector<Range>& px_serials, uint32_t base_lba = 0,
                            int depth = 0) {
    /* CE entries can chain. Real images never nest more than a step or two,
     * and a malformed one must not spin forever. */
    if(depth > 8) return;

    for(size_t at = begin; at + 4 <= end && at + 4 <= iso.size(); ) {
        uint8_t entry_len = iso[at + 2];
        if(entry_len < 4 || at + entry_len > end || at + entry_len > iso.size()) {
            return;
        }

        if(iso[at] == 'P' && iso[at + 1] == 'X' && entry_len >= 44) {
            px_serials.push_back({at + 36, at + 44});
        }

        if(iso[at] == 'C' && iso[at + 1] == 'E' && entry_len >= 28) {
            size_t block = le32(iso.data() + at + 4);
            size_t offset = le32(iso.data() + at + 12);
            size_t length = le32(iso.data() + at + 20);

            size_t ce_begin = offset_of((uint32_t) block, base_lba);
            if(ce_begin != (size_t) -1) {
                ce_begin += offset;
                if(length > 0 && ce_begin + length <= iso.size()) {
                    scan_system_use(iso, ce_begin, ce_begin + length, px_serials,
                                    base_lba, depth + 1);
                }
            }
        }

        at += entry_len;
    }
}

/* Walks every directory record of the volume -- "." and ".." included, since
 * they carry System Use areas of their own -- collecting the PX file serial
 * ranges. */
inline void collect_px_serials(const std::vector<uint8_t>& iso, uint32_t lba, uint32_t len,
                               std::vector<Range>& out, uint32_t base_lba = 0, int depth = 0) {
    if(depth > 16) return;

    size_t extent = offset_of(lba, base_lba);
    if(extent == (size_t) -1) return;

    for(uint32_t offset = 0; offset < len; ) {
        size_t at = extent + offset;
        if(at + 33 > iso.size()) return;

        uint8_t record_len = iso[at];
        if(record_len == 0) {
            offset = ((offset / SECTOR) + 1) * SECTOR;
            continue;
        }

        if(at + record_len > iso.size()) return;

        uint8_t name_len = iso[at + 32];

        /* The name is followed by a pad byte when its length is even, so that
         * the System Use area starts on an even offset. */
        size_t system_use = 33 + name_len + ((name_len % 2 == 0) ? 1 : 0);
        if(system_use < record_len) {
            scan_system_use(iso, at + system_use, at + record_len, out, base_lba);
        }

        bool is_self_or_parent = (name_len == 1 && (iso[at + 33] == 0 || iso[at + 33] == 1));
        bool is_dir = (iso[at + 25] & 0x02) != 0;

        if(is_dir && !is_self_or_parent) {
            collect_px_serials(iso, le32(iso.data() + at + 2), le32(iso.data() + at + 10),
                               out, base_lba, depth + 1);
        }

        offset += record_len;
    }
}

/* Every PX file serial field in the volume, root directory record included. */
inline std::vector<Range> px_serial_ranges(const std::vector<uint8_t>& iso,
                                           uint32_t base_lba = 0) {
    std::vector<Range> ranges;

    Pvd pvd = read_pvd(iso);
    if(!pvd.valid) return ranges;

    /* The root's own record lives inside the PVD, and carries the SP and CE
     * entries that introduce Rock Ridge for the whole volume. */
    size_t root_record = 16 * SECTOR + 156;
    if(root_record + iso[root_record] <= iso.size()) {
        uint8_t record_len = iso[root_record];
        uint8_t name_len = iso[root_record + 32];
        size_t system_use = 33 + name_len + ((name_len % 2 == 0) ? 1 : 0);

        if(system_use < record_len) {
            scan_system_use(iso, root_record + system_use, root_record + record_len,
                            ranges, base_lba);
        }
    }

    collect_px_serials(iso, pvd.root_lba, pvd.root_len, ranges, base_lba);
    return ranges;
}

/* Zeroes the one field of an image that does not reproduce: the Rock Ridge PX
 * file serial number. libisofs hands those out from a counter of its own, in
 * the order a sort by the source files' (filesystem, device, inode) puts the
 * nodes in -- and mkdcdisc stages every file into a fresh temporary directory,
 * so the operating system picks those inode numbers anew on each run. Two
 * builds of the same disc therefore agree on which serial numbers exist and
 * disagree on which file got which, wherever the platform hands out inode
 * numbers that are not in creation order. Windows/MSYS2 is one such platform;
 * a volume with subdirectories differs on any of them.
 *
 * Returns how many were masked. A change in that count is not a permutation:
 * it means libisofs started or stopped writing the field, which is worth
 * noticing.
 *
 * Masked here rather than turned off in mkdcdisc: dropping the field would
 * mean asking libisofs for RRIP 1.10, and after finding that KallistiOS reads
 * Rock Ridge at runtime to resolve filenames, changing what a disc carries to
 * make a test simpler is the wrong way round. Nothing on a Dreamcast reads
 * this particular field, so masking it costs the tests nothing. */
inline size_t mask_px_serials(std::vector<uint8_t>& iso, uint32_t base_lba = 0) {
    std::vector<Range> ranges = px_serial_ranges(iso, base_lba);

    for(const auto& range: ranges) {
        for(size_t at = range.begin; at < range.end && at < iso.size(); ++at) {
            iso[at] = 0;
        }
    }

    return ranges.size();
}

/* The whole tree, depth first, in the order the directory records appear --
 * which is the order libisofs wrote them, and so is itself worth pinning. */
inline std::vector<Entry> list_tree(const std::vector<uint8_t>& iso, uint32_t base_lba = 0) {
    std::vector<Entry> entries;

    Pvd pvd = read_pvd(iso);
    if(!pvd.valid) return entries;

    read_directory(iso, pvd.root_lba, pvd.root_len, "", entries, base_lba);
    return entries;
}

inline std::optional<Entry> find(const std::vector<uint8_t>& iso, const std::string& path,
                                 uint32_t base_lba = 0) {
    for(const auto& entry: list_tree(iso, base_lba)) {
        if(entry.path == path) return entry;
    }
    return std::nullopt;
}

/* The bytes a file's directory record points at -- what a console reading the
 * disc would get. Empty when the entry is missing or runs past the image. */
inline std::string file_bytes(const std::vector<uint8_t>& iso, const std::string& path,
                              uint32_t base_lba = 0) {
    auto entry = find(iso, path, base_lba);
    if(!entry || entry->is_dir) return {};

    size_t at = offset_of(entry->lba, base_lba);
    if(at == (size_t) -1 || at + entry->size > iso.size()) return {};

    return std::string((const char*) iso.data() + at, entry->size);
}

} // namespace iso_read
