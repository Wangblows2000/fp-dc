/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Structural checks on real .nrg files produced by cd_write_to_nrg().
 *
 * Like the CDI/MDS writers, cd_load_from_nrg() is an unimplemented stub, so
 * there's no round-trip to lean on. Instead this parses the trailer by hand
 * against the DAO/v2 chunk layout documented at the top of nrg.c:
 *
 *   raw track data (pregap included) -> (CUEX, DAOX) per session, in order
 *   -> SINF per session, grouped together -> MTYP -> END!
 *   -> 12-byte "NER5" footer
 *
 * CUEX holds a leading session-header entry, an index0/index1 pair per
 * track, and a single session-trailer entry (not a duplicated pair). Every
 * entry -- header, per-track, and trailer alike -- carries the bare session
 * mode byte; none of them set an extra flag bit.
 *
 * The LBAs/offsets found are checked against the same public accessors
 * (cd_track_start_lba(), cd_track_pregap_sectors(), ...) that nrg.c itself
 * is built on, so the test fails if the writer and the shared layout math
 * ever disagree.
 */

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#include "../common/test_helpers.h"

#define RAW_SECTOR_SIZE 2352

static uint32_t read_u32be(const uint8_t* p) {
    return ((uint32_t) p[0] << 24) | ((uint32_t) p[1] << 16) | ((uint32_t) p[2] << 8) | (uint32_t) p[3];
}

static uint64_t read_u64be(const uint8_t* p) {
    return ((uint64_t) read_u32be(p) << 32) | (uint64_t) read_u32be(p + 4);
}

static void read_bytes(FILE* f, long offset, void* buf, size_t len) {
    fseek(f, offset, SEEK_SET);
    CHECK(fread(buf, 1, len, f) == len);
}

/* Reads a chunk header (ID + big-endian payload size) at `offset` and
 * returns the offset of the *next* chunk. */
static long read_chunk_header(FILE* f, long offset, char id_out[5], uint32_t* size_out) {
    uint8_t header[8];
    read_bytes(f, offset, header, sizeof(header));
    memcpy(id_out, header, 4);
    id_out[4] = '\0';
    *size_out = read_u32be(header + 4);
    return offset + 8 + (long) *size_out;
}

int main(void) {
    cd_image_t* img = build_test_image(5000);

    temp_file_t nrg = open_temp_file();
    CHECK(nrg.file != NULL);
    CHECK(cd_write_to_nrg(img, nrg.file) == true);

    fseek(nrg.file, 0, SEEK_END);
    long file_size = ftell(nrg.file);
    CHECK(file_size > 12);

    /* --- Footer: "NER5" + 8-byte big-endian offset to the first chunk --- */
    uint8_t footer[12];
    read_bytes(nrg.file, file_size - 12, footer, sizeof(footer));
    CHECK(memcmp(footer, "NER5", 4) == 0);

    uint64_t trailer_offset = read_u64be(footer + 4);
    CHECK(trailer_offset > 0);
    CHECK(trailer_offset < (uint64_t) file_size);

    /* --- Trailer offset must equal the end of the raw track data area:
     * pregap + data + postgap for every track, back to back --- */
    long expected_data_size = 0;
    for(size_t s = 0; s < cd_image_session_count(img); ++s) {
        cd_session_t* session = cd_image_get_session(img, s);
        for(size_t t = 0; t < cd_session_track_count(session); ++t) {
            cd_track_t* track = cd_session_get_track(session, t);
            expected_data_size += (long) (cd_track_pregap_sectors(track) +
                cd_track_data_size_in_sectors(track) +
                cd_track_postgap_sectors(track)) * RAW_SECTOR_SIZE;
        }
    }
    CHECK((long) trailer_offset == expected_data_size);

    /* --- Walk (CUEX, DAOX) per session, then SINF per session, then END! --- */
    long offset = (long) trailer_offset;
    uint16_t next_track_number = 1;

    for(size_t s = 0; s < cd_image_session_count(img); ++s) {
        cd_session_t* session = cd_image_get_session(img, s);
        size_t n_tracks = cd_session_track_count(session);

        char id[5];
        uint32_t size;

        /* CUEX */
        long cuex_payload = offset + 8;
        offset = read_chunk_header(nrg.file, offset, id, &size);
        CHECK(memcmp(id, "CUEX", 4) == 0);
        CHECK(size == (uint32_t) ((n_tracks + 1) * 2 * 8));

        cd_track_t* first_track = cd_session_get_track(session, 0);
        uint8_t session_type = (cd_track_type(first_track) == TRACK_TYPE_AUDIO) ? 0x01 : 0x41;

        /* Session-header entry: session mode, track/index/reserved all 0,
         * LBA = first track's pregap start */
        {
            uint8_t hdr[8];
            read_bytes(nrg.file, cuex_payload, hdr, sizeof(hdr));

            int32_t first_start_lba = (int32_t) cd_track_start_lba(first_track);
            int32_t session_start_lba = first_start_lba - (int32_t) cd_track_pregap_sectors(first_track);

            CHECK(hdr[0] == session_type);
            CHECK(hdr[1] == 0);
            CHECK(hdr[2] == 0);
            CHECK(hdr[3] == 0);
            CHECK((int32_t) read_u32be(hdr + 4) == session_start_lba);
        }

        for(size_t t = 0; t < n_tracks; ++t) {
            cd_track_t* track = cd_session_get_track(session, t);

            uint8_t idx0[8], idx1[8];
            read_bytes(nrg.file, cuex_payload + 8 + (long) (t * 16), idx0, sizeof(idx0));
            read_bytes(nrg.file, cuex_payload + 8 + (long) (t * 16) + 8, idx1, sizeof(idx1));

            uint8_t expected_type = (cd_track_type(track) == TRACK_TYPE_AUDIO) ? 0x01 : 0x41;
            int32_t start_lba = (int32_t) cd_track_start_lba(track);
            int32_t pregap_lba = start_lba - (int32_t) cd_track_pregap_sectors(track);

            CHECK(idx0[0] == expected_type);
            CHECK(idx0[1] == (uint8_t) (next_track_number + t));
            CHECK(idx0[2] == 0);
            CHECK((int32_t) read_u32be(idx0 + 4) == pregap_lba);

            CHECK(idx1[0] == expected_type);
            CHECK(idx1[1] == (uint8_t) (next_track_number + t));
            CHECK(idx1[2] == 1);
            CHECK((int32_t) read_u32be(idx1 + 4) == start_lba);
        }

        /* Session-trailer entry: a single {session_mode, 0xAA, 0x01, 0x00,
         * end_lba} entry, not a duplicated index0/1 pair */
        uint8_t trailer[8];
        read_bytes(nrg.file, cuex_payload + 8 + (long) (n_tracks * 16), trailer, sizeof(trailer));
        CHECK(trailer[0] == session_type);
        CHECK(trailer[1] == 0xAA);
        CHECK(trailer[2] == 0x01);
        CHECK(trailer[3] == 0);

        /* DAOX */
        long daox_payload = offset + 8;
        offset = read_chunk_header(nrg.file, offset, id, &size);
        CHECK(memcmp(id, "DAOX", 4) == 0);
        CHECK(size == (uint32_t) (22 + n_tracks * 42));

        uint8_t common[22];
        read_bytes(nrg.file, daox_payload, common, sizeof(common));
        uint16_t expected_toc_type = (cd_track_type(first_track) == TRACK_TYPE_AUDIO) ? 0x0000 : 0x2001;
        CHECK(common[18] == (uint8_t) (expected_toc_type >> 8));
        CHECK(common[19] == (uint8_t) (expected_toc_type & 0xFF));
        CHECK(common[20] == (uint8_t) next_track_number);
        CHECK(common[21] == (uint8_t) (next_track_number + n_tracks - 1));

        for(size_t t = 0; t < n_tracks; ++t) {
            cd_track_t* track = cd_session_get_track(session, t);

            uint8_t rec[42];
            read_bytes(nrg.file, daox_payload + 22 + (long) (t * 42), rec, sizeof(rec));

            uint32_t sector_size = read_u32be(rec + 10);
            uint32_t mode = read_u32be(rec + 14);
            uint64_t index0 = read_u64be(rec + 18);
            uint64_t index1 = read_u64be(rec + 26);
            uint64_t end_of_track = read_u64be(rec + 34);

            uint32_t expected_mode = (cd_track_type(track) == TRACK_TYPE_AUDIO) ? 0x07000001 : 0x06000001;

            CHECK(sector_size == RAW_SECTOR_SIZE);
            CHECK(mode == expected_mode);
            CHECK(index0 <= index1);
            CHECK(index1 < end_of_track);
            CHECK(index1 - index0 == (uint64_t) cd_track_pregap_sectors(track) * RAW_SECTOR_SIZE);
            CHECK(end_of_track - index1 == (uint64_t) (cd_track_data_size_in_sectors(track) +
                cd_track_postgap_sectors(track)) * RAW_SECTOR_SIZE);
        }

        next_track_number = (uint16_t) (next_track_number + n_tracks);
    }

    /* --- SINF, one per session, grouped together after all CUEX/DAOX pairs --- */
    for(size_t s = 0; s < cd_image_session_count(img); ++s) {
        cd_session_t* session = cd_image_get_session(img, s);
        size_t n_tracks = cd_session_track_count(session);

        char id[5];
        uint32_t size;

        long sinf_payload = offset + 8;
        offset = read_chunk_header(nrg.file, offset, id, &size);
        CHECK(memcmp(id, "SINF", 4) == 0);
        CHECK(size == 4);

        uint8_t sinf_val[4];
        read_bytes(nrg.file, sinf_payload, sinf_val, sizeof(sinf_val));
        CHECK(read_u32be(sinf_val) == (uint32_t) n_tracks);
    }

    /* --- MTYP: one per image, value 1 --- */
    char id[5];
    uint32_t size;
    long mtyp_payload = offset + 8;
    offset = read_chunk_header(nrg.file, offset, id, &size);
    CHECK(memcmp(id, "MTYP", 4) == 0);
    CHECK(size == 4);

    uint8_t mtyp_val[4];
    read_bytes(nrg.file, mtyp_payload, mtyp_val, sizeof(mtyp_val));
    CHECK(read_u32be(mtyp_val) == 1);

    /* --- END! terminator, immediately followed by the footer --- */
    offset = read_chunk_header(nrg.file, offset, id, &size);
    CHECK(memcmp(id, "END!", 4) == 0);
    CHECK(size == 0);
    CHECK(offset == file_size - 12);

    close_temp_file(&nrg);
    cd_free_image(&img);

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
