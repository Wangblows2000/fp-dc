/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Unit tests for the core cd_image_t/cd_session_t/cd_track_t bookkeeping in
 * disc_image.c: sector-size rounding, pregap/postgap defaults, LBA
 * addressing, and session length (which includes lead-in/lead-out). These
 * don't touch cd_write_to_cdi/cd_write_to_mds at all. */

#include <stdint.h>
#include <stddef.h>

#include "../common/test_helpers.h"

int main(void) {
    cd_image_t* img = cd_new_image();
    CHECK(cd_image_session_count(img) == 0);
    CHECK(cd_image_track_count(img) == 0);

    cd_session_t* s0 = cd_new_session(img);
    CHECK(cd_image_session_count(img) == 1);

    /* A Mode 2 Form 1 sector holds 2048 bytes of user data */
    uint8_t data[2048 * 3 + 100];
    for(size_t i = 0; i < sizeof(data); ++i) {
        data[i] = (uint8_t) i;
    }

    cd_track_t* t0 = cd_new_track(s0, TRACK_TYPE_DATA, data, sizeof(data));
    cd_track_set_mode(t0, TRACK_MODE_XA_MODE2_FORM1);
    cd_track_set_pregap_sectors(t0, 0);
    cd_track_set_postgap_sectors(t0, 0);

    CHECK(cd_image_track_count(img) == 1);
    CHECK(cd_track_data_size_in_sectors(t0) == 4); /* 3 full + 1 partial, rounds up */
    CHECK(cd_track_data_size_in_bytes(t0) == sizeof(data));
    CHECK(cd_track_start_lba(t0) == 0);

    /* A track that's an exact multiple of the sector size needs no
     * rounded-up trailing sector */
    cd_track_t* t1 = cd_new_track(s0, TRACK_TYPE_DATA, data, 2048 * 2);
    cd_track_set_mode(t1, TRACK_MODE_XA_MODE2_FORM1);
    cd_track_set_pregap_sectors(t1, 0);
    cd_track_set_postgap_sectors(t1, 0);
    CHECK(cd_track_data_size_in_sectors(t1) == 2);
    CHECK(cd_track_start_lba(t1) == 4); /* right after t0's 4 sectors */

    /* Newly created tracks default to a 150-sector pregap and no postgap;
     * audio tracks default to CDDA mode */
    cd_track_t* t2 = cd_new_track(s0, TRACK_TYPE_AUDIO, data, 2352 * 2);
    CHECK(cd_track_pregap_sectors(t2) == 150);
    CHECK(cd_track_postgap_sectors(t2) == 0);
    CHECK(cd_track_mode(t2) == TRACK_MODE_CDDA);
    CHECK(cd_track_data_size_in_sectors(t2) == 2);
    CHECK(cd_track_start_lba(t2) == 4 + 2); /* after t0 + t1's data (their own pregap/postgap were zeroed above) */

    /* Session length = lead-in + lead-out + sum(pregap + data + postgap) */
    size_t expected_session_len = 4500 + 6750 + (4 + 0) + (2 + 0) + (150 + 2);
    CHECK(cd_session_length_in_sectors(s0) == expected_session_len);
    CHECK(cd_session_data_length_in_sectors(s0) == (4 + 0) + (2 + 0) + (150 + 2));

    /* A second session uses the shorter, non-first lead-out */
    cd_session_t* s1 = cd_new_session(img);
    cd_track_t* t3 = cd_new_track(s1, TRACK_TYPE_DATA, data, 2048);
    cd_track_set_mode(t3, TRACK_MODE_XA_MODE2_FORM1);
    cd_track_set_pregap_sectors(t3, 0);
    cd_track_set_postgap_sectors(t3, 0);

    CHECK(cd_session_length_in_sectors(s1) == 4500 + 2250 + 1);
    CHECK(cd_image_session_count(img) == 2);
    CHECK(cd_image_track_count(img) == 4);

    /* Session/track lookup by index */
    CHECK(cd_image_get_session(img, 0) == s0);
    CHECK(cd_image_get_session(img, 1) == s1);
    CHECK(cd_session_get_track(s0, 0) == t0);
    CHECK(cd_session_get_track(s0, 2) == t2);
    CHECK(cd_session_track_count(s0) == 3);

    cd_free_image(&img);
    CHECK(img == NULL);

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
