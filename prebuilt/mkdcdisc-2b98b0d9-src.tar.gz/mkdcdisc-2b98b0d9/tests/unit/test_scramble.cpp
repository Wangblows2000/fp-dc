/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Round-trip regression for scramble()/unscramble(). unscramble() is new: it
 * lets -B/--main-binary-scrambled be honored for -F gdi (which needs an
 * unscrambled 1ST_READ.BIN) by unscrambling the input in gather_files()
 * instead of rejecting the -B/-F gdi combination outright.
 *
 * Exercises sizes on both sides of several chunk-size halvings (2MB down to
 * the 32-byte slice minimum) and the sub-slice remainder below that, since
 * the chunking loop in scramble.cpp treats those differently. */

#include <cstdint>
#include <vector>

#include "../common/test_helpers.h"
#include "third_party/scramble/scramble.h"

/* A cheap multiplicative hash: distinct-enough content per byte that no
 * 32-byte slice duplicates another, so that where reordering happens at all
 * it is visible (checked below, only for sizes confirmed to reorder). */
static std::vector<char> pattern(size_t n) {
    std::vector<char> v(n);
    for(size_t i = 0; i < n; ++i) {
        v[i] = (char) (uint8_t) ((i * 2654435761u) >> 24);
    }
    return v;
}

int main() {
    /* A chunk of exactly 1 or 2 slices (32 or 64 bytes) always comes out
     * identical to its input: reorder_slices()'s (rand()*i)>>16 index is
     * mathematically forced to 0 whenever i is 0 or 1 (rand() never reaches
     * 65536), so those chunk sizes permute nothing regardless of content or
     * seed. Real movement only starts at 4 slices (128 bytes) -- confirmed
     * empirically alongside the sizes below. That is a property of this
     * specific algorithm, not a bug: it does not weaken the round-trip
     * checks, which hold for an identity permutation just as well. */
    static const size_t sizes[] = {
        0, 1, 16, 31, 32, 33, 64, 100, 127, 128, 129, 4096, 4096 + 17, 3u * 1024 * 1024 + 5,
    };

    for(size_t n: sizes) {
        std::vector<char> original = pattern(n);

        std::vector<char> to_scramble = original;
        std::vector<char> scrambled = scramble(to_scramble);
        CHECK(scrambled.size() == n);

        std::vector<char> unscrambled = unscramble(scrambled);
        CHECK(unscrambled == original);

        /* unscramble() runs the same slice permutation in reverse, so it must
         * be invertible by scramble() too, independently of the pair above. */
        std::vector<char> to_unscramble = original;
        std::vector<char> unscrambled_first = unscramble(to_unscramble);
        std::vector<char> rescrambled = scramble(unscrambled_first);
        CHECK(rescrambled == original);

        if(n >= 128) {
            CHECK(scrambled != original);
        }
    }

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
