/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Pins makeip::calc_crc(), the checksum written into the Device Info field of
 * every IP.BIN mkdcdisc generates.
 *
 * The point of pinning it is that nothing else would notice if it changed: the
 * four hex digits it produces are plausible whatever they are, no test reads
 * them back, and a disc carrying a wrong Device Info checksum is not obviously
 * broken until real hardware refuses it. So the expected values below were
 * produced by makeip's own crc.c, compiled and run against the same inputs,
 * rather than by this implementation.
 *
 * The first two vectors also identify *which* CRC-16 this is, which mkdcdisc
 * got wrong in a comment for a while (see src/third_party/makeip/README.md). */

#include <cstdint>
#include <cstring>
#include <string>

#include "../common/test_helpers.h"
#include "third_party/makeip/crc.hpp"

static uint16_t crc_of(const std::string& s) {
    return makeip::calc_crc((const uint8_t*) s.data(), s.size());
}

int main() {
    /* The CRC catalogue's check value -- the CRC of "123456789" -- is what
     * names a variant. 0x29B1 is CRC-16/IBM-3740 (CCITT-FALSE): polynomial
     * 0x1021 started from 0xFFFF. CRC-16/XMODEM is the same polynomial started
     * from 0x0000 and answers 0x31C3, so this check is what stops the two from
     * being confused again. */
    CHECK(crc_of("123456789") == 0x29B1);

    /* Empty input returns the initial value untouched, which is the other half
     * of the same statement: the register starts at 0xFFFF, not at 0. */
    CHECK(crc_of("") == 0xFFFF);

    CHECK(crc_of("A") == 0xB915);

    /* The real case: the 16 bytes update_ipbin_crc() hands over, being the
     * 10-byte product number followed by the 6-byte product version, both
     * space-padded. The last one is the shape mkdcdisc generates for itself
     * when -s/--serial is not given ("IND-" plus six digits). */
    CHECK(crc_of("T-00000   V1.000") == 0x2BF2);
    CHECK(crc_of("MK-51000  V1.000") == 0x6B32);
    CHECK(crc_of("IND-123456V1.000") == 0x8BFD);

    /* One byte apart, and in the version rather than the product number, so a
     * checksum that quietly stopped covering the whole 16-byte span -- or
     * stopped depending on its input at all -- shows up here. */
    CHECK(crc_of("T-00000   V1.001") == 0x3BD3);
    CHECK(crc_of("T-00000   V1.000") != crc_of("T-00000   V1.001"));

    /* Length is not implied by the string: the field is a fixed 16 bytes, and
     * the padding is part of what is summed. */
    CHECK(crc_of("T-00000   V1.000") != crc_of("T-00000V1.000"));

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
