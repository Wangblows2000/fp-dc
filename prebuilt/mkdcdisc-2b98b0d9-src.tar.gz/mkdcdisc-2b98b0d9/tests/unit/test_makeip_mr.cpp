/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Pins makeip::png_to_mr(), the PNG-to-MR conversion behind
 * -i/--bootstrap-mr-image.
 *
 * Two things are checked, and they fail differently. The crafted image below
 * pins the *format*: every field of the MR header, the palette's byte order,
 * and each of the four branches of the run-length encoder, which are otherwise
 * only reached by images of particular shapes and would not be missed. The
 * fixture at the end pins the *result*: the bundled default logo, converted,
 * has to come out byte-identical to the .mr committed beside it.
 *
 * A wrong MR is not a crash. It is a bootstrap that draws garbage on the
 * license screen of a disc that otherwise builds, boots and passes every other
 * test here, which is why this exists.
 *
 * Usage: test_makeip_mr <default-mr.png> <default-mr.mr>
 */

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include <png.h>

#include "../common/test_helpers.h"
#include "third_party/makeip/mr.hpp"

/* Writes an 8-bit RGB PNG, the plainest input libpng can be handed: what is
 * under test is the conversion, not libpng's own format handling.
 *
 * The row-pointer array is malloc'd rather than a std::vector for the same
 * reason mr.cpp does it: libpng reports an error by longjmp()ing back to the
 * setjmp() below, and a live object with a destructor would never have it
 * run. */
static bool write_rgb_png(const std::string& path, uint32_t width, uint32_t height,
                          const std::vector<uint8_t>& rgb) {
    FILE* fp = std::fopen(path.c_str(), "wb");
    if(!fp) {
        return false;
    }

    png_structp png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if(!png_ptr) {
        std::fclose(fp);
        return false;
    }

    png_infop info_ptr = png_create_info_struct(png_ptr);
    if(!info_ptr) {
        png_destroy_write_struct(&png_ptr, NULL);
        std::fclose(fp);
        return false;
    }

    png_bytep* row_pointers = NULL;

    if(setjmp(png_jmpbuf(png_ptr))) {
        png_destroy_write_struct(&png_ptr, &info_ptr);
        std::fclose(fp);
        std::free(row_pointers);
        return false;
    }

    png_init_io(png_ptr, fp);
    png_set_IHDR(png_ptr, info_ptr, width, height, 8, PNG_COLOR_TYPE_RGB,
        PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
    png_write_info(png_ptr, info_ptr);

    row_pointers = (png_bytep*) std::malloc(sizeof(png_bytep) * height);
    for(uint32_t row = 0; row < height; ++row) {
        row_pointers[row] = (png_bytep) (rgb.data() + (size_t) row * width * 3);
    }

    png_write_image(png_ptr, row_pointers);
    png_write_end(png_ptr, info_ptr);

    png_destroy_write_struct(&png_ptr, &info_ptr);
    std::fclose(fp);
    std::free(row_pointers);

    return true;
}

static std::vector<uint8_t> read_file(const std::string& path) {
    std::vector<uint8_t> data;

    FILE* f = std::fopen(path.c_str(), "rb");
    if(!f) {
        return data;
    }

    uint8_t buf[4096];
    size_t n;
    while((n = std::fread(buf, 1, sizeof(buf), f)) > 0) {
        data.insert(data.end(), buf, buf + n);
    }

    std::fclose(f);
    return data;
}

/* MR stores its header fields in the host's byte order, which for every
 * platform mkdcdisc builds for, and for the Dreamcast reading them, is little
 * endian. Read back explicitly so the test states that rather than inheriting
 * it. */
static uint32_t le32(const std::vector<uint8_t>& v, size_t offset) {
    if(offset + 4 > v.size()) {
        return 0xFFFFFFFFu;
    }
    return (uint32_t) v[offset] | ((uint32_t) v[offset + 1] << 8)
        | ((uint32_t) v[offset + 2] << 16) | ((uint32_t) v[offset + 3] << 24);
}

/* A path in the temp directory that nothing else is using. open_temp_file()
 * creates the file too, which is not wanted here -- libpng opens it itself --
 * so it is closed straight away and only the name kept. close_temp_file() on a
 * closed handle just removes it, which is exactly the cleanup needed. */
static temp_file_t reserve_temp_path() {
    temp_file_t tf = open_temp_file();
    if(tf.file) {
        std::fclose(tf.file);
        tf.file = NULL;
    }
    return tf;
}

/* Colors distinct in all three channels, so a conversion that compared only
 * some of them, or compared them in the wrong order, would still collapse two
 * of these into one palette entry and be caught. */
static void color_at(int index, uint8_t& r, uint8_t& g, uint8_t& b) {
    r = (uint8_t) (0x10 + index * 0x11);
    g = (uint8_t) (0x20 + index * 0x11);
    b = (uint8_t) (0x30 + index * 0x11);
}

/* One image, one horizontal line, holding a run of every length that the
 * encoder treats differently:
 *
 *     1     a lone pixel, emitted literally
 *     127   the longest 2-byte run (0x80|run)
 *     128   the shortest 3-byte run (0x81, run)
 *     255   the longest of those
 *     256   the shortest of the other 3-byte form (0x82, 0x80|(run-0x100))
 *     383   the longest run the encoder will build at all
 *     384   one past it, so the run has to be split
 *
 * Being consecutive runs of distinct colors, they also fix the palette: seven
 * entries, in the order the pixels are first seen. */
static void check_run_length_encoding() {
    static const int RUNS[] = {1, 127, 128, 255, 256, 383, 384};
    static const int COLOR_COUNT = 7;

    std::vector<uint8_t> rgb;
    uint32_t width = 0;

    for(int i = 0; i < COLOR_COUNT; ++i) {
        uint8_t r, g, b;
        color_at(i, r, g, b);

        for(int p = 0; p < RUNS[i]; ++p) {
            rgb.push_back(r);
            rgb.push_back(g);
            rgb.push_back(b);
            ++width;
        }
    }

    CHECK(width == 1534);

    temp_file_t png = reserve_temp_path();
    CHECK(write_rgb_png(png.path, width, 1, rgb));

    std::vector<uint8_t> mr;
    CHECK(makeip::png_to_mr(png.path, mr) == makeip::MrStatus::Ok);
    close_temp_file(&png);

    /* Header: "MR", then seven 4-byte fields, then the palette, then the
     * pixels. Two of the seven are reserved and have to stay zero. */
    const uint32_t expected_offset = 2 + 7 * 4 + COLOR_COUNT * 4;  /* 58 */
    const uint32_t expected_size = expected_offset + 19;           /* 77 */

    CHECK(mr.size() == expected_size);
    CHECK(mr.size() >= 2 && mr[0] == 'M' && mr[1] == 'R');
    CHECK(le32(mr, 2) == expected_size);
    CHECK(le32(mr, 6) == 0);
    CHECK(le32(mr, 10) == expected_offset);
    CHECK(le32(mr, 14) == width);
    CHECK(le32(mr, 18) == 1);
    CHECK(le32(mr, 22) == 0);
    CHECK(le32(mr, 26) == (uint32_t) COLOR_COUNT);

    /* Palette entries are BGR followed by a pad byte -- not RGB, which is what
     * the image was written in. */
    for(int i = 0; i < COLOR_COUNT; ++i) {
        uint8_t r, g, b;
        color_at(i, r, g, b);

        size_t at = 30 + (size_t) i * 4;
        CHECK(at + 4 <= mr.size());
        if(at + 4 > mr.size()) {
            continue;
        }

        CHECK(mr[at + 0] == b);
        CHECK(mr[at + 1] == g);
        CHECK(mr[at + 2] == r);
        CHECK(mr[at + 3] == 0);
    }

    static const uint8_t EXPECTED_PIXELS[] = {
        0x00,              /* 1 x index 0: below the run threshold, so literal */
        0xFF, 0x01,        /* 127 x index 1: 0x80|127 */
        0x81, 0x80, 0x02,  /* 128 x index 2: run no longer fits in the low 7 bits */
        0x81, 0xFF, 0x03,  /* 255 x index 3 */
        0x82, 0x80, 0x04,  /* 256 x index 4: 0x80|(256-0x100) */
        0x82, 0xFF, 0x05,  /* 383 x index 5: the longest single run */
        0x82, 0xFF, 0x06,  /* 384 x index 6 splits: 383 of them here... */
        0x06,              /* ...and the one left over, literal */
    };

    CHECK(sizeof(EXPECTED_PIXELS) == 19);
    CHECK(mr.size() >= expected_offset + sizeof(EXPECTED_PIXELS));

    for(size_t i = 0; i < sizeof(EXPECTED_PIXELS); ++i) {
        size_t at = expected_offset + i;
        if(at >= mr.size()) {
            break;
        }
        CHECK(mr[at] == EXPECTED_PIXELS[i]);
    }
}

/* One pixel per color, so `count` distinct colors exactly. */
static makeip::MrStatus convert_image_of_n_colors(int count, uint32_t& colors_written) {
    std::vector<uint8_t> rgb;
    for(int i = 0; i < count; ++i) {
        rgb.push_back((uint8_t) i);
        rgb.push_back(0);
        rgb.push_back(0);
    }

    temp_file_t png = reserve_temp_path();
    if(!write_rgb_png(png.path, (uint32_t) count, 1, rgb)) {
        close_temp_file(&png);
        return makeip::MrStatus::ReadFailed;
    }

    /* Pre-filled so that a failure returning without writing anything can be
     * told apart from one that half-wrote a result. */
    std::vector<uint8_t> mr(3, 0xAB);
    makeip::MrStatus status = makeip::png_to_mr(png.path, mr);
    close_temp_file(&png);

    colors_written = (status == makeip::MrStatus::Ok) ? le32(mr, 26) : 0;

    if(status != makeip::MrStatus::Ok) {
        CHECK(mr.size() == 3 && mr[0] == 0xAB && mr[1] == 0xAB && mr[2] == 0xAB);
    }

    return status;
}

int main(int argc, char** argv) {
    if(argc != 3) {
        fprintf(stderr, "usage: test_makeip_mr <default-mr.png> <default-mr.mr>\n");
        return 2;
    }

    check_run_length_encoding();

    /* An MR palette holds 128 entries and there is no wider format to fall
     * back on, so 128 has to work and 129 has to be refused rather than
     * silently writing past the palette. */
    uint32_t colors = 0;
    CHECK(convert_image_of_n_colors(makeip::MR_MAX_PALETTE_COLORS, colors) == makeip::MrStatus::Ok);
    CHECK(colors == (uint32_t) makeip::MR_MAX_PALETTE_COLORS);

    CHECK(convert_image_of_n_colors(makeip::MR_MAX_PALETTE_COLORS + 1, colors)
        == makeip::MrStatus::TooManyColors);

    /* A missing file is reported, not asserted on: -i names a path the user
     * typed. */
    std::vector<uint8_t> unused(3, 0xAB);
    CHECK(makeip::png_to_mr("no-such-file-here.png", unused) == makeip::MrStatus::ReadFailed);
    CHECK(unused.size() == 3 && unused[0] == 0xAB);

    /* The bundled logo, which is shipped in both forms: assets/iplogo has the
     * PNG it is drawn as and the MR that src/assets/iplogo.default.include is
     * generated from. Converting the first has to reproduce the second exactly
     * -- this is the one check that would notice the encoder changing in a way
     * the crafted image above does not reach. */
    std::vector<uint8_t> converted;
    CHECK(makeip::png_to_mr(argv[1], converted) == makeip::MrStatus::Ok);

    std::vector<uint8_t> committed = read_file(argv[2]);
    CHECK(!committed.empty());
    CHECK(converted.size() == committed.size());
    CHECK(converted == committed);

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
