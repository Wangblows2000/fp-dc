/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Pins the output of the vendored EDC/ECC encoder (src/third_party/libedc),
 * so that updating it to a newer upstream release cannot silently change what
 * gets written to a disc.
 *
 * This exists because the obvious check does not work: comparing whole images
 * built before and after a change proves nothing, since libisofs stamps the
 * ISO9660 volume descriptors with the wall clock and two runs a second apart
 * already differ. Exercising the encoder on its own removes that noise.
 *
 * Mirrors the writers' calling convention exactly -- a 2352-byte buffer, the
 * 8-byte XA subheader at offset 16, 2048 bytes of user data at offset 24, and
 * do_encode_L2() handed the whole buffer including the sync field. See
 * cd_write_to_cdi() in src/disc_image/formats/cdi.c.
 *
 * If a libedc update trips the checksum below, do not just re-pin it: find out
 * which field changed (sync, header, subheader, user data, EDC, or the P/Q
 * parity) and why, because every disc mkdcdisc has ever written carries the
 * old answer. */

#include <string.h>

#include "../common/test_helpers.h"
#include "third_party/libedc/libedc.h"

/* The subheader the writers use for a Form 1 data sector, duplicated as the
 * format requires -- the same bytes cd_write_to_cdi(), cd_write_to_mds() and
 * cd_write_to_nrg() each declare. It is covered by the EDC, so it is part of
 * what the digest below pins. */
static const unsigned char SUBHEADER[8] = {
    0x00, 0x00, 0x09, 0x00,
    0x00, 0x00, 0x09, 0x00
};

/* Addresses covering 0, the minute/second/frame carries in the sector header,
 * and the 150-sector pregap offsets the writers deal in. */
static const unsigned int ADDRESSES[] = {
    0, 1, 74, 75, 149, 150, 4499, 4500, 65535, 123456
};

#define PATTERN_COUNT 3

/* FNV-1a, 64-bit. Not for security -- just a stable digest that needs no
 * dependency and is reproduced identically by any C compiler. */
static uint64_t fnv1a(uint64_t hash, const unsigned char* data, size_t len) {
    for(size_t i = 0; i < len; ++i) {
        hash ^= data[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

static void fill_user_data(unsigned char* sector, int pattern) {
    for(int i = 0; i < 2048; ++i) {
        switch(pattern) {
        case 0:
            sector[24 + i] = 0x00;
            break;
        case 1:
            sector[24 + i] = 0xFF;
            break;
        default:
            /* Distinct-looking value per byte, so a misplaced field shows up. */
            sector[24 + i] = (unsigned char) ((i * 2654435761u) >> 24);
            break;
        }
    }
}

int main(void) {
    uint64_t hash = 14695981039346656037ULL; /* FNV-1a offset basis */

    for(size_t a = 0; a < sizeof(ADDRESSES) / sizeof(ADDRESSES[0]); ++a) {
        for(int pattern = 0; pattern < PATTERN_COUNT; ++pattern) {
            unsigned char sector[2352];

            memset(sector, 0, sizeof(sector));
            memcpy(sector + 16, SUBHEADER, sizeof(SUBHEADER));
            fill_user_data(sector, pattern);

            do_encode_L2(sector, MODE_2_FORM_1, ADDRESSES[a]);

            /* The 12-byte sync field is a constant the encoder writes in, and
             * the header at 12..15 encodes the address -- both are part of what
             * is being pinned, so the whole sector goes into the digest. */
            hash = fnv1a(hash, sector, sizeof(sector));
        }
    }

    /* Established against libedc 1.22 (the revision mkdcdisc carried from
     * img4dc since 2022) and confirmed unchanged by upstream 1.31. */
    const uint64_t EXPECTED = 0x38f7641ce2be677aULL;
    CHECK(hash == EXPECTED);
    if(hash != EXPECTED) {
        fprintf(stderr, "  encoder digest is 0x%016llx, expected 0x%016llx\n",
            (unsigned long long) hash, (unsigned long long) EXPECTED);
    }

    /* A sanity check that the digest covers something real: an encoded sector
     * must start with the Mode 2 sync pattern. */
    {
        unsigned char sector[2352];
        static const unsigned char SYNC[12] = {
            0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00
        };
        memset(sector, 0, sizeof(sector));
        memcpy(sector + 16, SUBHEADER, sizeof(SUBHEADER));
        fill_user_data(sector, 2);
        do_encode_L2(sector, MODE_2_FORM_1, 150);
        CHECK(memcmp(sector, SYNC, sizeof(SYNC)) == 0);
    }

    return g_test_failures ? 1 : 0;
}
