/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Regressions for elf_parser, the flattening step that replaced
 * `sh-elf-objcopy -O binary` and decides what ends up in 1ST_READ.BIN.
 *
 * Two things are pinned here, both of which produced a wrong boot binary
 * rather than a visible failure:
 *
 *   - the image is sized from p_filesz, never p_memsz. Sizing from p_memsz
 *     materialises the whole of .bss as zeros; on a real KallistiOS build
 *     that was 4.4MB of padding on a 522KB binary.
 *   - a `LOAD` segment carrying no file data at all -- which some toolchains,
 *     LTO builds especially, emit for .bss -- is dropped outright and not
 *     merely skipped when copying. Its p_paddr sits past the last real byte,
 *     so leaving it in the list stretched the image out to it in zeros.
 *
 * No payload in tests/ has that second shape, which is why it is built here
 * by hand: the ELFs that exposed it are 9.6MB apiece. The reference for all
 * of it is objcopy, which emits sections and so cannot reach past the last
 * section with contents.
 *
 * The rest covers Parser::Load()'s bounds checks. Every offset it indexes
 * with is read out of the file being parsed, and mkdcdisc is handed ELFs from
 * anywhere; before those checks existed a corrupt e_phoff, e_phnum or
 * e_phentsize each segfaulted outright. */

#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <vector>

#include "../common/test_helpers.h"
#include "progress.hpp"
#include "third_party/elf_parser/elf_parser.hpp"

/* The parser is the one module under third_party/ that streams its
 * diagnostics through the project rather than in its own voice (see its
 * README), so logging.cpp and terminal.cpp come along. These three are all
 * logging.cpp then reaches for, and pulling in the CLI and the progress
 * machinery to supply them would drag most of mkdcdisc into a test of one
 * file. There is no progress line here, so break_line() is never reached. */
int verbosity() { return 0; }
ProgressLine* active_progress_line() { return nullptr; }
void ProgressLine::break_line() {}

static const uint32_t RAM_START = 0x8c010000;

/* Header field sizes are fixed by the ELF32 spec, so they are written by
 * offset rather than through the bundled structs: a test that shares its
 * layout assumptions with the code under test cannot catch a mistake in
 * them. */
static const size_t EHDR_SIZE = 52;
static const size_t PHDR_SIZE = 32;

static void put16(std::vector<char>& v, size_t at, uint16_t x) {
    v[at + 0] = (char) (uint8_t) (x & 0xff);
    v[at + 1] = (char) (uint8_t) (x >> 8);
}

static void put32(std::vector<char>& v, size_t at, uint32_t x) {
    for(int i = 0; i < 4; ++i) {
        v[at + i] = (char) (uint8_t) ((x >> (8 * i)) & 0xff);
    }
}

struct SegSpec {
    uint32_t type;   /* 1 = PT_LOAD */
    uint32_t paddr;
    uint32_t filesz; /* bytes actually placed in the file */
    uint32_t memsz;  /* >= filesz; the excess is .bss */
    char fill;       /* byte this segment's file data is filled with */
};

/* A minimal well-formed SuperH ELF32 carrying exactly these segments. No
 * section headers: nothing reads them any more, and e_shoff/e_shnum being
 * zero is what an ELF stripped of them looks like. */
static std::vector<char> build_elf(const std::vector<SegSpec>& segs) {
    size_t data_at = EHDR_SIZE + PHDR_SIZE * segs.size();
    size_t total = data_at;
    for(const SegSpec& s: segs) {
        total += s.filesz;
    }

    std::vector<char> elf(total, 0);

    elf[0] = 0x7f;
    elf[1] = 'E';
    elf[2] = 'L';
    elf[3] = 'F';
    elf[4] = 1;                        /* EI_CLASS = ELFCLASS32 */
    elf[5] = 1;                        /* EI_DATA  = little-endian */
    elf[6] = 1;                        /* EI_VERSION */
    put16(elf, 16, 2);                 /* e_type    = ET_EXEC */
    put16(elf, 18, 42);                /* e_machine = EM_SH */
    put32(elf, 20, 1);                 /* e_version */
    put32(elf, 24, RAM_START);         /* e_entry */
    put32(elf, 28, (uint32_t) EHDR_SIZE);  /* e_phoff */
    put32(elf, 32, 0);                 /* e_shoff */
    put32(elf, 36, 0);                 /* e_flags */
    put16(elf, 40, (uint16_t) EHDR_SIZE);  /* e_ehsize */
    put16(elf, 42, (uint16_t) PHDR_SIZE);  /* e_phentsize */
    put16(elf, 44, (uint16_t) segs.size()); /* e_phnum */
    put16(elf, 46, (uint16_t) 40);     /* e_shentsize */
    put16(elf, 48, 0);                 /* e_shnum */
    put16(elf, 50, 0);                 /* e_shstrndx */

    size_t off = data_at;
    for(size_t i = 0; i < segs.size(); ++i) {
        const SegSpec& s = segs[i];
        size_t p = EHDR_SIZE + PHDR_SIZE * i;

        put32(elf, p + 0, s.type);
        put32(elf, p + 4, (uint32_t) off);  /* p_offset */
        put32(elf, p + 8, s.paddr);         /* p_vaddr */
        put32(elf, p + 12, s.paddr);        /* p_paddr */
        put32(elf, p + 16, s.filesz);
        put32(elf, p + 20, s.memsz);
        put32(elf, p + 24, 0x5);            /* p_flags = R+X */
        put32(elf, p + 28, 4);              /* p_align */

        for(uint32_t k = 0; k < s.filesz; ++k) {
            elf[off + k] = s.fill;
        }
        off += s.filesz;
    }

    return elf;
}

static bool loads(const std::vector<char>& elf) {
    return elfparser::Parser::Load(elf).has_value();
}

/* Runs the whole conversion. Returns false if either half refused, which is
 * what load_elf_file() in src/input_files.cpp does with them. */
static bool flatten(const std::vector<char>& elf, std::vector<char>& bin) {
    auto parser = elfparser::Parser::Load(elf);
    if(!parser.has_value()) {
        return false;
    }
    return parser.value()->fill_bin(bin);
}

/* Every byte of the segment landed, at the address it asked for. */
static bool holds(const std::vector<char>& bin, uint32_t paddr, uint32_t len, char fill) {
    size_t at = paddr - RAM_START;
    if(at + len > bin.size()) {
        return false;
    }
    for(uint32_t i = 0; i < len; ++i) {
        if(bin[at + i] != fill) {
            return false;
        }
    }
    return true;
}

int main() {
    /* The regression. A `LOAD` segment with p_filesz 0 sits at an address
     * past the end of the real data -- that is where the linker put .bss --
     * so counting it when sizing the image appends the gap as zeros. Here
     * that gap is 0x100 bytes; on the ELF that exposed it, 244. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({
            {1, RAM_START, 0x100, 0x100, 'a'},
            {1, RAM_START + 0x200, 0, 0x100000, 0},
        }), bin));
        CHECK(bin.size() == 0x100);
        CHECK(holds(bin, RAM_START, 0x100, 'a'));
    }

    /* The same segment placed *before* the data rather than after must not
     * pull the start of the image down to it either: the binary has to begin
     * at RAM_START, and a zero-length segment holds nothing to begin with. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({
            {1, RAM_START, 0x100, 0x100, 'a'},
            {1, RAM_START - 0x80, 0, 0x80, 0},
        }), bin));
        CHECK(bin.size() == 0x100);
    }

    /* p_memsz covers what the segment occupies in RAM, .bss included; the
     * image stops where the file data does. KOS zeroes .bss before main()
     * runs, so the difference is pure padding. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({{1, RAM_START, 0x100, 0x40000, 'a'}}), bin));
        CHECK(bin.size() == 0x100);
    }

    /* Both bounds are taken across every kept segment. Sizing from whichever
     * segment starts highest truncates an image whose lowest-addressed
     * segment is also its longest -- the segments overlap in that case, which
     * is exactly why only the extent matters here. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({
            {1, RAM_START + 0x1000, 0x10, 0x10, 'b'},
            {1, RAM_START, 0x2000, 0x2000, 'a'},
        }), bin));
        CHECK(bin.size() == 0x2000);
    }

    /* dcload and libronin ELFs carry a .stack segment below RAM start. It is
     * dropped, and it does not become the start of the image. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({
            {1, 0x8c000000, 0x40, 0x40, 's'},
            {1, RAM_START, 0x100, 0x100, 'a'},
        }), bin));
        CHECK(bin.size() == 0x100);
        CHECK(holds(bin, RAM_START, 0x100, 'a'));
    }

    /* Only PT_LOAD is loaded into memory; PT_NOTE (4) and PT_PHDR (6) are
     * not, whatever address they claim. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({
            {1, RAM_START, 0x100, 0x100, 'a'},
            {4, RAM_START + 0x8000, 0x20, 0x20, 'n'},
            {6, RAM_START + 0x9000, 0x20, 0x20, 'p'},
        }), bin));
        CHECK(bin.size() == 0x100);
    }

    /* Two separated segments: the hole between them is zero-filled and each
     * one's contents land at its own address. */
    {
        std::vector<char> bin;
        CHECK(flatten(build_elf({
            {1, RAM_START, 0x100, 0x100, 'a'},
            {1, RAM_START + 0x400, 0x80, 0x80, 'b'},
        }), bin));
        CHECK(bin.size() == 0x480);
        CHECK(holds(bin, RAM_START, 0x100, 'a'));
        CHECK(holds(bin, RAM_START + 0x100, 0x300, 0));
        CHECK(holds(bin, RAM_START + 0x400, 0x80, 'b'));
    }

    /* fill_bin() refuses rather than producing an empty or negatively-sized
     * image: nothing loadable at all, nothing loadable holding data, and a
     * binary that does not begin where the console expects. */
    {
        std::vector<char> bin;
        CHECK(!flatten(build_elf({{4, RAM_START, 0x100, 0x100, 'a'}}), bin));
    }
    {
        std::vector<char> bin;
        CHECK(!flatten(build_elf({
            {1, RAM_START, 0, 0x1000, 0},
            {1, RAM_START + 0x2000, 0, 0x1000, 0},
        }), bin));
    }
    {
        std::vector<char> bin;
        CHECK(!flatten(build_elf({{1, RAM_START + 0x10000, 0x100, 0x100, 'a'}}), bin));
    }

    /* A well-formed ELF still loads, so the checks below fail for the reason
     * each one names and not because the builder produces something the
     * parser rejects outright. */
    std::vector<char> good = build_elf({{1, RAM_START, 0x100, 0x100, 'a'}});
    CHECK(loads(good));

    /* Shorter than an Elf32_Ehdr. Every offset the parser reads lives in that
     * header, so there is nothing to read them from. */
    CHECK(!loads(std::vector<char>()));
    CHECK(!loads(std::vector<char>(4, 0x7f)));
    CHECK(!loads(std::vector<char>(EHDR_SIZE - 1, 0)));

    /* Not an ELF at all. This was four assert()s, which compile out under
     * NDEBUG and left a release build dereferencing the header regardless. */
    {
        std::vector<char> bad = good;
        bad[1] = 'X';
        CHECK(!loads(bad));
    }

    /* Wrong architecture, and wrong class. */
    {
        std::vector<char> bad = good;
        put16(bad, 18, 62); /* EM_X86_64 */
        CHECK(!loads(bad));
    }
    {
        std::vector<char> bad = good;
        bad[4] = 2; /* ELFCLASS64 */
        CHECK(!loads(bad));
    }

    /* An entry smaller than the Elf32_Phdr read out of it: walking the table
     * with that stride reads past its end. */
    {
        std::vector<char> bad = good;
        put16(bad, 42, 8);
        CHECK(!loads(bad));
    }

    /* A program header table that does not fit -- reached by moving it, and
     * by claiming more entries than are there. Both segfaulted before. */
    {
        std::vector<char> bad = good;
        put32(bad, 28, 0x7ffffff0);
        CHECK(!loads(bad));
    }
    {
        std::vector<char> bad = good;
        put16(bad, 44, 4096);
        CHECK(!loads(bad));
    }

    /* A segment whose contents run past the end of the file, both by offset
     * and by length. This is what a truncated ELF looks like. */
    {
        std::vector<char> bad = good;
        put32(bad, EHDR_SIZE + 4, (uint32_t) bad.size() + 1);
        CHECK(!loads(bad));
    }
    {
        std::vector<char> bad = good;
        put32(bad, EHDR_SIZE + 16, 0x10000);
        CHECK(!loads(bad));
    }
    {
        std::vector<char> truncated = good;
        truncated.resize(good.size() - 1);
        CHECK(!loads(truncated));
    }

    /* p_offset + p_filesz must not be allowed to wrap past the end either. */
    {
        std::vector<char> bad = good;
        put32(bad, EHDR_SIZE + 4, 0xfffffff0);
        put32(bad, EHDR_SIZE + 16, 0x20);
        CHECK(!loads(bad));
    }

    if(g_test_failures == 0) {
        printf("test_elf_parser: all checks passed\n");
    }
    return g_test_failures != 0;
}
