/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Tests for src/iso_reader.cpp: recovering the MSINFO a volume was built for,
 * and reading its root directory.
 *
 * The volumes here are built by hand rather than by mkdcdisc, which is the
 * point: the reader is what the boot prerequisite checks trust to describe a
 * filesystem nobody in this project wrote, so it has to be right about
 * ECMA-119 rather than merely agree with libisofs. A hand-built volume is also
 * the only way to reach the cases that matter and that libisofs never emits --
 * a truncated record, a root directory that is nowhere to be found.
 *
 * What libisofs actually writes is checked end to end in tests/e2e instead. */

#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include "iso_reader.hpp"

static int g_failures = 0;

#define CHECK(cond) do { \
    if(!(cond)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << ": " << #cond << std::endl; \
        g_failures++; \
    } \
} while(0)

static const size_t SECTOR = iso9660::SECTOR;

/* Where the hand-built volumes below put their root directory extent, which is
 * also where libisofs puts it in a real mkdcdisc image. */
static const uint32_t ROOT_SECTOR = 18;

static void put_le32(uint8_t* at, uint32_t value) {
    at[0] = (uint8_t) (value & 0xFF);
    at[1] = (uint8_t) ((value >> 8) & 0xFF);
    at[2] = (uint8_t) ((value >> 16) & 0xFF);
    at[3] = (uint8_t) ((value >> 24) & 0xFF);
}

/* ECMA-119 records its numbers twice, little-endian then big-endian. Only the
 * little-endian half is ever read back, but writing just that half would leave
 * the fixture describing something no writer produces. */
static void put_both_endian_32(uint8_t* at, uint32_t value) {
    put_le32(at, value);
    at[4] = (uint8_t) ((value >> 24) & 0xFF);
    at[5] = (uint8_t) ((value >> 16) & 0xFF);
    at[6] = (uint8_t) ((value >> 8) & 0xFF);
    at[7] = (uint8_t) (value & 0xFF);
}

static void put_both_endian_16(uint8_t* at, uint16_t value) {
    at[0] = (uint8_t) (value & 0xFF);
    at[1] = (uint8_t) ((value >> 8) & 0xFF);
    at[2] = (uint8_t) ((value >> 8) & 0xFF);
    at[3] = (uint8_t) (value & 0xFF);
}

/* One directory record, written at `at` and returning how many bytes it took.
 * `name` empty means the "." record, which ECMA-119 spells as the single byte
 * 0x00; "\x01" is likewise how ".." is spelled. */
static size_t write_record(std::vector<uint8_t>& iso, size_t at, const std::string& name,
                           uint32_t lba, uint32_t size, bool is_dir) {
    std::string identifier = name.empty() ? std::string(1, '\0') : name;

    size_t length = 33 + identifier.size();
    if(length % 2 != 0) {
        length += 1;  /* records are padded to an even length */
    }

    iso[at] = (uint8_t) length;
    iso[at + 1] = 0;
    put_both_endian_32(&iso[at + 2], lba);
    put_both_endian_32(&iso[at + 10], size);
    iso[at + 25] = is_dir ? 0x02 : 0x00;
    put_both_endian_16(&iso[at + 28], 1);
    iso[at + 32] = (uint8_t) identifier.size();
    std::memcpy(&iso[at + 33], identifier.data(), identifier.size());

    return length;
}

struct FileEntry {
    std::string name;
    uint32_t size;
    bool is_dir;
};

/* A volume built for MSINFO `msinfo`: every address it records is that much
 * higher than where the thing addressed actually sits in the buffer, which is
 * exactly what `mkisofs -C 0,N` and libisofs's ms_block produce.
 *
 * `root_length` lets a caller ask for a root directory spanning more than one
 * sector, so that the padding between the last record of one sector and the
 * first of the next gets walked. */
static std::vector<uint8_t> make_volume(uint32_t msinfo, const std::vector<FileEntry>& files,
                                        uint32_t root_length = (uint32_t) SECTOR,
                                        bool split_across_sectors = false) {
    uint32_t root_sectors = (root_length + (uint32_t) SECTOR - 1) / (uint32_t) SECTOR;
    size_t total_sectors = ROOT_SECTOR + root_sectors + 8;

    std::vector<uint8_t> iso(total_sectors * SECTOR, 0);

    /* The system area, which ECMA-119 reserves and a Dreamcast disc fills with
     * its boot header. Its content is nothing to do with the reader, so
     * something recognizable will do. */
    std::memcpy(&iso[0], "SEGA SEGAKATANA ", 16);

    uint8_t* pvd = &iso[iso9660::SYSTEM_AREA_SECTORS * SECTOR];
    pvd[0] = 1;
    std::memcpy(pvd + 1, "CD001", 5);
    pvd[6] = 1;
    std::memset(pvd + 40, ' ', 32);
    std::memcpy(pvd + 40, "TESTVOL", 7);
    put_both_endian_32(pvd + 80, (uint32_t) total_sectors);

    /* The root directory record, which lives inside the PVD rather than in any
     * directory. */
    write_record(iso, iso9660::SYSTEM_AREA_SECTORS * SECTOR + 156, "",
                 msinfo + ROOT_SECTOR, root_length, true);

    /* The volume descriptor set terminator. */
    uint8_t* terminator = &iso[(iso9660::SYSTEM_AREA_SECTORS + 1) * SECTOR];
    terminator[0] = 255;
    std::memcpy(terminator + 1, "CD001", 5);

    size_t extent = ROOT_SECTOR * SECTOR;
    size_t at = extent;

    at += write_record(iso, at, "", msinfo + ROOT_SECTOR, root_length, true);
    at += write_record(iso, at, std::string(1, '\x01'), msinfo + ROOT_SECTOR, root_length, true);

    uint32_t file_lba = msinfo + ROOT_SECTOR + root_sectors;

    for(size_t i = 0; i < files.size(); ++i) {
        /* Force the remaining entries into the next sector of the extent, so
         * the zero-length record that ends a sector's worth of records has to
         * be stepped over. */
        if(split_across_sectors && i == 1) {
            at = extent + SECTOR;
        }

        at += write_record(iso, at, files[i].name + (files[i].is_dir ? "" : ";1"),
                           file_lba, files[i].size, files[i].is_dir);
        file_lba += 1;
    }

    return iso;
}

static void test_reads_the_volume_descriptor() {
    std::vector<uint8_t> iso = make_volume(0, {{"1ST_READ.BIN", 4096, false}});

    iso9660::Volume volume = iso9660::read_volume(iso);

    CHECK(volume.valid);
    CHECK(volume.volume_id == "TESTVOL");
    CHECK(volume.root_lba == ROOT_SECTOR);
    CHECK(volume.root_length == SECTOR);
}

/* The three MSINFO values a Dreamcast disc is actually built for: a Data/Data
 * first session and a standalone .iso are 0, an Audio/Data data track is
 * wherever the audio session ended (11702 with the default filler), and a
 * GD-ROM's high-density volume is 45000. */
static void test_detects_msinfo() {
    struct { uint32_t msinfo; const char* what; } cases[] = {
        {0,     "a standalone ISO or a Data/Data first session"},
        {11702, "an Audio/Data data track with the default audio filler"},
        {45000, "a GD-ROM high-density volume"},
    };

    for(const auto& c: cases) {
        std::vector<uint8_t> iso = make_volume(c.msinfo, {{"1ST_READ.BIN", 4096, false}});

        auto detected = iso9660::detect_msinfo(iso);

        CHECK(detected.has_value());
        if(detected) {
            if(*detected != c.msinfo) {
                std::cerr << "  (" << c.what << ": expected " << c.msinfo
                          << ", detected " << *detected << ")" << std::endl;
            }
            CHECK(*detected == c.msinfo);
        }
    }
}

static void test_locates_the_root_directory() {
    std::vector<uint8_t> iso = make_volume(11702, {{"1ST_READ.BIN", 4096, false}});

    iso9660::RootDirectory root = iso9660::locate_root_directory(iso);

    CHECK(root.found);
    CHECK(root.declared_lba == 11702 + ROOT_SECTOR);
    CHECK(root.sector == ROOT_SECTOR);
    CHECK(root.length == SECTOR);
}

static void test_reads_root_entries() {
    std::vector<uint8_t> iso = make_volume(0, {
        {"1ST_READ.BIN", 4096, false},
        {"DATA", 2048, true},
        {"README.TXT", 12, false},
    });

    std::vector<iso9660::Entry> entries = iso9660::read_root_directory(iso);

    CHECK(entries.size() == 3);
    if(entries.size() != 3) {
        return;
    }

    /* "." and ".." are not entries anybody asked after, and the ";1" version
     * suffix is not part of what anyone calls the file. */
    CHECK(entries[0].name == "1ST_READ.BIN");
    CHECK(entries[0].size == 4096);
    CHECK(!entries[0].is_dir);

    CHECK(entries[1].name == "DATA");
    CHECK(entries[1].is_dir);

    CHECK(entries[2].name == "README.TXT");
    CHECK(!entries[2].is_dir);
}

/* A root directory of more than one sector ends each sector with padding
 * rather than letting a record straddle the boundary. Walking that padding as
 * if it were a record would end the listing at the first sector. */
static void test_reads_entries_across_a_sector_boundary() {
    std::vector<uint8_t> iso = make_volume(0, {
        {"1ST_READ.BIN", 4096, false},
        {"SECOND.BIN", 128, false},
    }, 2 * (uint32_t) SECTOR, /* split_across_sectors */ true);

    std::vector<iso9660::Entry> entries = iso9660::read_root_directory(iso);

    CHECK(entries.size() == 2);
    if(entries.size() == 2) {
        CHECK(entries[0].name == "1ST_READ.BIN");
        CHECK(entries[1].name == "SECOND.BIN");
    }
}

/* Nothing here may read past the end of the buffer it was handed, however
 * little of a volume that buffer holds. */
static void test_rejects_what_is_not_a_volume() {
    CHECK(!iso9660::read_volume({}).valid);
    CHECK(!iso9660::detect_msinfo({}).has_value());
    CHECK(iso9660::read_root_directory({}).empty());

    /* Long enough to hold a PVD, but holding anything but one. */
    std::vector<uint8_t> junk(20 * SECTOR, 0xAA);
    CHECK(!iso9660::read_volume(junk).valid);
    CHECK(!iso9660::detect_msinfo(junk).has_value());

    /* A real volume cut off before its root directory extent: the PVD still
     * reads, but the extent it names is not there to be found, and a detected
     * MSINFO would be a guess. */
    std::vector<uint8_t> truncated = make_volume(0, {{"1ST_READ.BIN", 4096, false}});
    truncated.resize(ROOT_SECTOR * SECTOR);

    CHECK(iso9660::read_volume(truncated).valid);
    CHECK(!iso9660::detect_msinfo(truncated).has_value());
    CHECK(iso9660::read_root_directory(truncated).empty());
}

/* A PVD naming a root directory that no sector of the volume claims to be.
 * There is no answer here, and inventing one -- the nearest match, say -- would
 * put a made-up MSINFO into a diagnostic the user is meant to act on. */
static void test_refuses_to_guess_a_missing_root_directory() {
    std::vector<uint8_t> iso = make_volume(0, {{"1ST_READ.BIN", 4096, false}});

    /* Move the recorded address without moving the extent. */
    put_le32(&iso[iso9660::SYSTEM_AREA_SECTORS * SECTOR + 156 + 2], ROOT_SECTOR + 3);

    CHECK(!iso9660::detect_msinfo(iso).has_value());
    CHECK(!iso9660::locate_root_directory(iso).found);
}

int main() {
    test_reads_the_volume_descriptor();
    test_detects_msinfo();
    test_locates_the_root_directory();
    test_reads_root_entries();
    test_reads_entries_across_a_sector_boundary();
    test_rejects_what_is_not_a_volume();
    test_refuses_to_guess_a_missing_root_directory();

    if(g_failures > 0) {
        std::cerr << g_failures << " check(s) failed" << std::endl;
        return 1;
    }

    std::cout << "All iso_reader tests passed" << std::endl;
    return 0;
}
