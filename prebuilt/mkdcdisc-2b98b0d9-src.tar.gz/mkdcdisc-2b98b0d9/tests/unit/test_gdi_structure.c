/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Structural checks on real .gdi/track??.* files produced by cd_write_to_gdi().
 *
 * Like the CDI/MDS/NRG writers, cd_load_from_gdi() is an unimplemented stub,
 * so there's no round-trip to lean on. Instead this parses the .gdi text
 * format by hand and checks it against the fixed 3-track shape
 * build_test_gdi_image() (mirroring build_gd() in build_gd.cpp) produces:
 * track 1 (Mode 1, LBA 0), track 2 (CDDA, LBA 450), track 3 (Mode 1, LBA
 * CD_GD_START_LBA).
 *
 * Both data-track sector formats are exercised: raw 2352-byte Mode 1
 * (track??.bin, the default) and plain 2048-byte user data (track??.iso).
 * For the raw case the sector framing itself is checked too, since a wrong
 * sync pattern or header address produces a file of exactly the right size
 * that no real hardware or emulator will read.
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#ifdef _WIN32
#include <direct.h>
#define MKTESTDIR(path) _mkdir(path)
#define RMTESTDIR(path) _rmdir(path)
#else
#include <sys/stat.h>
#define MKTESTDIR(path) mkdir(path, 0755)
#define RMTESTDIR(path) rmdir(path)
#endif

#include "../common/test_helpers.h"

static long file_size(const char* path) {
    FILE* f = fopen(path, "rb");
    if(!f) {
        return -1;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fclose(f);
    return size;
}

/* Reads len bytes from path at offset into out. Returns false if the file is
 * missing or too short. */
static bool read_at(const char* path, long offset, uint8_t* out, size_t len) {
    FILE* f = fopen(path, "rb");
    if(!f) {
        return false;
    }

    bool ok = fseek(f, offset, SEEK_SET) == 0 && fread(out, 1, len, f) == len;
    fclose(f);
    return ok;
}

/* Builds "<dir>/<name>", failing the test rather than quietly proceeding on
 * a truncated path -- the same check gdi.c's own join_track_path() makes. */
static void join_test_path(char* out, size_t out_size, const char* dir, const char* name) {
    int n = snprintf(out, out_size, "%s/%s", dir, name);
    CHECK(n > 0 && (size_t) n < out_size);
}

/* Reads one '\r\n'-terminated line into out (stripping the terminator).
 * Returns false at EOF. */
static bool read_line(FILE* f, char* out, size_t out_size) {
    if(!fgets(out, (int) out_size, f)) {
        return false;
    }
    size_t len = strlen(out);
    while(len > 0 && (out[len - 1] == '\n' || out[len - 1] == '\r')) {
        out[--len] = '\0';
    }
    return true;
}

/* A raw Mode 1 sector opens with the 12-byte sync pattern, then a 3-byte BCD
 * MSF address and the mode byte. Checks that framing at `offset` in path
 * against the address the sector at absolute `lba` has to carry. */
static void check_mode1_sector(const char* path, long offset, uint32_t lba, const char* label) {
    static const uint8_t SYNC[12] = {
        0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00
    };

    uint8_t head[16];
    if(!read_at(path, offset, head, sizeof(head))) {
        fprintf(stderr, "FAIL %s: cannot read sector header\n", label);
        g_test_failures++;
        return;
    }

    if(memcmp(head, SYNC, sizeof(SYNC)) != 0) {
        fprintf(stderr, "FAIL %s: bad sync pattern\n", label);
        g_test_failures++;
    }

    /* MSF counts from the lead-in, so the address stored is the FAD
     * (LBA + 150), each field in BCD. */
    uint32_t fad = lba + 150;
    uint32_t m = fad / (60 * 75);
    uint32_t s = (fad / 75) % 60;
    uint32_t f = fad % 75;

    uint8_t want[4] = {
        (uint8_t) (((m / 10) << 4) | (m % 10)),
        (uint8_t) (((s / 10) << 4) | (s % 10)),
        (uint8_t) (((f / 10) << 4) | (f % 10)),
        0x01 /* Mode 1 */
    };

    if(memcmp(head + 12, want, sizeof(want)) != 0) {
        fprintf(stderr, "FAIL %s: header is %02X %02X %02X %02X, want %02X %02X %02X %02X\n",
            label, head[12], head[13], head[14], head[15],
            want[0], want[1], want[2], want[3]);
        g_test_failures++;
    }
}

/* Writes the fixed 3-track image at the given data-track sector size, then
 * checks the .gdi text, the track filenames and the track file sizes.
 * data_ext is the extension the data tracks are expected to carry. */
static void check_gdi_image(uint32_t data_sector_size, const char* data_ext) {
    char dir[512];
    const char* tmp = getenv("TMPDIR");
    if(!tmp) tmp = getenv("TEMP");
    if(!tmp) tmp = getenv("TMP");
    if(!tmp) tmp = ".";

    int dir_len = snprintf(dir, sizeof(dir), "%s/mkdcdisc-test-gdi-%u-%d",
        tmp, (unsigned) data_sector_size, (int) TEST_GETPID());
    CHECK(dir_len > 0 && (size_t) dir_len < sizeof(dir));
    MKTESTDIR(dir);

    char gdi_path[1024];
    join_test_path(gdi_path, sizeof(gdi_path), dir, "test.gdi");

    /* Deliberately not a multiple of 2048, to exercise track03's padding. */
    cd_image_t* img = build_test_gdi_image(50000);

    FILE* gdi_file = fopen(gdi_path, "wb");
    CHECK(gdi_file != NULL);
    CHECK(cd_write_to_gdi(img, gdi_file, dir, data_sector_size) == true);
    fclose(gdi_file);

    FILE* check = fopen(gdi_path, "rb");
    CHECK(check != NULL);

    char line[256];
    char want[256];

    CHECK(read_line(check, line, sizeof(line)));
    CHECK(strcmp(line, "3") == 0);

    CHECK(read_line(check, line, sizeof(line)));
    snprintf(want, sizeof(want), "1 0 4 %u track01.%s 0", (unsigned) data_sector_size, data_ext);
    CHECK(strcmp(line, want) == 0);

    /* Audio is 2352-byte PCM whatever the data tracks use. */
    CHECK(read_line(check, line, sizeof(line)));
    CHECK(strcmp(line, "2 450 0 2352 track02.raw 0") == 0);

    CHECK(read_line(check, line, sizeof(line)));
    snprintf(want, sizeof(want), "3 45000 4 %u track03.%s 0", (unsigned) data_sector_size, data_ext);
    CHECK(strcmp(line, want) == 0);

    /* No further lines */
    CHECK(!read_line(check, line, sizeof(line)));

    fclose(check);

    char track01[1024], track02[1024], track03[1024];
    char name[32];

    snprintf(name, sizeof(name), "track01.%s", data_ext);
    join_test_path(track01, sizeof(track01), dir, name);
    join_test_path(track02, sizeof(track02), dir, "track02.raw");
    snprintf(name, sizeof(name), "track03.%s", data_ext);
    join_test_path(track03, sizeof(track03), dir, name);

    CHECK(file_size(track01) == 300L * (long) data_sector_size);
    CHECK(file_size(track02) == 302L * 2352);
    /* 50000 bytes padded up to the next 2048-byte sector boundary */
    CHECK(file_size(track03) == 25L * (long) data_sector_size);

    if(data_sector_size == CD_GDI_SECTOR_SIZE_RAW) {
        /* Track 1 starts at LBA 0, so its first sector carries FAD 150. */
        check_mode1_sector(track01, 0, 0, "track01 sector 0");

        /* The high-density track starts at a fixed LBA far from 0, so a
         * writer encoding track-relative addresses would pass the check
         * above and fail these. */
        check_mode1_sector(track03, 0, CD_GD_START_LBA, "track03 sector 0");
        check_mode1_sector(track03, 2352, CD_GD_START_LBA + 1, "track03 sector 1");
        check_mode1_sector(track03, 24L * 2352, CD_GD_START_LBA + 24, "track03 last sector");
    }

    remove(gdi_path);
    remove(track01);
    remove(track02);
    remove(track03);
    RMTESTDIR(dir);

    cd_free_image(&img);
}

int main(void) {
    check_gdi_image(CD_GDI_SECTOR_SIZE_RAW, "bin");
    check_gdi_image(CD_GDI_SECTOR_SIZE_COOKED, "iso");

    /* Anything other than the two supported sector sizes is refused rather
     * than silently written in some third format. */
    {
        cd_image_t* img = build_test_gdi_image(4096);
        temp_file_t out = open_temp_file();
        CHECK(out.file != NULL);
        CHECK(cd_write_to_gdi(img, out.file, ".", 2336) == false);
        close_temp_file(&out);
        cd_free_image(&img);
    }

    return g_test_failures ? 1 : 0;
}
