/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Regression tests for the validation cd_write_to_cdi()/cd_write_to_mds()/
 * cd_write_to_nrg() perform before writing anything: rejecting empty
 * images, images with an empty session, images exceeding the 99-track Red
 * Book/BCD limit, and track modes none of the writers actually implement
 * (only CDDA and XA Mode 2 Form 1 are ever produced by mkdcdisc). Each of
 * these used to be silently accepted (producing a corrupt image) or crash
 * before being fixed. */

#include <stdint.h>
#include <stddef.h>

#include "../common/test_helpers.h"

static const uint8_t DUMMY[16] = {0};

static void expect_all_writers_reject(cd_image_t* img, const char* label) {
    temp_file_t cdi = open_temp_file();
    temp_file_t mds = open_temp_file();
    temp_file_t mdf = open_temp_file();
    temp_file_t nrg = open_temp_file();

    CHECK(cdi.file && mds.file && mdf.file && nrg.file);

    CHECK(cd_write_to_cdi(img, cdi.file, label) == false);
    CHECK(cd_write_to_mds(img, mds.file, mdf.file) == false);
    CHECK(cd_write_to_nrg(img, nrg.file) == false);

    close_temp_file(&cdi);
    close_temp_file(&mds);
    close_temp_file(&mdf);
    close_temp_file(&nrg);
}

int main(void) {
    /* An image with no sessions at all */
    {
        cd_image_t* img = cd_new_image();
        expect_all_writers_reject(img, "no-sessions");
        cd_free_image(&img);
    }

    /* A session with no tracks */
    {
        cd_image_t* img = cd_new_image();
        cd_new_session(img);
        expect_all_writers_reject(img, "empty-session");
        cd_free_image(&img);
    }

    /* More than 99 tracks (BCD track numbers only go up to 99) */
    {
        cd_image_t* img = cd_new_image();
        cd_session_t* s = cd_new_session(img);
        for(int i = 0; i < 100; ++i) {
            cd_track_t* t = cd_new_track(s, TRACK_TYPE_DATA, DUMMY, sizeof(DUMMY));
            cd_track_set_mode(t, TRACK_MODE_XA_MODE2_FORM1);
            cd_track_set_pregap_sectors(t, 0);
        }
        CHECK(cd_image_track_count(img) == 100);
        expect_all_writers_reject(img, "too-many-tracks");
        cd_free_image(&img);
    }

    /* Track modes the writers don't implement must be rejected outright
     * rather than silently emitting a corrupt/truncated image */
    {
        static const track_mode_t unsupported[] = {
            TRACK_MODE_MODE1, TRACK_MODE_MODE2, TRACK_MODE_XA_MODE2_FORM2
        };

        for(size_t i = 0; i < sizeof(unsupported) / sizeof(unsupported[0]); ++i) {
            cd_image_t* img = cd_new_image();
            cd_session_t* s = cd_new_session(img);
            cd_track_t* t = cd_new_track(s, TRACK_TYPE_DATA, DUMMY, sizeof(DUMMY));
            cd_track_set_mode(t, unsupported[i]);
            cd_track_set_pregap_sectors(t, 0);

            expect_all_writers_reject(img, "unsupported-mode");
            cd_free_image(&img);
        }
    }

    /* Sanity check: a well-formed minimal image (the shape the previous
     * cases were deliberately deviating from) is in fact accepted */
    {
        cd_image_t* img = cd_new_image();
        cd_session_t* s = cd_new_session(img);
        cd_track_t* t = cd_new_track(s, TRACK_TYPE_DATA, DUMMY, sizeof(DUMMY));
        cd_track_set_mode(t, TRACK_MODE_XA_MODE2_FORM1);
        cd_track_set_pregap_sectors(t, 0);

        temp_file_t cdi = open_temp_file();
        CHECK(cd_write_to_cdi(img, cdi.file, "ok") == true);
        close_temp_file(&cdi);

        temp_file_t mds = open_temp_file();
        temp_file_t mdf = open_temp_file();
        CHECK(cd_write_to_mds(img, mds.file, mdf.file) == true);
        close_temp_file(&mds);
        close_temp_file(&mdf);

        temp_file_t nrg = open_temp_file();
        CHECK(cd_write_to_nrg(img, nrg.file) == true);
        close_temp_file(&nrg);

        cd_free_image(&img);
    }

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
