/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Pins gd_track::plan_track(), which decides how long a GD-ROM's high-density
 * data track is and how much of it the filesystem may fill.
 *
 * Worth pinning here rather than through the CLI because the answers that
 * matter are one sector apart. A padded build fails when the content exceeds
 * 504000 sectors, and driving mkdcdisc to either side of that boundary means
 * feeding it a gigabyte of input twice -- slow, and far too blunt to land on
 * the sector that decides it. The arithmetic depends on nothing but its three
 * arguments, so it can simply be asked.
 *
 * The constants themselves are pinned too. They are not free parameters: 150
 * reserved sectors and an end at LBA 549150 were read off commercial dumps
 * (see gd_track_plan.hpp), so a change to either is a change to what mkdcdisc
 * claims a GD-ROM looks like, and should have to be made deliberately. */

#include "../common/test_helpers.h"
#include "gd_track_plan.hpp"

using namespace gd_track;

int main() {
    /* The physical window, as read off the dumps: the filesystem starts at
     * LBA 45000 and the zone ends at 549150, so a full track is 504150
     * sectors and the filesystem may use all but the closing run-out. */
    CHECK(GD_END_LBA == 549150);
    CHECK(TRACK_END_RESERVED_SECTORS == 150);
    CHECK(FULL_TRACK_SECTORS == 504150);
    CHECK(MAX_CONTENT_SECTORS == 504000);

    /* Read off Sega's rules rather than off a dump, and corroborated by the
     * structure: 97 high-density tracks (3 to 99) less the data track at each
     * end of the audio. The TOC entry array write_gdi_hda_toc() fills is 97
     * long for the same reason, so the two must move together or the TOC
     * silently stops describing the tracks the disc has. */
    CHECK(MAX_GDDA_TRACKS == 95);
    CHECK(MAX_GDDA_TRACKS + 2 == 97);

    /* A padded build always produces the full physical track and always fills
     * it, whatever the content: that is what makes the boot binary land where
     * real hardware looks for it. The content size only decides whether it
     * fits at all. */
    {
        Plan p = plan_track(/* content */ 10, /* spacer */ 0, /* truncate */ false);
        CHECK(p.fits);
        CHECK(p.track_sectors == FULL_TRACK_SECTORS);
        CHECK(p.content_target_sectors == MAX_CONTENT_SECTORS);
    }

    /* The boundary, from both sides. Exactly filling the usable area fits;
     * one sector more does not. */
    {
        Plan p = plan_track(MAX_CONTENT_SECTORS, 0, false);
        CHECK(p.fits);
        CHECK(p.track_sectors == FULL_TRACK_SECTORS);

        CHECK(!plan_track(MAX_CONTENT_SECTORS + 1, 0, false).fits);
    }

    /* The spacer counts against the same budget as the content -- the
     * filesystem spans the GD-DA tracks rather than stopping before them --
     * and so do the two fillers that hold the data tracks either side of it
     * open, so the boundary moves by the spacer plus that reservation. */
    {
        const size_t reserve = split_reserve(1000);
        CHECK(reserve == 2 * MIN_SPLIT_SIDE_SECTORS);

        CHECK(plan_track(MAX_CONTENT_SECTORS - 1000 - reserve, 1000, false).fits);
        CHECK(!plan_track(MAX_CONTENT_SECTORS - 1000 - reserve + 1, 1000, false).fits);

        /* And nothing is reserved when there is no audio to split around. */
        CHECK(split_reserve(0) == 0);
    }

    /* A truncated build is sized to its content, so it fits by construction:
     * the same input that overflows a padded build is accepted here. */
    {
        Plan p = plan_track(MAX_CONTENT_SECTORS + 1, 0, true);
        CHECK(p.fits);
        CHECK(p.track_sectors == MAX_CONTENT_SECTORS + 1 + TRACK_END_RESERVED_SECTORS);
        CHECK(p.content_target_sectors == MAX_CONTENT_SECTORS + 1);
    }

    /* Truncated, the track is the content plus the run-out, and the
     * filesystem gets everything but that run-out -- which is the property
     * the whole layout rests on: no file may reach into the last 150
     * sectors. */
    {
        const size_t reserve = split_reserve(2000);

        Plan p = plan_track(/* content */ 5000, /* spacer */ 2000, true);
        CHECK(p.fits);
        CHECK(p.track_sectors == 5000 + 2000 + reserve + TRACK_END_RESERVED_SECTORS);
        CHECK(p.content_target_sectors == 5000 + 2000 + reserve);
        CHECK(p.track_sectors - p.content_target_sectors == TRACK_END_RESERVED_SECTORS);
    }

    /* The reservation exists so that neither piece of a split zone falls under
     * the minimum track length. Track 3 runs from the start of the zone to 150
     * sectors into the spacer, and the closing track from the end of the spacer
     * to the end of the zone; with a side's worth of filler at each end, both
     * clear MIN_HD_SECTORS however little the disc actually carries.
     *
     * Stated as the arithmetic the layout in build_gd() performs, since that is
     * where a regression would land. */
    {
        const size_t spacer = 2000;
        const size_t side = MIN_SPLIT_SIDE_SECTORS;

        Plan p = plan_track(/* content */ 1, spacer, true);

        /* Worst case: nothing but the fillers, the spacer and the descriptors,
         * of which the arithmetic below assumes none. */
        const size_t track3 = side + TRACK_END_RESERVED_SECTORS;
        const size_t closing = p.track_sectors - side - spacer;

        CHECK(track3 >= MIN_HD_SECTORS);
        CHECK(closing >= MIN_HD_SECTORS);
    }

    /* The Red Book floor, which a tiny disc would otherwise fall through.
     * Below it the track is padded up to MIN_HD_SECTORS and the filesystem
     * gains the slack, still stopping short of the run-out. */
    {
        Plan p = plan_track(/* content */ 1, /* spacer */ 0, true);
        CHECK(p.fits);
        CHECK(p.track_sectors == MIN_HD_SECTORS);
        CHECK(p.content_target_sectors == MIN_HD_SECTORS - TRACK_END_RESERVED_SECTORS);
    }

    /* An empty disc gets the same floor rather than a zero-length track. */
    {
        Plan p = plan_track(0, 0, true);
        CHECK(p.fits);
        CHECK(p.track_sectors == MIN_HD_SECTORS);
    }

    /* Just under and just over the floor, so the clamp is pinned at its own
     * boundary and not merely somewhere below it. */
    {
        const size_t at_floor = MIN_HD_SECTORS - TRACK_END_RESERVED_SECTORS;

        CHECK(plan_track(at_floor, 0, true).track_sectors == MIN_HD_SECTORS);
        CHECK(plan_track(at_floor + 1, 0, true).track_sectors == MIN_HD_SECTORS + 1);
    }

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
