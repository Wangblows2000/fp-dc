/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Structural checks on real .mds/.mdf files produced by cd_write_to_mds().
 *
 * Like the CDI writer, cd_load_from_mds() is an unimplemented stub, so
 * there's no round-trip to lean on. Instead this checks facts about the
 * "MEDIA DESCRIPTOR" v1.4 format that are documented at the top of mds.c
 * and are stable regardless of internal refactoring:
 *
 *   - The MDS starts with the "MEDIA DESCRIPTOR" magic and format version 1.4.
 *   - Its session count field matches the image.
 *   - The MDS ends with the "*.mdf" wildcard filename footer.
 *   - The MDF's total size matches the sum of each track's stored sectors
 *     (data + postgap; pregaps are declared, not stored) at 2352 bytes/sector.
 *
 * It then walks the descriptor the way a reader does, following the offset
 * fields the writer emits, and checks that they are self-consistent and
 * that none of them points past the end of the file. In particular the
 * extra block array holds one 8-byte slot per 80-byte block -- not one per
 * real track -- because readers exist that ignore each track's extra_offset
 * and recompute the slot address from the block index instead.
 */

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "../common/test_helpers.h"

#define MDS_BLOCK_SIZE 80
#define MDS_SESSION_BLOCK_SIZE 24
#define MDS_EXTRA_BLOCK_SIZE 8
#define MDS_FOOTER_SIZE 16

static uint16_t rd_u16(const uint8_t* p) {
    return (uint16_t) ((uint16_t) p[0] | ((uint16_t) p[1] << 8));
}

static uint32_t rd_u32(const uint8_t* p) {
    return (uint32_t) p[0] | ((uint32_t) p[1] << 8) |
           ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
}

static int slot_is_zero(const uint8_t* slot) {
    for(size_t i = 0; i < MDS_EXTRA_BLOCK_SIZE; ++i) {
        if(slot[i]) {
            return 0;
        }
    }
    return 1;
}

int main(void) {
    cd_image_t* img = build_test_image(5000);

    temp_file_t mds = open_temp_file();
    temp_file_t mdf = open_temp_file();
    CHECK(mds.file && mdf.file);
    CHECK(cd_write_to_mds(img, mds.file, mdf.file) == true);

    /* --- MDS header --- */
    fseek(mds.file, 0, SEEK_SET);
    uint8_t header[24] = {0};
    CHECK(fread(header, 1, sizeof(header), mds.file) == sizeof(header));
    CHECK(memcmp(header, "MEDIA DESCRIPTOR", 16) == 0);
    CHECK(header[0x10] == 1 && header[0x11] == 4); /* format version 1.4 */

    uint16_t session_count_le = rd_u16(header + 0x14);
    CHECK(session_count_le == (uint16_t) cd_image_session_count(img));
    CHECK(session_count_le == 2); /* sanity: matches build_test_image()'s shape */

    /* --- MDF size vs. expected stored sectors, using only public API --- */
    fseek(mdf.file, 0, SEEK_END);
    long mdf_size = ftell(mdf.file);

    long expected_mdf_size = 0;
    for(size_t s = 0; s < cd_image_session_count(img); ++s) {
        cd_session_t* session = cd_image_get_session(img, s);
        for(size_t t = 0; t < cd_session_track_count(session); ++t) {
            cd_track_t* track = cd_session_get_track(session, t);
            expected_mdf_size += (long) (cd_track_data_size_in_sectors(track) +
                cd_track_postgap_sectors(track)) * 2352;
        }
    }
    CHECK(mdf_size == expected_mdf_size);
    CHECK(mdf_size > 0);

    /* --- Footer: wildcard MDF filename --- */
    fseek(mds.file, 0, SEEK_END);
    long mds_size = ftell(mds.file);
    CHECK(mds_size >= 6);

    char tail[6] = {0};
    fseek(mds.file, mds_size - 6, SEEK_SET);
    CHECK(fread(tail, 1, sizeof(tail), mds.file) == sizeof(tail));
    CHECK(memcmp(tail, "*.mdf", 6) == 0);

    /* --- Offset fields, walked the way a reader walks them --- */
    uint8_t* buf = (uint8_t*) malloc((size_t) mds_size);
    CHECK(buf != NULL);
    fseek(mds.file, 0, SEEK_SET);
    CHECK(fread(buf, 1, (size_t) mds_size, mds.file) == (size_t) mds_size);

    if(buf && mds_size > 0x54) {
        size_t session_count = session_count_le;
        uint32_t sessions_offset = rd_u32(buf + 0x50);

        CHECK(sessions_offset == 0x58); /* v1.4; nullDC hardcodes this */
        CHECK((size_t) sessions_offset + session_count * MDS_SESSION_BLOCK_SIZE
            <= (size_t) mds_size);

        /* Session blocks: block counts and the offsets of their block runs */
        size_t total_blocks = 0;
        uint32_t last_blocks_offset = 0;
        size_t last_block_count = 0;
        uint32_t expected_blocks_offset =
            sessions_offset + (uint32_t) session_count * MDS_SESSION_BLOCK_SIZE;

        for(size_t s = 0; s < session_count; ++s) {
            const uint8_t* sb = buf + sessions_offset + s * MDS_SESSION_BLOCK_SIZE;
            size_t block_count = sb[0x0A];
            uint32_t blocks_offset = rd_u32(sb + 0x14);

            CHECK(block_count > 0);
            CHECK(sb[0x0B] == 3); /* A0/A1/A2 before the first track */
            CHECK(blocks_offset == expected_blocks_offset); /* runs are contiguous */
            CHECK((size_t) blocks_offset + block_count * MDS_BLOCK_SIZE
                <= (size_t) mds_size);

            expected_blocks_offset += (uint32_t) block_count * MDS_BLOCK_SIZE;
            last_blocks_offset = blocks_offset;
            last_block_count = block_count;
            total_blocks += block_count;
        }

        /* The extra block array follows the last session's blocks, and holds
         * one slot per block -- lead-in entries included. */
        uint32_t extra_base =
            last_blocks_offset + (uint32_t) last_block_count * MDS_BLOCK_SIZE;
        uint32_t footer_offset =
            extra_base + (uint32_t) total_blocks * MDS_EXTRA_BLOCK_SIZE;

        CHECK(total_blocks == 12); /* sanity: 3+1+3 then 3+1+1 for this image */
        CHECK((size_t) footer_offset + MDS_FOOTER_SIZE <= (size_t) mds_size);

        /* Footer points at the filename, which is the last thing in the file */
        uint32_t filename_offset = rd_u32(buf + footer_offset);
        CHECK(filename_offset == footer_offset + MDS_FOOTER_SIZE);
        CHECK((size_t) filename_offset + 6 == (size_t) mds_size);
        CHECK(memcmp(buf + filename_offset, "*.mdf", 6) == 0);

        /* Every block: real tracks own a slot, lead-in entries have a
         * zeroed one, and the slot a reader recomputes from the block
         * index is the one the block's extra_offset points at. */
        size_t block_idx = 0;
        size_t track_blocks = 0;

        for(size_t s = 0; s < session_count; ++s) {
            const uint8_t* sb = buf + sessions_offset + s * MDS_SESSION_BLOCK_SIZE;
            size_t block_count = sb[0x0A];
            uint32_t blocks_offset = rd_u32(sb + 0x14);

            for(size_t b = 0; b < block_count; ++b, ++block_idx) {
                const uint8_t* block = buf + blocks_offset + b * MDS_BLOCK_SIZE;
                const uint8_t* slot =
                    buf + extra_base + block_idx * MDS_EXTRA_BLOCK_SIZE;
                uint8_t point = block[0x04];
                uint32_t extra_offset = rd_u32(block + 0x0C);

                if(point >= 0xA0) {
                    CHECK(extra_offset == 0);
                    CHECK(slot_is_zero(slot));
                } else {
                    CHECK(extra_offset ==
                        extra_base + (uint32_t) block_idx * MDS_EXTRA_BLOCK_SIZE);
                    CHECK((size_t) extra_offset + MDS_EXTRA_BLOCK_SIZE
                        <= (size_t) mds_size);
                    CHECK(rd_u32(slot + 0x00) == 150); /* pregap */
                    CHECK(rd_u32(slot + 0x04) > 0);    /* length in sectors */
                    CHECK(rd_u32(block + 0x34) == footer_offset);
                    ++track_blocks;
                }
            }
        }

        CHECK(block_idx == total_blocks);
        CHECK(track_blocks == cd_image_track_count(img));
    }

    free(buf);
    close_temp_file(&mds);
    close_temp_file(&mdf);
    cd_free_image(&img);

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
