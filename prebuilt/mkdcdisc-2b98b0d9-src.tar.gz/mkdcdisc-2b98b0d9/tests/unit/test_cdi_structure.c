/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Structural checks on a real .cdi file produced by cd_write_to_cdi().
 *
 * cd_load_from_cdi() isn't implemented (it's a stub returning NULL), so we
 * can't round-trip the image back through the library. Instead this
 * validates the two self-describing invariants of the format as written by
 * write_cdi_header() in cdi.c:
 *
 *   - The last 4 bytes of the file are a byte count that, subtracted from
 *     the file size, points back at the start of the trailing header block.
 *   - That header block always begins with a single byte: the session
 *     count.
 */

#include <stdint.h>
#include <stddef.h>

#include "../common/test_helpers.h"

int main(void) {
    cd_image_t* img = build_test_image(5000); /* not a multiple of 2048 */

    temp_file_t cdi = open_temp_file();
    CHECK(cdi.file != NULL);
    CHECK(cd_write_to_cdi(img, cdi.file, "test") == true);

    fseek(cdi.file, 0, SEEK_END);
    long file_size = ftell(cdi.file);
    CHECK(file_size > 0);

    uint8_t offset_bytes[4] = {0};
    fseek(cdi.file, -4, SEEK_END);
    CHECK(fread(offset_bytes, 1, sizeof(offset_bytes), cdi.file) == sizeof(offset_bytes));

    uint32_t header_offset = (uint32_t) offset_bytes[0]
        | ((uint32_t) offset_bytes[1] << 8)
        | ((uint32_t) offset_bytes[2] << 16)
        | ((uint32_t) offset_bytes[3] << 24);

    /* header_offset must point strictly inside the file, and be large
     * enough to at least cover itself */
    CHECK(header_offset > 4);
    CHECK((long) header_offset < file_size);

    long header_start = file_size - (long) header_offset;
    CHECK(header_start >= 0);

    uint8_t session_count_byte = 0xFF;
    fseek(cdi.file, header_start, SEEK_SET);
    CHECK(fread(&session_count_byte, 1, 1, cdi.file) == 1);
    CHECK(session_count_byte == (uint8_t) cd_image_session_count(img));
    CHECK(session_count_byte == 2); /* sanity: matches build_test_image()'s shape */

    close_temp_file(&cdi);
    cd_free_image(&img);

    if(g_test_failures) {
        fprintf(stderr, "%d check(s) failed\n", g_test_failures);
        return 1;
    }
    return 0;
}
