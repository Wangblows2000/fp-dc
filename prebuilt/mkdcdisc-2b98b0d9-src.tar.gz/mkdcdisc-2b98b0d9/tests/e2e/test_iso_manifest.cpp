/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Pins what libisofs actually writes, byte for byte, so that updating the
 * vendored copy is a reviewable change rather than an act of faith.
 *
 * The other e2e checks assert properties -- the bootstrap survives, a file's
 * bytes are where its record says, Joliet is on for MIL-CD and off for
 * GD-ROM. Properties only catch what someone thought to assert. This one
 * catches everything else, by recording the whole output and requiring it not
 * to move: a corpus of small volumes, each described by a per-sector digest
 * and a decoded summary, committed as tests/fixtures/iso-manifest.txt.
 *
 * After updating libisofs, this fails. That is the point -- regenerate it and
 * read the diff, which names the sectors that moved and shows what changed in
 * the descriptors, the tree and the layout. Then decide whether the change is
 * acceptable, which is a judgement no test can make.
 *
 *     meson compile -C builddir regen-iso-manifest
 *
 * It only runs where the vendored libisofs is the one linked, which is the
 * MinGW-w64 build. Everywhere else mkdcdisc links the system libisofs, whose
 * version varies by distribution, and a byte-level pin would be pinning that
 * machine rather than this repository -- so the test reports itself skipped.
 *
 * Usage: test_iso_manifest <mkdcdisc> <fixture-bin> <manifest> [--vendored] [--regen]
 */

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "../common/digest.h"
#include "../common/iso_read.h"
#include "../common/subprocess.h"

namespace {

int g_failures = 0;

/* The digest and its formatting live in common/digest.h, shared with the
 * bootable-disc manifest so that both print the same line for the same
 * bytes. */
using digest::fnv1a;
using digest::hex;

/* One volume the manifest describes, and the mkdcdisc invocation producing
 * it. Each entry varies something that reaches libisofs differently; between
 * them they cover every option mkdcdisc has that changes what it is asked to
 * write.
 *
 * All of them stay small on purpose: -N and --gdi-truncate keep the padding
 * off, so a volume is tens of sectors and its per-sector digests are a few
 * lines rather than a wall. A padded image would be a gigabyte of zeroes and
 * would say nothing extra. */
struct CorpusEntry {
    std::string name;
    std::string description;

    /* Appended to a common prefix, with $SRC standing in for the corpus
     * input directory. */
    std::string args;

    /* A GD-ROM writes a track set into a directory of its own, and the volume
     * described is track03; everything else writes one .cdi with the .iso
     * dumped beside it. */
    bool gdi = false;
};

/* Fixed so that nothing derived from the wall clock or from the host reaches
 * the volume: the release date, the serial (whose default is a hash of the
 * boot binary), and the label. */
const char* const COMMON_ARGS =
    " -n \"Corpus Disc\" -a Corpus -s T-00000 -r 20200101 -P V1.000 -V CORPUS"
    " --no-banner -q";

std::vector<CorpusEntry> corpus() {
    return {
        {
            "cdi-flat",
            "MIL-CD: a flat directory, the plainest thing libisofs is asked for",
            " -D \"$SRC/flat\" -N -I",
        },
        {
            "cdi-nested",
            "MIL-CD: nested directories and names needing 8.3 translation",
            " -D \"$SRC/nested\" -N -I",
        },
        {
            "cdi-sorted",
            "MIL-CD: the same tree under a sort file, which reorders the extents",
            " -D \"$SRC/flat\" -S \"$SRC/sort.txt\" -N -I",
        },
        {
            "cdi-duplicates-kept",
            "MIL-CD: identical files without --duplicates-once, each with its own extent",
            " -D \"$SRC/dupes\" -N -I",
        },
        {
            "cdi-duplicates-once",
            "MIL-CD: the same tree deduplicated -- the three identical files share one lba, "
            "and the same-size-different-content file keeps its own",
            " -D \"$SRC/dupes\" --duplicates-once -N -I",
        },
        {
            "cdi-duplicates-sorted",
            "MIL-CD: deduplicated files carrying disagreeing sort weights -- the shared extent "
            "takes the highest of them",
            " -D \"$SRC/dupes\" --duplicates-once -S \"$SRC/dupes-sort.txt\" -N -I",
        },
        {
            "cdi-text-files",
            "MIL-CD: the three PVD text files, whose identifiers are patched in",
            " -D \"$SRC/flat\" --copyright \"$SRC/text/COPY.TXT\""
            " --abstract \"$SRC/text/ABS.TXT\" --biblio \"$SRC/text/BIB.TXT\" -N -I",
        },
        {
            "gdi-high-density",
            "GD-ROM: the high-density volume, Joliet off and all three text files generated",
            " -F gdi --gdi-truncate --gdi-sector-size 2048 -D \"$SRC/nested\"",
            true,
        },
    };
}

/* The corpus inputs. Their contents are fixed; their modification times are
 * deliberately not, see reset_corpus() below. */
bool write_corpus_inputs(const std::filesystem::path& src) {
    namespace fs = std::filesystem;

    fs::create_directories(src / "flat");
    fs::create_directories(src / "nested" / "LEVEL1" / "LEVEL2");
    fs::create_directories(src / "text");
    fs::create_directories(src / "dupes" / "SUB");

    auto put = [](const fs::path& path, const std::string& content) {
        std::ofstream out(path, std::ios::binary);
        out.write(content.data(), (std::streamsize) content.size());
    };

    /* Contents of awkward lengths: under a sector, exactly one, and spanning
     * three, so extent arithmetic has boundaries to get wrong. */
    std::string one_sector(2048, 'x');
    std::string three_sectors;
    while(three_sectors.size() < 3 * 2048) {
        three_sectors += "spanning sectors; ";
    }

    put(src / "flat" / "AAAA.TXT", "first file");
    put(src / "flat" / "MMMM.TXT", one_sector);
    put(src / "flat" / "ZZZZ.TXT", three_sectors);

    put(src / "nested" / "ROOT.TXT", "at the root");
    put(src / "nested" / "LEVEL1" / "ONE.TXT", "one level down");
    put(src / "nested" / "LEVEL1" / "LEVEL2" / "TWO.TXT", "two levels down");
    /* A name ISO9660 level 2 cannot carry as written, so the manifest records
     * how libisofs translates it. */
    put(src / "nested" / "a long lower-case name.text", "translated");

    /* The --duplicates-once tree. Three copies of one content, two beside
     * each other and one a directory down, plus a fourth file that is the
     * same LENGTH as the other three and a different thing entirely.
     *
     * That fourth file is the point of the tree. libisofs caches file sources
     * on (fs_id, dev_id, ino_id, size), and Windows has no stat identity to
     * offer it, so same-size-different-content is exactly the pair that once
     * collapsed onto a single extent and corrupted one of the two. It must
     * keep an extent of its own whether --duplicates-once is given or not.
     *
     * It is also the only same-size pair anywhere in this corpus, and so the
     * only thing here that would notice if the vendored libisofs lost the
     * lfs_get_id() fix in fs_local.c -- which the next update of that copy
     * has to replay. Reverting that fix makes cdi-duplicates-kept show all
     * four files sharing one lba, with no option given at all. Keep the two
     * lengths equal if this tree is ever changed.
     *
     * 600 bytes so that each copy costs a whole sector: the saving then shows
     * up in the recorded volume size, not just in the extent addresses. */
    std::string shared_content(600, 'd');
    std::string same_size_other(600, 'e');

    put(src / "dupes" / "AAAA.TXT", shared_content);
    put(src / "dupes" / "BBBB.TXT", same_size_other);
    put(src / "dupes" / "CCCC.TXT", shared_content);
    put(src / "dupes" / "SUB" / "DEEP.TXT", shared_content);

    /* Weights that disagree inside one set of identical files. A shared
     * extent has one position, so the set takes the highest weight among it,
     * which is what mkisofs does (the MAX() in its write.c). /AAAA.TXT is
     * therefore placed at 9000 rather than at the 100 it asks for, and the
     * build warns about it -- pinned here so that neither the promotion nor
     * the resulting address can change unnoticed. */
    put(src / "dupes-sort.txt", "/AAAA.TXT 100\n/CCCC.TXT 9000\n");

    put(src / "text" / "COPY.TXT", "corpus copyright\n");
    put(src / "text" / "ABS.TXT", "corpus abstract\n");
    put(src / "text" / "BIB.TXT", "corpus bibliography\n");

    /* Heavier files first: libisofs ranks high weights towards low block
     * addresses, so this reverses the extent order of the flat tree. */
    put(src / "sort.txt", "/ZZZZ.TXT 100\n/AAAA.TXT 1\n");

    return fs::exists(src / "flat" / "AAAA.TXT");
}

/* Deletes the corpus and writes it again, which is done once before each of
 * the two builds so that the two cannot agree on a single timestamp.
 *
 * libisofs records a node's modification time in its Rock Ridge TF entry and
 * in its directory record, so the mtimes of these files and directories reach
 * the volume. Holding them fixed instead would mean naming one absolute
 * instant that every machine and every future run agrees on, and C++17 offers
 * no portable way to do it: the epoch of file_time_type is
 * implementation-defined, and last_write_time() will not even set a
 * directory's on every platform -- it fails on the MinGW-w64 build.
 *
 * Making them differ is the opposite approach and needs none of that. The two
 * builds then disagree wherever an mtime landed, volatile_offsets() finds
 * those bytes along with the clock libisofs stamps its descriptors from, and
 * describe() zeroes the lot. Timestamps are precisely what a manifest must
 * not pin. Contents and names are identical between the two, so nothing else
 * about the volume moves. */
bool reset_corpus(const std::filesystem::path& src) {
    std::error_code ec;
    std::filesystem::remove_all(src, ec);
    if(ec) return false;

    return write_corpus_inputs(src);
}

/* Runs mkdcdisc for one corpus entry into `out_dir` and returns the bytes of
 * the volume it describes. */
std::vector<uint8_t> build_entry(const std::string& mkdcdisc, const std::string& fixture,
                                 const std::filesystem::path& src, const CorpusEntry& entry,
                                 const std::filesystem::path& out_dir, std::string& error) {
    namespace fs = std::filesystem;

    /* A directory per entry, so the GD-ROM track set has somewhere of its own
     * to land and nothing can be picked up from a neighbour. */
    fs::path entry_dir = out_dir / entry.name;
    fs::create_directories(entry_dir);

    fs::path output = entry_dir / (entry.gdi ? "disc.gdi" : "disc.cdi");

    std::string args = entry.args;
    for(size_t at = args.find("$SRC"); at != std::string::npos; at = args.find("$SRC")) {
        args.replace(at, 4, src.string());
    }

    std::string command = quote(mkdcdisc) + " -b " + quote(fixture) + args +
                          COMMON_ARGS + " -o " + quote(output.string());

    RunResult result = run(command);
    if(result.exit_code != 0) {
        error = "mkdcdisc exited " + std::to_string(result.exit_code) + ": " + result.output;
        return {};
    }

    /* -F gdi writes its high-density volume as track03; -I dumps the data
     * track beside the .cdi, under the same name. */
    fs::path volume = entry.gdi ? entry_dir / "track03.iso"
                                : fs::path(output).replace_extension("iso");

    if(!fs::exists(volume)) {
        error = "no volume at " + volume.string() + "; mkdcdisc said: " + result.output;
        return {};
    }

    return iso_read::read_whole_file(volume);
}

/* Where two builds of the same input disagree, as "N bytes, first at X", or
 * empty when they agree. With SOURCE_DATE_EPOCH set and the PX serials masked
 * they must agree: that is the whole promise, and the corpus is built twice to
 * hold it to it. */
std::string difference_summary(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b) {
    if(a.size() != b.size()) {
        return "sizes differ: " + std::to_string(a.size()) + " vs " + std::to_string(b.size());
    }

    size_t count = 0;
    size_t first = 0;
    for(size_t i = 0; i < a.size(); ++i) {
        if(a[i] != b[i]) {
            if(count == 0) first = i;
            ++count;
        }
    }

    if(count == 0) return {};

    return std::to_string(count) + " bytes differ, the first at offset "
        + std::to_string(first) + " (sector " + std::to_string(first / iso_read::SECTOR) + ")";
}

/* The manifest text for one entry. Nothing is masked: with SOURCE_DATE_EPOCH
 * set the volume is a function of its inputs alone, so every byte is fair to
 * pin. */
std::string describe(const CorpusEntry& entry, const std::vector<uint8_t>& iso,
                     size_t px_serials_masked, uint32_t base_lba) {
    std::ostringstream out;
    out << "## " << entry.name << "\n";
    out << "# " << entry.description << "\n";
    out << "args         : " << entry.args << "\n";
    out << "size         : " << iso.size() << " bytes, "
        << (iso.size() / iso_read::SECTOR) << " sectors\n";
    out << "px serials   : " << px_serials_masked << " masked\n";
    out << "digest       : " << hex(fnv1a(iso.data(), iso.size()), 16) << "\n";

    out << "descriptors  :";
    for(const auto& descriptor: iso_read::volume_descriptors(iso)) {
        out << " " << (int) descriptor.type;
        if(!descriptor.escape_sequences.empty()) {
            out << "(" << descriptor.escape_sequences << ")";
        }
    }
    out << "\n";

    iso_read::Pvd pvd = iso_read::read_pvd(iso);
    out << "pvd.system   : " << pvd.system_id << "\n";
    out << "pvd.volume   : " << pvd.volume_id << "\n";
    out << "pvd.space    : " << pvd.volume_space << "\n";
    out << "pvd.publisher: " << pvd.publisher_id << "\n";
    out << "pvd.preparer : " << pvd.preparer_id << "\n";
    out << "pvd.applicat : " << pvd.application_id << "\n";
    out << "pvd.copyright: " << pvd.copyright_file << "\n";
    out << "pvd.abstract : " << pvd.abstract_file << "\n";
    out << "pvd.biblio   : " << pvd.biblio_file << "\n";
    out << "pvd.root     : lba " << pvd.root_lba << ", " << pvd.root_len << " bytes\n";

    /* In the order the directory records appear, which is the order libisofs
     * wrote them and so is itself part of what is pinned. */
    for(const auto& node: iso_read::list_tree(iso, base_lba)) {
        out << (node.is_dir ? "dir          : " : "file         : ")
            << node.path << " lba " << node.lba << ", " << node.size << " bytes\n";
    }

    /* Per sector, so a diff names where a change is rather than only that
     * there was one. 16 bits each is plenty to notice a difference. */
    out << "sectors      :\n";
    for(size_t sector = 0; sector * iso_read::SECTOR < iso.size(); ++sector) {
        if(sector % 16 == 0) {
            out << "  " << hex(sector, 4) << ":";
        }

        size_t at = sector * iso_read::SECTOR;
        size_t len = std::min(iso_read::SECTOR, iso.size() - at);
        out << " " << hex(fnv1a(iso.data() + at, len) & 0xFFFF, 4);

        if(sector % 16 == 15) out << "\n";
    }
    if((iso.size() / iso_read::SECTOR) % 16 != 0) out << "\n";

    return out.str();
}

/* A unified-ish diff, enough to point at the first divergences without
 * pulling in a diff algorithm: the manifest is regenerated wholesale, so what
 * is wanted here is "where does it stop matching", not a minimal edit
 * script. */
void report_difference(const std::string& expected, const std::string& actual) {
    std::istringstream want(expected), got(actual);
    std::string want_line, got_line;

    size_t line = 0;
    size_t shown = 0;
    const size_t MAX_SHOWN = 40;

    while(shown < MAX_SHOWN) {
        bool has_want = (bool) std::getline(want, want_line);
        bool has_got = (bool) std::getline(got, got_line);
        if(!has_want && !has_got) break;

        ++line;
        if(!has_want) want_line = "(end of manifest)";
        if(!has_got) got_line = "(end of output)";

        if(want_line != got_line) {
            std::cerr << "  line " << line << ":\n"
                      << "    committed: " << want_line << "\n"
                      << "    built    : " << got_line << std::endl;
            ++shown;
        }
    }

    if(shown == MAX_SHOWN) {
        std::cerr << "  ... more differences follow" << std::endl;
    }
}

} // namespace

int main(int argc, char** argv) {
    namespace fs = std::filesystem;

    if(argc < 4) {
        std::cerr << "usage: test_iso_manifest <mkdcdisc> <fixture-bin> <manifest>"
                     " [--vendored] [--regen]" << std::endl;
        return 1;
    }

    std::string mkdcdisc = fs::path(argv[1]).make_preferred().string();
    std::string fixture = argv[2];
    fs::path manifest_path = argv[3];

    bool vendored = false;
    bool regen = false;
    for(int i = 4; i < argc; ++i) {
        if(std::strcmp(argv[i], "--vendored") == 0) vendored = true;
        if(std::strcmp(argv[i], "--regen") == 0) regen = true;
    }

    /* Meson reads 77 as "skipped". Everywhere but the MinGW-w64 build,
     * mkdcdisc links the system libisofs and this manifest describes a
     * different library than the one installed. */
    if(!vendored && !regen) {
        std::cout << "skipped: this build links the system libisofs, and "
                     "tests/fixtures/iso-manifest.txt describes the vendored copy"
                  << std::endl;
        return 77;
    }

    /* What makes any of this possible: with SOURCE_DATE_EPOCH set, mkdcdisc
     * puts no clock reading into the image, so the volume is a function of
     * its inputs and every byte of it can be pinned.
     *
     * TZ is fixed alongside it, and has to be. libisofs encodes the per-node
     * timestamps in local time with the offset recorded beside them, so the
     * same instant is different bytes in Paris and in UTC -- and this
     * manifest is committed here and compared on a CI runner elsewhere. The
     * volume descriptors need no such help: they go through vol_uuid, which
     * libisofs records as GMT (see apply_source_date_epoch()). */
    set_env("SOURCE_DATE_EPOCH", "946684800");  /* 2000-01-01T00:00:00Z */
    set_env("TZ", "UTC");

    fs::path work = fs::temp_directory_path() /
        ("mkdcdisc-iso-manifest-" + std::to_string((unsigned long) GETPID()));

    std::error_code ec;
    fs::remove_all(work, ec);
    fs::create_directories(work);

    fs::path src = work / "src";
    if(!write_corpus_inputs(src)) {
        std::cerr << "could not write the corpus inputs under " << src << std::endl;
        return 1;
    }

    std::ostringstream built;
    built << "# mkdcdisc ISO manifest -- what libisofs writes, pinned.\n"
             "#\n"
             "# Regenerate with:  meson compile -C builddir regen-iso-manifest\n"
             "# Do not edit by hand. See tests/e2e/test_iso_manifest.cpp for what\n"
             "# each field means and why a change here needs explaining.\n"
             "#\n"
             "# Every volume below is built with SOURCE_DATE_EPOCH set, so nothing in\n"
             "# it comes from the clock. The one field that still does not reproduce\n"
             "# is the Rock Ridge PX file serial number, which is zeroed -- the count\n"
             "# is recorded per entry so that a change in it is visible here. Each\n"
             "# volume is built twice, a second apart and from freshly written inputs,\n"
             "# and the two are required to be identical before either is described.\n";

    for(const auto& entry: corpus()) {
        std::string error;

        if(!reset_corpus(src)) {
            std::cerr << "FAIL " << entry.name << ": could not write the corpus inputs" << std::endl;
            ++g_failures;
            continue;
        }

        std::vector<uint8_t> first = build_entry(mkdcdisc, fixture, src, entry, work / "a", error);
        if(first.empty()) {
            std::cerr << "FAIL " << entry.name << ": " << error << std::endl;
            ++g_failures;
            continue;
        }

        /* The second build is deliberately made as unlike the first as the
         * environment allows: a second later, from inputs written again and
         * so carrying different modification times. Anything that reached the
         * volume from the clock rather than from the inputs shows up here. */
        std::this_thread::sleep_for(std::chrono::milliseconds(1100));

        if(!reset_corpus(src)) {
            std::cerr << "FAIL " << entry.name << ": could not write the corpus inputs" << std::endl;
            ++g_failures;
            continue;
        }

        std::vector<uint8_t> second = build_entry(mkdcdisc, fixture, src, entry, work / "b", error);
        if(second.empty()) {
            std::cerr << "FAIL " << entry.name << ": " << error << std::endl;
            ++g_failures;
            continue;
        }

        /* A GD-ROM's high-density volume records its addresses from the start
         * of the disc, not from the start of the track file they are read out
         * of, so following one means knowing where that volume begins. */
        uint32_t base_lba = entry.gdi ? iso_read::GD_HIGH_DENSITY_LBA : 0;

        /* The manifest records the count: see iso_read::mask_px_serials() for
         * why this field is masked rather than dropped from the disc. */
        size_t masked = iso_read::mask_px_serials(first, base_lba);
        if(iso_read::mask_px_serials(second, base_lba) != masked) {
            std::cerr << "FAIL " << entry.name << ": the two builds carry a different number "
                         "of Rock Ridge PX entries, which is a change of structure rather "
                         "than of serial numbers" << std::endl;
            ++g_failures;
            continue;
        }

        std::string difference = difference_summary(first, second);
        if(!difference.empty()) {
            std::cerr << "FAIL " << entry.name << ": two builds of the same inputs, with "
                      << "SOURCE_DATE_EPOCH set and the PX serials masked, are not identical -- "
                      << difference << ".\n"
                      << "  Something still reaches the image from the clock or the "
                         "environment. The manifest cannot pin what does not reproduce."
                      << std::endl;
            ++g_failures;
            continue;
        }

        built << "\n" << describe(entry, first, masked, base_lba);
    }

    fs::remove_all(work, ec);

    if(g_failures) {
        std::cerr << g_failures << " corpus entr(y/ies) could not be built" << std::endl;
        return 1;
    }

    if(regen) {
        std::ofstream out(manifest_path, std::ios::binary);
        if(!out) {
            std::cerr << "could not write " << manifest_path << std::endl;
            return 1;
        }

        out << built.str();
        std::cout << "wrote " << manifest_path << std::endl;
        return 0;
    }

    std::vector<uint8_t> committed_bytes = iso_read::read_whole_file(manifest_path);
    std::string committed((const char*) committed_bytes.data(), committed_bytes.size());

    /* Line endings are whatever git handed over; the manifest is compared as
     * text, not as bytes. */
    committed.erase(std::remove(committed.begin(), committed.end(), '\r'), committed.end());

    std::string actual = built.str();
    actual.erase(std::remove(actual.begin(), actual.end(), '\r'), actual.end());

    if(committed.empty()) {
        std::cerr << "FAIL: no manifest at " << manifest_path << std::endl;
        return 1;
    }

    if(committed != actual) {
        std::cerr << "FAIL: what libisofs writes is not what the manifest records.\n"
                     "\n"
                     "If libisofs was just updated, this is the change it made. Regenerate\n"
                     "with 'meson compile -C builddir regen-iso-manifest' and read the diff:\n"
                     "it names the sectors that moved and shows the descriptors, the tree\n"
                     "and the layout on both sides. If it was not updated, something else\n"
                     "changed what ends up on a disc.\n" << std::endl;
        report_difference(committed, actual);
        return 1;
    }

    return 0;
}
