/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Builds one GD-ROM the way a release actually ships it: padded out to the
 * full physical high-density zone, with no --gdi-truncate.
 *
 * Its own test, gated behind -Dslow_tests, because it is the one thing in this
 * suite that cannot be made small. "Padded" means the full physical size by
 * definition: mkdcdisc writes a ~984 MiB filler file into its staging
 * directory and then a ~1.10 GiB track file, and both are on disk at once
 * (the staging directory only goes at exit). Around 2.1 GiB and ten seconds,
 * against a handful of sectors for every other e2e case.
 *
 * Which is why the padded path had no coverage at all until this existed:
 * every other GD-ROM test in the suite passes --gdi-truncate. What that left
 * untested is what a real disc depends on -- the filler file, and the boot
 * binary landing at the physical address the console reads it from.
 *
 * The cheap half of the same ground is unit/test_gd_track_plan.cpp, which
 * pins the sizing arithmetic without building anything. This test is for what
 * arithmetic cannot answer: that the bytes really land where it said. */

#include <cstdint>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

#include "../common/gdi_verify.h"
#include "../common/subprocess.h"

static int g_failures = 0;

#define CHECK(cond) do { \
    if(!(cond)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << ": " << #cond << std::endl; \
        g_failures++; \
    } \
} while(0)

#define CHECK_RUN(result, cond) do { \
    if(!(cond)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << ": " << #cond \
                  << "\n  exit code: " << (result).exit_code \
                  << "\n  output: " << (result).output << std::endl; \
        g_failures++; \
    } \
} while(0)

/* The physical window, as build_gd() sizes it (see src/gd_track_plan.hpp).
 * Repeated rather than included: this test drives the built binary from the
 * outside, and a constant shared with the code under test would move with it
 * instead of holding it still. */
static const uint32_t GD_END_LBA = 549150;
static const uint32_t FULL_TRACK_SECTORS = GD_END_LBA - gdi_verify::GD_START_LBA;
static const uint32_t RAW_SECTOR = 2352;

int main(int argc, char** argv) {
    if(argc < 3) {
        std::cerr << "usage: " << argv[0] << " <mkdcdisc> <fixture.bin>" << std::endl;
        return 2;
    }

    /* See the note in test_cli.cpp: cmd.exe cannot resolve the forward-slash
     * relative path meson passes here. */
    std::string mkdcdisc = std::filesystem::path(argv[1]).make_preferred().string();
    std::string fixture = argv[2];

    std::error_code ec;
    std::filesystem::path dir = std::filesystem::temp_directory_path() /
        ("mkdcdisc-gdi-padded-" + std::to_string((unsigned long) GETPID()));

    std::filesystem::remove_all(dir, ec);
    std::filesystem::create_directories(dir, ec);

    std::filesystem::path gdi = dir / "out.gdi";

    auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                 " -n TestGame -a TestAuthor -r 20240101 -s T-00001"
                 " -F gdi -o " + quote(gdi.string()) + " -q");
    CHECK_RUN(r, r.exit_code == 0);

    if(r.exit_code == 0) {
        /* The whole point of not truncating: the track is the full physical
         * zone, whatever the disc actually holds. The fixture here is a few
         * kilobytes, so every sector but a handful came from the filler. */
        std::filesystem::path track03 = dir / "track03.bin";
        CHECK(std::filesystem::exists(track03));
        CHECK(std::filesystem::file_size(track03, ec) ==
              (uintmax_t) FULL_TRACK_SECTORS * RAW_SECTOR);

        /* Everything the shared verifier knows: track gaps, no file reaching
         * into a run-out, and the declared boot binary last in the area. */
        std::vector<std::string> errors = gdi_verify::verify(gdi);
        for(const auto& error: errors) {
            std::cerr << "  gdi-verify: " << error << std::endl;
        }
        CHECK(errors.empty());

        gdi_verify::Image img;
        std::vector<std::string> load_errors;
        std::vector<gdi_verify::File> files;

        if(img.load(gdi, load_errors)
            && gdi_verify::list_files(img, gdi_verify::GD_START_LBA, files)) {

            /* The assertion that only a padded build can make, and the reason
             * the padding exists at all. verify() above only establishes that
             * the boot binary is the last file and clear of the run-out --
             * true of a truncated image too, where it sits a gigabyte short of
             * where the console looks. Here it has to end exactly at the
             * physical address real GD-ROM hardware reads it from. */
            std::string boot = gdi_verify::boot_filename(img);
            bool found = false;

            for(const auto& file: files) {
                if(file.name != boot) {
                    continue;
                }
                found = true;
                CHECK(file.end_lba == GD_END_LBA - gdi_verify::TRACK_RUN_OUT);
            }

            CHECK(found);

            /* The filler is written into the staging directory like any other
             * file, and is kept out of every directory tree by a hidden flag
             * alone. list_files() reads the directory records, so a filler
             * that stopped being hidden would show up right here -- as a
             * ~984 MiB "0.0" in the root of a shipped disc. */
            for(const auto& file: files) {
                CHECK(file.name != "0.0");
            }
        } else {
            CHECK(false && "the high-density volume could not be read back");
        }
    }

    std::filesystem::remove_all(dir, ec);

    if(g_failures) {
        std::cerr << g_failures << " check(s) failed" << std::endl;
        return 1;
    }
    return 0;
}
