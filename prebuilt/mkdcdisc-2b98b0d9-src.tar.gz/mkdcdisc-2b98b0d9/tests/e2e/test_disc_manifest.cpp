/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Pins the table of contents mkdcdisc lays down -- how many sessions and
 * tracks a disc has, where each track begins, what mode it is written in --
 * across every layout and every one of the four output formats, as
 * tests/fixtures/disc-manifest.txt.
 *
 * The other e2e checks assert properties: a CDI has two sessions, MSINFO is
 * 11702, the boot binary is the last file on a GD-ROM. Properties only catch
 * what someone thought to assert, and the bugs this project has actually had
 * were all in the spaces between them -- an LBA silently gaining the 150-sector
 * FAD bias, a track placed against the wrong neighbour, a session ending where
 * the next one starts. This records the whole layout instead and requires it
 * not to move.
 *
 * The images are read back with common/disc_read.h, which parses the container
 * descriptors and shares no arithmetic with the writers. A reader built on the
 * writer's own layout code would confirm the writer including its mistakes,
 * which is the one way of doing this that would be worse than not doing it.
 *
 * Unlike the ISO manifest next door, this one runs everywhere. That is the
 * whole reason it records what it records: every field below is decided by
 * mkdcdisc, never by libisofs, whose version differs on all four CI targets.
 * The one quantity that unavoidably comes from libisofs is how many sectors a
 * filesystem needs, so no line states a data track's length. What the layout
 * puts *around* that filesystem is stated instead, and that is mkdcdisc's own:
 *
 *   - "gap" and "start", the distance from the end of the previous track,
 *     within a session and across a session boundary. These hold still even
 *     where both tracks they are measured between are sized by the filesystem,
 *     which is the case on every disc here that carries audio;
 *   - the run-out, how far the tracks reach past the end of the volume they
 *     carry;
 *   - "iso+N" on the whole-disc total, N being the lead-in, pregaps, postgaps
 *     and lead-out wrapped around every filesystem on the disc.
 *
 * Absolute LBAs appear only where the disc format fixes them: track 1 at 0, and
 * a GD-ROM's high-density area at 45000.
 *
 * A track that stopped carrying its whole volume, or a gap that gained 150
 * sectors, moves one of those. A distribution shipping a different libisofs
 * moves none of them.
 *
 * Nothing here is built twice to prove it reproduces: the table of contents
 * takes nothing from the clock in the first place, and it is
 * tests/e2e/test_iso_manifest.cpp that holds the reproducibility promise for
 * the bytes.
 *
 * After an intentional layout change, this fails. Regenerate it and read the
 * diff -- that diff is the change's effect on the shape of a disc:
 *
 *     meson compile -C builddir regen-disc-manifest
 *
 * Usage: test_disc_manifest <mkdcdisc> <fixture-bin> <manifest> [--regen]
 */

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "../common/disc_read.h"
#include "../common/iso_read.h"
#include "../common/subprocess.h"
#include "../common/volume_span.h"

namespace {

namespace fs = std::filesystem;

int g_failures = 0;

/* Fixed so that nothing derived from the wall clock or from the host reaches
 * the disc: the release date, the serial (whose default is a hash of the boot
 * binary), the version and the label. */
const char* const COMMON_ARGS =
    " -n \"Manifest Disc\" -a Manifest -s T-00000 -r 20200101 -P V1.000 -V MANIFEST"
    " --no-banner -q";

/* One disc the manifest describes: an mkdcdisc invocation, and the formats it
 * is written in. Every entry stays small -- -N and --gdi-truncate keep the
 * padding off -- because padding adds hundreds of megabytes of zeroes and not
 * one line of table of contents. */
struct CorpusEntry {
    std::string name;
    std::string description;

    /* Appended to a common prefix, with $SRC standing in for the corpus input
     * directory. */
    std::string args;

    /* Extensions to write this entry as. A GD-ROM only exists as a .gdi; the
     * MIL-CD layouts exist as all three single-file containers, and comparing
     * the three against each other is half the point -- they describe the same
     * disc and must agree about it. */
    std::vector<std::string> formats;
};

std::vector<CorpusEntry> corpus() {
    return {
        {
            "audio-data",
            "The default MIL-CD: a silent audio session, then the data session",
            " -D \"$SRC/files\" -N",
            {"cdi", "mds", "nrg"},
        },
        {
            "data-data",
            "Data/Data: no audio session at all, so both sessions carry a volume",
            " -L data-data -D \"$SRC/files\" -N",
            {"cdi", "mds", "nrg"},
        },
        {
            "cdda",
            "Audio/Data with two CD-DA tracks of different lengths in session 1",
            " -D \"$SRC/files\" -c \"$SRC/audio-a.raw\" -c \"$SRC/audio-b.raw\" -N",
            {"cdi", "mds", "nrg"},
        },
        {
            "gdrom",
            "A GD-ROM: low-density data and audio, then the high-density track",
            " -D \"$SRC/files\" --gdi-truncate",
            {"gdi"},
        },
        {
            "gdrom-2048",
            "The same, written as 2048-byte track files instead of raw 2352",
            " -D \"$SRC/files\" --gdi-truncate --gdi-sector-size 2048",
            {"gdi"},
        },
        {
            "gdrom-gdda",
            "GD-DA: the high-density filesystem split around two audio tracks",
            " -D \"$SRC/files\" -c \"$SRC/audio-a.raw\" -c \"$SRC/audio-b.raw\""
            " --gdi-truncate",
            {"gdi"},
        },
    };
}

/* The corpus inputs. Their contents are fixed, and small: what is on the disc
 * only matters here inasmuch as it gives the volume a size, and the sizes the
 * manifest records are the files' own. */
bool write_corpus_inputs(const fs::path& src) {
    std::error_code ec;
    fs::create_directories(src / "files" / "SUB", ec);

    auto put = [](const fs::path& path, const std::string& contents) {
        std::ofstream f(path, std::ios::binary);
        f << contents;
        return (bool) f;
    };

    /* Red Book's minimum audio track is 300 sectors. Two different lengths, so
     * a swapped or reused one shows up as a moved LBA further down the disc. */
    auto put_audio = [](const fs::path& path, size_t sectors) {
        std::ofstream f(path, std::ios::binary);
        std::vector<char> silence(2352, 0);
        for(size_t i = 0; i < sectors; ++i) {
            f.write(silence.data(), (std::streamsize) silence.size());
        }
        return (bool) f;
    };

    return put(src / "files" / "AAAA.TXT", "a\n")
        && put(src / "files" / "ZZZZ.TXT", std::string(6000, 'z'))
        && put(src / "files" / "SUB" / "NESTED.TXT", "nested\n")
        && put_audio(src / "audio-a.raw", 400)
        && put_audio(src / "audio-b.raw", 300);
}

/* Builds one corpus entry in one format and reads its table of contents back.
 * Each lands in a directory of its own, so a GD-ROM's track set has somewhere
 * to go and nothing can be picked up from a neighbour. */
disc_read::Disc build_entry(const std::string& mkdcdisc, const std::string& fixture,
                            const fs::path& src, const CorpusEntry& entry,
                            const std::string& format, const fs::path& out_dir,
                            std::string& error) {
    fs::path entry_dir = out_dir / (entry.name + "-" + format);

    std::error_code ec;
    fs::remove_all(entry_dir, ec);
    fs::create_directories(entry_dir, ec);

    fs::path output = entry_dir / ("disc." + format);

    std::string args = entry.args;
    for(size_t at = args.find("$SRC"); at != std::string::npos; at = args.find("$SRC")) {
        args.replace(at, 4, src.string());
    }

    /* -F is given explicitly rather than left to the extension: the manifest
     * says which format each block describes, and it should be describing the
     * one it asked for. */
    std::string command = quote(mkdcdisc) + " -b " + quote(fixture) + args + COMMON_ARGS
                        + " -F " + format + " -o " + quote(output.string());

    RunResult result = run(command);
    if(result.exit_code != 0) {
        error = "mkdcdisc exited " + std::to_string(result.exit_code) + ": " + result.output;
        return {};
    }

    if(!fs::exists(output)) {
        error = "no image at " + output.string() + "; mkdcdisc said: " + result.output;
        return {};
    }

    disc_read::Disc disc = disc_read::read(output);
    if(!disc.valid) {
        error = "the image could not be read back:";
        for(const auto& message: disc.errors) error += "\n    " + message;
    }

    return disc;
}

/* A whole-disc sector count, written as the part mkdcdisc decides: `iso` is
 * every filesystem on the disc together, and what is printed is what the
 * layout wraps around them -- lead-in, pregap, postgap, lead-out. */
std::string relative_to_iso(uint64_t sectors, uint64_t iso_sectors) {
    if(sectors >= iso_sectors) {
        return "iso+" + std::to_string(sectors - iso_sectors);
    }

    return "iso-" + std::to_string(iso_sectors - sectors);
}

std::string pad(const std::string& s, size_t width) {
    return s.size() >= width ? s : s + std::string(width - s.size(), ' ');
}

/* The manifest text for one built image. */
std::string describe(const CorpusEntry& entry, const std::string& format,
                     const disc_read::Disc& disc, std::string& error) {
    std::vector<volume_span::Span> volumes;
    if(!volume_span::find(disc, volumes, error)) {
        return {};
    }

    std::ostringstream out;

    out << "## " << entry.name << " / " << format << "\n";
    out << "# " << entry.description << "\n";
    out << "args         :" << entry.args << "\n";
    out << "sessions     : " << disc.sessions.size() << "\n";
    out << "tracks       : " << disc.tracks.size() << "\n";

    if(disc.total_sectors) {
        /* Only the filesystems that are really on the disc. A boot head's PVD
         * counts the volume in the session before it, which is already in the
         * total once; counting it twice would put a libisofs-sized quantity
         * into a line that is supposed to hold none. */
        uint64_t all_volumes = 0;
        for(const auto& span: volumes) {
            if(span.volume.has_tree()) all_volumes += span.volume.sectors;
        }
        out << "disc.sectors : " << relative_to_iso(*disc.total_sectors, all_volumes) << "\n";
    }

    /* Where the previous track stopped, carried across session boundaries: the
     * distance from it is what stays put when the filesystem's own size does
     * not. Empty before the first track of the disc. */
    auto end_of = [&](size_t index) {
        return disc.tracks[index].start_lba + (int64_t) disc.tracks[index].sectors;
    };

    for(size_t s = 0; s < disc.sessions.size(); ++s) {
        const disc_read::Session& session = disc.sessions[s];

        out << "session " << session.index << "    :";

        /* A session's declared program area, where the format declares one --
         * MDS and NRG do, CDI and GDI do not.
         *
         * Both ends are stated relative to what comes before, for the same
         * reason the track lines are: a session that follows one holding a
         * filesystem sits wherever that filesystem ended. What mkdcdisc decides
         * is the distance -- the lead-out and lead-in between two sessions,
         * and that a session ends exactly where its last track does. */
        if(session.start_lba) {
            if(s == 0) {
                out << " start " << *session.start_lba;
            } else {
                const disc_read::Session& previous = disc.sessions[s - 1];
                int64_t from = previous.tracks.empty() ? 0 : end_of(previous.tracks.back());
                out << " start +" << (*session.start_lba - from);
            }
        }

        if(session.end_lba && !session.tracks.empty()) {
            out << " end +" << (*session.end_lba - end_of(session.tracks.back()));
        }

        out << " tracks " << session.tracks.size() << "\n";

        for(size_t at = 0; at < session.tracks.size(); ++at) {
            size_t index = session.tracks[at];
            const disc_read::Track& track = disc.tracks[index];

            /* The raw value in hex, which is how every one of these formats
             * documents its own mode codes -- 0xEC for Alcohol's XA Mode 2
             * Form 1, 0x06000001 for Nero's. Printed alongside the name because
             * the formats disagree on how finely they describe a mode, and a
             * change in the value is worth seeing even when the name holds. */
            std::ostringstream mode;
            mode << track.mode_name << "(0x" << std::hex << track.mode_value << std::dec << ")";

            out << "  track " << track.number << "    : " << pad(mode.str(), 16)
                << " ctrl " << track.ctrl
                << " size " << track.sector_size;

            /* Where the track sits, stated as an absolute LBA only where that
             * LBA is a fixed physical property of the disc, and as a distance
             * everywhere else.
             *
             * Only two absolutes qualify. The first track of a disc begins at
             * 0, and a GD-ROM's zones begin at addresses the format fixes -- 0
             * for the low-density area, 45000 for the high-density one -- which
             * is precisely why they are worth pinning outright. Every other
             * track follows whatever precedes it, and what precedes it is often
             * a filesystem: on a Data/Data image the second session starts
             * after the first one's volume, and on a GD-DA disc the audio
             * starts after the front of the high-density volume. Their absolute
             * LBAs move with libisofs; their distances do not.
             *
             * That distance is also the field a stray FAD bias would land in.
             * "gap" is the step from the previous track of the same session,
             * "start" the step across a session boundary. */
            if(index == 0 || (disc.format == "gdi" && at == 0)) {
                out << " lba " << track.start_lba;
            } else if(at == 0) {
                const disc_read::Session& previous = disc.sessions[s - 1];
                int64_t from = previous.tracks.empty() ? 0 : end_of(previous.tracks.back());
                out << " start +" << (track.start_lba - from);
            } else {
                out << " gap " << (track.start_lba - end_of(session.tracks[at - 1]));
            }

            if(track.pregap_sectors) {
                out << " pregap " << *track.pregap_sectors;
            }

            /* An audio track's length is its own -- the supplied file, or the
             * silence mkdcdisc generates. A data track's is the filesystem's,
             * so it is not stated here; what the layout does around that
             * filesystem is stated on the volume line below. */
            if(!track.is_data()) {
                out << " sectors " << track.sectors;
            }

            out << "\n";
        }
    }

    for(const auto& span: volumes) {
        const disc_read::Track& anchor = disc.tracks[span.anchor];
        const disc_read::Track& last = disc.tracks[span.last];

        out << "volume       : track " << anchor.number
            << ", " << span.volume.volume_id << " / " << span.volume.system_id;

        if(span.volume.has_tree()) {
            /* How far the tracks reach past the end of the filesystem they
             * carry: a GD-ROM's 150-sector run-out, a MIL-CD's 2-sector
             * postgap. Both sides of the subtraction move with libisofs; the
             * difference does not, and a track that stopped carrying its whole
             * volume moves it. */
            int64_t run_out = (last.start_lba + (int64_t) last.sectors)
                            - anchor.start_lba - (int64_t) span.volume.sectors;

            out << ", spans tracks " << anchor.number << "-" << last.number
                << ", run-out " << run_out << "\n";
        } else {
            /* A boot head carries no filesystem to measure the track against,
             * and its length is mkdcdisc's own -- the minimum track length plus
             * the postgap -- so here the length is the thing to state. */
            out << ", descriptors only, sectors " << anchor.sectors << "\n";
        }

        /* Names and sizes, never extents: which sector libisofs chose to put a
         * file at is its business, but that the file is there and how big it is
         * are mkdcdisc's. A boot binary that grew, or a file that fell off the
         * disc, shows up here.
         *
         * libisofs also decides the order the directory records come in, which
         * is the order volume_span::find() reports them in; sorting by name
         * keeps a reordering out of the manifest, where it would be a libisofs
         * change dressed up as an mkdcdisc one. The ISO manifest is the place
         * that pins ordering, and it pins one libisofs to do it. */
        std::vector<iso_read::Entry> entries = span.volume.entries;
        std::sort(entries.begin(), entries.end(),
                  [](const iso_read::Entry& a, const iso_read::Entry& b) { return a.path < b.path; });

        for(const auto& item: entries) {
            out << "  " << (item.is_dir ? "dir        : " : "file       : ") << item.path;
            if(!item.is_dir) out << " " << item.size << " bytes";
            out << "\n";
        }
    }

    return out.str();
}

void report_difference(const std::string& expected, const std::string& actual) {
    std::istringstream want(expected), got(actual);
    std::string want_line, got_line;

    size_t line = 0;
    size_t shown = 0;
    const size_t MAX_SHOWN = 40;

    while(shown < MAX_SHOWN) {
        bool has_want = (bool) std::getline(want, want_line);
        bool has_got = (bool) std::getline(got, got_line);
        if(!has_want && !has_got) break;

        ++line;
        if(!has_want) want_line = "(end of manifest)";
        if(!has_got) got_line = "(end of output)";

        if(want_line != got_line) {
            std::cerr << "  line " << line << ":\n"
                      << "    committed: " << want_line << "\n"
                      << "    built    : " << got_line << std::endl;
            ++shown;
        }
    }

    if(shown == MAX_SHOWN) {
        std::cerr << "  ... more differences follow" << std::endl;
    }
}

} // namespace

int main(int argc, char** argv) {
    if(argc < 4) {
        std::cerr << "usage: test_disc_manifest <mkdcdisc> <fixture-bin> <manifest> [--regen]"
                  << std::endl;
        return 1;
    }

    /* On Windows, run() shells out via cmd.exe (_popen), which fails to resolve
     * forward-slash relative paths like "./mkdcdisc.exe" -- the form Meson
     * passes when the exe lives in the test's working directory. */
    std::string mkdcdisc = fs::path(argv[1]).make_preferred().string();
    std::string fixture = argv[2];
    fs::path manifest_path = argv[3];

    bool regen = false;
    for(int i = 4; i < argc; ++i) {
        if(std::strcmp(argv[i], "--regen") == 0) regen = true;
    }

    /* No timestamp reaches a table of contents, so this is not what makes the
     * manifest possible here the way it is next door. It is set anyway: the
     * volumes these discs carry are read back for their file lists, and a build
     * that took the clock into account would be a change worth failing on
     * wherever it showed up. */
    set_env("SOURCE_DATE_EPOCH", "946684800");  /* 2000-01-01T00:00:00Z */
    set_env("TZ", "UTC");

    fs::path work = fs::temp_directory_path() /
        ("mkdcdisc-disc-manifest-" + std::to_string((unsigned long) GETPID()));

    std::error_code ec;
    fs::remove_all(work, ec);
    fs::create_directories(work, ec);

    fs::path src = work / "src";
    if(!write_corpus_inputs(src)) {
        std::cerr << "could not write the corpus inputs under " << src << std::endl;
        return 1;
    }

    std::ostringstream built;
    built << "# mkdcdisc disc manifest -- the table of contents each format lays down.\n"
             "#\n"
             "# Regenerate with:  meson compile -C builddir regen-disc-manifest\n"
             "# Do not edit by hand. See tests/e2e/test_disc_manifest.cpp for what\n"
             "# each field means and why a change here needs explaining.\n"
             "#\n"
             "# Every value below is one mkdcdisc decides, so this file is the same\n"
             "# on every platform. How many sectors a filesystem occupies is not:\n"
             "# libisofs decides that, and its version differs across the CI targets.\n"
             "# So a data track's length is never stated, and neither is a position\n"
             "# that follows one. What the layout puts around the filesystem is\n"
             "# stated instead:\n"
             "#\n"
             "#   gap N      distance from the end of the previous track\n"
             "#   start +N   the same, measured across a session boundary\n"
             "#   run-out N  how far the tracks reach past the end of the volume\n"
             "#   iso+N      the disc total, less every filesystem on it\n"
             "#\n"
             "# An audio track's length is its own and is stated outright. Absolute\n"
             "# LBAs appear only where the disc format fixes them: track 1 at 0, and\n"
             "# a GD-ROM's high-density area at 45000.\n"
             "#\n"
             "# LBAs are native throughout: what the container stores, with no FAD\n"
             "# bias added or removed on the way in or out. A stray +150 is a diff.\n";

    for(const auto& entry: corpus()) {
        for(const auto& format: entry.formats) {
            std::string label = entry.name + "/" + format;
            std::string error;

            disc_read::Disc disc = build_entry(mkdcdisc, fixture, src, entry, format, work, error);
            if(!error.empty()) {
                std::cerr << "FAIL " << label << ": " << error << std::endl;
                ++g_failures;
                continue;
            }

            std::string block = describe(entry, format, disc, error);
            if(!error.empty()) {
                std::cerr << "FAIL " << label << ": " << error << std::endl;
                ++g_failures;
                continue;
            }

            built << "\n" << block;
        }
    }

    fs::remove_all(work, ec);

    if(g_failures) {
        std::cerr << g_failures << " image(s) could not be built or read back" << std::endl;
        return 1;
    }

    if(regen) {
        std::ofstream out(manifest_path, std::ios::binary);
        if(!out) {
            std::cerr << "could not write " << manifest_path << std::endl;
            return 1;
        }

        out << built.str();
        std::cout << "wrote " << manifest_path << std::endl;
        return 0;
    }

    std::vector<uint8_t> committed_bytes = iso_read::read_whole_file(manifest_path);
    std::string committed((const char*) committed_bytes.data(), committed_bytes.size());

    /* Line endings are whatever git handed over; the manifest is compared as
     * text, not as bytes. */
    committed.erase(std::remove(committed.begin(), committed.end(), '\r'), committed.end());

    std::string actual = built.str();
    actual.erase(std::remove(actual.begin(), actual.end(), '\r'), actual.end());

    if(committed.empty()) {
        std::cerr << "FAIL: no manifest at " << manifest_path << std::endl;
        return 1;
    }

    if(committed != actual) {
        std::cerr << "FAIL: the discs mkdcdisc lays out are not the ones the manifest\n"
                     "records.\n"
                     "\n"
                     "If a layout change was intended, this is its effect. Regenerate with\n"
                     "'meson compile -C builddir regen-disc-manifest' and read the diff: it\n"
                     "shows every session, track and LBA that moved. If none was intended,\n"
                     "something changed the shape of every disc mkdcdisc writes.\n"
                     "\n"
                     "This manifest holds nothing libisofs decides, so a distribution\n"
                     "shipping a different version of it is not an explanation.\n" << std::endl;
        report_difference(committed, actual);
        return 1;
    }

    return 0;
}
