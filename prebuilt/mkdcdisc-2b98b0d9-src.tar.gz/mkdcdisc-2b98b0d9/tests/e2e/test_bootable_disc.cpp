/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* Builds discs a real Dreamcast could boot -- from real SH-4 executables, in
 * every layout and every output format -- and pins what mkdcdisc put on them,
 * as tests/fixtures/bootable-disc-manifest.txt.
 *
 * Every other e2e test builds from tests/fixtures/dummy.bin: 4096 identical
 * bytes. Two things mkdcdisc does cannot be seen through a file like that.
 *
 *   - The ELF path. -e/--main-elf hands the file to elf_parser, which drops the
 *     non-loadable segments and lays the rest out as a raw binary. dummy.bin is
 *     not an ELF, so every -e in tests/e2e/test_cli.cpp is an error path and
 *     that conversion has never run in a test.
 *   - The scrambler. scramble() permutes 32-byte slices within chunks that step
 *     down from 2 MB to 32 bytes; permuting slices of a file whose every byte is
 *     'A' returns the same 4096 bytes. On a binary of about a megabyte the whole
 *     chunk ladder runs and the output really differs from the input.
 *
 * So the payloads here are ordinary Dreamcast programs -- one built against
 * KallistiOS, one with the Katana SDK -- committed prebuilt under
 * tests/payloads/, because no CI target has an SH-4 toolchain and the
 * Katana one cannot be installed on a runner at all. The same arrangement the
 * bundled MR logo has: the maintainer regenerates, the CI consumes.
 *
 * The three ways of supplying that executable are all covered. -e takes the KOS
 * ELF; -b takes the Katana binary unscrambled, so mkdcdisc scrambles it; and -B
 * takes that same binary already scrambled -- which costs no third fixture,
 * since this test links scramble() and can produce it.
 *
 * What is checked, per image: the boot binary is read back out of the finished
 * container, unscrambled where the format scrambles, and required to be exactly
 * the bytes that went in. Across images: one payload must land identically on
 * every disc it is written to, whatever the format or the layout, and the -b
 * and -B routes must arrive at the same bytes. Then the IP.BIN header, and on a
 * GD-ROM that the boot binary is still the last file of the volume -- which a
 * 4 KB dummy could never really put to the test.
 *
 * Reading is done through common/volume_span.h, which shares no arithmetic with
 * the writers. It also assembles the volume across its tracks, which this test
 * needs and the disc manifest does not: on a GD-DA disc the boot binary sorts
 * last and so lives in a closing track several tracks past its own PVD.
 *
 * Nothing libisofs decides is recorded, for the same reason as the disc
 * manifest next door: the four CI targets link four different versions of it.
 * A boot binary's size and contents are the payload's own, and which sector
 * libisofs put it at is not stated.
 *
 * After an intentional change, this fails. Regenerate it and read the diff:
 *
 *     meson compile -C builddir regen-bootable-disc-manifest
 *
 * The same corpus is what `meson compile -C builddir demo-discs` leaves behind
 * for downloading: images that have just been checked, ready to try on a
 * console. Those are truncated GD-ROMs; `demo-discs-full-gdi` builds the
 * GD-ROM half again at full physical size, for an emulator, which will not
 * read a truncated one.
 *
 * Usage: test_bootable_disc <mkdcdisc> <payload-dir> <manifest> [--regen]
 *                           [--keep <dir>] [--full-gdi]
 */

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "../common/digest.h"
#include "../common/disc_read.h"
#include "../common/gdi_verify.h"
#include "../common/iso_read.h"
#include "../common/subprocess.h"
#include "../common/volume_span.h"
#include "third_party/makeip/crc.hpp"
#include "third_party/scramble/scramble.h"

namespace {

namespace fs = std::filesystem;

int g_failures = 0;

void fail(const std::string& label, const std::string& message) {
    std::cerr << "FAIL " << label << ": " << message << std::endl;
    ++g_failures;
}

/* Fixed so that nothing derived from the wall clock or from the host reaches
 * the disc: the release date, the version and the label. The serial is not in
 * here -- one corpus entry deliberately leaves it out, see CorpusEntry -- and
 * neither is -n/--title, which is per-image; see image_id() below. */
const char* const COMMON_ARGS =
    " -a Bootable -r 20200101 -P V1.000 -V BOOTABLE --no-banner -q";

const char* const SERIAL_ARG = " -s T-00000";

/* The name mkdcdisc gives the executable on the disc, and what the IP.BIN
 * header asks the console for. Nothing in the corpus below overrides it. */
const char* const BOOT_NAME = "1ST_READ.BIN";

/* Red Book's minimum track length, four seconds' worth. Spelled out here rather
 * than taken from src/gd_track_plan.hpp: a test that imported the writer's own
 * constant would agree with it by construction, including when it is wrong. */
constexpr uint64_t MIN_TRACK_SECTORS = 300;

/* ------------------------------------------------------------------ */
/* The IP.BIN header                                                   */
/* ------------------------------------------------------------------ */

/* Offsets into the 256-byte header at the very start of a data track's user
 * area. Mirrors IPBin::meta in src/ip_boot.hpp field for field -- spelled out
 * here rather than included, because a reader that took the writer's own struct
 * would agree with it by construction. */
constexpr size_t IP_HARDWARE_ID = 0;
constexpr size_t IP_MAKER_ID = 16;
constexpr size_t IP_DEVICE_INFO = 32;
constexpr size_t IP_PRODUCT_NUMBER = 64;
constexpr size_t IP_PRODUCT_VERSION = 74;
constexpr size_t IP_BOOT_FILENAME = 96;
constexpr size_t IP_HEADER_SIZE = 256;

/* product_number and product_version, adjacent, are what the header's checksum
 * covers; the four uppercase hex digits it produces live in the first bytes of
 * device_info. See update_ipbin_crc() in src/ip_boot.cpp. */
constexpr size_t IP_CRC_SPAN = 16;

std::string ip_field(const std::vector<uint8_t>& header, size_t at, size_t len) {
    if(at + len > header.size()) return {};

    std::string s((const char*) header.data() + at, len);
    while(!s.empty() && (s.back() == ' ' || s.back() == '\0')) s.pop_back();
    return s;
}

/* ------------------------------------------------------------------ */
/* The payloads                                                        */
/* ------------------------------------------------------------------ */

/* One executable, in one of the three forms mkdcdisc accepts it in.
 *
 * Each lives at the root of its environment's folder, beside -- not inside --
 * the disc root that environment ships: mkdcdisc writes the boot binary into
 * the filesystem itself, so a copy sitting in the -D tree as well would be
 * handed to it twice.
 *
 * Named for what it is rather than for what it becomes. The name on the disc is
 * 1ST_READ.BIN, but that is mkdcdisc's to decide -- the IP.BIN header declares
 * it, and --boot-filename changes both together -- so calling the input that
 * would be claiming a decision this file does not make. */
struct Payload {
    std::string id;     /* How the corpus refers to it */
    std::string group;  /* Which binary it ultimately is, whatever the form */
    std::string env;    /* Which folder under tests/payloads/ it comes from */
    std::string flag;   /* -e, -b or -B */
    fs::path path;
    std::string label;  /* "-e kos/1ST_READ.elf", for the manifest */

    /* What the disc must end up carrying, unscrambled -- known outright
     * wherever a binary was supplied, and empty for the ELF, whose conversion
     * to a binary is elf_parser's business and is pinned by digest instead. */
    std::vector<uint8_t> expected;
};

/* The corpus refers to payloads by id; this resolves them, and produces the
 * scrambled form of the Katana binary in the work directory rather than asking
 * for a third committed file.
 *
 * The KallistiOS side is kept as an ELF and the Katana side as a binary because
 * that is what each toolchain hands over: turning the Katana ELF into a binary
 * needs elf2bin from its own SDK, which mkdcdisc has no equivalent of. Between
 * the two, -e and -b are both covered without either being contrived. */
bool load_payloads(const fs::path& payloads, const fs::path& work,
                   std::map<std::string, Payload>& out, std::string& error) {
    fs::path kos_elf = payloads / "kos" / "kos.elf";
    fs::path katana_bin = payloads / "katana" / "katana.bin";

    for(const fs::path& required: {kos_elf, katana_bin}) {
        if(!fs::exists(required)) {
            error = "no payload at " + required.string()
                  + ". Build it from that environment's src/; see"
                    " tests/payloads/README.md.";
            return false;
        }
    }

    std::vector<uint8_t> katana = iso_read::read_whole_file(katana_bin);
    if(katana.empty()) {
        error = "the Katana payload at " + katana_bin.string() + " is empty or unreadable";
        return false;
    }

    /* scramble() takes char, and takes it by non-const reference. */
    std::vector<char> plain((const char*) katana.data(),
                            (const char*) katana.data() + katana.size());
    std::vector<char> scrambled = scramble(plain);

    fs::path katana_scrambled = work / "katana-scrambled.bin";
    {
        std::ofstream f(katana_scrambled, std::ios::binary);
        f.write(scrambled.data(), (std::streamsize) scrambled.size());
        if(!f) {
            error = "could not write " + katana_scrambled.string();
            return false;
        }
    }

    out["kos"] = Payload{
        "kos", "kos", "kos", "-e", kos_elf, "-e kos/kos.elf", {}};
    out["katana"] = Payload{
        "katana", "katana", "katana", "-b", katana_bin, "-b katana/katana.bin", katana};
    out["katana-scrambled"] = Payload{
        "katana-scrambled", "katana", "katana", "-B", katana_scrambled,
        "-B katana/katana.bin (scrambled by the test)", katana};

    return true;
}

/* ------------------------------------------------------------------ */
/* The corpus                                                          */
/* ------------------------------------------------------------------ */

struct CorpusEntry {
    std::string payload;      /* Key into the payload map above */
    std::string name;
    std::string description;

    /* The layout flags only. What goes on the disc is not here: -D comes from
     * the payload's own disc root, and -c from the shared tracks, both worked
     * out in build_entry() below. */
    std::string args;

    /* Writes the two CD-DA tracks from tests/payloads/common/ ahead of the
     * data, which is what the payloads are built to play. */
    bool cdda = false;

    /* Leaves -s/--serial off, so mkdcdisc falls back to hashing the boot
     * binary for it. Only worth doing with a real payload, which is why it
     * appears here and not in the disc manifest. */
    bool default_serial = false;

    std::vector<std::string> formats;
};

/* The disc contents an image is built from: whichever of the payload's two disc
 * roots suits the format. Each environment ships the root for the disc its
 * payload was built for -- the KallistiOS one plays the MIL-CD track numbers
 * and has cd_root, the Katana one plays the GD-DA numbers and has gd_root -- so
 * the corpus below pairs each payload with the formats it has content for. Add
 * the other root to an environment and the missing combinations become
 * available; nothing here has to change but the table. */
fs::path disc_root(const fs::path& payloads, const Payload& payload,
                   const std::string& format) {
    return payloads / payload.env / (format == "gdi" ? "gd_root" : "cd_root");
}

std::vector<CorpusEntry> corpus() {
    return {
        /* The KallistiOS payload, supplied as an ELF, on the disc it was built
         * for: every MIL-CD container, and every MIL-CD layout that puts the
         * boot binary somewhere different. */
        {
            "kos", "milcd",
            "The default MIL-CD, from a KallistiOS ELF, in all three containers",
            " -N", false, false, {"cdi", "mds", "nrg"},
        },
        {
            "kos", "milcd-cdda",
            "The same with the two CD-DA tracks ahead of the data session",
            " -N", true, false, {"cdi"},
        },
        {
            "kos", "milcd-autoserial",
            "The same again with no -s: the serial is then a hash of the binary",
            " -N", false, true, {"cdi"},
        },
        {
            "kos", "datadata",
            "Data/Data, which closes the disc with a boot head carrying no tree",
            " -L data-data -N", false, false, {"cdi"},
        },

        /* The Katana payload, supplied as a binary, on the GD-ROM it was built
         * for. Unscrambled going in, and a GD-ROM wants it unscrambled on the
         * disc too, so mkdcdisc writes it through untouched. */
        {
            "katana", "gdrom",
            "A GD-ROM from an unscrambled Katana binary: the boot binary sorts"
            " last, at the far edge of the volume",
            " --gdi-truncate", false, false, {"gdi"},
        },
        {
            "katana", "gdrom-2048",
            "The same, written as 2048-byte track files instead of raw 2352",
            " --gdi-truncate --gdi-sector-size 2048", false, false, {"gdi"},
        },
        {
            "katana", "gdda",
            "GD-DA: the volume is split around the audio, so the binary ends up"
            " in a track of its own, well past its own PVD",
            " --gdi-truncate", true, false, {"gdi"},
        },

        /* And the same binary once more, already scrambled. A GD-ROM has to
         * unscramble it on the way in, which is the route -B used to be
         * rejected for outright, and the bytes must come out where -b's did. */
        {
            "katana-scrambled", "gdrom",
            "An already-scrambled Katana binary, which a GD-ROM must unscramble"
            " again before writing",
            " --gdi-truncate", false, false, {"gdi"},
        },
    };
}

/* The two CD-DA tracks, in the order they go on the disc. Real music rather
 * than the silence the disc manifest writes and rather than tones generated
 * here: these discs are meant to be played, the payloads are built to start
 * them, and whoever is holding the controller can tell which one is running.
 *
 * Different lengths on purpose -- 2709 sectors and 2448 -- so a swapped or
 * repeated track moves an LBA further down the disc as well as being audible.
 * See tests/payloads/common/README.md for where they come from. */
const char* const CDDA_TRACKS[] = { "wien-bleibt-wien.da", "stargazer.da" };

/* ------------------------------------------------------------------ */
/* Building and reading back                                           */
/* ------------------------------------------------------------------ */

/* What tells one image of the corpus from another: the payload, the layout and
 * the container. It names the directory the image is built in, and it is also
 * the -n/--title the disc carries, so that the title a GDEMU or an emulator like
 * Redream lists it under is the name of the folder it was downloaded in.
 *
 * Without it every image of the corpus announced itself the same way, and a
 * console showing eight identical entries could not say which one was about to
 * boot. The name only reaches the IP.BIN header: -V is given separately and
 * fixed, so the volume label stays the same across the corpus. */
std::string image_id(const Payload& payload, const CorpusEntry& entry,
                     const std::string& format) {
    return payload.id + "-" + entry.name + "-" + format;
}

/* Builds one corpus entry in one format. Each lands in a directory of its own,
 * so a GD-ROM's track set has somewhere to go and nothing can be picked up from
 * a neighbour. */
disc_read::Disc build_entry(const std::string& mkdcdisc, const Payload& payload,
                            const fs::path& payloads, const CorpusEntry& entry,
                            const std::string& format, const fs::path& out_dir,
                            bool full_gdi, std::string& error) {
    fs::path entry_dir = out_dir / image_id(payload, entry, format);

    std::error_code ec;
    fs::remove_all(entry_dir, ec);
    fs::create_directories(entry_dir, ec);

    fs::path output = entry_dir / ("disc." + format);
    fs::path root = disc_root(payloads, payload, format);

    if(!fs::is_directory(root)) {
        error = "no disc contents at " + root.string()
              + ", which is what this image would be built from";
        return {};
    }

    std::string contents = " -D " + quote(root.string());

    if(entry.cdda) {
        for(const char* track: CDDA_TRACKS) {
            fs::path path = payloads / "common" / track;
            if(!fs::exists(path)) {
                error = "no CD-DA track at " + path.string();
                return {};
            }

            contents += " -c " + quote(path.string());
        }
    }

    /* A full-size build is the same image with --gdi-truncate taken back out. The
     * flag is stripped here rather than removed from the corpus table so that
     * entry.args stays the one string both the build and the manifest read: a
     * normal run has to come out byte-identical to the committed manifest,
     * which prints entry.args verbatim. */
    std::string args = entry.args;
    if(full_gdi) {
        const std::string flag = " --gdi-truncate";
        size_t at = args.find(flag);
        if(at != std::string::npos) {
            args.erase(at, flag.size());
        }
    }

    /* -F is given explicitly rather than left to the extension: the manifest
     * says which format each block describes, and it should be describing the
     * one it asked for. */
    std::string command = quote(mkdcdisc) + " " + payload.flag + " " + quote(payload.path.string())
                        + contents + args + COMMON_ARGS
                        + " -n " + quote(image_id(payload, entry, format))
                        + (entry.default_serial ? "" : SERIAL_ARG)
                        + " -F " + format + " -o " + quote(output.string());

    RunResult result = run(command);
    if(result.exit_code != 0) {
        error = "mkdcdisc exited " + std::to_string(result.exit_code) + ": " + result.output;
        return {};
    }

    if(!fs::exists(output)) {
        error = "no image at " + output.string() + "; mkdcdisc said: " + result.output;
        return {};
    }

    disc_read::Disc disc = disc_read::read(output);
    if(!disc.valid) {
        error = "the image could not be read back:";
        for(const auto& message: disc.errors) error += "\n    " + message;
    }

    return disc;
}

/* What a console would find on the finished disc. */
struct BootBinary {
    std::vector<uint8_t> on_disc; /* Exactly the bytes the file holds */
    std::vector<uint8_t> plain;   /* The same, unscrambled where the format scrambles */

    /* The boot binary's extent is the highest of any file in the volume. What
     * mkdcdisc's sort weight arranges for a GD-ROM, and what stops the binary
     * from landing where a console cannot reliably read it. */
    bool last_in_volume = false;

    std::vector<uint8_t> ip_header; /* The 256 bytes at the head of the volume */
};

bool read_boot_binary(const disc_read::Disc& disc, bool scrambled, BootBinary& out,
                      std::string& error) {
    std::vector<volume_span::Span> volumes;
    if(!volume_span::find(disc, volumes, error)) return false;

    /* The volume the console boots from is the last one on the disc that has a
     * directory tree behind its descriptors. On a GD-ROM that is the
     * high-density area rather than the low-density one; on a Data/Data image
     * it steps back over the closing boot head, whose PVD describes a
     * filesystem the track does not carry. */
    const volume_span::Span* boot = nullptr;
    for(const auto& span: volumes) {
        if(span.volume.has_tree()) boot = &span;
    }

    if(!boot) {
        error = "no volume on the disc carries a directory tree";
        return false;
    }

    std::vector<uint8_t> window = volume_span::window(disc, *boot);
    uint32_t base = volume_span::base_lba(disc, *boot);

    if(window.size() >= IP_HEADER_SIZE) {
        out.ip_header.assign(window.begin(), window.begin() + IP_HEADER_SIZE);
    }

    std::string path = std::string("/") + BOOT_NAME;
    std::string bytes = iso_read::file_bytes(window, path, base);
    if(bytes.empty()) {
        error = "no " + path + " could be read out of the volume on track "
              + std::to_string(disc.tracks[boot->anchor].number);
        return false;
    }

    out.on_disc.assign(bytes.begin(), bytes.end());

    if(scrambled) {
        std::vector<char> stored(bytes.begin(), bytes.end());
        std::vector<char> restored = unscramble(stored);
        out.plain.assign(restored.begin(), restored.end());
    } else {
        out.plain = out.on_disc;
    }

    uint32_t highest = 0;
    uint32_t boot_lba = 0;
    for(const auto& item: iso_read::list_tree(window, base)) {
        if(item.is_dir) continue;
        if(item.lba > highest) highest = item.lba;
        if(item.path == path) boot_lba = item.lba;
    }

    out.last_in_volume = (boot_lba != 0 && boot_lba == highest);

    return true;
}

/* ------------------------------------------------------------------ */
/* The manifest                                                        */
/* ------------------------------------------------------------------ */

std::string describe(const Payload& payload, const CorpusEntry& entry,
                     const std::string& format, bool scrambled, const BootBinary& boot) {
    std::ostringstream out;

    out << "## " << payload.id << " / " << entry.name << " / " << format << "\n";
    out << "# " << entry.description << "\n";
    out << "input        : " << payload.label << "\n";
    out << "args         :" << entry.args << (entry.default_serial ? "   (no -s)" : "") << "\n";

    out << "boot file    : /" << BOOT_NAME << ", " << boot.on_disc.size() << " bytes\n";
    out << "on-disc      : " << (scrambled ? "scrambled" : "plain")
        << ", digest " << digest::of(boot.on_disc) << "\n";

    /* Only where the two differ. On a GD-ROM the binary is written as it is,
     * and a second identical digest would be a line saying nothing. */
    if(scrambled) {
        out << "unscrambled  : digest " << digest::of(boot.plain) << "\n";
    }

    out << "ip.bin       : " << ip_field(boot.ip_header, IP_HARDWARE_ID, 16)
        << " / " << ip_field(boot.ip_header, IP_MAKER_ID, 16)
        << ", serial " << ip_field(boot.ip_header, IP_PRODUCT_NUMBER, 10)
        << ", version " << ip_field(boot.ip_header, IP_PRODUCT_VERSION, 6)
        << ", boot " << ip_field(boot.ip_header, IP_BOOT_FILENAME, 16) << "\n";

    /* The header's own checksum, recomputed and compared against the four hex
     * digits it carries. A serial or version that reached the header without
     * the checksum being redone shows up here and nowhere else. */
    out << "ip.bin crc   : ";
    if(boot.ip_header.size() < IP_HEADER_SIZE) {
        out << "no header to check";
    } else {
        uint16_t computed = makeip::calc_crc(boot.ip_header.data() + IP_PRODUCT_NUMBER,
                                             IP_CRC_SPAN);
        char expected[5];
        std::snprintf(expected, sizeof(expected), "%04X", computed);

        std::string declared((const char*) boot.ip_header.data() + IP_DEVICE_INFO, 4);
        out << (declared == expected ? "ok" : "MISMATCH: header says " + declared
                                            + ", computed " + expected);
    }
    out << "\n";

    /* Only for a GD-ROM. There, mkdcdisc weights the boot binary so it sorts
     * last, and where it sits is mkdcdisc's decision and worth pinning. On a
     * MIL-CD nothing weights it, so the answer would be libisofs's and would
     * differ across the CI targets. */
    if(format == "gdi") {
        out << "placement    : " << (boot.last_in_volume ? "last file of the volume"
                                                         : "NOT the last file of the volume")
            << "\n";
    }

    return out.str();
}

void report_difference(const std::string& expected, const std::string& actual) {
    std::istringstream want(expected), got(actual);
    std::string want_line, got_line;

    size_t line = 0;
    size_t shown = 0;
    const size_t MAX_SHOWN = 40;

    while(shown < MAX_SHOWN) {
        bool has_want = (bool) std::getline(want, want_line);
        bool has_got = (bool) std::getline(got, got_line);
        if(!has_want && !has_got) break;

        ++line;
        if(!has_want) want_line = "(end of manifest)";
        if(!has_got) got_line = "(end of output)";

        if(want_line != got_line) {
            std::cerr << "  line " << line << ":\n"
                      << "    committed: " << want_line << "\n"
                      << "    built    : " << got_line << std::endl;
            ++shown;
        }
    }

    if(shown == MAX_SHOWN) {
        std::cerr << "  ... more differences follow" << std::endl;
    }
}

} // namespace

int main(int argc, char** argv) {
    if(argc < 4) {
        std::cerr << "usage: test_bootable_disc <mkdcdisc> <payload-dir> <manifest>"
                     " [--regen] [--keep <dir>] [--full-gdi]" << std::endl;
        return 1;
    }

    /* On Windows, run() shells out via cmd.exe (_popen), which fails to resolve
     * forward-slash relative paths like "./mkdcdisc.exe" -- the form Meson
     * passes when the exe lives in the test's working directory. */
    std::string mkdcdisc = fs::path(argv[1]).make_preferred().string();
    fs::path payloads = argv[2];
    fs::path manifest_path = argv[3];

    bool regen = false;
    bool full_gdi = false;
    fs::path keep;

    for(int i = 4; i < argc; ++i) {
        if(std::strcmp(argv[i], "--regen") == 0) {
            regen = true;
        } else if(std::strcmp(argv[i], "--full-gdi") == 0) {
            full_gdi = true;
        } else if(std::strcmp(argv[i], "--keep") == 0 && i + 1 < argc) {
            keep = argv[++i];
        }
    }

    /* --full-gdi builds the GD-ROM half of the corpus at its full physical
     * size, for testing on something that will not read a truncated .gdi --
     * nullDC and Demul among them. It is the corpus and the same checks, only
     * without --gdi-truncate, so what comes out has been verified the same way.
     *
     * GD-ROM entries only: padding is a GD-ROM question, and the MIL-CD entries
     * already boot everywhere as they are. Dropping their -N would grow six
     * images to the full CD size for nothing.
     *
     * It writes no manifest and compares against none. The manifest describes
     * the whole corpus in its normal shape, and this run is neither. */
    if(full_gdi && regen) {
        std::cerr << "--full-gdi and --regen are mutually exclusive: a full-size run"
                     " builds only part of the corpus, so it cannot write the manifest"
                  << std::endl;
        return 1;
    }

    if(full_gdi && keep.empty()) {
        std::cerr << "--full-gdi needs --keep <dir>: it writes some 4.8 GiB and"
                     " deleting that again on the way out would be the whole cost for"
                     " none of the benefit." << std::endl;
        return 1;
    }

    /* No timestamp reaches a boot binary, so this is not what makes the
     * manifest possible. It is set anyway: a build that took the clock into
     * account would be a change worth failing on wherever it showed up. */
    set_env("SOURCE_DATE_EPOCH", "946684800");  /* 2000-01-01T00:00:00Z */
    set_env("TZ", "UTC");

    /* --keep names where the images are to be left; without it they go to a
     * scratch directory that is removed on the way out. */
    fs::path work = keep.empty()
        ? fs::temp_directory_path() /
              ("mkdcdisc-bootable-disc-" + std::to_string((unsigned long) GETPID()))
        : keep;

    std::error_code ec;
    fs::remove_all(work, ec);
    fs::create_directories(work, ec);

    std::map<std::string, Payload> loaded;
    std::string error;
    if(!load_payloads(payloads, work, loaded, error)) {
        std::cerr << "FAIL: " << error << std::endl;
        return 1;
    }

    std::ostringstream built;
    built << "# mkdcdisc bootable-disc manifest -- what a real payload ends up as on\n"
             "# a disc, in every layout and every format.\n"
             "#\n"
             "# Regenerate with:  meson compile -C builddir regen-bootable-disc-manifest\n"
             "# Do not edit by hand. See tests/e2e/test_bootable_disc.cpp for what each\n"
             "# field means and why a change here needs explaining.\n"
             "#\n"
             "# The executables come from tests/payloads/, built by hand against\n"
             "# KallistiOS and the Katana SDK and committed prebuilt: no CI target has an\n"
             "# SH-4 toolchain. They are supplied to mkdcdisc all three ways it accepts\n"
             "# one -- -e an ELF, -b a plain binary, -B an already-scrambled one.\n"
             "#\n"
             "#   boot file    the file a console would load, and its size\n"
             "#   on-disc      the bytes as stored, scrambled where the format wants it\n"
             "#   unscrambled  the same bytes restored; must be what went in\n"
             "#   ip.bin       the header fields the console reads, and its checksum\n"
             "#   placement    GD-ROM only: the boot binary must sort last\n"
             "#\n"
             "# Every value below is one mkdcdisc decides, so this file is the same on\n"
             "# every platform. Where libisofs put the file is not stated, and neither\n"
             "# is anything sized by the filesystem.\n";

    /* One payload must arrive intact and identical wherever it is written. The
     * first image carrying it sets the answer and every later one is held to
     * it, which is how a format-specific corruption is caught: it makes cdi
     * disagree with gdi about a file neither of them was supposed to alter. */
    std::map<std::string, std::vector<uint8_t>> landed;
    std::map<std::string, std::string> landed_from;

    for(const auto& entry: corpus()) {
        auto found = loaded.find(entry.payload);
        if(found == loaded.end()) {
            fail(entry.payload + "/" + entry.name, "no such payload");
            continue;
        }

        const Payload& payload = found->second;

        for(const auto& format: entry.formats) {
            if(full_gdi && format != "gdi") continue;

            std::string label = payload.id + "/" + entry.name + "/" + format;

            /* MIL-CD carries a scrambled boot binary, a GD-ROM a plain one --
             * whichever of -e/-b/-B it arrived as. */
            bool scrambled = (format != "gdi");

            std::string build_error;
            disc_read::Disc disc = build_entry(mkdcdisc, payload, payloads, entry, format,
                                               work, full_gdi, build_error);
            if(!build_error.empty()) {
                fail(label, build_error);
                continue;
            }

            /* A full-size image is checked by gdi_verify instead, which reads
             * the .gdi structurally and seeks to what it needs. The checks
             * below cannot see one: they work from volume_span::window(), and
             * every read in tests/common is capped at MAX_TRACK_SECTORS -- 8192
             * against the 504150 a full high-density area spans -- so the boot
             * binary, which sorts to the far end of the volume, falls outside
             * the window and reads as missing. Raising that cap would put a
             * gigabyte buffer behind every test in the suite for this one case.
             *
             * gdi_verify is what tests/e2e/test_gdi_padded.cpp uses for the same
             * reason, and it checks the thing that matters here: the track
             * layout, and the boot binary landing last, TRACK_RUN_OUT sectors
             * before the end of the area. */
            if(full_gdi) {
                fs::path image = work / image_id(payload, entry, format) / ("disc." + format);
                std::vector<std::string> errors = gdi_verify::verify(image);
                for(const auto& message: errors) {
                    fail(label, message);
                }

                continue;
            }

            BootBinary boot;
            if(!read_boot_binary(disc, scrambled, boot, build_error)) {
                fail(label, build_error);
                continue;
            }

            /* Where the input was a binary, the disc must carry exactly it.
             * The ELF has no such answer to compare against -- producing one
             * would mean a second elf_parser -- so its conversion is pinned by
             * the digest in the manifest instead. */
            if(!payload.expected.empty() && boot.plain != payload.expected) {
                fail(label, "the boot binary on the disc is not the one supplied: "
                            + std::to_string(payload.expected.size()) + " bytes in, "
                            + std::to_string(boot.plain.size()) + " bytes back");
            }

            auto seen = landed.find(payload.group);
            if(seen == landed.end()) {
                landed[payload.group] = boot.plain;
                landed_from[payload.group] = label;
            } else if(seen->second != boot.plain) {
                fail(label, "this disc carries different bytes for the " + payload.group
                          + " payload than " + landed_from[payload.group] + " did");
            }

            /* No GD-ROM track may fall under the Red Book minimum. Not one of
             * the 25 reference dumps does -- the floor is reached exactly, on
             * data tracks as well as audio -- and GD-ROM Explorer refuses an
             * image where one does, which is how this was found. Nothing here
             * asserted it before: neither manifest states a data track's
             * length, since that is libisofs's to decide, so a GD-DA disc whose
             * zone had been cut into pieces below the floor read as perfectly
             * correct.
             *
             * Only for -F gdi, because only a GD-ROM's zone gets cut up. A
             * MIL-CD's tracks are whole by construction -- there is nothing to
             * split them around -- so the failure this guards against cannot
             * arise there, and its data track's own length is a separate
             * question that this is not the place to answer.
             *
             * The length is the track's own, not the filesystem's, so this
             * holds on every platform. */
            if(format == "gdi") {
                for(const auto& track: disc.tracks) {
                    if(track.sectors >= MIN_TRACK_SECTORS) continue;

                    fail(label, "track " + std::to_string(track.number) + " is "
                              + std::to_string(track.sectors) + " sectors, under the "
                              + std::to_string(MIN_TRACK_SECTORS) + "-sector minimum every"
                                " reference dump observes and GD-ROM tooling enforces");
                }
            }

            if(format == "gdi" && !boot.last_in_volume) {
                fail(label, "the boot binary is not the last file of the high-density"
                            " volume, so a console may not be able to read it");
            }

            built << "\n" << describe(payload, entry, format, scrambled, boot);
        }
    }

    if(keep.empty()) {
        fs::remove_all(work, ec);
    } else {
        std::cout << "images left in " << work << std::endl;
    }

    if(g_failures) {
        std::cerr << g_failures << " image(s) failed" << std::endl;
        return 1;
    }

    /* Nothing to hold a full-size run to: it built four of the ten images, in a
     * shape the manifest does not describe. The per-image checks above are what
     * it is verified by, and they have already run. */
    if(full_gdi) {
        return 0;
    }

    if(regen) {
        std::ofstream out(manifest_path, std::ios::binary);
        if(!out) {
            std::cerr << "could not write " << manifest_path << std::endl;
            return 1;
        }

        out << built.str();
        std::cout << "wrote " << manifest_path << std::endl;
        return 0;
    }

    std::vector<uint8_t> committed_bytes = iso_read::read_whole_file(manifest_path);
    std::string committed((const char*) committed_bytes.data(), committed_bytes.size());

    /* Line endings are whatever git handed over; the manifest is compared as
     * text, not as bytes. */
    committed.erase(std::remove(committed.begin(), committed.end(), '\r'), committed.end());

    std::string actual = built.str();
    actual.erase(std::remove(actual.begin(), actual.end(), '\r'), actual.end());

    if(committed.empty()) {
        std::cerr << "FAIL: no manifest at " << manifest_path << std::endl;
        return 1;
    }

    if(committed != actual) {
        std::cerr << "FAIL: the discs mkdcdisc builds from these payloads are not the\n"
                     "ones the manifest records.\n"
                     "\n"
                     "If the change was intended, this is its effect. Regenerate with\n"
                     "'meson compile -C builddir regen-bootable-disc-manifest' and read the\n"
                     "diff.\n"
                     "\n"
                     "This manifest holds nothing libisofs decides, so a distribution\n"
                     "shipping a different version of it is not an explanation.\n" << std::endl;
        report_difference(committed, actual);
        return 1;
    }

    return 0;
}
