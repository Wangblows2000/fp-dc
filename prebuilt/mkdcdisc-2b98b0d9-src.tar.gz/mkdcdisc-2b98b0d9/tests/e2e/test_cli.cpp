/* mkdcdisc - Sega Dreamcast Disc Image Generator
 *
 * SPDX-License-Identifier: MIT
 * Copyright (C) 2022-2026 Simulant and contributors
 * (https://www.simulant.dev/) */

/* End-to-end tests: run the actual built mkdcdisc binary and validate the
 * CDI/MDS/MDF/NRG files it produces, plus a few argument-validation error
 * paths. Structural checks intentionally avoid depending on internal
 * writer details beyond what's documented as stable file-format facts
 * (see the unit tests in tests/unit for the rationale).
 *
 * Usage: test_cli <path-to-mkdcdisc> <path-to-fixture-binary>
 */

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "../common/gdi_verify.h"
#include "../common/iso_read.h"
#include "../common/subprocess.h"

static int g_failures = 0;

#define CHECK(cond) do { \
    if(!(cond)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << ": " << #cond << std::endl; \
        g_failures++; \
    } \
} while(0)

/* Like CHECK, but prints what the command actually said. An exit code on its
 * own tells you nothing about why mkdcdisc refused, which is exactly what is
 * missing when a failure only reproduces on a CI runner. */
#define CHECK_RUN(result, cond) do { \
    if(!(cond)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << ": " << #cond \
                  << "\n  exit code: " << (result).exit_code \
                  << "\n  output: " << (result).output << std::endl; \
        g_failures++; \
    } \
} while(0)

/* Pulls the first run of digits out of `s`, or -1 if there isn't one */
static long parse_first_integer(const std::string& s) {
    size_t i = 0;
    while(i < s.size() && !std::isdigit((unsigned char) s[i])) ++i;
    size_t j = i;
    while(j < s.size() && std::isdigit((unsigned char) s[j])) ++j;
    if(i == j) return -1;
    return std::stol(s.substr(i, j - i));
}

/* Collapses every run of whitespace, line breaks included, into single spaces.
 * Diagnostics are word-wrapped at term::WRAP_WIDTH, and where the breaks fall
 * depends on how long the paths inside them happen to be -- which varies with
 * the temporary directory a given run was handed, and so with the platform the
 * suite runs on. Flattening lets a test name a message the way it is written in
 * the source rather than the way it came out of one particular run. */
static std::string flatten(const std::string& text) {
    std::string out;
    bool pending_space = false;

    for(char c: text) {
        if(std::isspace((unsigned char) c)) {
            pending_space = true;
            continue;
        }

        if(pending_space && !out.empty()) {
            out += ' ';
        }

        pending_space = false;
        out += c;
    }

    return out;
}

/* Whether `output` contains `message`, regardless of where it was wrapped. */
static bool says(const std::string& output, const std::string& message) {
    return flatten(output).find(flatten(message)) != std::string::npos;
}

static size_t count_occurrences(const std::string& haystack, const std::string& needle) {
    size_t count = 0;
    for(size_t at = haystack.find(needle); at != std::string::npos;
        at = haystack.find(needle, at + needle.size())) {
        ++count;
    }
    return count;
}

static uint32_t read_u32_le(std::ifstream& f, std::streamoff pos) {
    f.seekg(pos);
    uint8_t b[4] = {0};
    f.read(reinterpret_cast<char*>(b), 4);
    return (uint32_t) b[0] | ((uint32_t) b[1] << 8) | ((uint32_t) b[2] << 16) | ((uint32_t) b[3] << 24);
}

/* Same "last 4 bytes point back at a leading session-count byte" check as
 * tests/unit/test_cdi_structure.c, run against a file mkdcdisc actually
 * wrote to disk. */
static bool check_cdi_session_count(const std::filesystem::path& path, uint8_t expected) {
    std::ifstream f(path, std::ios::binary);
    if(!f) return false;

    f.seekg(0, std::ios::end);
    std::streamoff size = f.tellg();
    if(size < 4) return false;

    uint32_t header_offset = read_u32_le(f, size - 4);
    if(header_offset <= 4 || (std::streamoff) header_offset >= size) return false;

    std::streamoff header_start = size - (std::streamoff) header_offset;
    f.seekg(header_start);
    uint8_t session_count = 0xFF;
    f.read(reinterpret_cast<char*>(&session_count), 1);

    return session_count == expected;
}

static bool check_mds_header(const std::filesystem::path& path, uint16_t expected_sessions) {
    std::ifstream f(path, std::ios::binary);
    if(!f) return false;

    char magic[16] = {0};
    f.read(magic, sizeof(magic));
    if(std::memcmp(magic, "MEDIA DESCRIPTOR", 16) != 0) return false;

    uint8_t version[2] = {0};
    f.read(reinterpret_cast<char*>(version), sizeof(version));
    if(version[0] != 1 || version[1] != 4) return false;

    f.seekg(0x14);
    uint8_t sc[2] = {0};
    f.read(reinterpret_cast<char*>(sc), sizeof(sc));
    uint16_t session_count = (uint16_t) sc[0] | ((uint16_t) sc[1] << 8);

    return session_count == expected_sessions;
}

static uint32_t read_u32_be(std::ifstream& f, std::streamoff pos) {
    f.seekg(pos);
    uint8_t b[4] = {0};
    f.read(reinterpret_cast<char*>(b), 4);
    return ((uint32_t) b[0] << 24) | ((uint32_t) b[1] << 16) | ((uint32_t) b[2] << 8) | (uint32_t) b[3];
}

static uint64_t read_u64_be(std::ifstream& f, std::streamoff pos) {
    return ((uint64_t) read_u32_be(f, pos) << 32) | (uint64_t) read_u32_be(f, pos + 4);
}

/* Walks the "NER5" footer -> chunk chain -> "END!" of a real .nrg file,
 * counting SINF chunks (one per session), per the layout documented at the
 * top of nrg.c. */
static bool check_nrg_session_count(const std::filesystem::path& path, uint32_t expected_sessions) {
    std::ifstream f(path, std::ios::binary);
    if(!f) return false;

    f.seekg(0, std::ios::end);
    std::streamoff size = f.tellg();
    if(size < 12) return false;

    char footer_id[4] = {0};
    f.seekg(size - 12);
    f.read(footer_id, 4);
    if(std::memcmp(footer_id, "NER5", 4) != 0) return false;

    uint64_t offset = read_u64_be(f, size - 8);
    if(offset == 0 || (std::streamoff) offset >= size - 12) return false;

    uint32_t session_count = 0;
    while((std::streamoff) offset < size - 12) {
        char chunk_id[4] = {0};
        f.seekg((std::streamoff) offset);
        f.read(chunk_id, 4);
        uint32_t chunk_size = read_u32_be(f, (std::streamoff) offset + 4);

        if(std::memcmp(chunk_id, "END!", 4) == 0) break;
        if(std::memcmp(chunk_id, "SINF", 4) == 0) session_count++;

        offset += 8 + chunk_size;
    }

    return session_count == expected_sessions;
}

/* Maps an offset within a data track's user data to its offset in the track
 * file. They're the same for a 2048-byte-sector track, but a raw 2352-byte
 * Mode 1 sector prefixes each 2048-byte user area with a 16-byte sync +
 * header block. */
static std::streamoff gdi_file_offset(std::streamoff user_offset, unsigned sector_size) {
    if(sector_size == 2048) {
        return user_offset;
    }

    std::streamoff sector = user_offset / 2048;
    return sector * 2352 + 16 + (user_offset % 2048);
}

/* Validates the high-density-session TOC embedded in a GD-ROM's IP.BIN, at
 * system-area offset 0x100 of track03 (where the IP.BIN user data begins).
 * Checks the "TOC1" magic, the single data-track entry at LBA 45000, and the
 * first/last track-number words -- the exact bytes a real Sega disc carries
 * and that TOC-validating tools (e.g. GD-ROM Explorer) reject when absent. */
static bool check_gdi_ipbin_toc(const std::filesystem::path& track03, unsigned sector_size) {
    std::ifstream f(track03, std::ios::binary);
    if(!f) return false;

    char magic[4] = {0};
    f.seekg(gdi_file_offset(0x100, sector_size));
    f.read(magic, 4);
    if(std::memcmp(magic, "TOC1", 4) != 0) return false;

    /* entry[0] @ 0x104: CTRL=4 (data), ADR=1, FAD = 45000 + 150 = 45150 */
    uint32_t entry0 = read_u32_le(f, gdi_file_offset(0x104, sector_size));
    if(entry0 != ((4u << 28) | (1u << 24) | 45150u)) return false;

    /* first @ 0x288 / last @ 0x28C: CTRL=4, ADR=1, track number 3 */
    uint32_t first = read_u32_le(f, gdi_file_offset(0x288, sector_size));
    uint32_t last = read_u32_le(f, gdi_file_offset(0x28C, sector_size));
    uint32_t expected_point = (4u << 28) | (1u << 24) | (3u << 16);
    return first == expected_point && last == expected_point;
}

/* Validates the low-density boot image (IP0000.BIN) at the start of track01:
 * it must carry the SEGA header (so the disc self-identifies) but, unlike the
 * high-density IP.BIN, must NOT carry a TOC ("TOC1") at 0x100. */
static bool check_gdi_ld_bootheader(const std::filesystem::path& track01, unsigned sector_size) {
    std::ifstream f(track01, std::ios::binary);
    if(!f) return false;

    char hdr[16] = {0};
    f.seekg(gdi_file_offset(0, sector_size));
    f.read(hdr, 16);
    if(std::memcmp(hdr, "SEGA SEGAKATANA ", 16) != 0) return false;

    char toc[4] = {0};
    f.seekg(gdi_file_offset(0x100, sector_size));
    f.read(toc, 4);
    return std::memcmp(toc, "TOC1", 4) != 0; /* LD image has no TOC */
}

/* The 32K boot image at the start of a GD-ROM data track (IP.BIN on the
 * high-density one, IP0000.BIN on the low-density one), read back as plain
 * user data whatever the track's sector size. Empty if the track is short or
 * unreadable, which every caller checks before comparing. */
static std::vector<uint8_t> read_gdi_boot_image(const std::filesystem::path& track, unsigned sector_size) {
    std::ifstream f(track, std::ios::binary);
    if(!f) return {};

    std::vector<uint8_t> out(32768);
    for(size_t sector = 0; sector < 16; ++sector) {
        f.seekg(gdi_file_offset(sector * 2048, sector_size));
        if(!f.read((char*) out.data() + sector * 2048, 2048)) return {};
    }

    return out;
}

/* Every data track on a pressed GD-ROM ends with 150 sectors carrying no file
 * content -- the track's run-out. Checks that a data track's last 150 sectors
 * have an all-zero user area.
 *
 * This is what stops 1ST_READ.BIN, which sorts last, from being written into
 * the run-out: a real drive can fail to read that region back, which is why an
 * image whose boot binary lands there can pass every structural check and
 * still fail to boot on hardware while working fine in an emulator. */
static bool check_gdi_reserved_tail(const std::filesystem::path& track, unsigned sector_size) {
    const std::uintmax_t reserved_sectors = 150;

    auto size = std::filesystem::file_size(track);
    if(size % sector_size != 0) return false;

    auto total_sectors = size / sector_size;
    if(total_sectors < reserved_sectors) return false;

    std::ifstream f(track, std::ios::binary);
    if(!f) return false;

    for(auto s = total_sectors - reserved_sectors; s < total_sectors; ++s) {
        char user[2048] = {0};
        f.seekg(gdi_file_offset((std::streamoff) (s * 2048), sector_size));
        f.read(user, sizeof(user));
        if(!f) return false;

        for(char c: user) {
            if(c != 0) return false;
        }
    }

    return true;
}

/* Reads the 2048-byte user area of one absolute-LBA sector of the
 * high-density data track (which starts at CD_GD_START_LBA). */
static bool read_hd_sector(std::ifstream& f, uint32_t lba, unsigned sector_size, char out[2048]) {
    if(lba < 45000) return false;
    f.seekg(gdi_file_offset((std::streamoff) (lba - 45000) * 2048, sector_size));
    f.read(out, 2048);
    return (bool) f;
}

static uint32_t le32(const char* p) {
    return (uint32_t) (uint8_t) p[0] | ((uint32_t) (uint8_t) p[1] << 8)
         | ((uint32_t) (uint8_t) p[2] << 16) | ((uint32_t) (uint8_t) p[3] << 24);
}

/* Checks that `boot_name` is the last file of the high-density filesystem, ending
 * exactly 150 sectors before the end of the track.
 *
 * This is the placement every commercial GD-ROM uses and that the console
 * relies on. It is easy to get backwards: libisofs sorts HIGH weights towards
 * LOW block addresses, so pinning a file last means giving it the lowest
 * weight. With the comparison inverted the boot binary lands at the *start* of
 * the zone instead, which no structural check on the .gdi or the TOC would
 * catch -- only reading the filesystem, as this does. */
static bool check_gdi_boot_file_last(const std::filesystem::path& track03, unsigned sector_size,
                                     const std::string& boot_name) {
    std::ifstream f(track03, std::ios::binary);
    if(!f) return false;

    char pvd[2048];
    if(!read_hd_sector(f, 45000 + 16, sector_size, pvd)) return false;
    if(std::memcmp(pvd + 1, "CD001", 5) != 0) return false;

    uint32_t root_lba = le32(pvd + 156 + 2);
    uint32_t root_len = le32(pvd + 156 + 10);

    std::string target = boot_name + ";1";

    for(uint32_t s = 0; s * 2048 < root_len; ++s) {
        char dir[2048];
        if(!read_hd_sector(f, root_lba + s, sector_size, dir)) return false;

        for(size_t off = 0; off + 33 < sizeof(dir);) {
            unsigned rec_len = (unsigned char) dir[off];
            if(rec_len == 0) break;

            unsigned name_len = (unsigned char) dir[off + 32];
            if(off + 33 + name_len <= sizeof(dir)
                && target.size() == name_len
                && std::memcmp(dir + off + 33, target.data(), name_len) == 0) {

                uint32_t extent = le32(dir + off + 2);
                uint32_t bytes = le32(dir + off + 10);
                uint32_t ends_at = extent + (bytes + 2047) / 2048;

                auto track_sectors = std::filesystem::file_size(track03) / sector_size;
                uint32_t track_end = 45000 + (uint32_t) track_sectors;

                return ends_at + 150 == track_end;
            }

            off += rec_len;
        }
    }

    return false; /* boot file not found at the root of the data track */
}

/* Validates the low-density area's ISO9660 filesystem: a PVD at sector 16
 * (the IP0000.BIN system area occupies sectors 0-15 ahead of it), the three
 * file identifier fields, and the matching non-empty files at the root.
 *
 * All 18 reference dumps carry these three in the LDA and leave the same
 * fields empty in the high-density PVD, so this is what separates a track01
 * that looks like a real disc's from a zero-filled placeholder. */
static bool check_gdi_lda_filesystem(const std::filesystem::path& track01, unsigned sector_size,
                                     uint32_t expected_volume_space) {
    std::ifstream f(track01, std::ios::binary);
    if(!f) return false;

    char pvd[2048];
    f.seekg(gdi_file_offset(16 * 2048, sector_size));
    f.read(pvd, sizeof(pvd));
    if(!f || std::memcmp(pvd + 1, "CD001", 5) != 0) return false;

    /* Declares the whole low-density area (track 1 + pregap + track 2),
     * not just this filesystem, as every reference dump does. */
    if(le32(pvd + 80) != expected_volume_space) return false;

    auto field = [&](size_t off) {
        std::string s(pvd + off, 37);
        while(!s.empty() && (s.back() == ' ' || s.back() == '\0')) s.pop_back();
        return s;
    };

    if(field(702) != "COPYRIGH.TXT") return false;
    if(field(739) != "ABSTRACT.TXT") return false;
    if(field(776) != "BIBLIOGR.TXT") return false;

    uint32_t root_lba = le32(pvd + 156 + 2);
    uint32_t root_len = le32(pvd + 156 + 10);

    unsigned found = 0;
    for(uint32_t s = 0; (uint32_t) s * 2048 < root_len; ++s) {
        char dir[2048];
        f.seekg(gdi_file_offset((std::streamoff) (root_lba + s) * 2048, sector_size));
        f.read(dir, sizeof(dir));
        if(!f) return false;

        for(size_t off = 0; off + 33 < sizeof(dir);) {
            unsigned rec_len = (unsigned char) dir[off];
            if(rec_len == 0) break;

            unsigned name_len = (unsigned char) dir[off + 32];
            if(off + 33 + name_len > sizeof(dir)) break;

            std::string name(dir + off + 33, name_len);
            if((name == "COPYRIGH.TXT;1" || name == "ABSTRACT.TXT;1" || name == "BIBLIOGR.TXT;1")
                && le32(dir + off + 10) > 0) {
                ++found;
            }

            off += rec_len;
        }
    }

    return found == 3;
}

/* Runs the shared structural verifier over a produced .gdi and reports every
 * rule it broke. Unlike the single-file checks below, this one resolves LBAs
 * through the whole track map, so it still works once the filesystem spans
 * two data tracks with GD-DA between them. */
static bool check_gdi_valid(const std::filesystem::path& gdi) {
    auto errors = gdi_verify::verify(gdi);

    for(const auto& error: errors) {
        std::cerr << "  gdi-verify: " << error << std::endl;
    }

    return errors.empty();
}

/* Extent (starting LBA) of `name` at the root of a built .gdi's high-density
 * ISO9660 filesystem, or std::nullopt if it isn't there. Used to check
 * -S/--sort-file placement: libisofs ranks high weights towards low block
 * addresses, so a heavier file ends up at a lower extent. */
static std::optional<uint32_t> gdi_file_extent(const std::filesystem::path& gdi, const std::string& name) {
    std::vector<std::string> errors;
    gdi_verify::Image img;
    if(!img.load(gdi, errors)) return std::nullopt;

    std::vector<gdi_verify::File> files;
    if(!gdi_verify::list_files(img, gdi_verify::GD_START_LBA, files)) return std::nullopt;

    for(const auto& file: files) {
        if(file.name == name) return file.lba;
    }

    return std::nullopt;
}

/* Content bytes of `name` at the root of a built .gdi's high-density
 * filesystem, or std::nullopt if it isn't there. Rounded up to whole
 * 2048-byte sectors like the on-disc extent is, which is fine for comparing
 * two builds of the exact same content: both round the same way. */
static std::optional<std::vector<char>> gdi_read_root_file(const std::filesystem::path& gdi,
                                                            const std::string& name) {
    std::vector<std::string> errors;
    gdi_verify::Image img;
    if(!img.load(gdi, errors)) return std::nullopt;

    std::vector<gdi_verify::File> files;
    if(!gdi_verify::list_files(img, gdi_verify::GD_START_LBA, files)) return std::nullopt;

    for(const auto& file: files) {
        if(file.name != name) continue;

        std::vector<char> data;
        for(uint32_t lba = file.lba; lba < file.end_lba; ++lba) {
            uint8_t sector[2048];
            if(!img.read_sector(lba, sector)) return std::nullopt;
            data.insert(data.end(), (char*) sector, (char*) sector + 2048);
        }
        return data;
    }

    return std::nullopt;
}

/* Parses a .gdi and checks the gap between consecutive tracks: 150 sectors at
 * every data/audio boundary, and none at all between consecutive audio tracks.
 * That asymmetry holds across all 18 reference dumps -- 26 data/audio
 * boundaries at 150, 78 audio/audio ones at 0 -- and a per-track pregap walk
 * cannot express it, which is why tracks carry an explicit placement LBA.
 *
 * The step up to LBA 45000 is skipped: that is the fixed physical offset of
 * the high-density area, not a gap between tracks. */
static bool check_gdi_gaps(const std::filesystem::path& gdi, const std::filesystem::path& dir) {
    std::ifstream f(gdi);
    if(!f) return false;

    std::string line;
    if(!std::getline(f, line)) return false; /* track count */

    struct Entry { long lba; int ctrl; long sectors; };
    std::vector<Entry> tracks;

    while(std::getline(f, line)) {
        std::istringstream ls(line);
        int num = 0, ctrl = 0, sector_size = 0;
        long lba = 0;
        std::string name;

        if(!(ls >> num >> lba >> ctrl >> sector_size >> name)) continue;
        if(sector_size <= 0) return false;

        auto path = dir / name;
        if(!std::filesystem::exists(path)) return false;

        auto size = std::filesystem::file_size(path);
        if(size % (unsigned) sector_size != 0) return false;

        tracks.push_back({lba, ctrl, (long) (size / (unsigned) sector_size)});
    }

    if(tracks.size() < 2) return false;

    for(size_t i = 0; i + 1 < tracks.size(); ++i) {
        if(tracks[i + 1].lba == 45000) continue;

        long gap = tracks[i + 1].lba - (tracks[i].lba + tracks[i].sectors);
        long expected = (tracks[i].ctrl == 0 && tracks[i + 1].ctrl == 0) ? 0 : 150;

        if(gap != expected) return false;
    }

    /* Every reference dump carrying GD-DA closes on a data track. */
    return tracks.back().ctrl == 4;
}

/* Checks the high-density TOC's track range and the CTRL of each entry: data
 * for the first and last tracks of the zone, audio for everything between. */
static bool check_gdi_toc_shape(const std::filesystem::path& track03, unsigned sector_size,
                                unsigned first_track, unsigned last_track) {
    std::ifstream f(track03, std::ios::binary);
    if(!f) return false;

    char magic[4] = {0};
    f.seekg(gdi_file_offset(0x100, sector_size));
    f.read(magic, 4);
    if(std::memcmp(magic, "TOC1", 4) != 0) return false;

    unsigned count = last_track - first_track + 1;
    for(unsigned i = 0; i < count; ++i) {
        uint32_t entry = read_u32_le(f, gdi_file_offset(0x104 + i * 4, sector_size));
        bool want_data = (i == 0 || i + 1 == count);
        if((entry >> 28) != (want_data ? 4u : 0u)) return false;
    }

    /* The slot past the last track stays unused. */
    if(read_u32_le(f, gdi_file_offset(0x104 + count * 4, sector_size)) != 0xFFFFFFFFu) return false;

    uint32_t first = read_u32_le(f, gdi_file_offset(0x288, sector_size));
    uint32_t last = read_u32_le(f, gdi_file_offset(0x28C, sector_size));

    return ((first >> 16) & 0xFF) == first_track && ((last >> 16) & 0xFF) == last_track;
}

/* Looks for a file by name at the root of the low-density filesystem. */
static bool check_gdi_lda_has_file(const std::filesystem::path& track01, unsigned sector_size,
                                   const std::string& name) {
    std::ifstream f(track01, std::ios::binary);
    if(!f) return false;

    char pvd[2048];
    f.seekg(gdi_file_offset(16 * 2048, sector_size));
    f.read(pvd, sizeof(pvd));
    if(!f || std::memcmp(pvd + 1, "CD001", 5) != 0) return false;

    uint32_t root_lba = le32(pvd + 156 + 2);
    uint32_t root_len = le32(pvd + 156 + 10);
    std::string target = name + ";1";

    for(uint32_t s = 0; (uint32_t) s * 2048 < root_len; ++s) {
        char dir[2048];
        f.seekg(gdi_file_offset((std::streamoff) (root_lba + s) * 2048, sector_size));
        f.read(dir, sizeof(dir));
        if(!f) return false;

        for(size_t off = 0; off + 33 < sizeof(dir);) {
            unsigned rec_len = (unsigned char) dir[off];
            if(rec_len == 0) break;

            unsigned name_len = (unsigned char) dir[off + 32];
            if(off + 33 + name_len > sizeof(dir)) break;

            if(target.size() == name_len
                && std::memcmp(dir + off + 33, target.data(), name_len) == 0) {
                return true;
            }

            off += rec_len;
        }
    }

    return false;
}

/* Start LBA of a file at the root of the low-density filesystem, the
 * low-density counterpart of gdi_file_extent(). The gdi_verify reader cannot
 * serve here: it resolves through the high-density track map, whereas this
 * filesystem lives in track 1 at LBA 0. */
static std::optional<uint32_t> gdi_lda_file_extent(const std::filesystem::path& track01,
                                                    unsigned sector_size,
                                                    const std::string& name) {
    std::ifstream f(track01, std::ios::binary);
    if(!f) return std::nullopt;

    char pvd[2048];
    f.seekg(gdi_file_offset(16 * 2048, sector_size));
    f.read(pvd, sizeof(pvd));
    if(!f || std::memcmp(pvd + 1, "CD001", 5) != 0) return std::nullopt;

    uint32_t root_lba = le32(pvd + 156 + 2);
    uint32_t root_len = le32(pvd + 156 + 10);
    std::string target = name + ";1";

    for(uint32_t s = 0; (uint32_t) s * 2048 < root_len; ++s) {
        char dir[2048];
        f.seekg(gdi_file_offset((std::streamoff) (root_lba + s) * 2048, sector_size));
        f.read(dir, sizeof(dir));
        if(!f) return std::nullopt;

        for(size_t off = 0; off + 33 < sizeof(dir);) {
            unsigned rec_len = (unsigned char) dir[off];
            if(rec_len == 0) break;

            unsigned name_len = (unsigned char) dir[off + 32];
            if(off + 33 + name_len > sizeof(dir)) break;

            if(target.size() == name_len
                && std::memcmp(dir + off + 33, target.data(), name_len) == 0) {
                return le32(dir + off + 2);
            }

            off += rec_len;
        }
    }

    return std::nullopt;
}

/* One record of an ISO9660 directory: where its own extent is, and whether it
 * is a directory. Enough to walk from the root into a named subdirectory. */
struct IsoEntry {
    uint32_t lba;
    uint32_t len;
    bool is_dir;
};

/* Scans the directory extent at (lba, len) for `name`, which is compared
 * without the ";1" version suffix files carry and directories do not. */
static std::optional<IsoEntry> iso_find_entry(std::ifstream& f, uint32_t lba, uint32_t len,
                                              const std::string& name) {
    for(uint32_t s = 0; s * 2048 < len; ++s) {
        char dir[2048];
        f.seekg((std::streamoff) (lba + s) * 2048);
        f.read(dir, sizeof(dir));
        if(!f) return std::nullopt;

        for(size_t off = 0; off + 33 < sizeof(dir);) {
            unsigned rec_len = (unsigned char) dir[off];
            if(rec_len == 0) break;

            unsigned name_len = (unsigned char) dir[off + 32];
            if(off + 33 + name_len > sizeof(dir)) break;

            std::string entry(dir + off + 33, name_len);
            auto semi = entry.find(';');
            if(semi != std::string::npos) entry.resize(semi);

            if(entry == name) {
                return IsoEntry{le32(dir + off + 2), le32(dir + off + 10),
                                ((unsigned char) dir[off + 25] & 2) != 0};
            }

            off += rec_len;
        }
    }

    return std::nullopt;
}

/* Whether a plain 2048-byte ISO holds an entry of that name and kind, at the
 * root or inside the named subdirectory. Used to tell "the directory came
 * across as itself" from "its contents were spilled into the root", and to
 * look one level down, where a -d tree keeps everything it brought. */
static bool check_iso_has_entry(const std::filesystem::path& iso, const std::string& name,
                                bool want_dir, const std::string& within = "") {
    std::ifstream f(iso, std::ios::binary);
    if(!f) return false;

    char pvd[2048];
    f.seekg((std::streamoff) 16 * 2048);
    f.read(pvd, sizeof(pvd));
    if(!f || std::memcmp(pvd + 1, "CD001", 5) != 0) return false;

    uint32_t lba = le32(pvd + 156 + 2);
    uint32_t len = le32(pvd + 156 + 10);

    if(!within.empty()) {
        auto parent = iso_find_entry(f, lba, len, within);
        if(!parent || !parent->is_dir) return false;

        lba = parent->lba;
        len = parent->len;
    }

    auto found = iso_find_entry(f, lba, len, name);
    return found && found->is_dir == want_dir;
}

/* Compares the three PVD file identifier fields. An empty expectation means
 * the field must be blank -- naming a file the volume doesn't carry would
 * leave a dangling reference. `sector_size` covers the raw 2352-byte GD-ROM
 * tracks as well as a plain 2048-byte ISO. */
static bool check_iso_pvd_file_ids(const std::filesystem::path& iso,
                                   const std::string& copyright,
                                   const std::string& abstract,
                                   const std::string& biblio,
                                   unsigned sector_size = 2048) {
    std::ifstream f(iso, std::ios::binary);
    if(!f) return false;

    char pvd[2048];
    f.seekg(gdi_file_offset(16 * 2048, sector_size));
    f.read(pvd, sizeof(pvd));
    if(!f || std::memcmp(pvd + 1, "CD001", 5) != 0) return false;

    auto field = [&](size_t off) {
        std::string s(pvd + off, 37);
        while(!s.empty() && (s.back() == ' ' || s.back() == '\0')) s.pop_back();
        return s;
    };

    return field(702) == copyright && field(739) == abstract && field(776) == biblio;
}

/* Reads exactly expected_lines.size() lines from a .gdi text file (CRLF
 * terminated) and checks they match, in order. */
static bool check_gdi_lines(const std::filesystem::path& path, const std::vector<std::string>& expected_lines) {
    std::ifstream f(path);
    if(!f) return false;

    for(const auto& expected: expected_lines) {
        std::string line;
        if(!std::getline(f, line)) return false;
        while(!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
        if(line != expected) return false;
    }

    return true;
}

int main(int argc, char** argv) {
    if(argc < 3) {
        std::cerr << "usage: test_cli <mkdcdisc-exe> <fixture-bin>" << std::endl;
        return 1;
    }

    /* On Windows, run() shells out via cmd.exe (_popen), which fails to
     * resolve forward-slash relative paths like "./mkdcdisc.exe" (the form
     * Meson passes when the exe lives in the test's working directory) even
     * though the mkdcdisc binary itself accepts them fine. make_preferred()
     * swaps in backslashes there; it's a no-op elsewhere. */
    std::string mkdcdisc = std::filesystem::path(argv[1]).make_preferred().string();
    std::string fixture = argv[2];

    std::filesystem::path tmp_dir = std::filesystem::temp_directory_path() /
        ("mkdcdisc-e2e-" + std::to_string((unsigned long) GETPID()));

    /* --print-msinfo: the default Audio/Data layout's MSINFO is the fixed
     * length of a 4-second blank audio session (lead-in 4500 + lead-out
     * 6750 + 150 pregap + 302 data sectors = 11702), a golden regression
     * value tying together the CLI, add_audio_session(), and the
     * session-length math in disc_image.c. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo --no-banner");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11702);
    }

    /* -M answers a question and exits, so it prints the number and nothing
     * else: no banner, without having to ask for one to be left out. Every
     * other -M case here passes --no-banner, which would hide a regression.
     * Both spellings, since banner_wanted() matches them separately. */
    {
        auto r = run(quote(mkdcdisc) + " -M");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11702);
        CHECK(!says(r.output, "Sega Dreamcast Disc Image Generator"));
    }
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(!says(r.output, "Sega Dreamcast Disc Image Generator"));
    }

    /* --print-msinfo --disc-layout data-data always reports 0 (no audio
     * session). The long spelling here and -L below, so both reach the same
     * option. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo --disc-layout data-data --no-banner");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 0);
    }

    /* audio-data is the default, so naming it explicitly is the same run as
     * naming nothing: the option is one value with three spellings, not a
     * switch that only has something to say when it is turned on. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo -L audio-data --no-banner");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11702);
    }

    /* A value outside the three is refused, and the message names them, the
     * way --color and --gdi-sector-size answer a value they don't know. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo -L data-datum --no-banner");
        CHECK_RUN(r, r.exit_code == 2 && says(r.output,
            "Error: invalid -L/--disc-layout value: data-datum "
            "(expected 'audio-data', 'data-data' or 'merged-data')"));
    }

    /* data-data is incompatible with --cdda-track, even in msinfo-only mode
     * (checked before the -c file is ever opened) */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo -L data-data --cdda-track nope.wav");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "Error: -c/--cdda-track cannot be combined with -L/--disc-layout data-data. "
            "A Data/Data image has no audio session for CDDA tracks."));
    }

    /* -M is MIL-CD only, like the rest of its group: the number it prints is
     * for mkisofs to build an ISO that -t then wraps, and -t cannot be used
     * with -F gdi at all. It used to answer -F gdi with the MIL-CD number.
     *
     * Both ways of naming the format are checked, because -M is answered
     * before -o/--output is required: with no filename to infer from, only an
     * explicit -F can say gdi. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo -F gdi --no-banner");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "Error: option -M/--print-msinfo cannot be used with -F/--format gdi. "
            "MSINFO belongs to the multi-session MIL-CD layouts."));

        r = run(quote(mkdcdisc) + " --print-msinfo -o out.gdi --no-banner");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "Error: option -M/--print-msinfo cannot be used with -F/--format gdi."));

        /* ... and it still answers when no format is named at all */
        r = run(quote(mkdcdisc) + " --print-msinfo --no-banner");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11702);
    }

    std::filesystem::create_directories(tmp_dir);

    /* -e/-b/-B are mutually exclusive */
    {
        auto cdi_path = tmp_dir / "conflict.cdi";
        auto r = run(quote(mkdcdisc) + " -e " + quote(fixture) + " -b " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: -e/--main-elf, -b/--main-binary-unscrambled, and -B/--main-binary-scrambled are "
            "mutually exclusive; specify only one 1ST_READ.BIN source."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* data-data is incompatible with --cdda-track when actually building */
    {
        auto cdi_path = tmp_dir / "conflict2.cdi";
        auto r = run(quote(mkdcdisc) + " -L data-data --cdda-track nope.wav -b " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: -c/--cdda-track cannot be combined with -L/--disc-layout data-data. "
            "A Data/Data image has no audio session for CDDA tracks."));
    }

    /* A default Audio/Data CDI build: 2 sessions (audio + data).
     * -N/--disable-data-track-padding is essential here: without it mkdcdisc pads the data
     * track up to the standard ~333000-sector CD size (~650MB), which
     * would make this test extremely slow and disk-heavy for no benefit. */
    {
        auto cdi_path = tmp_dir / "out.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 -N " +
                      "-o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(cdi_path));
        CHECK(std::filesystem::file_size(cdi_path) > 0);
        CHECK(check_cdi_session_count(cdi_path, 2));
    }

    /* The same build in MDS/MDF format */
    {
        auto mds_path = tmp_dir / "out.mds";
        auto mdf_path = tmp_dir / "out.mdf";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 -N " +
                      "-F mds -o " + quote(mds_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(mds_path));
        CHECK(std::filesystem::exists(mdf_path));
        CHECK(std::filesystem::file_size(mdf_path) > 0);
        CHECK(check_mds_header(mds_path, 2));
    }

    /* The same build in NRG format */
    {
        auto nrg_path = tmp_dir / "out.nrg";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 -N " +
                      "-F nrg -o " + quote(nrg_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(nrg_path));
        CHECK(std::filesystem::file_size(nrg_path) > 0);
        CHECK(check_nrg_session_count(nrg_path, 2));
    }

    /* Data/Data layout also produces a valid two-session image (ISO
     * session + duplicated boot-head session) */
    {
        auto cdi_path = tmp_dir / "out-datadata.cdi";
        auto r = run(quote(mkdcdisc) + " -L data-data -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 -N " +
                      "-o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(check_cdi_session_count(cdi_path, 2));
    }

    /* --temp-dir stages the build where it is told to, and cleans up after
     * itself there.
     *
     * The cleanup half is the point. temp_dir_destroy() will only
     * delete a directory sitting directly inside the staging root, and that
     * root used to be the system temp directory unconditionally -- so an
     * unchanged check would leave every --temp-dir build's staging directory
     * behind, which an emptiness assertion catches and an exit code does
     * not. */
    {
        auto staging = tmp_dir / "staging";
        std::filesystem::create_directories(staging);

        auto cdi_path = tmp_dir / "out-tempdir.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 -N " +
                      "--temp-dir " + quote(staging.string()) + " " +
                      "-o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(cdi_path));
        CHECK(std::filesystem::is_empty(staging));

        std::filesystem::remove_all(staging);
    }

    /* A --temp-dir that does not exist is the user's typo, and is refused by
     * name rather than surfacing as an unexplained staging failure. */
    {
        auto missing = tmp_dir / "no-such-staging-dir";
        auto cdi_path = tmp_dir / "out-tempdir-missing.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -N --temp-dir " + quote(missing.string()) + " " +
                      "-o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code != 0);
        CHECK_RUN(r, says(r.output, "--temp-dir does not name a directory"));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* And one naming a file rather than a directory takes the same path:
     * is_directory() is false for both, which is why one message covers
     * them. */
    {
        auto cdi_path = tmp_dir / "out-tempdir-file.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -N --temp-dir " + quote(fixture) + " " +
                      "-o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code != 0);
        CHECK_RUN(r, says(r.output, "--temp-dir does not name a directory"));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* merged-data only exists as an External ISO Mode variant.
     *
     * There is deliberately no test for asking for two layouts at once: the
     * three are one option's three values, so that combination cannot be
     * written down, let alone reach a check. */
    {
        auto cdi_path = tmp_dir / "conflict-merged-no-t.cdi";
        auto r = run(quote(mkdcdisc) + " -L merged-data -b " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: -L/--disc-layout merged-data requires -t/--external-data-track, given "
            "twice (session 1 ISO, then session 2 ISO). Standard Mode does not support "
            "this layout."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* merged-data is incompatible with --cdda-track, even in msinfo-only
     * mode (checked before the -t file is ever opened) */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo -L merged-data --cdda-track nope.wav -t " +
                      quote(fixture));
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "Error: -c/--cdda-track cannot be combined with -L/--disc-layout merged-data. "
            "A Merged Data/Data image has no audio session for CDDA tracks."));
    }

    /* ...and when actually building */
    {
        auto cdi_path = tmp_dir / "conflict-merged-cdda.cdi";
        auto r = run(quote(mkdcdisc) + " -L merged-data --cdda-track nope.wav -t " + quote(fixture) +
                      " -t " + quote(fixture) + " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: -c/--cdda-track cannot be combined with -L/--disc-layout merged-data. "
            "A Merged Data/Data image has no audio session for CDDA tracks."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* merged-data requires exactly two -t/--external-data-track ISOs */
    {
        auto cdi_path = tmp_dir / "conflict-merged-onet.cdi";
        auto r = run(quote(mkdcdisc) + " -L merged-data -t " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: -L/--disc-layout merged-data requires exactly two "
            "-t/--external-data-track ISOs (session 1, then session 2)."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* --print-msinfo with merged-data: the session 2 start LBA computed
     * from the session 1 ISO's own size alone. The fixture is 4096 bytes (2
     * data sectors), a golden regression value tying the CLI to
     * data_session_length_in_sectors()'s accounting in main.cpp (lead-in
     * 4500 + lead-out 6750 + pregap 150 + 2 data sectors + postgap 2 = 11404). */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo -L merged-data -t " + quote(fixture) +
                      " --no-banner");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11404);
    }

    /* merged-data builds a valid two-session image from two pre-built ISOs.
     * What is checked here is the wrapping -- mkdcdisc does not build either
     * filesystem, it only lays the raw bytes into two sessions -- so the
     * fixture stands in for both.
     *
     * It is not a bootable disc and does not pretend to be: 4096 bytes cannot
     * hold a boot header, and the boot prerequisite checks say so. Overriding
     * them is what keeps this test about the session layout rather than about
     * the content, which the checks have tests of their own for. */
    {
        auto cdi_path = tmp_dir / "out-merged.cdi";
        auto r = run(quote(mkdcdisc) + " -L merged-data -t " + quote(fixture) + " -t " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q --disable-bootstrap-checks");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(check_cdi_session_count(cdi_path, 2));
    }

    /* The boot prerequisite checks, run over an external ISO.
     *
     * All of them need a volume that is genuinely bootable to start from, so
     * mkdcdisc builds one and -I dumps it out: a Data/Data data track is
     * written at MSINFO 0, which is exactly what -t expects to be handed back.
     * -N keeps it to its actual contents rather than padding it out to a
     * 74-minute disc, which would make every case below read and write most of
     * a gigabyte for nothing. */
    {
        auto source_cdi = tmp_dir / "bootcheck-source.cdi";
        auto good_iso = tmp_dir / "bootcheck-source.iso";

        auto built = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -o " + quote(source_cdi.string()) +
                          " -L data-data -I -N -q");
        CHECK_RUN(built, built.exit_code == 0);
        CHECK(std::filesystem::exists(good_iso));

        std::vector<uint8_t> good = iso_read::read_whole_file(good_iso);
        CHECK(good.size() > iso_read::SYSTEM_AREA_SIZE);

        /* Writes `data` out under `name` in the temporary directory, so each
         * case below can damage one copy without disturbing the others. */
        auto write_iso = [&](const std::string& name, const std::vector<uint8_t>& data) {
            auto path = tmp_dir / name;
            std::ofstream out(path, std::ios::binary);
            out.write((const char*) data.data(), (std::streamsize) data.size());
            out.close();
            return path;
        };

        /* Runs a -t build over `path` and returns what mkdcdisc said about it. */
        auto build_from = [&](const std::filesystem::path& path, const std::string& extra = "") {
            auto out_cdi = tmp_dir / (path.stem().string() + "-out.cdi");
            return run(quote(mkdcdisc) + " -t " + quote(path.string()) + " -o " +
                       quote(out_cdi.string()) + " -L data-data --no-banner " + extra);
        };

        /* The volume as mkdcdisc built it passes, which is what makes every
         * refusal below mean something. */
        {
            auto r = build_from(good_iso);
            CHECK_RUN(r, r.exit_code == 0);
        }

        /* An ISO built without mkisofs' -G switch: the system area is there,
         * but nothing put a boot header in it. */
        {
            std::vector<uint8_t> damaged = good;
            std::fill(damaged.begin(), damaged.begin() + iso_read::SYSTEM_AREA_SIZE, 0);

            auto r = build_from(write_iso("bootcheck-noheader.iso", damaged));
            CHECK_RUN(r, r.exit_code == 5);
            CHECK(flatten(r.output).find("carries no boot header") != std::string::npos);
        }

        /* One byte of the SEGA licence screen code changed. The boot ROM
         * compares that zone against a copy of its own and refuses the disc on
         * any difference at all, so one byte is the whole test: the message
         * has to name where it is, in the offsets the layout tables use. */
        {
            std::vector<uint8_t> damaged = good;
            damaged[0x3000] = (uint8_t) (damaged[0x3000] ^ 0xFF);

            auto r = build_from(write_iso("bootcheck-license.iso", damaged));
            CHECK_RUN(r, r.exit_code == 5);

            std::string said = flatten(r.output);
            CHECK(said.find("modified SEGA licence screen code") != std::string::npos);
            CHECK(said.find("1 of the 13312 bytes") != std::string::npos);
            CHECK(said.find("the first at offset 3000") != std::string::npos);
        }

        /* The same disc, built anyway. The failure is still reported, as a
         * warning, and the image is written. */
        {
            std::vector<uint8_t> damaged = good;
            damaged[0x3000] = (uint8_t) (damaged[0x3000] ^ 0xFF);

            auto path = write_iso("bootcheck-override.iso", damaged);
            auto r = build_from(path, "--disable-bootstrap-checks");

            CHECK_RUN(r, r.exit_code == 0);

            std::string said = flatten(r.output);
            CHECK(said.find("modified SEGA licence screen code") != std::string::npos);
            CHECK(said.find("Error:") == std::string::npos);
            CHECK(std::filesystem::exists(tmp_dir / "bootcheck-override-out.cdi"));
        }

        /* The Boot Filename field emptied. Nothing names the executable, so
         * there is nothing for the console to look up. */
        {
            std::vector<uint8_t> damaged = good;
            std::fill(damaged.begin() + 0x060, damaged.begin() + 0x070, (uint8_t) ' ');

            auto r = build_from(write_iso("bootcheck-noboot.iso", damaged));
            CHECK_RUN(r, r.exit_code == 5);

            std::string said = flatten(r.output);
            CHECK(said.find("declares no boot file name") != std::string::npos);
            CHECK(said.find("IP.BIN offset 0060") != std::string::npos);
        }

        /* The Maker ID, which is not the disc's to choose either. */
        {
            std::vector<uint8_t> damaged = good;
            std::memcpy(&damaged[0x010], "NOT SEGA AT ALL!", 16);

            auto r = build_from(write_iso("bootcheck-maker.iso", damaged));
            CHECK_RUN(r, r.exit_code == 5);
            CHECK(flatten(r.output).find("declares the Maker ID") != std::string::npos);
        }

        /* Overwrites the Boot Filename field (IP.BIN 060-06F), space-padded the
         * way every field of the header is. */
        auto rename_boot_file = [&](std::vector<uint8_t> iso, const std::string& name) {
            std::fill(iso.begin() + 0x060, iso.begin() + 0x070, (uint8_t) ' ');
            std::memcpy(&iso[0x060], name.data(), name.size());
            return iso;
        };

        /* The header naming a file that is not on the disc. The message has to
         * say what the root does hold -- "not found" on its own leaves the
         * reader unable to tell a typo from a file that never got added. */
        {
            auto path = write_iso("bootcheck-missing.iso", rename_boot_file(good, "NOSUCH.BIN"));
            auto r = build_from(path);

            CHECK_RUN(r, r.exit_code == 5);

            std::string said = flatten(r.output);
            CHECK(said.find("does not carry \"NOSUCH.BIN\" at its root") != std::string::npos);
            CHECK(said.find("Its root holds: 1ST_READ.BIN") != std::string::npos);
        }

        /* The header naming the right file in the wrong case.
         *
         * A warning rather than a refusal, because the case that reaches it is
         * a header mkdcdisc did not write: a -p/--bootstrap IP.BIN is used
         * verbatim, so one declaring a lower-case name keeps it, and an
         * external ISO carries whatever its own header says. mkdcdisc's own
         * --boot-filename no longer lands here -- it upper-cases the name,
         * ISO9660 having no lower case to offer -- but the disc in front of it
         * was not necessarily built by mkdcdisc.
         *
         * Whether the console's own lookup is case-sensitive is not documented
         * anywhere consulted here, which is why this is not an error; saying
         * nothing would hide the one difference that explains a disc which
         * builds cleanly and does not boot. */
        {
            auto path = write_iso("bootcheck-case.iso", rename_boot_file(good, "1st_read.bin"));
            auto r = build_from(path);

            CHECK_RUN(r, r.exit_code == 0);

            std::string said = flatten(r.output);
            CHECK(said.find("Warning:") != std::string::npos);
            CHECK(said.find("Error:") == std::string::npos);
            CHECK(said.find("its filesystem calls it \"1ST_READ.BIN\"") != std::string::npos);
        }

        /* The header naming something that is at the root but is a directory.
         * Needs a volume that has one, so this is the one case that builds its
         * own source rather than patching the shared one. */
        {
            auto dir_cdi = tmp_dir / "bootcheck-dir.cdi";
            auto dir_iso = tmp_dir / "bootcheck-dir.iso";
            auto fixtures_dir = std::filesystem::path(fixture).parent_path();

            auto built_dir = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -o " +
                                 quote(dir_cdi.string()) + " -d " + quote(fixtures_dir.string()) +
                                 " -L data-data -I -N -q");
            CHECK_RUN(built_dir, built_dir.exit_code == 0);

            std::vector<uint8_t> with_dir = iso_read::read_whole_file(dir_iso);
            CHECK(with_dir.size() > iso_read::SYSTEM_AREA_SIZE);

            /* Upper-cased, because that is the name the ISO9660 primary tree
             * holds it under -- and the check has to match it exactly to reach
             * the "that is a directory" answer rather than the "no such name"
             * one. */
            std::string dir_name = fixtures_dir.filename().string();
            for(char& c: dir_name) {
                c = (char) std::toupper((unsigned char) c);
            }

            auto path = write_iso("bootcheck-isdir.iso", rename_boot_file(with_dir, dir_name));
            auto r = build_from(path);

            CHECK_RUN(r, r.exit_code == 5);
            CHECK(flatten(r.output).find("The console cannot start a directory") != std::string::npos);
        }
    }

    /* merged-data holds its two sessions to different standards: session 2 is
     * the one the console boots, and session 1 is read through session 2's
     * merged view of it and never booted at all. So a boot header in session 1
     * is reported as unused rather than as required or as wrong. */
    {
        auto good_iso = tmp_dir / "bootcheck-source.iso";
        auto out_cdi = tmp_dir / "bootcheck-merged.cdi";

        auto r = run(quote(mkdcdisc) + " -L merged-data -t " + quote(good_iso.string()) +
                     " -t " + quote(good_iso.string()) + " -o " + quote(out_cdi.string()) +
                     " --no-banner");

        CHECK_RUN(r, r.exit_code == 0);
        CHECK(flatten(r.output).find("The boot header in the session 1 ISO is unused") != std::string::npos);
    }

    /* The MSINFO check: whether the external ISO was built for the sector it is
     * about to be written at.
     *
     * An ISO records absolute addresses, so mkisofs has to be told where the
     * session will start (-C 0,N) before it writes any of them. The value is
     * chosen by hand, and nothing checked that the choice matched the disc.
     * Every case here is a warning: mkdcdisc's figure is a model of where the
     * session lands rather than a measurement, and a build refused on a model
     * is a build refused on an opinion. */
    {
        auto good_iso = tmp_dir / "bootcheck-source.iso";
        std::vector<uint8_t> good = iso_read::read_whole_file(good_iso);
        CHECK(good.size() > iso_read::SYSTEM_AREA_SIZE);

        /* What -M says this disc's data track starts at, asked rather than
         * written down, so the two cannot disagree. */
        auto printed = run(quote(mkdcdisc) + " --print-msinfo --no-banner");
        CHECK_RUN(printed, printed.exit_code == 0);

        long audio_msinfo = parse_first_integer(printed.output);
        CHECK(audio_msinfo > 0);

        /* Makes a volume claim it was built for sector `start`.
         *
         * Two places record where the root directory is -- the root directory
         * record inside the PVD, and the "." record at the head of the root
         * extent itself -- and detect_msinfo() recovers the intended start from
         * the difference between the address recorded and the sector the extent
         * physically sits at. Both are rewritten, because the reader requires
         * them to agree; that agreement is what makes its answer
         * self-validating rather than a guess.
         *
         * The source volume is at MSINFO 0, so its recorded root address is
         * also the sector the extent sits at, which is what makes this a plain
         * addition. */
        auto built_for_sector = [&](std::vector<uint8_t> iso, long start) {
            const size_t pvd_record = 16 * iso_read::SECTOR + 156;
            uint32_t root_lba = iso_read::le32(iso.data() + pvd_record + 2);

            auto put_both_endian = [&](size_t at, uint32_t value) {
                for(int i = 0; i < 4; ++i) {
                    iso[at + i] = (uint8_t) ((value >> (8 * i)) & 0xFF);
                    iso[at + 4 + i] = (uint8_t) ((value >> (8 * (3 - i))) & 0xFF);
                }
            };

            put_both_endian(pvd_record + 2, (uint32_t) (root_lba + start));
            put_both_endian((size_t) root_lba * iso_read::SECTOR + 2, (uint32_t) (root_lba + start));

            return iso;
        };

        auto build_at = [&](const std::string& name, long start, const std::string& layout) {
            auto path = tmp_dir / name;
            std::vector<uint8_t> iso = built_for_sector(good, start);

            std::ofstream out(path, std::ios::binary);
            out.write((const char*) iso.data(), (std::streamsize) iso.size());
            out.close();

            return run(quote(mkdcdisc) + " -t " + quote(path.string()) + " -o " +
                       quote((tmp_dir / (path.stem().string() + "-out.cdi")).string()) +
                       " --no-banner " + layout);
        };

        /* A Data/Data first session starts the disc, so the expectation is
         * exactly 0 and gets no allowance: there is nothing to model. */
        {
            auto r = build_at("msinfo-dd-shifted.iso", 200, "-L data-data");
            CHECK_RUN(r, r.exit_code == 0);

            std::string said = flatten(r.output);
            CHECK(said.find("was built to start at sector 200") != std::string::npos);
            CHECK(said.find("written at sector 0 (+200)") != std::string::npos);
            CHECK(said.find("mkisofs -C 0,0") != std::string::npos);
        }

        /* Built for exactly where it is going: nothing to say. */
        {
            auto r = build_at("msinfo-exact.iso", audio_msinfo, "");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(flatten(r.output).find("was built to start at sector") == std::string::npos);
        }

        /* The tolerance, from both sides. One CD pregap of latitude, because
         * that is the one quantity two mastering models legitimately disagree
         * about when they say where a session starts. Pinned here so the
         * number cannot drift unnoticed: 100 sectors out is a modelling
         * difference, 200 is a wrong -C. */
        {
            auto inside = build_at("msinfo-near.iso", audio_msinfo + 100, "");
            CHECK_RUN(inside, inside.exit_code == 0);
            CHECK(flatten(inside.output).find("was built to start at sector") == std::string::npos);

            auto outside = build_at("msinfo-far.iso", audio_msinfo + 200, "");
            CHECK_RUN(outside, outside.exit_code == 0);
            CHECK(flatten(outside.output).find("was built to start at sector") != std::string::npos);
        }

        /* The mistake this check exists for: a plain standalone ISO, built
         * without -C at all, wrapped into the default Audio/Data layout. Every
         * address in it is a whole audio session too low. */
        {
            auto r = build_at("msinfo-forgot-c.iso", 0, "");
            CHECK_RUN(r, r.exit_code == 0);

            std::string said = flatten(r.output);
            CHECK(said.find("was built to start at sector 0") != std::string::npos);
            CHECK(said.find("(-" + std::to_string(audio_msinfo) + ")") != std::string::npos);
            CHECK(said.find("run mkdcdisc -M to get this exact number") != std::string::npos);
        }
    }

    /* What -q/-v 0 may silence among the boot checks, and what it may not.
     *
     * The severity decides it. An error always prints: a build that refuses to
     * produce a disc has to say why, whatever was asked of the output, which is
     * the one exception logging.hpp's level 0 makes. Anything softer is
     * silenceable, the way every other structural warning here already is -- and
     * a warning is exactly what --disable-bootstrap-checks turns a failure into,
     * silence included, because the build is then going ahead and the finding is
     * advice about the disc rather than the reason there isn't one. */
    {
        auto good_iso = tmp_dir / "bootcheck-source.iso";
        std::vector<uint8_t> good = iso_read::read_whole_file(good_iso);
        CHECK(good.size() > iso_read::SYSTEM_AREA_SIZE);

        auto write_and_run = [&](const std::string& name, const std::vector<uint8_t>& iso,
                                 const std::string& extra) {
            auto path = tmp_dir / name;
            {
                std::ofstream out(path, std::ios::binary);
                out.write((const char*) iso.data(), (std::streamsize) iso.size());
            }

            return run(quote(mkdcdisc) + " -t " + quote(path.string()) + " -o " +
                       quote((tmp_dir / (path.stem().string() + "-out.cdi")).string()) +
                       " --no-banner " + extra);
        };

        /* The header pointed at a file the disc does not have: a blocking one. */
        std::vector<uint8_t> missing = good;
        std::fill(missing.begin() + 0x060, missing.begin() + 0x070, (uint8_t) ' ');
        std::memcpy(&missing[0x060], "NOSUCH.BIN", 10);

        /* A warning on its own. The source ISO is at MSINFO 0 and the default
         * Audio/Data layout will write it further in, so the MSINFO check has
         * something to say -- and -q means it does not say it. */
        {
            auto r = write_and_run("quiet-warning.iso", good, "-q");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(flatten(r.output).empty());
        }

        /* A refusal still explains itself, -q or not. */
        {
            auto r = write_and_run("quiet-error.iso", missing, "-q -L data-data");
            CHECK_RUN(r, r.exit_code == 5);
            CHECK(flatten(r.output).find("does not carry \"NOSUCH.BIN\"") != std::string::npos);
        }

        /* The same finding, overridden into a warning, and therefore silenced.
         * A run that asked for silence and still got its disc gets silence. */
        {
            auto r = write_and_run("quiet-override.iso", missing,
                "-q -L data-data --disable-bootstrap-checks");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(flatten(r.output).empty());
            CHECK(std::filesystem::exists(tmp_dir / "quiet-override-out.cdi"));
        }
    }

    /* The same checks over the filesystem mkdcdisc builds itself, which is
     * where they should never fire -- so what is pinned here is that they run
     * at all, and still refuse when given something that cannot boot.
     *
     * -p/--bootstrap is the way in: it is used verbatim, so a bootstrap that is
     * not a boot header makes mkdcdisc generate a data track that cannot boot,
     * without any external ISO involved. Both formats, because they reach the
     * checks through different builders and name their volume differently. */
    {
        /* 32K that is definitely not a boot header. */
        std::vector<uint8_t> junk(32768, 0);
        for(size_t i = 0; i < junk.size(); ++i) {
            junk[i] = (uint8_t) ((i * 37 + 11) & 0xFF);
        }
        std::memcpy(junk.data() + 0x60, "1ST_READ.BIN    ", 16);

        auto junk_path = tmp_dir / "internal-junk-bootstrap.bin";
        {
            std::ofstream out(junk_path, std::ios::binary);
            out.write((const char*) junk.data(), (std::streamsize) junk.size());
        }

        /* A MIL-CD build, refused before anything is written. */
        {
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -p " + quote(junk_path.string()) +
                         " -V INTERNAL -N --no-banner -o " +
                         quote((tmp_dir / "internal-junk.cdi").string()));

            CHECK_RUN(r, r.exit_code == 5);
            CHECK(flatten(r.output).find("the data track carries no boot header") != std::string::npos);
        }

        /* The same, as a GD-ROM: a different builder, and the volume it names
         * is the high-density one -- the low-density volume is deliberately not
         * checked, its header being a 256-byte copy of this one that names a
         * boot file living in the other area. */
        {
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -p " + quote(junk_path.string()) +
                         " -V INTERNAL -F gdi --gdi-truncate --no-banner -o " +
                         quote((tmp_dir / "internal-junk.gdi").string()));

            CHECK_RUN(r, r.exit_code == 5);

            std::string said = flatten(r.output);
            CHECK(said.find("the high-density data track carries no boot header") != std::string::npos);

            /* Exactly one volume reported, not two: the low-density one carries
             * the same unusable header and is deliberately not checked. Counted
             * rather than searched for the word "low-density", which the build
             * prints legitimately while building that area. */
            CHECK(count_occurrences(said, "carries no boot header") == 1);
        }

        /* And the override lets the same build through, which is what makes the
         * refusals above a choice rather than a wall. */
        {
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -p " + quote(junk_path.string()) +
                         " -V INTERNAL -N --no-banner --disable-bootstrap-checks -o " +
                         quote((tmp_dir / "internal-junk-forced.cdi").string()));

            CHECK_RUN(r, r.exit_code == 0);
            CHECK(std::filesystem::exists(tmp_dir / "internal-junk-forced.cdi"));
        }
    }

    /* A --boot-filename whose case ISO9660 cannot keep ends up on the disc three
     * ways, one per reader, and they all name the same file.
     *
     * ECMA-119's d-characters are A-Z, 0-9 and _, so libisofs upper-cases every
     * name on its way into the primary tree -- the tree the console reads at
     * boot. The IP.BIN Boot Filename field is upper-cased to match it, because
     * matching it is the field's whole job. Joliet and Rock Ridge have no such
     * restriction and keep the name as given, which matters because those are
     * the names KallistiOS resolves at runtime.
     *
     * The earlier bug was the header being written verbatim while the primary
     * tree upper-cased: the console then looked up a name that tree did not
     * hold. Fixing it by upper-casing the file itself would have cost the case
     * everywhere, Rock Ridge included, so the conversion belongs to the field
     * alone. */
    {
        auto cdi_path = tmp_dir / "bootname-case.cdi";
        auto iso_path = tmp_dir / "bootname-case.iso";

        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -o " + quote(cdi_path.string()) +
                     " -N -I --no-banner -v 2 --boot-filename lower.bin");

        CHECK_RUN(r, r.exit_code == 0);

        std::string said = flatten(r.output);
        CHECK(said.find("IP.BIN declares the boot file as LOWER.BIN") != std::string::npos);

        std::vector<uint8_t> iso = iso_read::read_whole_file(iso_path);
        CHECK(iso.size() > iso_read::SYSTEM_AREA_SIZE);

        if(iso.size() > iso_read::SYSTEM_AREA_SIZE) {
            /* The header field and the primary tree, naming the same thing. */
            CHECK(std::string((const char*) iso.data() + 0x60, 9) == "LOWER.BIN");
            CHECK(iso_read::find(iso, "/LOWER.BIN").has_value());
            CHECK(!iso_read::find(iso, "/lower.bin").has_value());

            /* And the given case surviving somewhere, which is the point of
             * converting the field rather than the file. Searched for as bytes
             * rather than walked: a Rock Ridge NM entry holds the name as plain
             * ASCII, and this reader deliberately knows only the primary tree
             * (see tests/common/iso_read.h). So it says "the case is still in
             * the image" rather than "Rock Ridge resolves to it" -- enough to
             * catch the file itself being renamed, which is what would undo
             * this. */
            std::string as_given = "lower.bin";
            auto at = std::search(iso.begin(), iso.end(), as_given.begin(), as_given.end());
            CHECK(at != iso.end());
        }

        /* And the boot prerequisite checks have nothing left to report: the
         * mismatch they used to surface here is what this fixed. */
        CHECK(said.find("its filesystem calls it") == std::string::npos);
    }

    /* -t/--external-data-track refuses every option that would have fed the
     * filesystem or the IP.BIN mkdcdisc is not building here (the
     * disabled_in_external_mode table in main.cpp).
     *
     * One case per group, plus the five long-only options, which were accepted
     * and silently did nothing until they joined the table: mkdcdisc never
     * reads them on this path, so a run passing --boot-filename got a disc
     * whose header named something else entirely and no word about it.
     *
     * Refused before the ISO is even opened, hence a path that does not exist:
     * what is pinned is that the option is rejected on its own merits, not
     * that some later step happened to fail. */
    {
        static const char* refused[] = {
            "-a Author", "-n Title", "-r 20260101", "-s HDR0000", "-p boot.bin",
            "-V LABEL", "-S sort.txt", "-N", "-I", "-P V2.000", "-H E000F10",
            "--boot-filename FOO.BIN", "--duplicates-once",
            "--copyright c.txt", "--abstract a.txt", "--biblio b.txt",
        };

        for(const char* option: refused) {
            auto out = tmp_dir / "conflict-external.cdi";
            auto r = run(quote(mkdcdisc) + " -t " + quote(fixture) + " -o " +
                         quote(out.string()) + " --no-banner " + option);

            CHECK_RUN(r, r.exit_code == 2);
            CHECK_RUN(r, says(r.output, "cannot be used with -t/--external-data-track"));
            CHECK(!std::filesystem::exists(out));
        }
    }

    /* -F gdi rejects -t/--external-data-track, -L and -I outright (the
     * disabled_in_gdi_mode table in main.cpp). -B is deliberately not in that
     * list: see the -B/-F gdi build further down, which -B used to be
     * rejected alongside until GD-ROM learned to unscramble an
     * already-scrambled boot binary instead. --cdda-track isn't in it either
     * -- unlike the others, it's valid for GD-ROM (it becomes a GD-DA track)
     * -- so the block below it exercises a different failure entirely. */
    {
        auto gdi_path = tmp_dir / "conflict-gdi-t.gdi";
        auto r = run(quote(mkdcdisc) + " -F gdi -t " + quote(fixture) +
                      " -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: option -t/--external-data-track cannot be used with -F/--format gdi."));
        CHECK(!std::filesystem::exists(gdi_path));
    }
    {
        /* Not actually a -F gdi rejection: -c/--cdda-track is valid for GD-ROM
         * (it becomes a GD-DA track), so this instead exercises a plain
         * nonexistent-file failure while building one. Note it isn't the
         * ".wav"-specific message: load_audio_track() dispatches on content
         * (a RIFF header), not the file extension, and a missing file has
         * neither, so it falls through to the raw-CD-DA loader's own error. */
        auto gdi_path = tmp_dir / "conflict-gdi-cdda.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " --cdda-track nope.wav " +
                      "-o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: couldn't load raw audio file: nope.wav"));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* -N/--disable-data-track-padding has no effect on the GD-ROM path, which does its own
     * padding, so it must be rejected rather than silently ignored. */
    {
        auto gdi_path = tmp_dir / "conflict-gdi-nopad.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -N -F gdi " +
                      "-o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: option -N/--disable-data-track-padding cannot be used with -F/--format gdi. "
            "Use --gdi-truncate instead."));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* A --gdi-truncate build says so when it is done, under the line naming the
     * file it wrote: the image is non-standard, and what reads it may refuse
     * it. Said at the end rather than up front because it is about the artifact
     * that now exists, and worded defensively -- only nullDC and Demul have
     * been tried. */
    {
        /* Its own directory, like every .gdi build below: a .gdi set is a
         * descriptor plus track files whose names carry nothing of it, so two
         * sets sharing a directory are one set -- which mkdcdisc now refuses to
         * write into rather than quietly merging. */
        auto gdi_dir = tmp_dir / "truncate-notice";
        std::filesystem::create_directories(gdi_dir);

        auto gdi_path = gdi_dir / "truncate-notice.gdi";
        auto r = run(quote(mkdcdisc) + " -F gdi -b " + quote(fixture) +
                      " --gdi-truncate --no-banner -o " + quote(gdi_path.string()));
        CHECK_RUN(r, r.exit_code == 0);
        CHECK_RUN(r, says(r.output, "This is not a standard image and may not boot"));
        CHECK_RUN(r, says(r.output, "where a GD-ROM ends at 549150"));

        /* Said about an image that exists, not instead of writing one.
         *
         * That it comes *after* the "Wrote ..." line is deliberately not
         * asserted: that line goes to stdout and this one to stderr, so their
         * relative order in a captured pipe is a matter of which stream flushes
         * first, not something mkdcdisc promises. */
        CHECK(std::filesystem::exists(gdi_path));
    }

    /* -q silences it, like every other advisory: it is a caveat about the
     * build, not a failure. */
    {
        auto gdi_dir = tmp_dir / "truncate-notice-quiet";
        std::filesystem::create_directories(gdi_dir);

        auto gdi_path = gdi_dir / "truncate-notice-quiet.gdi";
        auto r = run(quote(mkdcdisc) + " -F gdi -b " + quote(fixture) +
                      " --gdi-truncate -q -o " + quote(gdi_path.string()));
        CHECK_RUN(r, r.exit_code == 0);
        CHECK_RUN(r, !says(r.output, "not a standard image"));
        CHECK(std::filesystem::exists(gdi_path));
    }

    /* --gdi-truncate only makes sense with -F gdi */
    {
        auto cdi_path = tmp_dir / "conflict-truncate.cdi";
        auto r = run(quote(mkdcdisc) + " --gdi-truncate -b " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-truncate only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* A GD-ROM's high-density area holds at most 95 GD-DA tracks. Past that the
     * TOC written into the system area stopped describing the disc rather than
     * refusing it: its entry array is 97 long and simply stopped being filled,
     * while the `last` field it publishes kept counting.
     *
     * Refused from the count alone, before a single file is opened, which is
     * what makes this test free: 96 four-second tracks would be ~135 MB of
     * fixtures, so the paths given here do not exist and never need to. The
     * absent-file error would be the failure if the guard ever moved back
     * behind the loading. */
    {
        auto gdi_path = tmp_dir / "too-many-gdda.gdi";
        std::string args;
        for(int i = 0; i < 96; ++i) {
            args += " -c nope" + std::to_string(i) + ".raw";
        }

        auto r = run(quote(mkdcdisc) + " -F gdi -b " + quote(fixture) + args +
                      " --no-banner -o " + quote(gdi_path.string()));
        CHECK_RUN(r, r.exit_code == 2 && says(r.output,
            "Error: 96 GD-DA tracks given, but at most 95 fit: a GD-ROM's high-density area "
            "spans tracks 3 to 99, and the audio sits between an opening data track and the "
            "closing one."));
        CHECK(!std::filesystem::exists(gdi_path));

        /* Nothing was attempted: refused as an invocation, not as a build. */
        CHECK_RUN(r, !says(r.output, "unable to build the disc image"));
        CHECK_RUN(r, !says(r.output, "couldn't load raw audio file"));
    }

    /* The MIL-CD counterpart, from the Red Book ceiling rather than from Sega's
     * rules: 99 tracks in all, one of which is the data track. The writers
     * refuse the same thing, but only once the disc has been built, with a bare
     * "unable to build the disc image" that names nothing. */
    {
        auto cdi_path = tmp_dir / "too-many-cdda.cdi";
        std::string args;
        for(int i = 0; i < 99; ++i) {
            args += " -c nope" + std::to_string(i) + ".raw";
        }

        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + args +
                      " --no-banner -o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code == 2 && says(r.output,
            "Error: 99 CDDA tracks given, but at most 98 fit: a disc holds 99 tracks and the "
            "data track takes one of them."));
        CHECK(!std::filesystem::exists(cdi_path));
        CHECK_RUN(r, !says(r.output, "unable to build the disc image"));
        CHECK_RUN(r, !says(r.output, "couldn't load raw audio file"));
    }

    /* -M/--print-msinfo is covered by the same check, which is why it sits
     * above the msinfo block rather than with the format-specific validation.
     * -M exists to prepare a build; answering it for a disc that cannot be
     * built would hand the caller a number to feed mkisofs with, and refuse the
     * result afterwards. */
    {
        std::string args;
        for(int i = 0; i < 99; ++i) {
            args += " -c nope" + std::to_string(i) + ".raw";
        }

        auto r = run(quote(mkdcdisc) + " --print-msinfo --no-banner" + args);
        CHECK_RUN(r, r.exit_code == 2 && says(r.output,
            "Error: 99 CDDA tracks given, but at most 98 fit:"));

        /* No number printed, and no attempt to open the tracks. */
        CHECK_RUN(r, !says(r.output, "couldn't load raw audio file"));
    }

    /* Each limit's last accepted value, so neither is off by one. The files
     * still do not exist, so the run goes on to open them and fails there --
     * which is the proof it got past the guard rather than being stopped by
     * it. */
    for(const auto& [format, count]: std::vector<std::pair<std::string, int>>{
            {"gdi", 95}, {"cdi", 98}}) {
        /* A directory per format: the .gdi half would otherwise be writing its
         * track files where an earlier .gdi build already put a set. */
        auto out_dir = tmp_dir / ("just-enough-audio-" + format);
        std::filesystem::create_directories(out_dir);

        auto out_path = out_dir / ("just-enough-audio." + format);
        std::string args;
        for(int i = 0; i < count; ++i) {
            args += " -c nope" + std::to_string(i) + ".raw";
        }

        auto r = run(quote(mkdcdisc) + " -F " + format + " -b " + quote(fixture) + args +
                      " --no-banner -o " + quote(out_path.string()));
        CHECK_RUN(r, r.exit_code != 2);
        CHECK_RUN(r, !says(r.output, "tracks given, but at most"));
        CHECK_RUN(r, says(r.output, "couldn't load raw audio file"));
    }

    /* -d/--directory brings the directory across under its own name, and -D
     * only its contents. Two ways that used to break, both silent:
     *
     *  - the name came from stem(), which drops everything from the last dot
     *    on, so "assets.v2" landed as "assets";
     *  - with a trailing separator -- which shell completion adds by itself --
     *    filename() is empty, the destination collapsed to the root, and -d
     *    quietly behaved like -D. */
    {
        auto src = tmp_dir / "dirtest";
        std::filesystem::create_directories(src / "assets.v2" / "inner");
        {
            std::ofstream f1(src / "assets.v2" / "TOP.TXT", std::ios::binary);
            f1 << "top\r\n";
            std::ofstream f2(src / "assets.v2" / "inner" / "DEEP.TXT", std::ios::binary);
            f2 << "deep\r\n";
        }

        auto build = [&](const std::string& arg, const std::string& tag) {
            auto cdi_path = tmp_dir / (tag + ".cdi");
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -n T -a A -N -I " +
                          "-d " + quote(arg) + " -o " + quote(cdi_path.string()) + " -q");
            CHECK_RUN(r, r.exit_code == 0);
            return std::filesystem::path(cdi_path).replace_extension("iso");
        };

        /* ASSETS_V2, not ASSETS: libisofs maps the dot to an underscore, since
         * an ISO9660 directory identifier cannot carry one, but everything
         * after it survives. stem() would have dropped it. */
        auto plain = build((src / "assets.v2").string(), "dir-plain");
        CHECK(check_iso_has_entry(plain, "ASSETS_V2", /* want_dir */ true));
        CHECK(!check_iso_has_entry(plain, "TOP.TXT", /* want_dir */ false));

        /* A trailing separator must not change what the option means. */
        auto trailing = build((src / "assets.v2").string() + "/", "dir-trailing");
        CHECK(check_iso_has_entry(trailing, "ASSETS_V2", /* want_dir */ true));
        CHECK(!check_iso_has_entry(trailing, "TOP.TXT", /* want_dir */ false));
    }

    /* A file where a directory is expected is rejected, rather than copied
     * under a truncated name (-d) or fed to a directory iterator (-D). */
    for(const std::string& flag: {std::string("-d"), std::string("-D")}) {
        auto cdi_path = tmp_dir / ("dir-not-a-dir" + flag + ".cdi");
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " " + flag + " " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: no such directory: " + fixture));
    }

    /* The file given as the executable is never added a second time, whichever
     * of -d/-D/-f sweeps it up: it is already on the disc as the boot binary,
     * converted, and the source copy is dead weight the size of the payload
     * again. -f is treated no differently -- naming the file explicitly does
     * not make a second copy of it useful -- and it used to end the run on a
     * raw filesystem error when the name collided.
     *
     * Matched by identity rather than by name, so a build directory holding
     * game.elf is caught exactly like one holding 1ST_READ.BIN. */
    {
        auto src = tmp_dir / "exetree";
        std::filesystem::remove_all(src);
        std::filesystem::create_directories(src / "nested");
        std::filesystem::copy_file(fixture, src / "game.bin");
        {
            std::ofstream f(src / "KEEP.TXT", std::ios::binary);
            f << "keep\r\n";
        }

        const std::string exe = (src / "game.bin").string();

        /* One image per case, named after the option it exercises -- spelled
         * out rather than by option letter, because "exe-d" and "exe-D" are the
         * same file on Windows and macOS, and the second run of a pair like
         * that is now a run refusing to write over the first. */
        auto build = [&](const std::string& tag, const std::string& args) {
            auto cdi_path = tmp_dir / (tag + ".cdi");
            return std::make_pair(
                run(quote(mkdcdisc) + args + " -N -I --no-banner -o " + quote(cdi_path.string())),
                std::filesystem::path(cdi_path).replace_extension("iso"));
        };

        const std::string warned = " file, already on the disc as 1ST_READ.BIN";

        /* The control first: the same bytes in a different file. Content is not
         * what the rule keys off, so this copy is ordinary disc content and
         * lands as GAME.BIN -- which is also what makes the negative checks
         * below mean something, since it is the entry they look for. */
        {
            auto twin = tmp_dir / "exe-outside" / "game.bin";
            std::filesystem::remove_all(twin.parent_path());
            std::filesystem::create_directories(twin.parent_path());
            std::filesystem::copy_file(fixture, twin);

            auto [r, iso] = build("exe-control", " -b " + quote(twin.string()) +
                                                 " -D " + quote(src.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, !says(r.output, "Warning: not adding"));
            CHECK(check_iso_has_entry(iso, "GAME.BIN", /* want_dir */ false));
        }

        /* -D spills the tree into the root, so the copy would have landed
         * beside the boot file it duplicates. */
        {
            auto [r, iso] = build("exe-dir-contents", " -b " + quote(exe) + " -D " + quote(src.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, says(r.output, "from -D/--directory-contents: it is the "
                "-b/--main-binary-unscrambled" + warned));
            CHECK_RUN(r, says(r.output, "(saves 4096 bytes)"));
            CHECK(!check_iso_has_entry(iso, "GAME.BIN", /* want_dir */ false));

            /* The rest of the sweep is untouched: this drops one file, not the
             * option that named the tree. */
            CHECK(check_iso_has_entry(iso, "KEEP.TXT", /* want_dir */ false));
        }

        /* -f named it outright, and is refused all the same. */
        {
            auto [r, iso] = build("exe-file", " -b " + quote(exe) + " -f " + quote(exe));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, says(r.output, "from -f/--file: it is the "
                "-b/--main-binary-unscrambled" + warned));
            CHECK(!check_iso_has_entry(iso, "GAME.BIN", /* want_dir */ false));
        }

        /* -d keeps the tree a directory down, so the copy has to be looked for
         * inside EXETREE rather than at the root, where it never was. */
        {
            auto [r, iso] = build("exe-dir", " -b " + quote(exe) + " -d " + quote(src.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, says(r.output, "from -d/--directory: it is the "
                "-b/--main-binary-unscrambled" + warned));
            CHECK(check_iso_has_entry(iso, "EXETREE", /* want_dir */ true));
            CHECK(check_iso_has_entry(iso, "KEEP.TXT", /* want_dir */ false, "EXETREE"));
            CHECK(!check_iso_has_entry(iso, "GAME.BIN", /* want_dir */ false, "EXETREE"));
        }

        /* Nested one deep: -D only iterates the top level, so the executable
         * rides in inside a subdirectory unless the tree copy drops it too. */
        {
            std::filesystem::remove(src / "game.bin");
            std::filesystem::copy_file(fixture, src / "nested" / "game.bin");

            auto [r, iso] = build("exe-dir-contents-nested",
                " -b " + quote((src / "nested" / "game.bin").string()) +
                " -D " + quote(src.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, says(r.output, "from -D/--directory-contents: it is the "
                "-b/--main-binary-unscrambled" + warned));
            CHECK(check_iso_has_entry(iso, "NESTED", /* want_dir */ true));
            CHECK(!check_iso_has_entry(iso, "GAME.BIN", /* want_dir */ false, "NESTED"));
        }
    }

    /* A file that is not the executable but carries the boot filename is left
     * out too, on the other ground: copying it would replace the binary that
     * was just generated with one that does not boot. What used to be a -v 2
     * aside for -D is now said at normal verbosity, and -f no longer aborts. */
    {
        auto src = tmp_dir / "impostor";
        std::filesystem::remove_all(src);
        std::filesystem::create_directories(src);
        {
            std::ofstream f(src / "1ST_READ.BIN", std::ios::binary);
            f << "not the boot binary at all";
        }

        for(const std::string& flag: {std::string("-D"), std::string("-f")}) {
            auto target = (flag == "-D") ? src.string() : (src / "1ST_READ.BIN").string();
            auto cdi_path = tmp_dir / ("impostor" + flag + ".cdi");
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " " + flag + " " +
                          quote(target) + " -N --no-banner -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, says(r.output, "1ST_READ.BIN is generated from "
                "-b/--main-binary-unscrambled, and this copy would replace it."));
            CHECK(std::filesystem::exists(cdi_path));
        }
    }

    /* An unreadable --copyright/--abstract/--biblio file is rejected up front,
     * rather than producing a volume quietly missing what was asked for. */
    {
        auto cdi_path = tmp_dir / "missing-copyright.cdi";
        auto missing = (tmp_dir / "does-not-exist.txt").string();
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " --copyright " + quote(missing) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: cannot read --copyright file: " + missing));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* Outside -F gdi only the files explicitly asked for are added, so an
     * ordinary build keeps producing exactly what it always did. The written
     * identifier keeps its '.' -- libisofs' own setters would have turned
     * COPYRIGH.TXT into COPYRIGH_TXT. */
    {
        auto notice = tmp_dir / "notice.txt";
        {
            std::ofstream nf(notice, std::ios::binary);
            nf << "Test copyright notice.\r\n";
        }

        auto cdi_path = tmp_dir / "pvd-ids.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -N -I " +
                      "--copyright " + quote(notice.string()) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);

        auto iso_path = std::filesystem::path(cdi_path).replace_extension("iso");
        CHECK(std::filesystem::exists(iso_path));
        CHECK(check_iso_pvd_file_ids(iso_path, "COPYRIGH.TXT", "", ""));
    }

    /* A GD-ROM carrying GD-DA: the audio tracks sit inside the high-density
     * zone, between an opening data track holding the filesystem headers and a
     * closing one holding the content -- the shape GD Drive Repair and
     * Millennium Racer have.
     *
     * Only the gap pattern is asserted, not absolute LBAs: those follow the
     * filesystem's own size and would pin the test to one libisofs version. */
    {
        auto gdda_dir = tmp_dir / "gdi-gdda";
        std::filesystem::create_directories(gdda_dir);

        /* Red Book's minimum track is 300 sectors. Two different lengths, so a
         * swapped or reused size would show up in the gaps. */
        auto make_audio = [&](const std::string& name, size_t sectors) {
            auto path = gdda_dir / name;
            std::ofstream af(path, std::ios::binary);
            std::vector<char> silence(2352, 0);
            for(size_t i = 0; i < sectors; ++i) {
                af.write(silence.data(), (std::streamsize) silence.size());
            }
            return path;
        };

        auto first_audio = make_audio("first.raw", 400);
        auto second_audio = make_audio("second.raw", 300);

        auto gdi_path = gdda_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "-c " + quote(first_audio.string()) + " -c " + quote(second_audio.string()) +
                      " -F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(gdi_path));

        /* Two data tracks and two audio ones, on top of the low-density pair */
        CHECK(std::filesystem::exists(gdda_dir / "track03.bin"));
        CHECK(std::filesystem::exists(gdda_dir / "track04.raw"));
        CHECK(std::filesystem::exists(gdda_dir / "track05.raw"));
        CHECK(std::filesystem::exists(gdda_dir / "track06.bin"));

        CHECK(std::filesystem::file_size(gdda_dir / "track04.raw") == 400ull * 2352);
        CHECK(std::filesystem::file_size(gdda_dir / "track05.raw") == 300ull * 2352);

        CHECK(check_gdi_gaps(gdi_path, gdda_dir));
        CHECK(check_gdi_toc_shape(gdda_dir / "track03.bin", 2352, 3, 6));
        CHECK(check_gdi_valid(gdi_path));

        /* The run-out rule holds on the track that carries the content.
         *
         * check_gdi_boot_file_last() cannot be used here: it reads the PVD out
         * of the track it is given and measures from LBA 45000, whereas the
         * filesystem now spans two tracks -- headers in track 3, the boot
         * binary in track 6. Confirming the binary's placement across that
         * split needs a reader that resolves an LBA through the whole track
         * map. */
        CHECK(check_gdi_reserved_tail(gdda_dir / "track06.bin", 2352));
    }

    /* --gdi-lda-file puts a file in the low-density area under its own
     * leaf name. libisofs splits paths on '/' to derive that name, so a
     * Windows path handed over verbatim would land as one mangled name like
     * "C__USERS_..._EXTRA.TXT" rather than "EXTRA.TXT". */
    {
        auto lda_dir = tmp_dir / "lda-extra";
        std::filesystem::create_directories(lda_dir);
        {
            std::ofstream ef(lda_dir / "EXTRA.TXT", std::ios::binary);
            ef << "low-density payload\r\n";
        }

        auto gdi_dir = tmp_dir / "gdi-lda";
        auto gdi_path = gdi_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "--gdi-lda-file " + quote((lda_dir / "EXTRA.TXT").string()) +
                      " -F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);

        auto track01 = gdi_dir / "track01.bin";
        CHECK(std::filesystem::exists(track01));
        CHECK(check_gdi_lda_has_file(track01, 2352, "EXTRA.TXT"));

        /* The generated text files are still there alongside it. */
        CHECK(check_gdi_lda_has_file(track01, 2352, "COPYRIGH.TXT"));
    }

    /* --gdi-disable-* takes one of the three generated text files off the
     * disc: no file in the low-density root, and its PVD identifier field left
     * blank rather than naming something that isn't there. The two not
     * disabled are unaffected, so a single flag doesn't switch off the set. */
    {
        auto disable_dir = tmp_dir / "gdi-disable";
        std::filesystem::create_directories(disable_dir);

        auto gdi_path = disable_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "--gdi-disable-abstract --gdi-disable-biblio " +
                      "-F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);

        auto track01 = disable_dir / "track01.bin";
        CHECK(std::filesystem::exists(track01));
        CHECK(check_gdi_lda_has_file(track01, 2352, "COPYRIGH.TXT"));
        CHECK(!check_gdi_lda_has_file(track01, 2352, "ABSTRACT.TXT"));
        CHECK(!check_gdi_lda_has_file(track01, 2352, "BIBLIOGR.TXT"));
        CHECK(check_iso_pvd_file_ids(track01, "COPYRIGH.TXT", "", "", 2352));
    }

    /* Disabling wins over supplying the same file, and says so: the two
     * options were both given and only one of them can be what was meant. */
    {
        auto notice = tmp_dir / "own-notice.txt";
        {
            std::ofstream nf(notice, std::ios::binary);
            nf << "Copyright (c) 2024 Me\r\n";
        }

        auto conflict_dir = tmp_dir / "gdi-disable-conflict";
        std::filesystem::create_directories(conflict_dir);

        auto gdi_path = conflict_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "--copyright " + quote(notice.string()) + " --gdi-disable-copyright " +
                      "-F gdi -o " + quote(gdi_path.string()));
        CHECK_RUN(r, r.exit_code == 0 && says(r.output,
            "Warning: --copyright is ignored because --gdi-disable-copyright was given."));

        auto track01 = conflict_dir / "track01.bin";
        CHECK(std::filesystem::exists(track01));
        CHECK(!check_gdi_lda_has_file(track01, 2352, "COPYRIGH.TXT"));
        CHECK(check_iso_pvd_file_ids(track01, "", "ABSTRACT.TXT", "BIBLIOGR.TXT", 2352));
    }

    /* ... and they are GD-ROM only, like every other --gdi- option */
    {
        auto cdi_path = tmp_dir / "conflict-disable.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -N --gdi-disable-copyright" +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-disable-copyright only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* The low-density options are GD-ROM only */
    {
        auto cdi_path = tmp_dir / "conflict-lda.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " --gdi-lda-file " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-lda-file only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* ... and a path that doesn't exist is rejected up front */
    {
        auto gdi_path = tmp_dir / "missing-lda.gdi";
        auto missing = (tmp_dir / "no-such-dir").string();
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -F gdi --gdi-truncate " +
                      "--gdi-lda-directory " + quote(missing) +
                      " -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: no such path for --gdi-lda-directory: " + missing));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* --gdi-lda-cdda-track replaces the generated silence of low-density
     * track 2 with a real audio track. The track's length then comes from the
     * file rather than the fixed 526-sector default, which the PVD's volume
     * space must follow: it declares the whole low-density area, so a track 2
     * sized from audio and a volume space left on the default would disagree
     * about where that area ends. */
    {
        auto lda_audio_dir = tmp_dir / "lda-cdda";
        std::filesystem::create_directories(lda_audio_dir);

        /* 400 sectors, so neither the 526-sector default nor a reused GD-DA
         * length could pass for it. Non-zero, to tell the audio apart from the
         * silence it replaces. */
        const size_t LDA_AUDIO_SECTORS = 400;
        auto audio_path = lda_audio_dir / "lda.raw";
        {
            std::ofstream af(audio_path, std::ios::binary);
            std::vector<char> tone(2352, 0x5A);
            for(size_t i = 0; i < LDA_AUDIO_SECTORS; ++i) {
                af.write(tone.data(), (std::streamsize) tone.size());
            }
        }

        auto gdi_path = lda_audio_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "--gdi-lda-cdda-track " + quote(audio_path.string()) +
                      " -F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);

        auto track01 = lda_audio_dir / "track01.bin";
        auto track02 = lda_audio_dir / "track02.raw";
        CHECK(std::filesystem::file_size(track02) == (std::uintmax_t) LDA_AUDIO_SECTORS * 2352);

        /* The audio itself, not silence padded to the same length. */
        {
            std::ifstream tf(track02, std::ios::binary);
            char head[16] = {0};
            tf.read(head, sizeof(head));
            CHECK_RUN(r, tf && std::all_of(head, head + sizeof(head),
                [](char c) { return c == 0x5A; }));
        }

        /* Track 2 still starts where it always does; only its length moved. */
        CHECK(check_gdi_lines(gdi_path, {
            "3",
            "1 0 4 2352 track01.bin 0",
            "2 600 0 2352 track02.raw 0",
            "3 45000 4 2352 track03.bin 0",
        }));

        CHECK(check_gdi_lda_filesystem(track01, 2352, 450 + 150 + LDA_AUDIO_SECTORS));
        CHECK(check_gdi_valid(gdi_path));
    }

    /* Shorter than Red Book's 4-second minimum, the same floor -c enforces */
    {
        auto short_dir = tmp_dir / "lda-cdda-short";
        std::filesystem::create_directories(short_dir);

        auto audio_path = short_dir / "short.raw";
        {
            std::ofstream af(short_dir / "short.raw", std::ios::binary);
            std::vector<char> tone(2352, 0x5A);
            for(size_t i = 0; i < 299; ++i) {
                af.write(tone.data(), (std::streamsize) tone.size());
            }
        }

        auto gdi_path = short_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -F gdi --gdi-truncate " +
                      "--gdi-lda-cdda-track " + quote(audio_path.string()) +
                      " -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "is too short - it must be at least 705600 bytes (4 seconds)"));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* Like the other --gdi-lda-* options, a path that doesn't exist is
     * rejected up front rather than mid-build */
    {
        auto gdi_path = tmp_dir / "missing-lda-cdda.gdi";
        auto missing = (tmp_dir / "no-such-track.raw").string();
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -F gdi --gdi-truncate " +
                      "--gdi-lda-cdda-track " + quote(missing) +
                      " -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: no such path for --gdi-lda-cdda-track: " + missing));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* ...and it only applies to -F/--format gdi. The path has to exist: that check runs
     * for every format, and so fires before the -F gdi gating below it. */
    {
        auto cdi_path = tmp_dir / "lda-cdda-on-cdi.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " --gdi-lda-cdda-track " + quote(fixture) +
                      " -N -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-lda-cdda-track only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* Naming convention: every option restricted to -F gdi carries the --gdi-
     * prefix, so `--help | grep gdi` lists the whole mode. The help text marks
     * those options with "-F gdi only:" on the same line as the flag, so the
     * two can be cross-checked without duplicating the option list here -- a
     * new gdi-only option named without the prefix fails this. */
    {
        auto r = run(quote(mkdcdisc) + " --help");
        CHECK_RUN(r, r.exit_code == 0);

        std::istringstream help(r.output);
        std::string line;
        unsigned checked = 0;

        while(std::getline(help, line)) {
            if(line.find("-F gdi only:") == std::string::npos) continue;
            ++checked;
            CHECK(line.find("--gdi-") != std::string::npos);
        }

        /* Guards against the marker being reworded, which would silently turn
         * the loop above into a no-op. */
        CHECK(checked >= 2);
    }

    /* The other half of that convention: an option a GD-ROM refuses says so on
     * its own line too, so neither restriction is discovered only by running
     * into it. Both markers are written by print_help() from the option
     * table's disc_type field, the same field main() refuses from, which is
     * what keeps the help text and the diagnostics agreeing.
     *
     * The exception is a group that is MIL-CD only end to end: "Disc Layout"
     * says it once in its description instead of on each of its lines, so -L
     * and -M are deliberately unmarked. */
    {
        auto r = run(quote(mkdcdisc) + " --help");
        CHECK_RUN(r, r.exit_code == 0);

        /* --help wraps its descriptions at a fixed width, so a marker can fall
         * across two lines -- which says nothing about whether the option
         * carries it, and everything about how long the longest option name in
         * the table happens to be. Continuation lines (indented, and not
         * themselves an option) are folded back onto the entry they belong to,
         * so what follows sees one logical line per option however it wrapped.
         *
         * Without the fold, adding an option whose name is longer than any
         * before it breaks these checks and points at the three options they
         * name rather than at the new one: the description column shifts right
         * for the whole table, and -I/--dump-iso's marker -- the marker
         * nearest a line end -- wraps onto a line of its own. Found by walking
         * into it. */
        std::vector<std::string> entries;
        {
            std::istringstream raw(r.output);
            std::string raw_line;

            while(std::getline(raw, raw_line)) {
                size_t text = raw_line.find_first_not_of(' ');

                bool is_continuation = !entries.empty()
                    && text != std::string::npos
                    && raw_line.rfind("      ", 0) == 0
                    && raw_line.rfind("  -", 0) != 0
                    && raw_line.rfind("      --", 0) != 0;

                if(is_continuation) {
                    entries.back() += " " + raw_line.substr(text);
                } else {
                    entries.push_back(raw_line);
                }
            }
        }

        unsigned marked = 0;
        bool in_disc_layout = false;
        bool layout_says_gdi = false;
        bool layout_option_marked = false;

        for(const std::string& line: entries) {
            bool is_option_line = line.rfind("  -", 0) == 0;
            bool has_marker = line.find("(not with -F gdi)") != std::string::npos;

            if(has_marker) ++marked;

            if(line.rfind("Disc Layout:", 0) == 0) in_disc_layout = true;
            else if(line.rfind("Disc Tracks:", 0) == 0) in_disc_layout = false;

            if(!in_disc_layout) continue;

            /* Its description is the run of non-option lines under the heading */
            if(!is_option_line && line.find("-F gdi") != std::string::npos) layout_says_gdi = true;
            if(is_option_line && has_marker) layout_option_marked = true;
        }

        /* -t, -I and -N at least, which also guards against the marker being
         * reworded into something the loop no longer recognizes. */
        CHECK(marked >= 3);
        CHECK(layout_says_gdi);
        CHECK(!layout_option_marked);
    }

    /* A GD-ROM (.gdi) build: track01.bin/track02.raw/track03.bin next to
     * out.gdi, with the fixed low-density placeholder tracks' LBAs/sizes and
     * the high-density track pinned at CD_GD_START_LBA. Data tracks default
     * to raw 2352-byte Mode 1 sectors. --gdi-truncate is essential here: without
     * it mkdcdisc pads the high-density track out to the full ~1GB physical
     * GD-ROM size, which would make this test extremely slow and disk-heavy
     * for no benefit (mirrors -N/--disable-data-track-padding for CDI above). */
    {
        auto gdi_dir = tmp_dir / "gdi-default";
        std::filesystem::create_directories(gdi_dir);

        auto gdi_path = gdi_dir / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "-F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(gdi_path));

        auto track01 = gdi_dir / "track01.bin";
        auto track02 = gdi_dir / "track02.raw";
        auto track03 = gdi_dir / "track03.bin";
        CHECK(std::filesystem::exists(track01));
        CHECK(std::filesystem::exists(track02));
        CHECK(std::filesystem::exists(track03));
        CHECK(std::filesystem::file_size(track01) == 450ull * 2352);
        CHECK(std::filesystem::file_size(track02) == 526ull * 2352);
        CHECK(std::filesystem::file_size(track03) > 0);
        CHECK(std::filesystem::file_size(track03) % 2352 == 0);

        CHECK(check_gdi_lines(gdi_path, {
            "3",
            "1 0 4 2352 track01.bin 0",
            "2 600 0 2352 track02.raw 0",
            "3 45000 4 2352 track03.bin 0",
        }));

        CHECK(check_gdi_ipbin_toc(track03, 2352));
        CHECK(check_gdi_ld_bootheader(track01, 2352));
        CHECK(check_gdi_lda_filesystem(track01, 2352, 450 + 150 + 526));
        CHECK(check_gdi_valid(gdi_path));
        CHECK(check_gdi_reserved_tail(track03, 2352));
        CHECK(check_gdi_boot_file_last(track03, 2352, "1ST_READ.BIN"));
    }

    /* -B/--main-binary-scrambled used to be rejected outright for -F gdi, since
     * GD-ROM boot requires an unscrambled 1ST_READ.BIN and -B's whole point
     * is to skip scrambling a binary that is already in that form. It is now
     * unscrambled on the way in instead (see gather_files() in
     * input_files.cpp), so this build must succeed and its 1ST_READ.BIN must
     * come out identical to the -b build above, built again here into its
     * own directory.
     *
     * `fixture` doubles as the "-B" input as-is: it is a uniform byte-filled
     * dummy binary (see tests/fixtures/dummy.bin), and scramble()/unscramble()
     * are both no-ops on uniform data (permuting identical bytes changes
     * nothing) -- so treating it as already-scrambled and unscrambling it
     * reproduces it exactly, the same as the plain -b path. That degeneracy
     * is exactly why this test cannot stand in for exercising the actual
     * permutation math; test_scramble (unit suite) covers that with
     * non-uniform data instead. What this test is responsible for is the
     * plumbing: that -F gdi accepts -B at all, and that doing so does not
     * corrupt the resulting disc structure.
     *
     * The comparison is scoped to 1ST_READ.BIN's own content, not the whole
     * track: an earlier version compared full tracks byte-for-byte and was
     * intermittently flaky, because the ISO9660 volume/directory records also
     * carry a build-time recording timestamp that legitimately differs
     * between this build and the one above whenever they land in different
     * seconds. That has nothing to do with what this test is checking. */
    {
        auto dir_scrambled = tmp_dir / "gdi-scrambled-input";
        auto gdi_path = dir_scrambled / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -B " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "-F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(gdi_path));

        auto track01 = dir_scrambled / "track01.bin";
        auto track02 = dir_scrambled / "track02.raw";
        auto track03 = dir_scrambled / "track03.bin";
        CHECK(std::filesystem::exists(track01));
        CHECK(std::filesystem::exists(track02));
        CHECK(std::filesystem::exists(track03));

        CHECK(check_gdi_valid(gdi_path));
        CHECK(check_gdi_boot_file_last(track03, 2352, "1ST_READ.BIN"));

        auto boot_from_b = gdi_read_root_file(tmp_dir / "gdi-default" / "out.gdi", "1ST_READ.BIN");
        auto boot_from_B = gdi_read_root_file(gdi_path, "1ST_READ.BIN");
        CHECK(boot_from_b.has_value() && boot_from_B.has_value());
        CHECK(boot_from_b == boot_from_B);
    }

    /* -S/--sort-file: build the same two root files twice, with the heavier
     * weight given to the other file the second time, and check that the
     * extent order actually reverses. libisofs ranks high weights towards low
     * block addresses ("the greater this value is, the closer from the
     * beginning of image the file will be written" -- sort_file.hpp).
     *
     * A single build compared against an unweighted baseline was tried first
     * and dropped: for two equal (default) weights, libisofs' tie-break falls
     * back to something that is not stable across runs (observed to flip
     * between two invocations of the very same binary with no input change at
     * all), so treating that baseline as a fixed point made this test flaky
     * by construction. Comparing two builds that both carry an explicit,
     * opposite pair of weights sidesteps that tie-break entirely. */
    {
        auto dir_sort_src = tmp_dir / "sort-src";
        std::filesystem::create_directories(dir_sort_src);

        auto file_a = dir_sort_src / "AAAA.TXT";
        auto file_z = dir_sort_src / "ZZZZ.TXT";
        {
            std::ofstream(file_a, std::ios::binary) << std::string(100, 'A');
            std::ofstream(file_z, std::ios::binary) << std::string(100, 'Z');
        }

        auto build_with_sort_file = [&](const std::string& label, const std::string& sort_contents) {
            auto sort_path = tmp_dir / ("sort-" + label + ".txt");
            std::ofstream(sort_path, std::ios::binary) << sort_contents;

            auto dir = tmp_dir / ("sort-" + label);
            auto gdi_path = dir / "out.gdi";
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                          " -f " + quote(file_a.string()) + " -f " + quote(file_z.string()) +
                          " -S " + quote(sort_path.string()) +
                          " --gdi-truncate -F gdi -o " + quote(gdi_path.string()) + " -q");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(check_gdi_valid(gdi_path));

            return gdi_path;
        };

        auto gdi_a_first = build_with_sort_file("a-first", "/AAAA.TXT 1000000\n/ZZZZ.TXT -1000000\n");
        auto a_first_a = gdi_file_extent(gdi_a_first, "AAAA.TXT");
        auto a_first_z = gdi_file_extent(gdi_a_first, "ZZZZ.TXT");
        CHECK(a_first_a.has_value() && a_first_z.has_value());
        if(a_first_a.has_value() && a_first_z.has_value()) {
            CHECK(*a_first_a < *a_first_z);
        }

        auto gdi_z_first = build_with_sort_file("z-first", "/AAAA.TXT -1000000\n/ZZZZ.TXT 1000000\n");
        auto z_first_a = gdi_file_extent(gdi_z_first, "AAAA.TXT");
        auto z_first_z = gdi_file_extent(gdi_z_first, "ZZZZ.TXT");
        CHECK(z_first_a.has_value() && z_first_z.has_value());
        if(z_first_a.has_value() && z_first_z.has_value()) {
            CHECK(*z_first_z < *z_first_a);
        }
    }

    /* -S/--sort-file on the MIL-CD/Audio-Data layout (build_cd.cpp) exercises
     * a second, independent call site for parse_sort_file()/
     * traverse_and_set_weights() -- the GD-ROM check above only proves the
     * GD-ROM one (build_gd.cpp) wires it up correctly; this is separate C++
     * code, not a shared function, so it could be wrong on its own.
     *
     * Verifying actual on-disc extent order here the same way would need a
     * CDI-specific ISO9660 reader: unlike a GD-ROM track, a CDI data track's
     * sectors carry Mode 2 Form 1 framing (a 12+4+8-byte prefix, not the
     * GD-ROM helpers' 16), and locating that track's start offset means
     * parsing the trailing header write_cdi_header() appends, which nothing
     * in this suite does yet. Cheaper and still decisive: build_cd.cpp dumps
     * the whole tree with each file's weight at -v 3, once before and once
     * after applying the sort file (traverse_directory() in sort_file.cpp),
     * so this checks that dump instead of the bytes on disc. The mapping
     * from weight to actual placement is libisofs' job, already exercised by
     * the GD-ROM test above through the same sort-weight write path. */
    {
        auto dir_milcd_src = tmp_dir / "milcd-sort-src";
        std::filesystem::create_directories(dir_milcd_src);

        auto file_a = dir_milcd_src / "AAAA.TXT";
        auto file_z = dir_milcd_src / "ZZZZ.TXT";
        std::ofstream(file_a, std::ios::binary) << std::string(100, 'A');
        std::ofstream(file_z, std::ios::binary) << std::string(100, 'Z');

        auto sort_file = tmp_dir / "milcd-sort.txt";
        std::ofstream(sort_file, std::ios::binary) << "/AAAA.TXT 1000000\n/ZZZZ.TXT -1000000\n";

        /* -N: a MIL-CD build pads its data track to the ~650MB standard CD
         * size by default (see the -N CDI test near the top of this file);
         * pointless disk churn for a build this is only reading the log of. */
        auto cdi_path = tmp_dir / "milcd-sort.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -f " + quote(file_a.string()) + " -f " + quote(file_z.string()) +
                      " -S " + quote(sort_file.string()) +
                      " -N -v 3 --no-banner -o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(check_cdi_session_count(cdi_path, 2));

        /* Before applying the sort file both files sit at the default weight
         * (0); only the second, later dump should show what the sort file
         * assigned. Both lines are checked so a build_cd.cpp change that
         * dropped the sort-file block entirely -- leaving every weight at 0
         * -- would still be caught: the "assigned" lines would then be
         * missing rather than trivially present. */
        CHECK(r.output.find("AAAA.TXT [Weight: 0]") != std::string::npos);
        CHECK(r.output.find("ZZZZ.TXT [Weight: 0]") != std::string::npos);
        CHECK(r.output.find("AAAA.TXT [Weight: 1000000]") != std::string::npos);
        CHECK(r.output.find("ZZZZ.TXT [Weight: -1000000]") != std::string::npos);
    }

    /* --gdi-lda-sort-file orders the low-density filesystem, the way -S orders
     * the high-density one. Same two-build reversal as the -S test above, for
     * the same tie-break reason.
     *
     * Both are given in every build, with -S kept fixed while the low-density
     * one flips: the two filesystems are unrelated trees that happen to be
     * addressed by identically-shaped paths, so this also pins down that
     * neither sort file reaches into the other's tree. */
    {
        auto lda_sort_src = tmp_dir / "lda-sort-src";
        std::filesystem::create_directories(lda_sort_src);

        auto lda_a = lda_sort_src / "LAAA.TXT";
        auto lda_z = lda_sort_src / "LZZZ.TXT";
        auto hda_a = lda_sort_src / "HAAA.TXT";
        auto hda_z = lda_sort_src / "HZZZ.TXT";
        {
            std::ofstream(lda_a, std::ios::binary) << std::string(100, 'A');
            std::ofstream(lda_z, std::ios::binary) << std::string(100, 'Z');
            std::ofstream(hda_a, std::ios::binary) << std::string(100, 'A');
            std::ofstream(hda_z, std::ios::binary) << std::string(100, 'Z');
        }

        /* Fixed across both builds, so any drift in the high-density order can
         * only come from the low-density sort file leaking into it. */
        auto hda_sort = tmp_dir / "lda-sort-hda.txt";
        std::ofstream(hda_sort, std::ios::binary) << "/HAAA.TXT 1000000\n/HZZZ.TXT -1000000\n";

        auto build_with_lda_sort = [&](const std::string& label, const std::string& sort_contents) {
            auto sort_path = tmp_dir / ("lda-sort-" + label + ".txt");
            std::ofstream(sort_path, std::ios::binary) << sort_contents;

            auto dir = tmp_dir / ("lda-sort-" + label);
            auto gdi_path = dir / "out.gdi";
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                          " -f " + quote(hda_a.string()) + " -f " + quote(hda_z.string()) +
                          " -S " + quote(hda_sort.string()) +
                          " --gdi-lda-file " + quote(lda_a.string()) +
                          " --gdi-lda-file " + quote(lda_z.string()) +
                          " --gdi-lda-sort-file " + quote(sort_path.string()) +
                          " --gdi-truncate -F gdi -o " + quote(gdi_path.string()) + " -q");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(check_gdi_valid(gdi_path));

            /* The high-density order the unchanging -S asked for, in both */
            auto h_a = gdi_file_extent(gdi_path, "HAAA.TXT");
            auto h_z = gdi_file_extent(gdi_path, "HZZZ.TXT");
            CHECK(h_a.has_value() && h_z.has_value());
            if(h_a.has_value() && h_z.has_value()) {
                CHECK(*h_a < *h_z);
            }

            return dir / "track01.bin";
        };

        auto track01_a = build_with_lda_sort("a-first", "/LAAA.TXT 1000000\n/LZZZ.TXT -1000000\n");
        auto a_first_a = gdi_lda_file_extent(track01_a, 2352, "LAAA.TXT");
        auto a_first_z = gdi_lda_file_extent(track01_a, 2352, "LZZZ.TXT");
        CHECK(a_first_a.has_value() && a_first_z.has_value());
        if(a_first_a.has_value() && a_first_z.has_value()) {
            CHECK(*a_first_a < *a_first_z);
        }

        auto track01_z = build_with_lda_sort("z-first", "/LAAA.TXT -1000000\n/LZZZ.TXT 1000000\n");
        auto z_first_a = gdi_lda_file_extent(track01_z, 2352, "LAAA.TXT");
        auto z_first_z = gdi_lda_file_extent(track01_z, 2352, "LZZZ.TXT");
        CHECK(z_first_a.has_value() && z_first_z.has_value());
        if(z_first_a.has_value() && z_first_z.has_value()) {
            CHECK(*z_first_z < *z_first_a);
        }
    }

    /* ...and it only applies to -F/--format gdi */
    {
        auto cdi_path = tmp_dir / "lda-sort-on-cdi.cdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " --gdi-lda-sort-file " + quote(fixture) +
                      " -N -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-lda-sort-file only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* --gdi-sector-size 2048 drops the raw sector framing, which also renames
     * the data tracks to track??.iso. Built in its own directory so its track
     * files don't collide with the raw build above. */
    {
        auto dir_2048 = tmp_dir / "gdi2048";
        auto gdi_path = dir_2048 / "out.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate " +
                      "--gdi-sector-size 2048 -F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(gdi_path));

        auto track01 = dir_2048 / "track01.iso";
        auto track03 = dir_2048 / "track03.iso";
        CHECK(std::filesystem::exists(track01));
        CHECK(std::filesystem::exists(dir_2048 / "track02.raw"));
        CHECK(std::filesystem::exists(track03));

        /* The .bin names belong to the raw format only */
        CHECK(!std::filesystem::exists(dir_2048 / "track01.bin"));
        CHECK(!std::filesystem::exists(dir_2048 / "track03.bin"));

        CHECK(std::filesystem::file_size(track01) == 450ull * 2048);
        CHECK(std::filesystem::file_size(track03) > 0);
        CHECK(std::filesystem::file_size(track03) % 2048 == 0);

        CHECK(check_gdi_lines(gdi_path, {
            "3",
            "1 0 4 2048 track01.iso 0",
            "2 600 0 2352 track02.raw 0",
            "3 45000 4 2048 track03.iso 0",
        }));

        CHECK(check_gdi_ipbin_toc(track03, 2048));
        CHECK(check_gdi_ld_bootheader(track01, 2048));
        CHECK(check_gdi_lda_filesystem(track01, 2048, 450 + 150 + 526));
        CHECK(check_gdi_valid(gdi_path));
        CHECK(check_gdi_reserved_tail(track03, 2048));
        CHECK(check_gdi_boot_file_last(track03, 2048, "1ST_READ.BIN"));
    }

    /* --gdi-sector-size takes only 2048 or 2352 */
    {
        auto gdi_path = tmp_dir / "bad-sector-size.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " --gdi-sector-size 2336 " +
                      "-F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: invalid --gdi-sector-size value: 2336 (expected '2352' for raw Mode 1 sectors "
            "or '2048' for plain user data)"));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* ... and only makes sense with -F gdi */
    {
        auto cdi_path = tmp_dir / "conflict-sector-size.cdi";
        auto r = run(quote(mkdcdisc) + " --gdi-sector-size 2048 -b " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-sector-size only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* --gdi-fpu-rounding picks between the two bundled high-density bootstrap
     * templates. They differ only in the second-stage bootstrap (bootstrap2,
     * at 0x6000 of the boot image), which is where the SH-4 FPSCR rounding
     * mode is set: everything the console reads before reaching it -- the
     * header, the TOC, the licence screen, the first-stage bootstrap -- is the
     * same in both, and so is the low-density IP0000.BIN, which is built from
     * the header they share.
     *
     * Checked as "same below 0x6000, different above" rather than against the
     * exact byte ranges that differ today, so that regenerating the templates
     * from new binaries doesn't rewrite the test. */
    {
        const size_t BOOTSTRAP2 = 0x6000;
        const std::string common = " -b " + quote(fixture) +
            " -n TestGame -a TestAuthor -r 20240101 -s T-00001 --gdi-truncate -F gdi ";

        auto build = [&](const std::string& dir_name, const std::string& extra) {
            auto dir = tmp_dir / dir_name;
            std::filesystem::create_directories(dir);
            auto r = run(quote(mkdcdisc) + common + extra + "-o " +
                          quote((dir / "out.gdi").string()) + " -q");
            return std::make_pair(r, dir);
        };

        auto [r_near, near_dir] = build("fpu-nearest", "");
        CHECK_RUN(r_near, r_near.exit_code == 0);
        auto [r_zero, zero_dir] = build("fpu-zero", "--gdi-fpu-rounding zero ");
        CHECK_RUN(r_zero, r_zero.exit_code == 0);

        auto hd_near = read_gdi_boot_image(near_dir / "track03.bin", 2352);
        auto hd_zero = read_gdi_boot_image(zero_dir / "track03.bin", 2352);
        CHECK(hd_near.size() == 32768);
        CHECK(hd_zero.size() == 32768);

        CHECK(std::equal(hd_near.begin(), hd_near.begin() + BOOTSTRAP2, hd_zero.begin()));
        CHECK(!std::equal(hd_near.begin() + BOOTSTRAP2, hd_near.end(), hd_zero.begin() + BOOTSTRAP2));

        /* The low-density image comes from the header the two share, so the
         * rounding mode leaves it untouched. */
        CHECK(read_gdi_boot_image(near_dir / "track01.bin", 2352)
           == read_gdi_boot_image(zero_dir / "track01.bin", 2352));

        /* An explicit 'nearest' is what a run without the option already got. */
        auto [r_explicit, explicit_dir] = build("fpu-nearest-explicit", "--gdi-fpu-rounding nearest ");
        CHECK_RUN(r_explicit, r_explicit.exit_code == 0);
        CHECK(read_gdi_boot_image(explicit_dir / "track03.bin", 2352) == hd_near);

        /* A -p/--bootstrap file is used verbatim, bootstrap included, so it
         * settles the rounding mode itself and the option cannot apply. */
        auto ipbin_path = tmp_dir / "custom-ip.bin";
        {
            std::ofstream out(ipbin_path, std::ios::binary);
            out.write((const char*) hd_zero.data(), hd_zero.size());
        }

        auto p_dir = tmp_dir / "fpu-custom-bootstrap";
        std::filesystem::create_directories(p_dir);
        auto r_p = run(quote(mkdcdisc) + common + "--gdi-fpu-rounding zero -p " + quote(ipbin_path.string()) +
                        " -o " + quote((p_dir / "out.gdi").string()));
        CHECK_RUN(r_p, r_p.exit_code == 0 && says(r_p.output,
            "Warning: --gdi-fpu-rounding is ignored because -p/--bootstrap supplies its own bootstrap."));
    }

    /* --gdi-fpu-rounding takes only 'nearest' or 'zero' */
    {
        auto gdi_path = tmp_dir / "bad-fpu-rounding.gdi";
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) + " --gdi-fpu-rounding truncate " +
                      "-F gdi -o " + quote(gdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: invalid --gdi-fpu-rounding value: truncate (expected 'nearest' or 'zero')"));
        CHECK(!std::filesystem::exists(gdi_path));
    }

    /* ... and only makes sense with -F gdi */
    {
        auto cdi_path = tmp_dir / "conflict-fpu-rounding.cdi";
        auto r = run(quote(mkdcdisc) + " --gdi-fpu-rounding zero -b " + quote(fixture) +
                      " -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code != 0 && says(r.output,
            "mkdcdisc: error: --gdi-fpu-rounding only applies to -F/--format gdi."));
        CHECK(!std::filesystem::exists(cdi_path));
    }

    /* A superseded option spelling still resolves to the option that replaced
     * it, and names the replacement so the warning is actionable. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo --no-banner --no-padding");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11702);
        CHECK(r.output.find("--no-padding is deprecated") != std::string::npos);
        CHECK(r.output.find("--disable-data-track-padding") != std::string::npos);
    }

    /* ... and -q silences the warning without changing the result. Nothing
     * here proves the warning went to stderr rather than stdout -- run()
     * merges the two -- but the 11702 above would be preceded by the warning
     * text on stdout, which parse_first_integer would still skip. */
    {
        auto r = run(quote(mkdcdisc) + " --print-msinfo --no-banner --no-padding -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(parse_first_integer(r.output) == 11702);
        CHECK(r.output.find("deprecated") == std::string::npos);
    }

    /* A superseded spelling of a value-taking option still consumes its
     * value: the parser decides flag-vs-value from the canonical entry, which
     * it only reaches through the alias. */
    {
        auto cdi_path = tmp_dir / "deprecated-alias.cdi";
        auto r = run(quote(mkdcdisc) + " --unscrambled-binary " + quote(fixture) +
                      " -N -o " + quote(cdi_path.string()) + " -q");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(cdi_path));
    }

    /* An option can carry more than one superseded spelling -- -b and -B have
     * been renamed twice -- and every one of them reaches the same entry and
     * names the current spelling. Only the second rename is checked here: the
     * first has the test above, and what is new is that an option's aliases are
     * a list rather than a single previous name. */
    {
        auto cdi_path = tmp_dir / "deprecated-alias-2.cdi";
        auto r = run(quote(mkdcdisc) + " --main-bin-unscrambled " + quote(fixture) +
                      " -N --no-banner -o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(std::filesystem::exists(cdi_path));
        CHECK_RUN(r, says(r.output, "option --main-bin-unscrambled is deprecated, "
            "use --main-binary-unscrambled instead."));
    }

    /* Superseded spellings are accepted but deliberately absent from --help */
    {
        auto r = run(quote(mkdcdisc) + " --help");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(r.output.find("--no-padding") == std::string::npos);
        CHECK(r.output.find("--external-iso-track") == std::string::npos);
        CHECK(r.output.find("--main-bin-unscrambled") == std::string::npos);
        CHECK(r.output.find("--disable-data-track-padding") != std::string::npos);
    }

    /* The banner introduces the program, so it comes above whatever the
     * program then has to say -- including a complaint from the option parser,
     * which runs after it. That ordering is why what suppresses the banner is
     * read from argv rather than from the parsed options (banner_wanted()),
     * and each of the three ways of asking for silence is checked here since
     * each is a separate line of that argv scan. */
    {
        auto r = run(quote(mkdcdisc) + " -x");
        CHECK_RUN(r, r.exit_code == 2);

        auto banner = r.output.find("Sega Dreamcast Disc Image Generator");
        auto copyright = r.output.find("Copyright (C)");
        auto complaint = r.output.find("Error: invalid argument: -x");

        CHECK_RUN(r, banner != std::string::npos);
        CHECK_RUN(r, copyright != std::string::npos);
        CHECK_RUN(r, complaint != std::string::npos);
        CHECK_RUN(r, banner < copyright && copyright < complaint);
    }

    for(const char* silent: {" --no-banner", " -q", " -v 0"}) {
        auto r = run(quote(mkdcdisc) + " -x" + silent);

        /* --no-banner only drops the banner; -q and -v 0 ask for silence, and
         * a diagnostic from a run that asked for silence names the program,
         * since the banner is no longer there to do it (term::Diagnostic). */
        const std::string complaint = std::string(silent) == " --no-banner"
            ? "Error: invalid argument: -x"
            : "mkdcdisc: error: invalid argument: -x";

        CHECK_RUN(r, r.exit_code == 2);
        CHECK_RUN(r, r.output.find(complaint) != std::string::npos);
        CHECK_RUN(r, r.output.find("Sega Dreamcast Disc Image Generator") == std::string::npos);
        CHECK_RUN(r, r.output.find("Copyright (C)") == std::string::npos);
    }

    /* An invocation that went wrong says what is wrong and where the valid
     * spellings are -- it does not answer with the whole option list, which
     * would scroll the message that named the problem off the screen. Each of
     * these three used to print the full help instead, and the last two used
     * to print it with no message at all, naming neither what was missing nor
     * that anything was. */
    {
        struct BadInvocation {
            std::string args;
            std::string expected;
        };

        const std::vector<BadInvocation> bad = {
            {" -x", "Error: invalid argument: -x"},
            {" -e " + quote(fixture), "no output file given"},
            {" -o " + quote((tmp_dir / "no-exec.cdi").string()), "no main executable given"},
        };

        for(const auto& invocation: bad) {
            auto r = run(quote(mkdcdisc) + " --no-banner" + invocation.args);
            CHECK_RUN(r, r.exit_code == 2);
            CHECK_RUN(r, r.output.find(invocation.expected) != std::string::npos);
            CHECK_RUN(r, r.output.find("Try 'mkdcdisc --help'") != std::string::npos);

            /* The option list is what --help is for. "General:" is one of its
             * group headings, and appears nowhere else. */
            CHECK_RUN(r, r.output.find("General:") == std::string::npos);
        }
    }

    /* Refusing an invocation is refusing an invocation, whichever check
     * caught it: the same exit code, and the same pointer at --help. Most of
     * these used to print their message and stop there, so the sweep is over
     * every kind of refusal rather than one representative of them -- that is
     * exactly the shape of thing that goes back out of step one branch at a
     * time. */
    {
        const std::vector<std::string> refusals = {
            " -F gdi -t x.iso",
            " -F gdi -N -b " + quote(fixture),
            " -F gdi -I -b " + quote(fixture),
            " --gdi-truncate -b " + quote(fixture),
            " -F gdi --gdi-sector-size 2336 -b " + quote(fixture),
            " -F bogus -b " + quote(fixture),
            " -L merged-data -b " + quote(fixture),
            " -L data-datum -b " + quote(fixture),
            " -t a.iso -t b.iso",
            " -e " + quote(fixture) + " -b " + quote(fixture),
            " -L data-data --cdda-track nope.wav -b " + quote(fixture),
            " -t a.iso -a Foo",
            " --color bogus -b " + quote(fixture),
        };

        for(const auto& args: refusals) {
            auto cdi_path = tmp_dir / "refused.cdi";
            std::error_code ec;
            std::filesystem::remove(cdi_path, ec);

            auto r = run(quote(mkdcdisc) + " --no-banner" + args +
                          " -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code == 2);
            CHECK_RUN(r, says(r.output, "Try 'mkdcdisc --help'"));
            CHECK_RUN(r, !std::filesystem::exists(cdi_path));
        }
    }

    /* A conflict between two options is settled before any of the work is
     * done, not partway through it. This one used to be left to the CD
     * builder, which only reaches it once the executable has been loaded and
     * scrambled -- so it announced two steps, did their work, and only then
     * refused, as a build failure rather than as a usage error. */
    {
        auto cdi_path = tmp_dir / "late-conflict.cdi";
        auto r = run(quote(mkdcdisc) + " --no-banner -L data-data --cdda-track nope.wav -b " +
                      quote(fixture) + " -o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code == 2);
        CHECK_RUN(r, says(r.output,
            "Error: -c/--cdda-track cannot be combined with -L/--disc-layout data-data."));

        /* Nothing was attempted: no step announced itself, and the message is
         * not followed by a second one blaming the build. */
        CHECK_RUN(r, r.output.find("Done.") == std::string::npos);
        CHECK_RUN(r, r.output.find("unable to build the disc image") == std::string::npos);
    }

    /* Nothing already on disc is written over unless --allow-overwrite says it
     * may -- which is what mkdcdisc did unconditionally, and in silence, up to
     * this check existing.
     *
     * What counts is every file the run would write, not only the one -o names:
     * an .mds carries its bulk in a sibling .mdf, -I/--dump-iso adds an .iso,
     * and a .gdi's track files carry no part of the descriptor's name at all. */
    {
        auto dir = tmp_dir / "overwrite";
        std::filesystem::create_directories(dir);

        auto build = [&](const std::filesystem::path& out, const std::string& extra = "") {
            return run(quote(mkdcdisc) + " --no-banner -b " + quote(fixture) + " -N -o " +
                        quote(out.string()) + " " + extra);
        };

        /* The same image asked for twice. The second run is a file error rather
         * than a usage one -- the invocation was right -- so it says so without
         * pointing at an option list that has nothing to add. */
        auto cdi_path = dir / "twice.cdi";

        auto first = build(cdi_path);
        CHECK_RUN(first, first.exit_code == 0);

        auto refused = build(cdi_path);
        CHECK_RUN(refused, refused.exit_code == 4 && says(refused.output,
            "Error: the output file already exists: " + cdi_path.string() +
            ". Nothing has been written; use --allow-overwrite to write over it, "
            "or -o/--output to build somewhere else."));
        CHECK_RUN(refused, refused.output.find("Try 'mkdcdisc --help'") == std::string::npos);

        /* And it still says why at -q, like every other refusal: silence is
         * about the progress of a run that works. It names itself there, too:
         * -q suppresses the banner, so nothing else in that output says which
         * program is talking (see term::Diagnostic). */
        auto quiet = build(cdi_path, "-q");
        CHECK_RUN(quiet, quiet.exit_code == 4 && says(quiet.output,
            "mkdcdisc: error: the output file already exists: " + cdi_path.string()));
        CHECK_RUN(quiet, !says(quiet.output, "Error: the output file"));

        auto allowed = build(cdi_path, "--allow-overwrite");
        CHECK_RUN(allowed, allowed.exit_code == 0 && says(allowed.output,
            "Allow overwriting: writing over " + cdi_path.string()));

        /* The .mdf half of an Alcohol pair, on its own: it is half the image
         * and the half whose name -o never mentions. */
        auto mds_path = dir / "pair.mds";
        auto mdf_path = dir / "pair.mdf";

        auto pair = build(mds_path);
        CHECK_RUN(pair, pair.exit_code == 0);
        std::filesystem::remove(mds_path);

        auto mdf_left = build(mds_path);
        CHECK_RUN(mdf_left, mdf_left.exit_code == 4 && says(mdf_left.output,
            "Error: the output file already exists: " + mdf_path.string()));

        /* Likewise the .iso of -I/--dump-iso, which is written beside the image
         * rather than being part of it. */
        auto dump_path = dir / "dumped.cdi";

        auto dumped = build(dump_path, "-I");
        CHECK_RUN(dumped, dumped.exit_code == 0);
        std::filesystem::remove(dump_path);

        auto iso_left = build(dump_path, "-I");
        CHECK_RUN(iso_left, iso_left.exit_code == 4 && says(iso_left.output,
            "Error: the output file already exists: " +
            std::filesystem::path(dump_path).replace_extension("iso").string()));

        /* A .gdi set is the case the check has to find on its own: how many
         * track files a build writes is not known until the disc has been laid
         * out, and none of them is named after the descriptor -- so a build
         * under a new name into a directory that already holds a set used to
         * destroy it while reporting only what it had written itself. */
        auto gdi_dir = dir / "gd";
        std::filesystem::create_directories(gdi_dir);

        auto gdi_build = [&](const std::filesystem::path& out, const std::string& extra = "") {
            return run(quote(mkdcdisc) + " --no-banner -b " + quote(fixture) +
                        " -F gdi --gdi-truncate -o " + quote(out.string()) + " " + extra);
        };

        auto gdi_first = gdi_build(gdi_dir / "disc.gdi");
        CHECK_RUN(gdi_first, gdi_first.exit_code == 0);

        std::filesystem::remove(gdi_dir / "disc.gdi");

        auto under_new_name = gdi_build(gdi_dir / "other.gdi");
        CHECK_RUN(under_new_name, under_new_name.exit_code == 4 && says(under_new_name.output,
            "Error: the output files already exist: " + (gdi_dir / "track01.bin").string() + ", " +
            (gdi_dir / "track02.raw").string() + ", " + (gdi_dir / "track03.bin").string() + "."));

        auto gdi_allowed = gdi_build(gdi_dir / "other.gdi", "--allow-overwrite");
        CHECK_RUN(gdi_allowed, gdi_allowed.exit_code == 0);
    }

    /* A file named by an option that is missing or unreadable is not a usage
     * error -- the option was right, the file is not -- so it says so without
     * pointing at an option list that has nothing to add, and exits with the
     * file-error code rather than the usage one. Two of these used to exit 2
     * while every other missing file exited 4.
     *
     * The whole scale is pinned here rather than each code where it happens
     * to be produced: a wrapper script can only tell these apart by the
     * number, so which number it is is the contract, not an implementation
     * detail (see the table at the top of main.cpp). */
    {
        auto missing = quote((tmp_dir / "no-such-file").string());
        auto out = " -o " + quote((tmp_dir / "exit-code.cdi").string());

        struct Invocation {
            std::string args;
            int expected;
        };

        const std::vector<Invocation> invocations = {
            /* 2: refused over the way it was invoked. */
            {" -x", 2},
            {" --color bogus -b " + quote(fixture) + out, 2},
            {" -v abc -b " + quote(fixture) + out, 2},
            {" -F gdi -t x.iso -o " + quote((tmp_dir / "e.gdi").string()), 2},
            {" -b " + quote(fixture), 2},
            {out, 2},

            /* 4: a file it was told to use is not there. */
            {" -b " + quote(fixture) + " --copyright " + missing + out, 4},
            {" -e " + missing + " -N" + out, 4},
            {" -b " + missing + " -N" + out, 4},
            {" -t " + missing + out, 4},
            {" -F gdi --gdi-lda-file " + missing + " -b " + quote(fixture) +
                " -o " + quote((tmp_dir / "e.gdi").string()), 4},
        };

        for(const auto& invocation: invocations) {
            auto r = run(quote(mkdcdisc) + " --no-banner" + invocation.args);
            CHECK_RUN(r, r.exit_code == invocation.expected);

            /* And the pointer at --help follows the split exactly. */
            bool pointed = r.output.find("Try 'mkdcdisc --help'") != std::string::npos;
            CHECK_RUN(r, pointed == (invocation.expected == 2));
        }
    }

    /* A refusal still says why at -q: silence is about the progress of a run
     * that works, not about the reason one did not. */
    {
        auto r = run(quote(mkdcdisc) + " -q -F gdi -t x.iso -o " +
                      quote((tmp_dir / "quiet-refusal.gdi").string()));
        CHECK_RUN(r, r.exit_code == 2);
        CHECK_RUN(r, says(r.output,
            "mkdcdisc: error: option -t/--external-data-track cannot be used with -F/--format gdi."));
    }

    /* ... while --help itself still answers with the whole thing, and says so
     * successfully rather than as a refusal. */
    {
        auto r = run(quote(mkdcdisc) + " --help --no-banner");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK_RUN(r, r.output.find("General:") != std::string::npos);
        CHECK_RUN(r, r.output.find("Try 'mkdcdisc --help'") == std::string::npos);
    }

    /* A bare invocation is not a typo but someone who does not know what this
     * is yet, so it keeps the description and the usage line. */
    {
        auto r = run(quote(mkdcdisc));
        CHECK_RUN(r, r.exit_code == 2);
        CHECK_RUN(r, r.output.find("Usage: mkdcdisc") != std::string::npos);
        CHECK_RUN(r, r.output.find("Try 'mkdcdisc --help'") != std::string::npos);
        CHECK_RUN(r, r.output.find("General:") == std::string::npos);
    }

    /* Colored output. Everything run() runs is talking to a pipe, so this is
     * the redirected case throughout: what --color auto must never do is what
     * is checked first, since a stray escape sequence in a log file or in
     * something's parsed input is the failure that actually costs anyone
     * anything. */
    {
        auto r = run(quote(mkdcdisc) + " --help");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(r.output.find('\033') == std::string::npos);
    }

    /* --color always is the one that overrides the redirection, and the only
     * way this suite can see a sequence at all. */
    {
        auto r = run(quote(mkdcdisc) + " --color always --help");
        CHECK_RUN(r, r.exit_code == 0);
        /* The bold group headings, and a reset closing each of them. */
        CHECK(r.output.find("\033[1mGeneral:\033[0m") != std::string::npos);
    }

    {
        auto r = run(quote(mkdcdisc) + " --color never --help");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(r.output.find('\033') == std::string::npos);
    }

    /* --disable-color is only a spelling of --color never... */
    {
        auto r = run(quote(mkdcdisc) + " --disable-color --help");
        CHECK_RUN(r, r.exit_code == 0);
        CHECK(r.output.find('\033') == std::string::npos);
    }

    /* ... and --color still wins over it whichever order they are given in,
     * which is also what settles the colors of a message printed before the
     * options have finished parsing (see term::configure()). */
    {
        auto r = run(quote(mkdcdisc) + " --color always --disable-color --bogus-option");
        CHECK_RUN(r, r.exit_code != 0);
        CHECK(r.output.find('\033') != std::string::npos);

        r = run(quote(mkdcdisc) + " --disable-color --color always --bogus-option");
        CHECK_RUN(r, r.exit_code != 0);
        CHECK(r.output.find('\033') != std::string::npos);
    }

    {
        auto r = run(quote(mkdcdisc) + " --color bogus --no-banner");
        CHECK_RUN(r, r.exit_code == 2);
        CHECK(r.output.find("invalid --color value: bogus") != std::string::npos);
        /* Rejected, so nothing it says is colored either. */
        CHECK(r.output.find('\033') == std::string::npos);
    }

    /* Verbosity levels. What each one is for is a contract (see
     * src/logging.hpp), not a suggestion, so each level is checked for what it
     * must show and for what it must not.
     *
     * -N throughout: these builds are only read for their log, and padding the
     * data track to the full ~650MB CD size for that is pointless disk churn.
     */
    {
        auto dir_src = tmp_dir / "verbosity-src";
        std::filesystem::create_directories(dir_src);
        std::ofstream(dir_src / "LOGGED.TXT", std::ios::binary) << "content";

        auto base = quote(mkdcdisc) + " -b " + quote(fixture) +
                    " -D " + quote(dir_src.string()) + " -N -o ";

        /* -q means nothing at all, not less: no banner, no steps, no detail.
         * Both -q and -v 0 -- they are the same level, and the banner used to
         * be silenced only by the former. */
        int silent_run = 0;
        for(const char* silent: {" -q", " -v 0"}) {
            /* A file of its own per run: the same one twice would make the
             * second a refusal to write over the first. */
            auto cdi_path = tmp_dir / ("verbosity-silent-" + std::to_string(++silent_run) + ".cdi");
            auto r = run(base + quote(cdi_path.string()) + silent);
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(std::filesystem::exists(cdi_path));
            CHECK(r.output.empty());
        }

        /* The default level is a checklist of the steps, in the order they
         * happen. Each is checked by name: a step that silently stopped
         * announcing itself is exactly the regression this guards against. */
        {
            auto cdi_path = tmp_dir / "verbosity-default.cdi";
            auto r = run(base + quote(cdi_path.string()) + " --no-banner");
            CHECK_RUN(r, r.exit_code == 0);

            /* -b supplies an unscrambled binary and this is a CDI, so the
             * scrambler does run and the step says so -- the one step whose
             * name depends on what it is actually about to do. */
            static const std::vector<std::string> expected_steps = {
                "Loading main executable...",
                "Scrambling 1ST_READ.BIN...",
                "Gathering input files...",
                "Building bootstrap...",
                "Generating data track...",
                "Checking boot prerequisites...",
                "Writing disc image...",
            };

            for(const auto& step: expected_steps) {
                CHECK_RUN(r, r.output.find(step) != std::string::npos);
            }

            /* Every one of them reached its end rather than being abandoned
             * half-drawn, and the run named what it wrote. */
            CHECK_RUN(r, count_occurrences(r.output, "Done.") == expected_steps.size());
            CHECK(r.output.find("Wrote ") != std::string::npos);

            /* ... and nothing from the levels above it. */
            CHECK(r.output.find("LOGGED.TXT") == std::string::npos);
            CHECK(r.output.find("Data track is ") == std::string::npos);
        }

        /* -v 2 adds the things handled inside a step, indented under it. */
        {
            auto cdi_path = tmp_dir / "verbosity-2.cdi";
            auto r = run(base + quote(cdi_path.string()) + " --no-banner -v 2");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(r.output.find("Gathering input files...") != std::string::npos);
            CHECK_RUN(r, r.output.find("  Adding \"LOGGED.TXT\"") != std::string::npos);
            /* Still not the internals. */
            CHECK(r.output.find("Data track is ") == std::string::npos);
        }

        /* -v 3 adds the internals -- and prints its byte counts in decimal.
         * They used to come out in hex without saying so, because the ELF
         * parser left std::cout in std::hex and every number printed after it
         * inherited that. A data track of a -N build of this fixture is a few
         * hundred KB; read as hex the same digits would be a wildly different
         * number, so the check is that what was printed parses back to a
         * plausible size rather than that it merely contains digits. */
        {
            auto cdi_path = tmp_dir / "verbosity-3.cdi";
            auto r = run(base + quote(cdi_path.string()) + " --no-banner -v 3");
            CHECK_RUN(r, r.exit_code == 0);

            auto marker = r.output.find("Data track is ");
            CHECK_RUN(r, marker != std::string::npos);

            if(marker != std::string::npos) {
                unsigned long long reported = std::strtoull(
                    r.output.c_str() + marker + std::strlen("Data track is "), nullptr, 10);

                /* The .cdi on disc wraps this track in session/track framing,
                 * so it is comfortably larger -- but only by framing, not by
                 * the factor a hex-vs-decimal misread would introduce. */
                std::error_code size_ec;
                auto cdi_size = std::filesystem::file_size(cdi_path, size_ec);
                CHECK_RUN(r, reported > 0 && !size_ec && reported <= cdi_size);
            }
        }

        /* A step announces itself before it runs, so a step that then fails
         * has already put its label on a line still waiting for "Done.". The
         * diagnostic must not be appended to it: stderr closes the step's
         * line first, wherever in the program the failure came from (see
         * logging::install_diagnostic_guard()). */
        {
            auto missing = tmp_dir / "not-here.elf";
            auto cdi_path = tmp_dir / "verbosity-error.cdi";
            auto r = run(quote(mkdcdisc) + " -e " + quote(missing.string()) +
                          " -N --no-banner -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code != 0);

            /* The whole diagnostic, prefix included: it is the "Error: " that
             * has to begin the line, since that is what the step's label
             * would otherwise be sitting in front of. */
            auto message = r.output.find("Error: ELF file does not exist");
            CHECK_RUN(r, message != std::string::npos);

            if(message != std::string::npos) {
                auto line_start = r.output.rfind('\n', message);
                CHECK_RUN(r, line_start != std::string::npos && line_start + 1 == message);
            }

            CHECK_RUN(r, r.output.find("Loading main executable...") != std::string::npos);
        }
    }

    /* The -v 3 build plan: what the run was asked for, printed before any of
     * it happens. The point of the block is that it agrees with the build that
     * follows it, so the checks below are on the values that are decided
     * somewhere else and merely reported here -- an option's default, a
     * template's own field, the name the closing "Wrote" will use. A plan that
     * grew a second opinion about any of them is the regression to catch. */
    {
        auto plan_src = tmp_dir / "plan-src";
        std::filesystem::create_directories(plan_src);
        std::ofstream(plan_src / "PLANNED.TXT", std::ios::binary) << "content";

        {
            auto mds_path = tmp_dir / "plan.mds";
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                          " -D " + quote(plan_src.string()) +
                          " -n " + quote("My Game") + " -N --no-banner -v 3 -o " +
                          quote(mds_path.string()));
            CHECK_RUN(r, r.exit_code == 0);

            /* The plan comes first: it describes a build that has not started,
             * so anything the build itself prints must come after it. */
            auto plan = r.output.find("Build plan:");
            CHECK_RUN(r, plan != std::string::npos);
            CHECK_RUN(r, plan < r.output.find("Loading main executable..."));

            static const std::vector<std::string> expected_fields = {
                "Disc type               : MIL-CD",
                "Image format            : Alcohol 120% (MDS+MDF)",
                "Image layout            : Audio/Data",
                "Boot filename           : 1ST_READ.BIN",
                /* -n/--title, and the volume label defaulting to it. */
                "Software title          : My Game",
                "Volume label            : MY_GAME",
                /* Read out of the bundled MIL-CD template, which is the only
                 * thing that decides them when no option does. */
                "Product version         : V1.000",
                "Peripherals             : E799F10",
                /* -N, and the one directory -D contributed. */
                "Disc contents           : 1 directory",
                "Data track padding      : disabled",
            };

            for(const auto& expected: expected_fields) {
                CHECK_RUN(r, r.output.find(expected) != std::string::npos);
            }

            /* An MDS run writes two files, and the plan names the pair the
             * same way the closing line does. */
            auto pair = mds_path.string().substr(0, mds_path.string().size() - 4);
            CHECK_RUN(r, count_occurrences(r.output, pair + ".mds + " + pair + ".mdf") == 2);

            /* Not at a level below it: the plan is one of the internals. */
            int quieter_run = 0;
            for(const char* quieter: {" -v 2", ""}) {
                /* One pair of files per run, for the same reason. */
                auto quiet_path = tmp_dir /
                    ("plan-quiet-" + std::to_string(++quieter_run) + ".mds");
                auto q = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                              " -N --no-banner -o " + quote(quiet_path.string()) + quieter);
                CHECK_RUN(q, q.exit_code == 0);
                CHECK_RUN(q, q.output.find("Build plan:") == std::string::npos);
            }
        }

        /* External-ISO mode has no filesystem and no IP.BIN of mkdcdisc's own,
         * so the plan reports the ISO it was handed instead of metadata it
         * does not decide -- every one of those options is refused there. */
        {
            auto iso_path = tmp_dir / "plan-external.iso";
            auto seed = run(quote(mkdcdisc) + " -b " + quote(fixture) + " -N -q -I -o " +
                            quote((tmp_dir / "plan-external.cdi").string()));
            CHECK_RUN(seed, seed.exit_code == 0);
            CHECK(std::filesystem::exists(iso_path));

            auto r = run(quote(mkdcdisc) + " -t " + quote(iso_path.string()) +
                          " --no-banner -v 3 -o " +
                          quote((tmp_dir / "plan-wrapped.cdi").string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, r.output.find("Data track              : " + iso_path.string()) != std::string::npos);
            CHECK_RUN(r, r.output.find("Boot filename") == std::string::npos);
            CHECK_RUN(r, r.output.find("Software title") == std::string::npos);
        }
    }

    /* A sort file line that isn't a path followed by a weight is skipped, and
     * says so. The build succeeds either way -- what it produces is a disc
     * ordered differently from what was asked for, which nothing about the
     * image itself would ever reveal, so the warning is the only thing
     * standing between a typo and a silently slower disc. */
    {
        auto sort_src = tmp_dir / "sort-warn-src";
        std::filesystem::create_directories(sort_src);
        std::ofstream(sort_src / "A.TXT", std::ios::binary) << std::string(100, 'A');

        /* Line 3 is the trap worth naming: it looks perfectly correct, but a
         * path with a space in it parses as a path plus a non-numeric
         * weight. Line 4 is an outright bad weight; lines 1, 2 and 5 are
         * valid and must not be complained about. */
        auto sort_file = tmp_dir / "sort-warn.txt";
        std::ofstream(sort_file, std::ios::binary)
            << "# a comment\n"
               "/A.TXT 1000\n"
               "/MY FILE.TXT 500\n"
               "/A.TXT abc\n"
               "/A.TXT -1000\n";

        auto base = quote(mkdcdisc) + " -b " + quote(fixture) +
                    " -D " + quote(sort_src.string()) +
                    " -S " + quote(sort_file.string()) + " --no-banner -o ";

        {
            auto cdi_path = tmp_dir / "sort-warn.cdi";
            auto r = run(base + quote(cdi_path.string()) + " -N");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(std::filesystem::exists(cdi_path));

            CHECK_RUN(r, r.output.find("ignoring line 3 of the sort file") != std::string::npos);
            CHECK_RUN(r, r.output.find("ignoring line 4 of the sort file") != std::string::npos);
            /* The valid lines, and the comment, stayed quiet. */
            CHECK_RUN(r, count_occurrences(r.output, "ignoring line ") == 2);
        }

        /* -q means nothing at all, warnings included. */
        {
            auto cdi_path = tmp_dir / "sort-warn-quiet.cdi";
            auto r = run(base + quote(cdi_path.string()) + " -N -q");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(r.output.empty());
        }

        /* A GD-ROM builds its high-density filesystem twice -- once to
         * measure it, once for real -- so the sort file is parsed twice. The
         * user's typo is still only worth one warning. */
        {
            auto gdi_dir = tmp_dir / "sort-warn-gdi";
            std::filesystem::create_directories(gdi_dir);

            auto gdi_path = gdi_dir / "sort-warn.gdi";
            auto r = run(base + quote(gdi_path.string()) + " --gdi-truncate");
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, count_occurrences(r.output, "ignoring line 3 of the sort file") == 1);
        }

        /* A sort file that cannot be opened at all is the same class of
         * silence, and -S (unlike --gdi-lda-sort-file) is not checked for
         * existence up front. */
        {
            auto cdi_path = tmp_dir / "sort-missing.cdi";
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                          " -S " + quote((tmp_dir / "no-such-sort.txt").string()) +
                          " -N --no-banner -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, r.output.find("could not open the sort file") != std::string::npos);
        }
    }

    /* An entry that parses perfectly but names nothing on the disc. This is
     * the other half of the same silence: the weights are applied by walking
     * the disc and asking the sort file, so an entry the disc never asks about
     * is not so much ignored as never consulted -- and the image it produces
     * looks exactly like one built without that line.
     *
     * Almost always a path written against the source tree rather than the
     * volume: -D drops the directory name it was given, so a file passed as
     * data/A.TXT lands at /A.TXT, not /data/A.TXT. */
    {
        auto orphan_src = tmp_dir / "orphan-src";
        std::filesystem::create_directories(orphan_src);
        std::ofstream(orphan_src / "A.TXT", std::ios::binary) << std::string(100, 'A');

        auto base = quote(mkdcdisc) + " -b " + quote(fixture) +
                    " -D " + quote(orphan_src.string()) + " -N --no-banner ";

        /* One orphan among two entries: few enough to name outright. The
         * matching entry must not be reported, or the check below would pass
         * on a build that complained about everything. */
        {
            auto sort_file = tmp_dir / "orphan-few.txt";
            std::ofstream(sort_file, std::ios::binary)
                << "/A.TXT 100\n"
                   "/orphan-src/A.TXT 200\n";

            auto cdi_path = tmp_dir / "orphan-few.cdi";
            auto r = run(base + "-S " + quote(sort_file.string()) +
                          " -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK(std::filesystem::exists(cdi_path));

            CHECK_RUN(r, says(r.output, "/orphan-src/A.TXT, which is not on the disc"));
            CHECK_RUN(r, count_occurrences(flatten(r.output), "is not on the disc") == 1);
            /* The note explaining -d/-D is what makes it actionable. */
            CHECK_RUN(r, says(r.output, "-D does not"));
        }

        /* A whole sort file written against the wrong prefix orphans every
         * line at once. Six of them is one line saying so, not six saying it
         * separately -- and the count has to be the real one. */
        {
            auto sort_file = tmp_dir / "orphan-many.txt";
            {
                std::ofstream out(sort_file, std::ios::binary);
                out << "/A.TXT 1\n";
                for(int i = 0; i < 6; ++i) {
                    out << "/orphan-src/F" << i << ".TXT " << (i + 1) << "\n";
                }
            }

            auto cdi_path = tmp_dir / "orphan-many.cdi";
            auto r = run(base + "-S " + quote(sort_file.string()) +
                          " -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, says(r.output, "6 entries of the sort file"));
            CHECK_RUN(r, !says(r.output, "is not on the disc"));

            /* -v 2 asks to be told about each thing handled, so it overrides
             * the summary. */
            auto cdi_v2 = tmp_dir / "orphan-many-v2.cdi";
            auto rv = run(base + "-S " + quote(sort_file.string()) +
                           " -v 2 -o " + quote(cdi_v2.string()));
            CHECK_RUN(rv, rv.exit_code == 0);
            CHECK_RUN(rv, count_occurrences(flatten(rv.output), "is not on the disc") == 6);
        }

        /* A sort file whose every entry lands says nothing at all -- the check
         * that keeps all of the above from being noise on correct input. */
        {
            auto sort_file = tmp_dir / "orphan-none.txt";
            std::ofstream(sort_file, std::ios::binary) << "/A.TXT 100\n";

            auto cdi_path = tmp_dir / "orphan-none.cdi";
            auto r = run(base + "-S " + quote(sort_file.string()) +
                          " -o " + quote(cdi_path.string()));
            CHECK_RUN(r, r.exit_code == 0);
            CHECK_RUN(r, !says(r.output, "is not on the disc"));
            CHECK_RUN(r, !says(r.output, "entries of the sort file"));
        }
    }

    /* What libisofs is asked for, checked on its own output rather than
     * through the writers that wrap it. These three run against whatever
     * libisofs the build linked -- the vendored copy on MinGW-w64, the
     * system one everywhere else -- so they say nothing about byte layout,
     * which legitimately differs between versions. They say what must hold of
     * any of them, and each has a distinct way of going wrong in an update:
     *
     *   - the 32K bootstrap must come back untouched, or the disc will not
     *     boot however correct its filesystem is;
     *   - a file's directory record must point at that file's bytes, which no
     *     other test reads back;
     *   - Joliet must be on for MIL-CD and off for GD-ROM, which is one
     *     iso_write_opts_set_joliet() call apart and invisible otherwise.
     */
    {
        auto iso_src = tmp_dir / "iso-src";
        std::filesystem::create_directories(iso_src);

        /* Contents chosen to be recognisable and of awkward lengths: one
         * shorter than a sector, one spanning three of them, so a file read
         * back at the wrong extent or truncated to a sector boundary cannot
         * match by accident. */
        const std::string small_content = "mkdcdisc iso content check";
        std::string large_content;
        for(int i = 0; large_content.size() < 5000; ++i) {
            large_content += "block " + std::to_string(i) + " of the large file; ";
        }

        std::ofstream(iso_src / "SMALL.TXT", std::ios::binary) << small_content;
        std::ofstream(iso_src / "LARGE.TXT", std::ios::binary) << large_content;

        /* A bootstrap of known bytes rather than a real IP.BIN: -p/--bootstrap
         * is used verbatim (nothing on the MIL-CD path rewrites it), so
         * whatever is put here is exactly what the system area must contain
         * afterwards. Arbitrary content proves libisofs copied it, where a
         * real template could match for the wrong reason. The one field that
         * has to be meaningful is the boot file name at 0x60, which
         * boot_filename() reads and warns about when it is unusable. */
        std::vector<uint8_t> bootstrap(iso_read::SYSTEM_AREA_SIZE);
        for(size_t i = 0; i < bootstrap.size(); ++i) {
            bootstrap[i] = (uint8_t) ((i * 37 + 11) & 0xFF);
        }

        const char* boot_name = "1ST_READ.BIN    ";
        std::memcpy(bootstrap.data() + 0x60, boot_name, 16);

        auto bootstrap_path = tmp_dir / "iso-bootstrap.bin";
        {
            std::ofstream out(bootstrap_path, std::ios::binary);
            out.write((const char*) bootstrap.data(), (std::streamsize) bootstrap.size());
        }

        auto cdi_path = tmp_dir / "iso-checks.cdi";
        auto iso_path = tmp_dir / "iso-checks.iso";

        /* -V rather than letting the label fall back to the IP.BIN title,
         * which here is 128 bytes of the pattern above.
         *
         * --disable-bootstrap-checks because the bootstrap above is deliberately
         * not a boot header: an arbitrary, position-dependent byte pattern is
         * what makes a single moved byte visible, which is the whole point of
         * the comparison below, and it is also everything the boot prerequisite
         * checks exist to reject. What is under test here is that libisofs
         * hands the system area back exactly as it got it -- not whether the
         * disc would boot, which it plainly would not. */
        auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                      " -D " + quote(iso_src.string()) +
                      " -p " + quote(bootstrap_path.string()) +
                      " -V ISOCHECK -N -I --no-banner -q --disable-bootstrap-checks" +
                      " -o " + quote(cdi_path.string()));
        CHECK_RUN(r, r.exit_code == 0);
        CHECK_RUN(r, std::filesystem::exists(iso_path));

        std::vector<uint8_t> iso = iso_read::read_whole_file(iso_path);
        CHECK(iso.size() > iso_read::SYSTEM_AREA_SIZE);

        if(iso.size() > iso_read::SYSTEM_AREA_SIZE) {
            /* 1. The system area is handed to libisofs and must come back as
             * it went in. A single byte moved here is a disc the BIOS
             * refuses, and nothing else in this suite would notice. */
            CHECK(std::memcmp(iso.data(), bootstrap.data(), iso_read::SYSTEM_AREA_SIZE) == 0);

            /* 2. A directory record is only as good as what it points at.
             * The extents themselves are checked elsewhere (see
             * gdi_file_extent); what is read back here is the data. */
            CHECK(iso_read::file_bytes(iso, "/SMALL.TXT") == small_content);
            CHECK(iso_read::file_bytes(iso, "/LARGE.TXT") == large_content);

            /* A file that was never added must not be found, or the two
             * checks above would pass against a reader that matches
             * anything. */
            CHECK(!iso_read::find(iso, "/ABSENT.TXT").has_value());

            /* 3. The descriptor set: a PVD, the Joliet SVD the MIL-CD path
             * asks for, and the terminator. The escape sequence is what marks
             * an SVD as Joliet -- UCS-2 level 1, 2 or 3 (ECMA-119 / the Joliet
             * specification), which is "%/@", "%/C" or "%/E". */
            auto descriptors = iso_read::volume_descriptors(iso);
            CHECK(descriptors.size() >= 2);

            bool has_pvd = false;
            bool has_terminator = false;
            std::string joliet_escapes;

            for(const auto& descriptor: descriptors) {
                if(descriptor.type == 1) has_pvd = true;
                if(descriptor.type == 255) has_terminator = true;
                if(descriptor.type == 2) joliet_escapes = descriptor.escape_sequences;
            }

            CHECK(has_pvd);
            CHECK(has_terminator);
            CHECK(joliet_escapes == "%/@" || joliet_escapes == "%/C" || joliet_escapes == "%/E");
        }

        /* The other half of the Joliet check: build_gd() turns it off, to
         * match commercial GD-ROM images, so the high-density volume must
         * carry no supplementary descriptor at all. Read out of track03's
         * user data, which is where that volume begins. */
        {
            auto gdi_dir = tmp_dir / "iso-checks-gdi";
            std::filesystem::create_directories(gdi_dir);

            auto gdi_path = gdi_dir / "gdi.gdi";
            auto g = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                          " -D " + quote(iso_src.string()) +
                          " -F gdi --gdi-truncate --gdi-sector-size 2048"
                          " --no-banner -q -o " + quote(gdi_path.string()));
            CHECK_RUN(g, g.exit_code == 0);

            /* 2048-byte sectors, so the track file is the volume's own bytes
             * with no raw-sector framing, and its descriptor set starts at
             * file sector 16 like any other volume's. (The addresses recorded
             * inside are absolute, counting from LBA 45000, but nothing here
             * follows one.) */
            auto track03 = gdi_dir / "track03.iso";
            CHECK(std::filesystem::exists(track03));

            std::vector<uint8_t> track = iso_read::read_whole_file(track03);
            if(!track.empty()) {
                auto descriptors = iso_read::volume_descriptors(track);
                CHECK(!descriptors.empty());

                bool has_supplementary = false;
                for(const auto& descriptor: descriptors) {
                    if(descriptor.type == 2) has_supplementary = true;
                }

                CHECK(!has_supplementary);
            }
        }
    }

    /* SOURCE_DATE_EPOCH: the same inputs must produce the same bytes, once the
     * Rock Ridge PX file serial numbers are masked out. Those are the one
     * field that does not reproduce -- 8 bytes per node of metadata no
     * Dreamcast reads, permuted between two builds on any platform whose inode
     * numbers are not handed out in creation order. See
     * iso_read::mask_px_serials() for the mechanism and for why they are
     * masked here rather than dropped from the disc. */
    {
        auto src = tmp_dir / "epoch-src";
        std::filesystem::create_directories(src);
        std::ofstream(src / "AAAA.TXT", std::ios::binary) << "first";
        std::ofstream(src / "ZZZZ.TXT", std::ios::binary) << "second";

        auto build = [&](const std::string& name) {
            auto cdi = tmp_dir / (name + ".cdi");
            auto r = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                          " -D " + quote(src.string()) +
                          " -V EPOCH -N -I --no-banner -q -o " + quote(cdi.string()));
            CHECK_RUN(r, r.exit_code == 0);
            return iso_read::read_whole_file(std::filesystem::path(cdi).replace_extension("iso"));
        };

        set_env("SOURCE_DATE_EPOCH", "946684800");  /* 2000-01-01T00:00:00Z */

        auto first = build("epoch-1");

        /* The two builds have to straddle a second boundary, or a run that
         * ignored SOURCE_DATE_EPOCH entirely would still produce identical
         * images and this check would pass for the wrong reason. */
        std::this_thread::sleep_for(std::chrono::milliseconds(1100));

        auto second = build("epoch-2");

        CHECK(!first.empty());
        CHECK(first.size() == second.size());

        /* A differing count is not a permutation of the serial numbers: it is
         * libisofs having started or stopped writing the field, which the
         * comparison below would hide. */
        size_t masked = iso_read::mask_px_serials(first);
        CHECK(masked > 0);
        CHECK(iso_read::mask_px_serials(second) == masked);

        CHECK(first == second);

        /* And it reaches the boot header too: with no -r/--release, the date
         * comes from the epoch rather than from today, read in UTC. The
         * release date field sits at offset 0x50 of the IP.BIN, which is what
         * the system area at the front of the .iso carries. */
        if(first.size() > iso_read::SYSTEM_AREA_SIZE) {
            std::string release((const char*) first.data() + 0x50, 8);
            CHECK(release == "20000101");
        }

        /* A value that is not a number of seconds is refused without failing
         * the build: an environment variable the user did not ask for should
         * not stop a disc from being written. */
        set_env("SOURCE_DATE_EPOCH", "yesterday");

        auto bad_cdi = tmp_dir / "epoch-bad.cdi";
        auto bad = run(quote(mkdcdisc) + " -b " + quote(fixture) +
                        " -D " + quote(src.string()) +
                        " -V EPOCH -N --no-banner -o " + quote(bad_cdi.string()));
        CHECK_RUN(bad, bad.exit_code == 0);
        CHECK_RUN(bad, says(bad.output, "SOURCE_DATE_EPOCH is not a whole number of seconds"));

        unset_env("SOURCE_DATE_EPOCH");
    }

    std::error_code ec;
    std::filesystem::remove_all(tmp_dir, ec);

    if(g_failures) {
        std::cerr << g_failures << " check(s) failed" << std::endl;
        return 1;
    }
    return 0;
}
